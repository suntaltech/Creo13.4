"""Offline Stage1 pairing of existing Extract-R11.ps1 JSONL; no ETL/Creo access.

Source order is primary. PID/generation scopes path anchors. Cross-context IRP
references are retained as observations, never as successful byte evidence.
"""
import argparse
from bisect import bisect_right
from collections import Counter, defaultdict
import calendar
from datetime import datetime, timedelta, timezone
import hashlib
import heapq
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def integer(value):
    if value is None or isinstance(value, bool):
        return None
    try:
        text = str(value)
        return int(text, 16 if text.lower().startswith("0x") else 10)
    except ValueError:
        return None


def ptr(value):
    n = integer(value)
    if n is not None and -(1 << 63) <= n < 0:
        n += 1 << 64
    return n if n is not None and 0 < n < (1 << 64) else None


def status_code(value):
    n = integer(value)
    if n is not None and -(1 << 31) <= n < 0:
        n += 1 << 32
    return n if n is not None and 0 <= n < (1 << 32) else None


def pid(event):
    return integer(event.get("execution_pid"))


def time_ns(text):
    m = re.fullmatch(r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.(\d{1,9}))?(Z|[+-]\d{2}:\d{2})", text)
    if not m:
        raise ValueError("timestamp without explicit reviewed offset/precision: " + text)
    offset = m[3]
    minutes = 0 if offset == "Z" else (int(offset[1:3]) * 60 + int(offset[4:6])) * (1 if offset[0] == "+" else -1)
    dt = datetime.strptime(m[1], "%Y-%m-%dT%H:%M:%S") - timedelta(minutes=minutes)
    return calendar.timegm(dt.timetuple()) * 10**9 + int((m[2] or "").ljust(9, "0"))


def lines(path):
    previous = 0
    with Path(path).open(encoding="utf-8-sig") as f:
        for line in f:
            event = json.loads(line)
            sequence = integer(event.get("source_sequence"))
            if sequence is None or sequence <= previous:
                raise ValueError("missing/non-increasing source sequence: " + str(path))
            previous = sequence
            yield event


def merge_events(target, context):
    previous = 0
    for e in heapq.merge(lines(target), lines(context), key=lambda e: e["source_sequence"]):
        if e["source_sequence"] <= previous:
            raise ValueError("duplicate/overlapping source sequence across passes")
        previous = e["source_sequence"]
        yield e


def validate_layout(event, contract):
    """Recheck the extractor's array mapping, not just its self-reported gate."""
    fields = contract["positions"].get(str(event["event_id"]))
    if event.get("mapping") == "unresolved":
        return
    if fields is None:
        if event.get("mapping") != "named_event_xml_no_position_guess":
            raise ValueError("unknown layout requires named fields, never guessed positions")
        required = contract["named_fields"].get(str(event["event_id"]))
        if required is None or not set(required).issubset(event["data"]):
            raise ValueError("named payload lacks calibration contract fields")
        return
    raw = event.get("raw_properties", [])
    if len(raw) != len(fields) or set(event["data"]) != set(fields):
        raise ValueError("property count/names differ from contract")
    for field, item in zip(fields, raw):
        if event["data"][field] != item["value"]:
            raise ValueError("mapped field differs from raw property: " + field)


class Lifetimes:
    """Use named ProcessID in retained process payload; never header execution PID."""
    def __init__(self, path=None):
        self.boundaries = defaultdict(list)
        self.errors = []
        if path is None:
            return
        for e in lines(path):
            if str(e.get("event_id")) not in ("1", "2"):
                continue
            try:
                tree = ET.fromstring(e["raw_xml"])
                data = {n.get("Name"): n.text for n in tree.iter()
                        if n.tag.rsplit("}", 1)[-1] == "Data"}
                process_id = integer(data.get("ProcessID"))
                if process_id is None:
                    raise ValueError("no named ProcessID")
                self.boundaries[process_id].append((e["source_sequence"], str(e["event_id"])))
            except (ValueError, KeyError, ET.ParseError) as error:
                self.errors.append({"sequence": e["source_sequence"], "error": str(error)})

    def generation(self, process_id, sequence):
        rows = self.boundaries.get(process_id, [])
        index = bisect_right(rows, (sequence, "z")) - 1
        if index < 0 or rows[index][1] != "1":
            return None
        return rows[index][0]


class Matcher:
    def __init__(self, target_pid, emit=lambda *_: None, lifetimes=None,
                 enabled=True, status_names=None, window=None):
        self.target_pid = target_pid
        self.emit = emit
        self.life = lifetimes
        self.enabled = enabled
        self.status_names = status_names or {0: "STATUS_SUCCESS", 0xC0000011: "STATUS_END_OF_FILE"}
        self.window = window
        self.pending = defaultdict(list)
        self.irp_index = defaultdict(set)
        self.object_pending = defaultdict(set)
        self.anchors = {}
        self.generations = Counter()
        self.rows = {}
        self.counts = Counter()
        self.target_ids = Counter()
        self.offsets = Counter()

    def row(self, path):
        if path not in self.rows:
            self.rows[path] = {"path": path, "opens_observed": 0,
                "read_requests": 0, "write_requests": 0,
                "read_request_bytes": 0, "write_request_bytes": 0,
                "successful_read_bytes_candidate": 0, "successful_write_bytes_candidate": 0,
                "read_pairs": 0, "write_pairs": 0, "eof_read_pairs": 0,
                "non_read_write_pairs": 0, "pending_requests": 0}
        return self.rows[path]

    def on_event(self, event):
        data = event.get("data", {})
        event_id = str(event["event_id"])
        process_id = pid(event)
        sequence = event["source_sequence"]
        clock = time_ns(event["system_time"])
        self.offsets["Z" if event["system_time"].endswith("Z") else event["system_time"][-6:]] += 1
        in_window = self.window is None or self.window[0] <= clock <= self.window[1]
        if process_id == self.target_pid:
            self.target_ids[event_id] += 1
            if not in_window:
                self.counts["target_outside_window"] += 1
        if event.get("mapping") == "unresolved":
            self.counts["unmapped_events"] += 1
            self.emit("unresolved", {"reason": "unmapped_event_payload", "event": event})
            return
        generation = self.life.generation(process_id, sequence) if self.life else 0
        if generation is None:
            self.counts["unknown_process_lifetime"] += 1
        scope = (process_id, generation)
        fo, fk, irp = ptr(data.get("FileObject")), ptr(data.get("FileKey")), ptr(data.get("Irp"))
        anchor_key = (*scope, fo)
        # ID12 under the supplied Get-WinEvent layout has NO Irp. An open is
        # an observed path anchor, never a successful-create completion claim.
        if event_id == "12" and fo and data.get("FileName"):
            # Reusing a FileObject while an earlier generation still has pending
            # operations is not a proven continuation of the old path lifetime.
            for pending_key in self.object_pending.get(anchor_key, ()):
                for old in self.pending[pending_key]:
                    old["tainted"] = True
            if self.object_pending.get(anchor_key):
                self.emit("overlaps", {"reason": "file_object_reopened_with_pending_operations", "event": event})
                self.counts["file_object_reuse_with_pending"] += 1
            self.generations[anchor_key] += 1
            self.anchors[anchor_key] = {"path": data["FileName"], "file_key": fk,
                "generation": self.generations[anchor_key], "open_sequence": sequence}
            if process_id == self.target_pid:
                self.row(data["FileName"])["opens_observed"] += 1
        anchor = self.anchors.get(anchor_key) if fo else None
        if anchor and fk and anchor["file_key"] and fk != anchor["file_key"]:
            self.emit("missing-anchor", {"reason": "file_key_conflicts_with_open", "event": event, "anchor": anchor})
            anchor = None
        path = anchor["path"] if anchor else None
        if event_id in ("15", "16") and process_id == self.target_pid:
            if path:
                r = self.row(path)
                direction = "read" if event_id == "15" else "write"
                r[direction + "_requests"] += 1
                size = integer(data.get("IOSize"))
                if size is not None and size >= 0:
                    r[direction + "_request_bytes"] += size
            else:
                self.counts["requests_missing_anchor"] += 1
                self.emit("missing-anchor", {"reason": "no_explicit_same_pid_open_anchor", "event": event})
        if event_id == "14":
            self.anchors.pop(anchor_key, None)
        if event_id == "24":
            self.complete(event, scope, irp, in_window)
            return
        if not irp:
            # Name/reparse events are retained in raw stream; never fabricate an IRP.
            return
        key = (*scope, irp)
        existing = set(self.irp_index[irp])
        req = {"event": event, "path": path, "anchor": anchor,
               "lifetime_generation": generation, "in_window": in_window,
               "tainted": bool(existing)}
        if existing:
            for other in existing:
                for p in self.pending[other]:
                    p["tainted"] = True
            self.counts["overlap_requests"] += 1
            self.emit("overlaps", {"reason": "overlapping_irp_generations_or_contexts",
                 "existing_request_sequences": [p["event"]["source_sequence"]
                    for k in existing for p in self.pending[k]], "new_request": req})
        self.pending[key].append(req)
        self.irp_index[irp].add(key)
        if fo:
            self.object_pending[anchor_key].add(key)

    def complete(self, completion, scope, irp, in_window):
        candidates = set(self.irp_index.get(irp, ())) if irp else set()
        key = (*scope, irp)
        same = self.pending.get(key, [])
        if not candidates:
            self.counts["orphan_completions"] += 1
            self.emit("unresolved", {"reason": "no_pending_request", "completion": completion})
            return
        if not same:
            self.counts["cross_context_completions"] += 1
            self.emit("cross-context", {"reason": "IRP_reference_only_not_matched",
                "completion": completion, "request_references": [
                    {"source_sequence": p["event"]["source_sequence"],
                     "pid": p["event"]["execution_pid"], "tid": p["event"]["execution_tid"]}
                    for k in candidates for p in self.pending[k]]})
            # Do not consume a request based on another execution context.
            for k in candidates:
                for p in self.pending[k]:
                    p["tainted"] = True
            return
        if len(same) != 1 or len(candidates) != 1 or same[0]["tainted"]:
            self.counts["ambiguous_completions"] += 1
            self.emit("unresolved", {"reason": "overlapping_or_tainted_irp",
                "completion": completion, "request_sequences": [p["event"]["source_sequence"]
                for k in candidates for p in self.pending[k]]})
            return
        req = same[0]
        self.pending.pop(key)
        request_fo = ptr(req["event"]["data"].get("FileObject"))
        if request_fo:
            object_key = (*scope, request_fo)
            self.object_pending[object_key].discard(key)
            if not self.object_pending[object_key]:
                self.object_pending.pop(object_key)
        self.irp_index[irp].discard(key)
        if not self.irp_index[irp]:
            self.irp_index.pop(irp)
        event = req["event"]
        data, cd = event["data"], completion["data"]
        operation = str(event["event_id"])
        st, size, extra = status_code(cd.get("Status")), integer(data.get("IOSize")), integer(cd.get("ExtraInformation"))
        exact_success = st == 0
        conditions = {"integrity_or_calibration_gate_not_passed": self.enabled,
            "not_target_execution_pid": pid(event) == self.target_pid,
            "non_read_write_operation": operation in ("15", "16"),
            "no_open_path_anchor": req["path"] is not None,
            "unknown_lifetime": req["lifetime_generation"] is not None,
            "outside_window": req["in_window"] and in_window,
            "not_exact_status_success": exact_success,
            "invalid_request_or_completion_size": size is not None and extra is not None and 0 <= extra <= size}
        exclusions = [reason for reason, passed in conditions.items() if not passed]
        eligible = not exclusions
        raw_pair = {"request": req, "completion": completion,
            "request_bytes": size if operation in ("15", "16") else None,
            "completion_information_raw": cd.get("ExtraInformation"),
            "transferred_bytes_candidate": extra if eligible else None,
            "byte_candidate_exclusions": exclusions,
            "status": {"raw": cd.get("Status"), "name": self.status_names.get(st, "unresolved"),
                "severity": ("success", "informational", "warning", "error")[(st >> 30) & 3]
                    if st is not None and 0 <= st < 2**32 else "unknown",
                "exact_zero": exact_success}, "scope": "same-context operation candidate, not strict proof"}
        self.emit("pairs", raw_pair)
        self.counts["pairs"] += 1
        if req["path"] and pid(event) == self.target_pid:
            r = self.row(req["path"])
            if operation in ("15", "16"):
                direction = "read" if operation == "15" else "write"
                r[direction + "_pairs"] += 1
                if eligible:
                    r["successful_" + direction + "_bytes_candidate"] += extra
                if operation == "15" and st == 0xC0000011:
                    r["eof_read_pairs"] += 1
            else:
                r["non_read_write_pairs"] += 1

    def finish(self):
        for requests in self.pending.values():
            for req in requests:
                self.counts["pending_requests"] += 1
                if req["path"] and pid(req["event"]) == self.target_pid:
                    self.row(req["path"])["pending_requests"] += 1
                self.emit("pending", {"reason": "ambiguous" if req["tainted"] else "no_completion_in_input", **req})
        return {"counters": dict(self.counts), "target_event_counts": dict(self.target_ids),
                "observed_offsets": dict(self.offsets), "files": list(self.rows.values()),
                "pending_irp_scope_slots": len(self.pending)}


def run(directory, output, contract_path, calibration_path=None):
    contract = load(contract_path)
    extraction = load(directory / "extraction.json")
    mode = extraction["mode"]
    expected = contract[mode]
    if output.exists():
        raise ValueError("output directory already exists; refusing overwrite")
    gates = {"extractor_completed": extraction["complete"] is True,
             "source_unchanged": extraction["source_unchanged"] is True and
                extraction["source_sha256_before"] == extraction["source_sha256_after"],
             "contract_hash": extraction["contract_sha256"].lower() == sha(contract_path),
             "source_size": extraction["source_bytes"] == expected["bytes"],
             "two_pass_counts_equal": extraction["pass1_total_events"] == extraction["pass2_total_events"],
             "two_pass_target_order": extraction.get("target_order_matches") is True and
                extraction.get("target_order_hash_pass1") == extraction.get("target_order_hash_pass2"),
             "payload_decoding": extraction["decode_errors"] == 0,
             "target_pid": extraction["target_pid"] == expected["pid"]}
    for name in ("target-events.jsonl", "context-events.jsonl", "process-events.jsonl"):
        spec = extraction["files"][name]
        gates["hash_" + name] = (directory / name).stat().st_size == spec["bytes"] and sha(directory / name) == spec["sha256"].lower()
    life = Lifetimes(directory / "process-events.jsonl")
    if mode == "formal":
        gates["formal_etl_hash"] = extraction["source_sha256_before"].lower() == expected["sha256"].lower()
        gates["get_winevent_total"] = extraction["pass1_total_events"] == expected["get_winevent_total"]
        gates["pid_counts_declared"] = extraction["target_event_counts"] == expected["event_counts"]
        calibration = load(calibration_path) if calibration_path else {}
        gates["calibration_65_byte_actual_replay"] = (calibration.get("calibration_gate") is True
            and calibration.get("accepted") is True and calibration.get("contract_sha256") == sha(contract_path)
            and calibration.get("mode") == "calibration")
        gates["process_payloads_decoded"] = not life.errors
        gates["target_creation_present"] = any(k == "1" for _, k in life.boundaries.get(expected["pid"], []))
    output.mkdir(parents=True)
    names = ("pairs", "unresolved", "pending", "overlaps", "cross-context", "missing-anchor")
    writers = {n: (output / (n + ".jsonl")).open("x", encoding="utf-8") for n in names}
    calibration_stats = Counter()
    calibration_sequences = {"write_65": [], "read_65": []}
    codec = load(ROOT / "reference/formal-codec-review.json")
    status_names = {status_code(x["code"]): x["name"] for x in codec["status_code_table"]}
    def emit(kind, record):
        writers[kind].write(json.dumps(record, ensure_ascii=False) + "\n")
        if mode == "calibration" and kind == "pairs":
            req = record["request"]
            if (req["path"] or "").lower().endswith(expected["baseline_suffix"].lower()):
                value = record["transferred_bytes_candidate"]
                if value == expected["baseline_bytes"]:
                    kind65 = "write_65" if str(req["event"]["event_id"]) == "16" else "read_65"
                    rd = req["event"]["data"]
                    if integer(rd.get("ByteOffset")) == 0 and (kind65 != "write_65" or integer(rd.get("IOSize")) == 65):
                        calibration_stats[kind65] += 1
                        calibration_sequences[kind65].append((req["event"]["source_sequence"], record["completion"]["source_sequence"]))
                if (str(req["event"]["event_id"]) == "15" and
                    integer(req["event"]["data"].get("ByteOffset")) == 65):
                    calibration_stats["read_offset_65_seen"] += 1
    matcher = Matcher(expected["pid"], emit, life if mode == "formal" else None,
        enabled=all(gates.values()), status_names=status_names,
        window=(time_ns(expected["start_utc"]), time_ns(expected["stop_utc"])))
    try:
        for e in merge_events(directory / "target-events.jsonl", directory / "context-events.jsonl"):
            if e.get("provider_guid", "").strip("{}").lower() != contract["file_provider"]:
                raise ValueError("unexpected provider in file event stream")
            validate_layout(e, contract)
            matcher.on_event(e)
        result = matcher.finish()
    finally:
        for writer in writers.values():
            writer.close()
    gates["stored_counts_equal_extractor"] = result["target_event_counts"] == extraction["target_event_counts"]
    gates["all_payloads_mapped"] = result["counters"].get("unmapped_events", 0) == 0
    gates["target_inside_window"] = result["counters"].get("target_outside_window", 0) == 0
    gates["get_winevent_utc_clock"] = set(result["observed_offsets"]) == {"Z"}
    if mode == "formal":
        gates["stored_counts_equal_baseline"] = result["target_event_counts"] == expected["event_counts"]
        gates["target_lifetime_known"] = all(life.generation(expected["pid"], e["source_sequence"]) is not None
            for e in lines(directory / "target-events.jsonl"))
    calibration_gate = (mode == "calibration" and calibration_stats["read_offset_65_seen"] > 0 and
        any(w[1] < r[0] for w in calibration_sequences["write_65"] for r in calibration_sequences["read_65"]))
    if mode == "calibration":
        gates["write_then_read_65_observed"] = calibration_gate
    accepted = all(gates.values())
    # Never expose successful-byte aggregates as accepted when a later integrity
    # gate fails. Detail records remain diagnostic operation candidates only.
    if not accepted:
        for row in result["files"]:
            for field in ("successful_read_bytes_candidate", "successful_write_bytes_candidate"):
                row[field] = None
    for row in result["files"]:
        row["target_file"] = row["path"].split("\\")[-1].lower() in contract["target_names"]
    target_coverage = {name: [r["path"] for r in result["files"]
        if r["path"].split("\\")[-1].lower() == name] for name in contract["target_names"]}
    report = {"schema": "r11-stage1-pairing/1", "mode": mode, "accepted": accepted,
        "acceptance_scope": "extractor/field-map/count gates only; candidate matching may remain unresolved",
        "calibration_gate": calibration_gate if mode == "calibration" else gates["calibration_65_byte_actual_replay"],
        "calibration_observations": dict(calibration_stats), "contract_sha256": sha(contract_path),
        "input_extraction_sha256": sha(directory / "extraction.json"),
        "input_source_etl_sha256": extraction["source_sha256_before"], "gates": gates,
        "process_decode_errors": life.errors, **result,
        "target_coverage": target_coverage,
        "coverage_note": "Empty lists mean no explicit open path observed in this replay, not proof of no access.",
        "formal_header_events_lost_reported": load(ROOT / "reference/formal-session-header.json")["session"]["events_lost"] if mode == "formal" else None,
        "formal_header_reference_sha256": sha(ROOT / "reference/formal-session-header.json") if mode == "formal" else None,
        "formal_buffers_lost": None,
        "total_count_comparison": {"read": extraction["pass1_total_events"],
            "get_winevent_baseline": expected.get("get_winevent_total"),
            "tracerpt_header_reported": expected.get("header_events_processed"),
            "header_delta": extraction["pass1_total_events"] - expected["header_events_processed"] if mode == "formal" else None,
            "note": "One-event channel difference is documented, not silently reconciled."},
        "limitations": ["No GUI parsing, DLL initialization or file-layer exclusion conclusion.",
            "Candidate bytes are not unique file bytes and not a full losslessness proof.",
            "BuffersLost unknown; no inference from calibration zero loss.",
            "Historical volume mapping not guessed. IOFlags and conflicting InfoClass semantics remain raw.",
            "Get-WinEvent contract excludes Irp on ID12; cannot infer successful open from ID24.",
            "accepted is not a signature or proof against modified input artifacts."]}
    report["outputs"] = {p.name: {"bytes": p.stat().st_size, "sha256": sha(p)} for p in output.glob("*.jsonl")}
    (output / "pairing-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return report


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--input-dir", type=Path, required=True)
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument("--contract", type=Path, default=ROOT / "reference/contract.json")
    p.add_argument("--calibration-report", type=Path)
    args = p.parse_args()
    report = run(args.input_dir, args.output_dir, args.contract, args.calibration_report)
    print(json.dumps({"accepted": report["accepted"], "gates": report["gates"]}, ensure_ascii=False))
    raise SystemExit(0 if report["accepted"] else 2)


if __name__ == "__main__":
    main()

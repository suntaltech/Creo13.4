#requires -Version 5.1
<# Read an EXISTING ETL twice. Never starts/stops ETW or writes to the ETL.
Pass 1 retains every target execution-PID file event (no path prefilter).
Pass 2 retains other-PID operations/completions sharing a target IRP, plus
unmapped other-context events so unknown schemas cannot silently hide collisions.
Property positions come from the supplied Get-WinEvent contract, NOT XML order.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$Etl,
    [Parameter(Mandatory=$true)][ValidateSet('formal','calibration')][string]$Mode,
    [Parameter(Mandatory=$true)][string]$OutputDirectory,
    [string]$Contract = (Join-Path $PSScriptRoot '..\reference\contract.json')
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$cfg = Get-Content -LiteralPath $Contract -Raw -Encoding UTF8 | ConvertFrom-Json
$selected = $cfg.$Mode
$source = Get-Item -LiteralPath $Etl
if ($source.PSIsContainer -or $source.Extension -ine '.etl') { throw 'Expected an existing ETL file' }
if ($source.Length -ne $selected.bytes) { throw 'ETL size differs from contract' }
$beforeHash = (Get-FileHash -LiteralPath $source.FullName -Algorithm SHA256).Hash
if ($Mode -eq 'formal' -and $beforeHash -ine $selected.sha256) { throw 'Formal ETL hash mismatch' }
$dest = [IO.Path]::GetFullPath($OutputDirectory)
if (Test-Path -LiteralPath $dest) { throw 'Output directory must not exist; nothing will be overwritten' }
[void][IO.Directory]::CreateDirectory($dest)
$encoding = New-Object System.Text.UTF8Encoding($false)
$fileGuid = [Guid]$cfg.file_provider
$processGuid = [Guid]$cfg.process_provider
$targetPid = [int]$selected.pid
$script:decodeErrors = 0
$script:versions = @{}
$irps = New-Object 'System.Collections.Generic.HashSet[string]'

function Write-JsonLine($Writer, $Record) {
    $Writer.WriteLine(($Record | ConvertTo-Json -Depth 32 -Compress))
}
function Add-RecordHash($Hasher, $Record) {
    $bytes = $encoding.GetBytes(($Record | ConvertTo-Json -Depth 32 -Compress) + "`n")
    [void]$Hasher.TransformBlock($bytes,0,$bytes.Length,$bytes,0)
}
function Pointer-Key($Value) {
    if ($null -eq $Value -or [string]::IsNullOrEmpty([string]$Value)) { return $null }
    $v = [string]$Value
    try {
        if ($v.StartsWith('0x',[StringComparison]::OrdinalIgnoreCase)) {
            $n = [Convert]::ToUInt64($v.Substring(2),16)
        } elseif ($v.StartsWith('-')) {
            $n = [BitConverter]::ToUInt64([BitConverter]::GetBytes([long]::Parse($v)),0)
        } else { $n = [UInt64]::Parse($v,[Globalization.CultureInfo]::InvariantCulture) }
        if ($n -eq 0) { return $null }
        return $n.ToString('X16')
    } catch { return $null }
}
function Convert-FileRecord($Event, [long]$Sequence) {
    $raw = @()
    $data = [ordered]@{}
    $mapping = 'unresolved'
    $decodeError = $null
    $namedXml = $null
    try {
        foreach ($property in $Event.Properties) {
            $value = $property.Value
            $type = if ($null -eq $value) { 'null' } else { $value.GetType().FullName }
            $text = if ($null -eq $value) { $null } elseif ($value -is [byte[]]) {
                [BitConverter]::ToString($value).Replace('-','')
            } elseif ($value -is [IFormattable]) {
                $value.ToString($null,[Globalization.CultureInfo]::InvariantCulture)
            } else { [string]$value }
            $raw += [ordered]@{ type=$type; value=$text }
        }
        $layoutProperty = $cfg.positions.PSObject.Properties[[string]$Event.Id]
        if ($null -ne $layoutProperty) {
            $layout = @($layoutProperty.Value)
            if ($raw.Count -ne $layout.Count) { throw "Property count mismatch for ID $($Event.Id)" }
            for ($i=0; $i -lt $layout.Count; $i++) { $data[[string]$layout[$i]] = $raw[$i].value }
            $mapping = 'supplied_position_contract_pending_calibration'
        } else {
            # Unknown position arrays are NEVER assigned the XML fields' order.
            $namedXml = $Event.ToXml()
            [xml]$document = $namedXml
            $nodes = $document.SelectNodes("//*[local-name()='EventData']/*[local-name()='Data']")
            foreach ($node in $nodes) {
                $name = $node.GetAttribute('Name')
                if ([string]::IsNullOrEmpty($name) -or $data.Contains($name)) { throw 'Unnamed/duplicate XML field' }
                $data[$name] = $node.InnerText
            }
            if ($data.Count -eq 0) { throw 'No named EventData fields; raw payload remains undecoded' }
            $namedContract = $cfg.named_fields.PSObject.Properties[[string]$Event.Id]
            if ($null -eq $namedContract) { throw 'Unknown EventID has no verified named-field contract' }
            foreach ($requiredField in @($namedContract.Value)) {
                if (-not $data.Contains([string]$requiredField)) { throw "Missing named field $requiredField" }
            }
            $mapping = 'named_event_xml_no_position_guess'
        }
    } catch {
        $script:decodeErrors++
        $decodeError = $_.Exception.Message
        $mapping = 'unresolved'
        $data = [ordered]@{}
    }
    $signature = '{0}/{1}/{2}' -f $Event.Id,$Event.Version,$Event.Opcode
    if (-not $script:versions.ContainsKey($signature)) { $script:versions[$signature]=0 }
    $script:versions[$signature]++
    if ($null -eq $Event.TimeCreated) { throw 'Event has no TimeCreated' }
    $operation = switch ([int]$Event.Id) {
        12 { 'Open/Create' } 13 { 'Cleanup' } 14 { 'Close' }
        15 { 'ReadFile' } 16 { 'WriteFile' } 24 { 'IRP completion' }
        default { 'Other operation (raw)' }
    }
    return [ordered]@{
        schema='r11-stream-event/1'; event_id=[string]$Event.Id; operation=$operation;
        version=[string]$Event.Version; opcode=[string]$Event.Opcode;
        provider_guid=('{'+$Event.ProviderId.ToString()+'}'); provider_name=$Event.ProviderName;
        execution_pid=[string]$Event.ProcessId; execution_tid=[string]$Event.ThreadId;
        source_sequence=$Sequence; record_id=$Event.RecordId;
        system_time=$Event.TimeCreated.ToUniversalTime().ToString('o');
        mapping=$mapping; decode_error=$decodeError; raw_properties=$raw; named_xml=$namedXml; data=$data
    }
}

$eventsPath = Join-Path $dest 'target-events.jsonl'
$contextPath = Join-Path $dest 'context-events.jsonl'
$processPath = Join-Path $dest 'process-events.jsonl'
$targetWriter = New-Object IO.StreamWriter($eventsPath,$false,$encoding)
$contextWriter = New-Object IO.StreamWriter($contextPath,$false,$encoding)
$processWriter = New-Object IO.StreamWriter($processPath,$false,$encoding)
$targetHash1 = [Security.Cryptography.SHA256]::Create()
$targetHash2 = [Security.Cryptography.SHA256]::Create()
$counts = @{}
$total1 = [long]0; $total2 = [long]0; $contextCount = [long]0
$processCount = [long]0; $success = $false; $failure = $null
try {
    Get-WinEvent -Path $source.FullName -Oldest -ErrorAction Stop | ForEach-Object {
        $ev = $_
        try {
            $total1++
            if ($ev.ProviderId -eq $fileGuid -and $ev.ProcessId -eq $targetPid) {
                $id = [string]$ev.Id
                if (-not $counts.ContainsKey($id)) { $counts[$id]=0 }
                $counts[$id]++
                $rec = Convert-FileRecord $ev $total1
                Write-JsonLine $targetWriter $rec
                Add-RecordHash $targetHash1 $rec
                $key = Pointer-Key $rec.data['Irp']
                if ($null -ne $key) { [void]$irps.Add($key) }
            } elseif ($ev.ProviderId -eq $processGuid) {
                $processCount++
                Write-JsonLine $processWriter ([ordered]@{
                    source_sequence=$total1; event_id=$ev.Id; version=$ev.Version; opcode=$ev.Opcode;
                    provider_guid=('{'+$ev.ProviderId.ToString()+'}');
                    execution_pid=$ev.ProcessId; execution_tid=$ev.ThreadId;
                    system_time=$ev.TimeCreated.ToUniversalTime().ToString('o'); raw_xml=$ev.ToXml()
                })
            }
        } finally { $ev.Dispose() }
    }
    $targetWriter.Flush()
    # A second traversal sees cross-context records even if they precede a target request.
    Get-WinEvent -Path $source.FullName -Oldest -ErrorAction Stop | ForEach-Object {
        $ev = $_
        try {
            $total2++
            if ($ev.ProviderId -eq $fileGuid -and $ev.ProcessId -eq $targetPid) {
                # Bind cross-context source_sequence to an independently verified
                # identical target stream; tied-time reordering must not be guessed.
                $rec = Convert-FileRecord $ev $total2
                Add-RecordHash $targetHash2 $rec
            } elseif ($ev.ProviderId -eq $fileGuid -and $ev.ProcessId -ne $targetPid) {
                $rec = Convert-FileRecord $ev $total2
                $key = Pointer-Key $rec.data['Irp']
                if ($rec.mapping -eq 'unresolved' -or ($null -ne $key -and $irps.Contains($key))) {
                    Write-JsonLine $contextWriter $rec
                    $contextCount++
                }
            }
        } finally { $ev.Dispose() }
    }
    $success = $true
} catch {
    $failure = $_.Exception.Message
} finally {
    $targetWriter.Dispose(); $contextWriter.Dispose(); $processWriter.Dispose()
}
$afterHash = (Get-FileHash -LiteralPath $source.FullName -Algorithm SHA256).Hash
[void]$targetHash1.TransformFinalBlock([byte[]]@(),0,0)
[void]$targetHash2.TransformFinalBlock([byte[]]@(),0,0)
$orderHash1 = [BitConverter]::ToString($targetHash1.Hash).Replace('-','')
$orderHash2 = [BitConverter]::ToString($targetHash2.Hash).Replace('-','')
$targetHash1.Dispose(); $targetHash2.Dispose()
$files = @{}
foreach ($filename in @('target-events.jsonl','context-events.jsonl','process-events.jsonl')) {
    $path = Join-Path $dest $filename
    $files[$filename] = [ordered]@{bytes=(Get-Item -LiteralPath $path).Length;
        sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash}
}
$report = [ordered]@{
    schema='r11-extraction/1'; mode=$Mode; target_pid=$targetPid;
    complete=$success; error=$failure; extraction_channel='Get-WinEvent -Oldest, two read-only passes';
    source_path=$source.FullName; source_bytes=$source.Length;
    source_sha256_before=$beforeHash; source_sha256_after=$afterHash; source_unchanged=($beforeHash -eq $afterHash);
    pass1_total_events=$total1; pass2_total_events=$total2; target_event_counts=$counts;
    target_order_hash_pass1=$orderHash1; target_order_hash_pass2=$orderHash2;
    target_order_matches=($orderHash1 -eq $orderHash2);
    context_records=$contextCount; process_records=$processCount; decode_errors=$script:decodeErrors;
    version_opcode_counts=$script:versions; files=$files;
    contract_sha256=(Get-FileHash -LiteralPath $Contract -Algorithm SHA256).Hash;
    position_validation='structural only; run Python calibration gate for actual 65-byte observations';
    cross_context_rule='Other-PID IRP records retained, never use their FileObject as target-PID path anchors';
    volume_mapping=@{}; volume_mapping_note='Historical device-to-drive mapping not inferred from current host';
    buffers_lost=$null
}
[IO.File]::WriteAllText((Join-Path $dest 'extraction.json'),($report | ConvertTo-Json -Depth 32),$encoding)
if (-not $success) { throw "Extraction incomplete: $failure" }
if ($beforeHash -ne $afterHash) { throw 'ETL changed during extraction; reject this output' }
Write-Output "Read-only extraction finished: $dest (not yet accepted; run offline pairing gates)"

import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("pair_r11", ROOT / "tools/pair_r11.py")
m = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(m)
CONTRACT = m.load(ROOT / "reference/contract.json")


def event(seq, eid, process=23636, **data):
    fields = CONTRACT["positions"].get(str(eid))
    if fields:
        data = {name: str(data.get(name, "0")) for name in fields}
    return {"schema": "r11-stream-event/1", "event_id": str(eid),
            "version": "0", "opcode": "0", "provider_guid": "{"+CONTRACT["file_provider"]+"}",
            "execution_pid": str(process), "execution_tid": "8", "source_sequence": seq,
            "record_id": None, "system_time": f"2026-11-12T07:25:20.{seq:07d}Z",
            "mapping": "supplied_position_contract_pending_calibration" if fields else "named_event_xml_no_position_guess",
            "decode_error": None, "raw_properties": [{"type": "System.String", "value": data[k]} for k in fields or []],
            "data": data}


def basic():
    return [event(1, 12, FileObject="2", FileKey="3", FileName="\\Device\\x\\a.txt"),
            event(2, 15, FileObject="2", FileKey="3", Irp="4", IOSize="4096"),
            event(3, 24, Irp="4", ExtraInformation="65", Status="0")]


def match(events, enabled=True):
    out = {}
    def emit(kind, record):
        out.setdefault(kind, []).append(copy.deepcopy(record))
    matcher = m.Matcher(23636, emit, enabled=enabled)
    for e in events:
        matcher.on_event(e)
    return matcher.finish(), out


class PairingTests(unittest.TestCase):
    def test_id12_no_irp_anchor_still_works(self):
        events = basic()
        self.assertNotIn("Irp", events[0]["data"])
        report, out = match(events)
        self.assertEqual(report["files"][0]["successful_read_bytes_candidate"], 65)
        self.assertEqual(out["pairs"][0]["completion"]["data"]["Status"], "0")

    def test_open_and_cleanup_information_not_read_bytes(self):
        report, out = match(basic() + [event(4, 13, FileObject="2", Irp="4"),
            event(5, 24, Irp="4", ExtraInformation="2", Status="0")])
        self.assertEqual(report["files"][0]["successful_read_bytes_candidate"], 65)
        self.assertIsNone(out["pairs"][1]["transferred_bytes_candidate"])

    def test_cross_context_not_counted_or_consumed(self):
        events = basic()
        events[2]["execution_pid"] = "0"
        report, out = match(events)
        self.assertEqual(report["counters"]["cross_context_completions"], 1)
        self.assertEqual(report["counters"]["pending_requests"], 1)
        self.assertEqual(out["cross-context"][0]["request_references"][0]["pid"], "23636")

    def test_cross_pid_fileobject_is_never_target_anchor(self):
        events = basic()
        events[0]["execution_pid"] = "99"
        report, out = match(events)
        self.assertEqual(out["pairs"][0]["request"]["path"], None)
        self.assertEqual(report["counters"]["requests_missing_anchor"], 1)

    def test_overlap_generation_tombstone_not_cleared_by_completion(self):
        report, out = match(basic()[:2] + [event(3, 15, FileObject="2", Irp="4", IOSize="50"),
            event(4, 24, Irp="4", ExtraInformation="40", Status="0"),
            event(5, 24, Irp="4", ExtraInformation="40", Status="0")])
        self.assertEqual(report["counters"]["pending_requests"], 2)
        self.assertEqual(report["pending_irp_scope_slots"], 1)
        self.assertNotIn("pairs", out)

    def test_fileobject_reopen_with_pending_read_taints_old_generation(self):
        report, out = match(basic()[:2] + [event(3, 12, FileObject="2", FileName="b.txt"),
            event(4, 24, Irp="4", Status="0", ExtraInformation="65")])
        self.assertEqual(report["counters"]["ambiguous_completions"], 1)
        self.assertNotIn("pairs", out)

    def test_close_invalidates_anchor(self):
        events = [basic()[0], event(2, 14, FileObject="2", Irp="8"),
            event(3, 24, Irp="8", Status="0", ExtraInformation="0"),
            event(4, 15, FileObject="2", Irp="9", IOSize="65"),
            event(5, 24, Irp="9", Status="0", ExtraInformation="65")]
        report, out = match(events)
        self.assertIsNone(out["pairs"][1]["request"]["path"])

    def test_eof_does_not_become_success_bytes(self):
        events = basic()
        events[-1]["data"]["Status"] = "0xc0000011"
        report, out = match(events)
        self.assertEqual(report["files"][0]["eof_read_pairs"], 1)
        self.assertEqual(report["files"][0]["successful_read_bytes_candidate"], 0)

    def test_completed_bytes_cannot_exceed_request(self):
        events = basic()
        events[-1]["data"]["ExtraInformation"] = "5000"
        _, out = match(events)
        self.assertIsNone(out["pairs"][0]["transferred_bytes_candidate"])

    def test_disabled_gate_never_counts_bytes(self):
        report, _ = match(basic(), enabled=False)
        self.assertEqual(report["files"][0]["successful_read_bytes_candidate"], 0)

    def test_status_extra_positions_are_not_interchanged(self):
        e = event(1, 24, Irp="1", ExtraInformation="65", Status="3221225489")
        m.validate_layout(e, CONTRACT)
        e["data"]["Status"], e["data"]["ExtraInformation"] = e["data"]["ExtraInformation"], e["data"]["Status"]
        with self.assertRaises(ValueError):
            m.validate_layout(e, CONTRACT)

    def test_unknown_position_layout_refuses_guess(self):
        e = event(1, 17, Irp="4", InfoClass="589992")
        e["mapping"] = "guess"
        with self.assertRaises(ValueError):
            m.validate_layout(e, CONTRACT)

    def test_missing_named_irp_field_cannot_silently_hide_operation(self):
        e=event(1,22,InfoClass="9")
        with self.assertRaises(ValueError):
            m.validate_layout(e,CONTRACT)

    def test_timestamps_retain_100ns_and_explicit_offsets(self):
        self.assertEqual(m.time_ns("2026-11-12T07:25:20.0000001Z") - m.time_ns("2026-11-12T07:25:20Z"), 100)
        self.assertEqual(m.time_ns("2026-11-12T15:25:20+08:00"), m.time_ns("2026-11-12T07:25:20Z"))
        with self.assertRaises(ValueError):
            m.time_ns("2026-11-12T15:25:20")

    def test_signed_pointer_preserved_as_64bit_pattern(self):
        self.assertEqual(m.ptr("-1"), 2**64-1)
        self.assertIsNone(m.ptr("0"))

    def test_signed_status_decoded_without_changing_raw(self):
        events = basic()
        events[-1]["data"]["Status"] = "-1073741807"
        _, out = match(events)
        self.assertEqual(out["pairs"][0]["status"]["name"], "STATUS_END_OF_FILE")
        self.assertEqual(out["pairs"][0]["status"]["raw"], "-1073741807")

    def test_merge_uses_source_order_and_rejects_duplicates(self):
        with tempfile.TemporaryDirectory() as d:
            a, b = Path(d)/"a", Path(d)/"b"
            a.write_text(json.dumps(basic()[0])+"\n"+json.dumps(basic()[2])+"\n")
            b.write_text(json.dumps(basic()[1])+"\n")
            self.assertEqual([e["source_sequence"] for e in m.merge_events(a,b)], [1,2,3])
            b.write_text(json.dumps(basic()[0])+"\n")
            with self.assertRaises(ValueError):
                list(m.merge_events(a,b))

    def test_compat_export_retains_clock_value_and_raw_header(self):
        with tempfile.TemporaryDirectory() as d:
            source,dest=Path(d)/"raw.jsonl",Path(d)/"compat.jsonl"
            e=basic()[0]
            source.write_text(json.dumps(e)+"\n")
            subprocess.run([sys.executable,str(ROOT/"tools/export_compat.py"),"--input",str(source),"--output",str(dest)],check=True,capture_output=True,text=True)
            record=json.loads(dest.read_text())
            self.assertEqual(record["system_time"],"2026-11-12T07:25:20.000000100+00:00")
            self.assertEqual(record["original_system_time"],e["system_time"])
            self.assertEqual(record["data"],e["data"])

    def test_process_named_pid_and_generation_boundaries(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)/"process.jsonl"
            records=[]
            for seq,eid in [(1,1),(4,2),(8,1)]:
                records.append({"source_sequence":seq,"event_id":eid,"execution_pid":0,
                    "raw_xml":"<Event><EventData><Data Name='ProcessID'>23636</Data></EventData></Event>"})
            p.write_text("".join(json.dumps(r)+"\n" for r in records))
            life=m.Lifetimes(p)
            self.assertEqual(life.generation(23636,2),1)
            self.assertIsNone(life.generation(23636,6))
            self.assertEqual(life.generation(23636,9),8)
            self.assertIsNone(life.generation(0,2))


class PipelineTests(unittest.TestCase):
    def fixture(self, folder):
        contract=copy.deepcopy(CONTRACT)
        contract["calibration"].update({"pid":23636,"bytes":1,
            "start_utc":"2026-11-12T07:25:00Z","stop_utc":"2026-11-12T07:26:00Z"})
        cp=folder/"contract.json"
        cp.write_text(json.dumps(contract))
        events=[event(1,12,FileObject="2",FileName="\\Device\\x\\calibration-baseline.txt"),
            event(2,16,FileObject="2",Irp="4",IOSize="65",ByteOffset="0"),
            event(3,24,Irp="4",Status="0",ExtraInformation="65"),
            event(4,15,FileObject="2",Irp="5",IOSize="4096",ByteOffset="0"),
            event(5,24,Irp="5",Status="0",ExtraInformation="65"),
            event(6,15,FileObject="2",Irp="6",IOSize="4096",ByteOffset="65"),
            event(7,24,Irp="6",Status="0xc0000011",ExtraInformation="0")]
        extract=folder/"extract"
        extract.mkdir()
        (extract/"target-events.jsonl").write_text("".join(json.dumps(e)+"\n" for e in events))
        for n in ("context-events.jsonl","process-events.jsonl"):
            (extract/n).write_text("")
        meta={"mode":"calibration","complete":True,"source_unchanged":True,
              "source_sha256_before":"fake-calibration-hash","source_sha256_after":"fake-calibration-hash",
              "source_bytes":1,"contract_sha256":m.sha(cp),"target_pid":23636,
              "pass1_total_events":7,"pass2_total_events":7,"decode_errors":0,
              "target_order_matches":True,"target_order_hash_pass1":"fixture-order","target_order_hash_pass2":"fixture-order",
              "target_event_counts":dict(m.Counter(e["event_id"] for e in events)),
              "files":{n:{"bytes":(extract/n).stat().st_size,"sha256":m.sha(extract/n)} for n in
                       ("target-events.jsonl","context-events.jsonl","process-events.jsonl")}}
        (extract/"extraction.json").write_text(json.dumps(meta))
        return extract,cp

    def test_calibration_pipeline_and_exclusive_output(self):
        with tempfile.TemporaryDirectory() as d:
            folder=Path(d)
            extract,cp=self.fixture(folder)
            report=m.run(extract,folder/"result",cp)
            self.assertTrue(report["accepted"])
            self.assertTrue(report["calibration_gate"])
            self.assertEqual(report["calibration_observations"]["write_65"],1)
            with self.assertRaises(ValueError):
                m.run(extract,folder/"result",cp)

    def test_tampered_file_rejected_and_aggregate_withheld(self):
        with tempfile.TemporaryDirectory() as d:
            folder=Path(d)
            extract,cp=self.fixture(folder)
            with (extract/"target-events.jsonl").open("a") as f:
                f.write(json.dumps(event(8,24,Irp="99",Status="0",ExtraInformation="100"))+"\n")
            report=m.run(extract,folder/"result",cp)
            self.assertFalse(report["accepted"])
            self.assertFalse(report["gates"]["hash_target-events.jsonl"])
            self.assertIsNone(report["files"][0]["successful_read_bytes_candidate"])

    def test_two_pass_target_order_difference_is_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            folder=Path(d)
            extract,cp=self.fixture(folder)
            p=extract/"extraction.json"
            meta=m.load(p)
            meta["target_order_hash_pass2"]="different-order"
            p.write_text(json.dumps(meta))
            report=m.run(extract,folder/"result",cp)
            self.assertFalse(report["accepted"])
            self.assertFalse(report["gates"]["two_pass_target_order"])

    def test_wrong_mapping_cannot_be_calibration_success(self):
        with tempfile.TemporaryDirectory() as d:
            folder=Path(d)
            extract,cp=self.fixture(folder)
            p=extract/"target-events.jsonl"
            events=list(m.lines(p))
            for e in events:
                if e["event_id"]=="24":
                    e["data"]["ExtraInformation"],e["data"]["Status"] = e["data"]["Status"],e["data"]["ExtraInformation"]
                    e["raw_properties"]=[{"type":"System.String","value":e["data"][name]} for name in CONTRACT["positions"]["24"]]
            p.write_text("".join(json.dumps(e)+"\n" for e in events))
            meta=m.load(extract/"extraction.json")
            meta["files"][p.name]={"bytes":p.stat().st_size,"sha256":m.sha(p)}
            (extract/"extraction.json").write_text(json.dumps(meta))
            report=m.run(extract,folder/"result",cp)
            self.assertFalse(report["calibration_gate"])
            self.assertFalse(report["accepted"])

    def test_formal_count_header_difference_and_calibration_requirement(self):
        with tempfile.TemporaryDirectory() as d:
            folder=Path(d)
            cp=folder/"contract.json"
            contract=copy.deepcopy(CONTRACT)
            events=basic()
            for e in events:
                e["source_sequence"]+=1
            counts=dict(m.Counter(e["event_id"] for e in events))
            contract["formal"].update({"bytes":1,"sha256":"fixture-etl-hash",
                "get_winevent_total":4,"header_events_processed":5,"event_counts":counts})
            cp.write_text(json.dumps(contract))
            extract=folder/"extract"
            extract.mkdir()
            (extract/"target-events.jsonl").write_text("".join(json.dumps(e)+"\n" for e in events))
            (extract/"context-events.jsonl").write_text("")
            process={"source_sequence":1,"event_id":1,"raw_xml":"<Event><EventData><Data Name='ProcessID'>23636</Data></EventData></Event>"}
            (extract/"process-events.jsonl").write_text(json.dumps(process)+"\n")
            meta={"mode":"formal","target_pid":23636,"complete":True,"source_unchanged":True,
                "source_bytes":1,"source_sha256_before":"fixture-etl-hash","source_sha256_after":"fixture-etl-hash",
                "contract_sha256":m.sha(cp),"pass1_total_events":4,"pass2_total_events":4,
                "target_order_matches":True,"target_order_hash_pass1":"same","target_order_hash_pass2":"same",
                "decode_errors":0,"target_event_counts":counts,
                "files":{n:{"bytes":(extract/n).stat().st_size,"sha256":m.sha(extract/n)} for n in
                    ("target-events.jsonl","context-events.jsonl","process-events.jsonl")}}
            (extract/"extraction.json").write_text(json.dumps(meta))
            rejected=m.run(extract,folder/"no-cal",cp)
            self.assertFalse(rejected["accepted"])
            self.assertFalse(rejected["gates"]["calibration_65_byte_actual_replay"])
            cal=folder/"calibration-report.json"
            cal.write_text(json.dumps({"mode":"calibration","accepted":True,"calibration_gate":True,"contract_sha256":m.sha(cp)}))
            accepted=m.run(extract,folder/"with-cal",cp,cal)
            self.assertTrue(accepted["accepted"])
            self.assertEqual(accepted["total_count_comparison"]["header_delta"],-1)
            self.assertIsNone(accepted["formal_buffers_lost"])
            self.assertEqual(accepted["files"][0]["successful_read_bytes_candidate"],65)


if __name__=="__main__":
    unittest.main()

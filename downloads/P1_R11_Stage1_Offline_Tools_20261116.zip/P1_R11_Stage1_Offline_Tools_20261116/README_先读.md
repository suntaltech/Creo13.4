# R11 Stage1：现存 ETL 只读提取与配对候选

这是 **离线源码候选交付**。Python 离线测试 24 项通过；Windows PowerShell 解析/执行、真实校准 ETL 与正式 ETL 回放、目标计数对齐尚未在云端验证。本包没有 DLL、正式运行结果或原始 ETL，不改变 Creo 插件、配置、模型或采集会话。

先读 `STATIC_REVIEW.md`。`input_docs/` 保留本轮任务与缺口盘点；`reference/` 是用户提供的校准、编解码、会话头、时钟证据及独立的通道 A 属性位置合同。旧片段没有被伪装为完整输入。

## 交付文件

- `tools/Extract-R11.ps1`：Windows PowerShell 5.1+，对现存 ETL 两遍 Get-WinEvent -Oldest 流读。不启动/停止 ETW，不运行 tracerpt，不生成全量 XML/CSV，不写原始 ETL。输出目录必须尚不存在。
- `tools/pair_r11.py`：Python 3.9+，只处理提取器输出 JSONL；校验哈希、基线计数、UTC 会话窗、PID 生命周期、校准门和两遍流读的一致性。输出候选配对及未决记录。
- `tools/export_compat.py`：可选的旧参考配对器事件适配，保留原始时戳，将 Z 仅等价写成 +00:00 并补齐 9 位精度。它不补缺事件，也不生成旧 per-path paired 集合。
- `tests/` 与 `validation/`：合成事件测试、结果及验证边界。没有真实 ETL 回放通过的声明。

## 本机审核顺序

先在解压目录执行 Python 测试：

```powershell
py -3 -m unittest discover -s tests -v
if ($LASTEXITCODE -ne 0) { throw '离线测试未通过，停止' }
```

然后先做 PowerShell 原生语法解析，不能用 Python 测试代替：

```powershell
$ReviewTokens = $null
$ReviewParseErrors = $null
[void][System.Management.Automation.Language.Parser]::ParseFile(
    (Join-Path (Get-Location).Path 'tools\Extract-R11.ps1'),
    [ref]$ReviewTokens, [ref]$ReviewParseErrors)
if ($ReviewParseErrors.Count -ne 0) { $ReviewParseErrors; throw '提取器语法门未通过' }
```

## 对现存证据做离线回放

以下都是读取过去保留的 ETL，不是新采集、插件部署或现场 UI 操作。路径先由本机助手核实。校准 ETL 如不在示例同目录，应改成其**现存**实际路径；如已不存在，停止并回报，不新采、不伪造校准通过。无需为了运行脚本修改执行策略。

```powershell
$FormalEvidenceEtl = 'D:\creo-tools\build\p1-step41-r10-late-find-review-20261112\runtime-r11\formal.etl'
$CalibrationEvidenceEtl = Join-Path (Split-Path $FormalEvidenceEtl) 'calibrate.etl'
$OfflineReviewRoot = 'F:\P1_R11_Stage1_Offline_20261116'
if (-not (Test-Path -LiteralPath $CalibrationEvidenceEtl -PathType Leaf)) { throw '找不到现存校准 ETL，停止；不要重新采集' }
if (-not (Test-Path -LiteralPath $FormalEvidenceEtl -PathType Leaf)) { throw '找不到正式 ETL，停止' }
```

第一步先验证通道 A 的实际 65 字节写后读链：

```powershell
.\tools\Extract-R11.ps1 -Etl $CalibrationEvidenceEtl -Mode calibration -OutputDirectory (Join-Path $OfflineReviewRoot 'cal-extract')
py -3 .\tools\pair_r11.py --input-dir (Join-Path $OfflineReviewRoot 'cal-extract') --output-dir (Join-Path $OfflineReviewRoot 'cal-pairs')
if ($LASTEXITCODE -ne 0) { throw '实际校准门未通过，停止；保留诊断产物' }
```

第二步才做正式证据的离线读取与配对：

```powershell
.\tools\Extract-R11.ps1 -Etl $FormalEvidenceEtl -Mode formal -OutputDirectory (Join-Path $OfflineReviewRoot 'formal-extract')
py -3 .\tools\pair_r11.py --input-dir (Join-Path $OfflineReviewRoot 'formal-extract') --output-dir (Join-Path $OfflineReviewRoot 'formal-pairs') --calibration-report (Join-Path $OfflineReviewRoot 'cal-pairs\pairing-report.json')
if ($LASTEXITCODE -ne 0) { throw '正式回放门未通过，停止结论升级；保留诊断产物' }
```

提取器出错须立即停止后续命令，不要把部分输出当完整回放。已经存在的输出目录不会覆盖；重复检查使用新的目录名，不删除原证据。两遍流读需要比单遍更长时间，未知 schema 的 named XML 读取也有成本；没有“保证 2.5–5 分钟完成”的承诺。

## 验收看什么

`pairing-report.json` 的 accepted=true 仅表示该次提取/映射/计数验收门通过，**不表示所有操作严格配对、完全无丢失、GUI 解析成功或 DLL 初始化成功**。逐项检查 gates；退出码 2 表示拒绝验收。若后置完整性门失败，文件级成功字节小计会置 null；明细仍只是诊断候选。

目标 EventID 计数必须逐项等于 `reference/contract.json` 的 PID 23636 基线，不能以旧片段 1184 个事件代替。Get-WinEvent 总数基线为 1,916,191；输入会话头写的是 1,916,192，报告保留 -1 差异，不自行宣告对齐或假定缺的是哪一条。

`target-events.jsonl` 保留目标 PID 全部文件事件，没有路径预过滤；`context-events.jsonl` 保留另一执行上下文中与目标 IRP 有关的记录及无法解码的记录；`process-events.jsonl` 保留进程创建/退出原始 XML。设备路径保持原样，历史卷号映射不按当前主机猜测。

配对明细按流拆分为 pairs、unresolved、pending、overlaps、cross-context、missing-anchor。pending_requests 统计**请求条数**，pending_irp_scope_slots 统计作用域键数；一个键可能有多个重叠请求。每个目标路径单独给请求量、完成量候选及待解项，`.ui` 的 Roaming/Temp 路径不会合并。target_coverage 的空列表只是未观察到显式路径锚点，不等于从未访问。

当前明确保留：BuffersLost 未知；IOFlags 位语义未解码；InfoClass 冲突项不推测；0x216 未解码；tracerpt +07:59 根因未解决。通道 A 原始 UTC 与旧 XML 时戳各自保留，不能把旧时戳直接“加一分钟修正”。

## 最小回传清单

先回传本机 PowerShell 语法检查结果、两次 extraction.json、校准与正式 pairing-report.json。若失败，附首条报错及对应少量原始事件（含 source_sequence/version/opcode/raw_properties/data），保留哈希。若通过，再选目标路径的少量 pairs/unresolved/pending/cross-context 记录，三消息、DAT、DLL、两条 config.pro、两条 .ui/.ui.bak 均说明覆盖状态。

不要回传整份 ETL 或大体积全量 JSONL；不为补齐结论重新采集、改 UI、改插件或执行真实转换。本阶段先确定提取与配对证据质量，UI 根因仍未确定。

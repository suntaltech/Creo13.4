# P1 第五轮：离线兼容与诊断加固（待真实SDK编译）

基于第四轮最终四文件，以及本轮新增六个现场输入。所有输入SHA256/大小已核对；运行时BAT只读核对，未改写或执行。本包是供审核/暂存编译的补丁，**不能标记第五轮完整离线验收通过**：本云环境没有真实otk.jar及Windows，尚无本轮真实SDK编译退出码/生产class major。不能沿用第四轮真实编译结果。

## 基线与补丁

`P1_Round5_from_Round4.patch` 只修改 `BatchRename.java` 和 `web/about.html`。Java基于第四轮最终文件；about.html基于本轮实际现场文件（此前第四轮包未包含该页）。完整输入哈希见input-sha256.json。先在副本核对哈希、`git apply --check`，再应用；不得覆盖仍运行旧版的现场源码/class/Web。若现场未应用第四轮，应先在隔离副本按第四轮文档建立相应基线，不能直接将本补丁用于最初生产源码。

包内提供最终BatchRename、core.js、about.html及未修改的业务页面/脚本，便于复跑；不是完整安装器，未包含现场base.css等完整资源。不应整体覆盖现场目录。reference/runtime为现场BAT原样只读副本，禁止作为本轮修改/部署脚本。tests类不进入生产。

## Java最小变化

1. `validateLaunchDirectory` 增加setvars.bat检查：批准根内可读普通文件、非链接、真实父目录仍为批准根。失败抛InvalidLaunchEnvironment，诊断为directory/rejected、INVALID_LAUNCH_ENVIRONMENT，并在探测端口/提交进程之前返回。**不解析或修改BAT内容**。原严格目录/批准根、脚本/日志检查保留。
2. 将目录阶段提取为private辅助方法，生产仅传入原本的resolveLaunchDirectory；测试可用临时目录独立验证错误路径，不运行Windows进程。directory/validated新增setvars完整路径。
3. 启动诊断保存private、volatile、不可变的最近事件快照，仅供离线反射测试；没有浏览器/HTTP入口，不读模型。全部事件ready=false、saved=false。occupied_unverified不是服务身份；submitted不是服务就绪；shellPid仍只表示外层shell。
4. 失败事件补充异常类和最多240字符单行消息摘要；堆栈仍仅入诊断日志。日志晚到/丢弃策略不变，stop后不重建worker。检查与执行仍有TOCTOU窗口；不是BAT签名认证或Windows ACL审计。

没有恢复模型创建、重生成、保存或浏览器监听；生产仍无转换方法/校验契约，tests/P1ClosedContract仅为测试底稿。

## 关于页文案

基于实际about.html，仅替换“并按驱动曲面或抽壳方式转换”为“当前仅提供普通实体零件的只读适用性分析；真实转换通道未开放，不自动创建钣金特征”。保留全部DOM ID、core/update脚本顺序、版本逻辑及debug=1模拟按钮规则。没有新增参数或保存入口。

## 公共层与业务兼容

core.js保持第四轮字节不变；rename.html、rename.js、update.js、sheetmetal.js、sheetmetal.html也均未修改。没有发现本轮需要修改公共API的断裂。

使用**实际提供的rename.js、update.js和about内联脚本**加载同一core.js，完成14项DOM/HTTP模拟兼容检查，另保留27项P1/core测试。覆盖：

- connectSession、ensureSession、call、request、el、状态/审计/storage、版本工具、getter/setter等真实消费者引用存在；
- 重命名启动单次30秒连接、失败后恢复预览按钮并可再次连接；预览及onlysession:true改名；取消不写；业务错误不重连；只读不确定失败保留一次重连；
- 既有重命名可选file/save保持原业务（**仅模拟请求**）；它不是P1保存通道；
- 关于页版本展示、受控清单请求、下载链接展示而不自动下载/覆盖class、debug=1按钮显示、非HTTPS链接拒绝、local版本读取失败回退；
- P1显式startupRetry:true最多4×3秒，默认公共层单次30秒；所有bridgeCall仍阻断；P1转换控件禁用且不发送写请求。

模拟使用内存模型和替身HTTP，没有连接CREOSON、修改/保存真实模型或下载更新。它不证明现场rename/about/update全量无回归。

### 既有更新模块观察（未修改）

现场update.js固定访问`https://raw.githubusercontent.com/zcxkij/creo-tools/main/version.json`，与当前交付仓库不是同一个仓库；本轮保留该配置，未访问远程。其下载链接校验使用`hostname.endsWith("github.com")`，边界偏宽（如非GitHub的`examplegithub.com`也会匹配）。这不是本轮公共API断裂；按要求未改update.js业务。不能把现有校验宣称为完整严格的GitHub域名白名单。建议另行明确授权后修正并补安全用例；本包不扩大或利用该行为。

## 运行时BAT静态核对

`reference/runtime`两文件与输入逐字节相同。creoson_run.bat SHA256为f041b68e775130f6a217ce6111bdcadde531b8e042d02c1d4d54dedec6faeda1；setvars.bat为b0d11f8f472debef1907322169547f8751d95d93a77bea689e34f6e6d4a2f9f1。

已观察：bat依赖工作目录内setvars.bat，检查PROE_COMMON/PROE_ENV/JAVA_HOME/JSON_PORT；失败分支含pause；构造patch-classes、目录JAR及pfcasync.jar classpath；使用JAVA_HOME运行MainServer；setvars配置Creo13.4路径、x86e_win64、JDK25及9056端口。

这里的pfcasync.jar属于**外部CREOSON运行时**；本轮未改变它，也没有混入BatchRename同步SDK编译。JAVA_HOME=JDK25不证明CREOSON真实运行兼容；`start /b`继承stdout/stderr、stdin=NUL对pause的行为、实际文件存在/权限/服务进程存活均未验证。Java前置检查仅验证setvars文件形态，不执行BAT解析或猜测环境可用。

## 测试移植与计数

Java Stub现在独立记录passed/skipped/failed，结果JSON包含跳过原因。仅捕获符号链接创建的明确权限/能力异常；其他文件系统错误、断言失败仍导致非零退出。不会因一个链接用例缺权限而跳过后续日志/stop/reload测试；链接断言失败也不会被吞成SKIPPED。

两种模式：

- 本云Linux真实创建链接：75 passed、0 skipped、0 failed。
- **测试专用的权限拒绝模拟**：71 passed、4 skipped、0 failed；后续日志/stop/reload检查继续执行。它验证跳过机制，不等于在Windows复现了权限/链接行为。

可复跑：

```sh
python3 tests/run_java.py --jdk /JDK目录 --output /新的输出目录
python3 tests/run_java.py --jdk /JDK目录 --output /另一个新的输出目录 --simulate-no-symlinks
node tests/test_round4.cjs /输出目录/p1-frontend.jsonl
node tests/test_existing_pages.cjs /输出目录/existing-pages.jsonl
node --check web/assets/js/core.js
node --check web/assets/js/rename.js
node --check web/assets/js/update.js
node --check web/assets/js/sheetmetal.js
```

输出目录父目录需存在；Java输出目录自身必须不存在。test_round4名称保留用于已有P1/core回归，不代表使用旧源文件；其加载本包最终源码。tests/check_onsite_inputs.py可只读核对输入是否齐全（不执行BAT）。

前端41项=27项现有P1/core+14项实际业务页面模拟；四项node --check退出0。Java完整编辑后主类对生成的SDK替身编译退出0、Stub class major61；这不是本轮真实SDK编译证据。补丁实际check/apply后复现最终文件字节，allMatch=true。

## 真实SDK暂存编译：本轮待执行

在源码副本应用补丁后，用唯一同步otk.jar；不编译tests为生产，不混pfcasync.jar，不输出到现场classes：

```powershell
& 'D:\creoson\jdk25\jdk-25.0.5+8\bin\javac.exe' --release 17 -encoding UTF-8 `
  -cp 'D:\Program Files\PTC\Creo 13.4.0.0\Common Files\text\java\otk.jar' `
  -d '<新的暂存目录>' '.\BatchRename.java'
```

期望退出0、生产major61；当前真实编译退出码=null、生产class major=null（未执行）。不得将Stub的major61填作生产结果。请在现场返回本轮编译日志、class数量/major/哈希，才可完成该离线验收条件。

## 验收状态与未执行项

当前**第五轮完整离线验收未通过：仍缺本轮真实otk.jar编译证据**，不能称“离线通过”，也不是发布包。已完成部分见evidence/summary.json；第四轮真实编译报告不能替代当前源码。

Windows真实detached启动、CREOSON身份连接、BAT输出/权限/junction、三Ribbon/五模式、重命名/关于页现场回归、现场部署/回滚均未执行。真实钣金创建/重生成/选择对象/材料侧/shell移除面/生产参数通道/转换保存/A4仍未实现。不修改BAT、rbn、config.pro；未回写现场生产源码、class或Web。云端无法核验远程现场文件是否被他人改动，本包“未部署”仅指本助手未执行部署。

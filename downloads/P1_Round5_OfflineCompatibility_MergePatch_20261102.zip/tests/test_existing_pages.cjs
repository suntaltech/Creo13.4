'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const parent=path.resolve(__dirname,'..'),root=fs.existsSync(path.join(parent,'updated'))?path.join(parent,'updated'):parent;
const evidence=[];let passed=0;
async function test(name,fn){await fn();passed++;console.log('PASS '+name);}
class Element{
 constructor(){this.style={};this.dataset={};this.children=[];this.value='';this.checked=false;this.disabled=false;this.textContent='';this.className='';this.listeners={};}
 addEventListener(k,f){this.listeners[k]=f;}appendChild(c){this.children.push(c);return c;}replaceChildren(...c){this.children=c;}
 setAttribute(){}remove(){}click(){return this.listeners.click?.();}
}
function fixture(kind,options={}){
 const html=fs.readFileSync(path.join(root,'web',kind+'.html'),'utf8'),ids={},calls=[],timers=new Map(),intervals=new Map(),timerMs=[],values=new Map();let serial=0,connectFailures=options.connectFailures||0;
 for(const m of html.matchAll(/<[^>]+\bid="([^"]+)"[^>]*>/g)){
  const e=ids[m[1]]=new Element(),tag=m[0],value=/\bvalue="([^"]*)"/.exec(tag);if(value)e.value=value[1];e.checked=/\bchecked\b/.test(tag);e.disabled=/\bdisabled\b/.test(tag);
  const style=/style="([^"]+)"/.exec(tag);if(style&&/display:none/.test(style[1]))e.style.display='none';
 }
 if(kind==='rename')Object.assign(ids.mode,{value:'prefix'});
 const files=['ROOT.ASM','A.PRT','SUB.ASM','B.PRT'];const renamed=new Map();
 const file=n=>renamed.get(n)||n;
 const bom=()=>({children:{file:'ROOT.ASM',children:[{file:file('A.PRT'),path:[1]},{file:file('SUB.ASM'),path:[2],children:[{file:file('B.PRT'),path:[2,1]}]}]}});
 const ctx={URL,URLSearchParams,AbortController,Blob,console,location:{search:options.search||''},
  document:{getElementById:id=>ids[id],createElement:()=>new Element(),body:new Element(),
   querySelectorAll:selector=>{const list=[];const visit=e=>{if(e.className==='include-row')list.push(e);for(const c of e.children)visit(c);};Object.values(ids).forEach(visit);return list;}},
  localStorage:{getItem:k=>values.get(k)??null,setItem:(k,v)=>values.set(k,String(v))},
  confirm:()=>options.confirm!==false,
  setTimeout(fn,ms){const id=++serial;timers.set(id,{fn,ms});timerMs.push(ms);return id;},clearTimeout:id=>timers.delete(id),
  setInterval(fn,ms){const id=++serial;intervals.set(id,{fn,ms});return id;},clearInterval:id=>intervals.delete(id),
  fetch:async(url,request)=>{
   if(url==='/version.json')return {ok:!options.localVersionFail,json:async()=>({version:'1.15.2'})};
   if(url!=='/creoson'){
    calls.push({url});assert.equal(url,'https://raw.githubusercontent.com/zcxkij/creo-tools/main/version.json');
    return {ok:true,json:async()=>options.remote||{version:'1.16.0',note:'mock update',download_url:'https://github.com/zcxkij/creo-tools/releases'}};
   }
   const p=JSON.parse(request.body),key=p.command+'/'+p.function;calls.push(p);
   if(key==='connection/connect'&&connectFailures-->0)throw new Error('mock unavailable');
   if(options.business===key)return {ok:true,json:async()=>({status:{error:true,message:'mock business failure'}})};
   if(options.networkOnce===key&&!options.networkUsed){options.networkUsed=true;throw new Error('mock network loss');}
   if(key==='connection/connect')return {ok:true,json:async()=>({status:{error:false},sessionId:'mock-real-page-session'})};
   const data={ 'file/get_active':{file:options.active||'ROOT.ASM'},'bom/get_paths':bom(),'file/list':{files:[...files]},'file/save':{} };
   if(key==='file/rename'){
    assert.equal(p.data.onlysession,true);assert.ok(files.includes(p.data.file));files[files.indexOf(p.data.file)]=p.data.new_name;renamed.set(p.data.file,p.data.new_name);data[key]={};
   }
   assert.ok(data[key],key);return {ok:true,json:async()=>({status:{error:false},data:data[key]})};
  }};
 ctx.window=ctx;Object.defineProperty(ctx,'external',{get(){throw new Error('no native browser access allowed');}});
 vm.createContext(ctx);
 const load=n=>vm.runInContext(fs.readFileSync(path.join(root,'web/assets/js',n),'utf8'),ctx,{filename:n});
 load('core.js');
 if(kind==='rename')load('rename.js');else{
  load('update.js');for(const m of html.matchAll(/<script>([\s\S]*?)<\/script>/g))vm.runInContext(m[1],ctx,{filename:'about-inline.js'});
 }
 async function flush(){for(let i=0;i<30;i++)await Promise.resolve();}
 async function runTimers(ms){for(const [id,t]of [...timers])if(t.ms===ms){timers.delete(id);await t.fn();}await flush();}
 return {ids,calls,ctx,files,timerMs,intervals,flush,runTimers,options,record(scenario){evidence.push(...ctx.SiswCore.events.map(e=>({executionContext:'actual_sources_mock_dom_http',scenario,...e})));}};
}
(async()=>{
 await test('actual rename/update consumers use existing SiswCore exports',async()=>{
  const f=fixture('rename');await f.flush();
  for(const file of ['rename.js','update.js']){
   const src=fs.readFileSync(path.join(root,'web/assets/js',file),'utf8');
   for(const m of src.matchAll(/\bcore\.([A-Za-z_$][\w$]*)/g))assert.ok(m[1] in f.ctx.SiswCore,file+': '+m[1]);
  }
  for(const name of ['connectSession','ensureSession','call','request','el','setStatus','setBusy','audit','downloadLog','bridgeCall','compareVersions','loadLocalVersion'])assert.equal(typeof f.ctx.SiswCore[name],'function');
  assert.equal(typeof f.ctx.SiswCore.debugMode,'boolean');assert.ok(Array.isArray(f.ctx.SiswCore.events));
 });
 await test('actual rename startup uses one normal 30-second connection',async()=>{
  const f=fixture('rename');await f.flush();assert.equal(f.calls.filter(p=>p.function==='connect').length,1);assert.equal(f.timerMs[0],30000);assert.equal(f.ids.previewBtn.disabled,false);
  assert.ok(!JSON.stringify(f.ctx.SiswCore.events).includes('mock-real-page-session'));f.record('rename-startup');
 });
 await test('actual rename connection failure re-enables preview; later preview can reconnect',async()=>{
  const f=fixture('rename',{connectFailures:1});await f.flush();assert.equal(f.ids.previewBtn.disabled,false);assert.match(f.ids.status.textContent,/未连接/);
  await f.ids.previewBtn.click();assert.match(f.ids.status.textContent,/预览完成/);assert.equal(f.calls.filter(p=>p.function==='connect').length,2);f.record('rename-startup-recover');
 });
 await test('actual rename preview and onlysession rename still work without implicit save',async()=>{
  const f=fixture('rename');await f.flush();await f.ids.previewBtn.click();assert.match(f.ids.status.textContent,/预览完成/);assert.equal(f.ids.executeBtn.disabled,false);
  await f.ids.executeBtn.click();assert.equal(f.calls.filter(p=>p.function==='rename').length,2);assert.ok(f.calls.filter(p=>p.function==='rename').every(p=>p.data.onlysession===true));assert.equal(f.calls.filter(p=>p.function==='save').length,0);f.record('legacy-rename-onlysession');
 });
 await test('actual legacy rename optional save remains distinct from P1 conversion',async()=>{
  const f=fixture('rename');await f.flush();await f.ids.previewBtn.click();f.ids.saveDisk.checked=true;await f.ids.executeBtn.click();
  assert.equal(f.calls.filter(p=>p.function==='save').length,1);assert.equal(f.intervals.size,0);assert.match(f.ids.status.textContent,/成功 2/);f.record('legacy-rename-optional-save-mock');
 });
 await test('actual rename cancellation makes no write',async()=>{
  const f=fixture('rename',{confirm:false});await f.flush();await f.ids.previewBtn.click();await f.ids.executeBtn.click();assert.equal(f.calls.filter(p=>['rename','save'].includes(p.function)).length,0);
 });
 await test('actual rename business failure does not reconnect or leave preview stuck',async()=>{
  const f=fixture('rename',{business:'file/get_active'});await f.flush();await f.ids.previewBtn.click();assert.match(f.ids.status.textContent,/预览失败/);assert.equal(f.ids.previewBtn.disabled,false);assert.equal(f.calls.filter(p=>p.function==='connect').length,1);f.record('rename-business-error');
 });
 await test('actual rename readonly uncertain request retains one reconnect',async()=>{
  const f=fixture('rename',{networkOnce:'file/get_active'});await f.flush();await f.ids.previewBtn.click();assert.match(f.ids.status.textContent,/预览完成/);assert.equal(f.calls.filter(p=>p.function==='get_active').length,2);assert.equal(f.calls.filter(p=>p.function==='connect').length,2);
 });
 await test('actual rename mode guard prevents bootstrap requests',async()=>{
  const f=fixture('rename',{search:'?guard=need_assembly'});await f.flush();assert.equal(f.calls.length,0);assert.equal(f.ids.previewBtn.disabled,true);
 });
 await test('actual about IDs and module text preserve script lifecycle',async()=>{
  const f=fixture('about');await f.flush();for(const id of ['versionLabel','updateBtn','mockUpdateBtn','downloadUpdate','updateInfo'])assert.ok(f.ids[id]);
  assert.match(f.ids.versionLabel.textContent,/1\.15\.2/);assert.equal(f.ids.mockUpdateBtn.style.display,'none');
  const html=fs.readFileSync(path.join(root,'web/about.html'),'utf8');assert.match(html,/当前仅提供.*只读适用性分析/);assert.ok(!html.includes('并按驱动曲面或抽壳方式转换'));
  assert.ok(html.indexOf('assets/js/core.js')<html.indexOf('assets/js/update.js'));
 });
 await test('actual about update check uses fixed HTTPS manifest and offers download only',async()=>{
  const f=fixture('about');await f.flush();await f.runTimers(300);assert.equal(f.calls.length,1);assert.ok(!f.calls.some(p=>p.command));
  assert.equal(f.ids.downloadUpdate.style.display,'inline-flex');assert.match(f.ids.updateInfo.textContent,/发现新版本/);f.record('about-version-check');
 });
 await test('actual about debug mock button shows only with debug=1',async()=>{
  const f=fixture('about',{search:'?debug=1'});await f.flush();assert.equal(f.ids.mockUpdateBtn.style.display,'');assert.equal(f.ids.mockUpdateBtn.disabled,false);
 });
 await test('actual about rejects non-HTTPS update download URL',async()=>{
  const f=fixture('about',{remote:{version:'2.0',download_url:'http://github.com/project/release'}});await f.flush();await f.ids.updateBtn.click();assert.equal(f.ids.downloadUpdate.style.display,'none');assert.match(f.ids.updateInfo.textContent,/更新检查失败/);f.record('about-invalid-update-link');
 });
 await test('actual about falls back to packaged version when local manifest missing',async()=>{
  const f=fixture('about',{localVersionFail:true});await f.flush();assert.match(f.ids.versionLabel.textContent,/1\.15\.2/);
 });
 if(process.argv[2])fs.writeFileSync(process.argv[2],evidence.map(e=>JSON.stringify(e)).join('\n')+'\n');
 console.log(`TOTAL ${passed} passed; actual supplied scripts with mock DOM/HTTP only; no live rename/save/update download/Creo operations`);
})().catch(e=>{console.error(e);process.exitCode=1;});

"""Inventory actual onsite inputs without executing BAT or printing file contents. Exit 2 = incomplete."""
from pathlib import Path
import argparse,hashlib,json
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
required=['creoson_run.bat','setvars.bat','rename.html','rename.js','about.html','update.js']
rows=[]
for name in required:
 matches=list(a.root.rglob(name)) if a.root.is_dir() else []
 if len(matches)!=1:
  rows.append({'file':name,'status':'missing' if not matches else 'ambiguous','matches':len(matches)})
 else:
  path=matches[0];data=path.read_bytes();row={'file':name,'status':'present','path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
  if name=='creoson_run.bat':
   row['matchesDocumentedBaseline']=row['sha256']=='f041b68e775130f6a217ce6111bdcadde531b8e042d02c1d4d54dedec6faeda1'
  rows.append(row)
ready=all(x['status']=='present' for x in rows)
a.output.parent.mkdir(parents=True,exist_ok=True)
a.output.write_text(json.dumps({'status':'inputs_present' if ready else 'blocked_missing_inputs','files':rows,'note':'Presence alone is not compatibility or runtime validation.'},ensure_ascii=False,indent=2)+'\n')
for x in rows:print(x['file']+': '+x['status'])
raise SystemExit(0 if ready else 2)

'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const parent = path.resolve(__dirname, '..');
const root = fs.existsSync(path.join(parent, 'updated')) ? path.join(parent, 'updated') : parent;
const records = [];
let checks = 0;
async function test(name, fn) { await fn(); checks++; console.log('PASS ' + name); }
function fixture(options = {}) {
  const ids = {}, calls = [], values = new Map(Object.entries(options.storage || {}));
  const timers = new Set(), timerSchedules = []; let fileReads = 0, connects = 0, once = false, bridgeCalls = 0, startupFailures = 0;
  function element(value = '') { return { value, checked: false, disabled: false, textContent: '', className: '',
    handlers: {}, addEventListener(k, f) { this.handlers[k] = f; } }; }
  for (const id of ['smtAnalyzeBtn','smtConvertBtn','smtThickness','smtSave','smtStatus','smtResult','smtThicknessUnit']) ids[id] = element();
  const modes = [element('driving'), element('shell')]; modes[0].checked = true;
  const context = {
    URLSearchParams, URL, AbortController, Blob, console,
    location: { search: options.search === undefined ? '?modelMode=solid_part' : options.search },
    localStorage: { getItem: k => values.get(k) ?? null, setItem: (k, v) => values.set(k, String(v)) },
    document: { getElementById: id => ids[id], querySelectorAll: () => modes,
      querySelector: selector => selector.includes(':checked') ? modes.find(m => m.checked) : modes.find(m => selector.includes(m.value)) },
    setTimeout(fn, ms) { timerSchedules.push(ms); const t = setTimeout(fn, options.fastTimers && ms === 1000 ? 0 : ms); timers.add(t); return t; },
    clearTimeout(t) { timers.delete(t); clearTimeout(t); },
    fetch: async (_url, request) => {
      if (_url === '/version.json') return { ok: true, json: async () => ({version: '2.3.4'}) };
      const p = JSON.parse(request.body), key = p.command + '/' + p.function; calls.push(p);
      if (key === 'connection/connect' && startupFailures++ < (options.startupFailures || 0)) throw new Error('service booting');
      if (options.networkOnce === key && !once) { once = true; throw new Error('transport failed secret-session-1'); }
      if (options.networkAlways === key) throw new Error('transport failed');
      if (options.timeout === key) { const e = new Error('aborted'); e.name = 'AbortError'; throw e; }
      if (options.business === key) return {ok: true, json: async () => ({status:{error:true,message:'private error secret-session-1'}})};
      if (key === 'file/get_fileinfo') fileReads++;
      const data = {
        'file/get_fileinfo': {file: options.changed && fileReads > 1 ? 'different.prt' : options.file || '测试功能02.prt', revision: options.revisionChanged && fileReads > 1 ? 2 : 1},
        'feature/list': {featlist: [{type:'WALL',status:'ACTIVE'}]},
        'geometry/get_surfaces': {surflist:[{surface_id:43, area:100, min_extent:{x:0,y:0,z:0}, max_extent:{x:30,y:20,z:0}}]},
        'geometry/bound_box': {xmin:0,xmax:337.5,ymin:0,ymax:75.75,zmin:0,zmax:389},
        'file/get_length_units': {units: options.units || 'mm'},
        'bom/get_paths': {paths:[]}
      };
      if (key === 'connection/connect') return {ok: true, json: async () => ({status:{error:false},sessionId:'secret-session-'+(++connects)})};
      assert.ok(data[key] || options.override?.[key], 'unexpected API: ' + key);
      return {ok:true, json:async()=>({status:{error:false}, data:options.override?.[key] || data[key]})};
    }
  };
  context.window = context; context.external = {ptc() {bridgeCalls++;}};
  vm.createContext(context);
  vm.runInContext(fs.readFileSync(root+'/web/assets/js/core.js','utf8'), context);
  if (!options.coreOnly) vm.runInContext(fs.readFileSync(root+'/web/assets/js/sheetmetal.js','utf8'), context);
  return {ids, calls, values, modes, timerSchedules, core:context.SiswCore, context,
    analyze:()=>ids.smtAnalyzeBtn.handlers.click(), get bridgeCalls(){return bridgeCalls;},
    dispose(){for(const t of timers)clearTimeout(t);}, record(label){records.push(...context.SiswCore.events.map(e=>({executionContext:'mock_http_dom',scenario:label,...e})));}};
}
(async()=>{
 await test('existing SiswCore API, storage, version tools preserved', async()=>{
  const f=fixture({coreOnly:true});
  for(const name of ['call','ensureSession','request','audit','setStatus','setBusy','downloadLog','el','bridgeCall','parseVersion','compareVersions','loadLocalVersion']) assert.equal(typeof f.core[name],'function',name);
  f.core.storage.set('x','1'); assert.equal(f.core.storage.get('x'),'1');
  assert.equal(f.core.compareVersions('2.0','1.9'),1);
  assert.equal(await f.core.loadLocalVersion(null,'1'),'2.3.4');
  await f.core.call('bom','get_paths'); assert.equal(f.calls.at(-1).command,'bom'); f.dispose();
 });
 await test('connect/sessionId and nested credential fields are absent from audit',async()=>{
  const f=fixture({coreOnly:true});await f.core.ensureSession();
  f.core.audit('test',{sessionId:f.core.sessionId,nested:{token:'token',message:'value '+f.core.sessionId}});
  const text=JSON.stringify(f.core.events);assert.ok(!text.includes('secret-session-'));assert.ok(!text.includes('"token":"token"'));f.dispose();
 });
 await test('core blocks all sisw-smt actions before native access',async()=>{
  const f=fixture({coreOnly:true});
  for(const action of ['convert','analyze','health','unknown','']) {
   await assert.rejects(f.core.bridgeCall({action}),/CHANNEL_BLOCKED/);
  }
  assert.equal(f.bridgeCalls,0);f.record('all-smt-actions-blocked');f.dispose();
 });
 await test('all incorrect model modes block before any fetch',async()=>{
  for(const mode of ['assembly','drawing','sheetmetal','no_model','no_session','other','unknown','']){
   const f=fixture({search:'?modelMode='+mode});assert.equal(f.ids.smtAnalyzeBtn.disabled,true);await f.analyze();assert.equal(f.calls.length,0);f.dispose();
  }
 });
 await test('explicit need_part and sheetmetal guards take precedence',async()=>{
  for(const suffix of ['&guard=need_part','&state=sheetmetal']){const f=fixture({search:'?modelMode=solid_part'+suffix});assert.equal(f.ids.smtAnalyzeBtn.disabled,true);f.dispose();}
 });
 await test('analysis reads actual units, pins files and labels heuristic candidates',async()=>{
  const f=fixture({units:'inch'});await f.analyze();
  const result=f.ids.smtResult.textContent;
  assert.match(result,/337\.500 inch/);assert.match(result,/长度单位：inch/);
  assert.match(f.ids.smtThicknessUnit.textContent,/输入契约按 mm.*inch.*未换算/);assert.match(result,/启发式/);assert.match(result,/IsSheetmetal.*需原生确认/);
  assert.ok(!result.includes('已是钣金零件'));assert.ok(!result.includes('337.500 mm'));
  assert.match(result,/非正式壁厚/);assert.equal(f.ids.smtThickness.value,'');
  const expected=['connection/connect','file/get_fileinfo','feature/list','geometry/get_surfaces','geometry/bound_box','file/get_length_units','file/get_fileinfo'];
  assert.deepEqual(f.calls.map(p=>p.command+'/'+p.function),expected);
  for(const p of f.calls.slice(2,-1)) assert.equal(p.data.file,'测试功能02.prt');
  assert.equal(f.ids.smtStatus.className,'ok');f.record('units-inch-analysis');f.dispose();
 });
 await test('unit business failure degrades to unknown, never assumes mm',async()=>{
  const f=fixture({business:'file/get_length_units'});await f.analyze();
  assert.match(f.ids.smtResult.textContent,/单位未确认/);assert.match(f.ids.smtThicknessUnit.textContent,/单位待确认/);assert.ok(!f.ids.smtResult.textContent.includes('337.500 mm'));
  assert.ok(f.core.events.some(e=>e.event==='smt_units_unconfirmed'));f.record('units-unconfirmed');f.dispose();
 });
 await test('malformed unit response is explicitly unconfirmed',async()=>{
  const f=fixture({override:{'file/get_length_units':{}}});await f.analyze();assert.match(f.ids.smtResult.textContent,/单位未确认/);f.dispose();
 });
 await test('existing network retry reconnects once and resumes readonly analysis',async()=>{
  const f=fixture({networkOnce:'geometry/get_surfaces'});await f.analyze();
  assert.equal(f.calls.filter(p=>p.function==='connect').length,2);
  assert.equal(f.calls.filter(p=>p.function==='get_surfaces').length,2);
  assert.equal(f.ids.smtStatus.className,'ok');assert.ok(!JSON.stringify(f.core.events).includes('secret-session-'));f.record('reconnect');f.dispose();
 });
 await test('persistent network failure remains failure and restores analyze button',async()=>{
  const f=fixture({networkAlways:'geometry/get_surfaces'});await f.analyze();assert.match(f.ids.smtStatus.textContent,/NETWORK_ERROR/);
  assert.equal(f.ids.smtAnalyzeBtn.disabled,false);assert.equal(f.ids.smtResult.textContent,'');f.record('network-failure');f.dispose();
 });
 await test('business failure preserves Chinese error and hides server details',async()=>{
  const f=fixture({business:'geometry/get_surfaces'});await f.analyze();assert.match(f.ids.smtStatus.textContent,/CREOSON_ERROR/);
  assert.ok(!f.ids.smtStatus.textContent.includes('private error'));assert.ok(!JSON.stringify(f.core.events).includes('secret-session-'));f.record('business-failure');f.dispose();
 });
 await test('timeout has an explicit failure outcome',async()=>{
  const f=fixture({timeout:'geometry/get_surfaces'});await f.analyze();assert.match(f.ids.smtStatus.textContent,/TIMEOUT/);f.dispose();
 });
 await test('active model change invalidates analysis',async()=>{
  const f=fixture({changed:true});await f.analyze();assert.match(f.ids.smtStatus.textContent,/MODEL_CHANGED/);assert.equal(f.ids.smtResult.textContent,'');f.record('model-changed');f.dispose();
 });
 await test('nonpart HTTP response blocks analysis',async()=>{
  const f=fixture({file:'test.asm'});await f.analyze();assert.match(f.ids.smtStatus.textContent,/NOT_PART/);assert.equal(f.calls.length,2);f.dispose();
 });
 await test('malformed geometry never becomes successful analysis',async()=>{
  for(const override of [{'geometry/get_surfaces':{}},{'geometry/bound_box':{xmin:2,xmax:1}}]){
   const f=fixture({override});await f.analyze();assert.match(f.ids.smtStatus.textContent,/INVALID_RESPONSE/);f.dispose();
  }
 });
 await test('busy guard rejects repeat clicks and controls stay disabled after analysis',async()=>{
  const f=fixture();const first=f.analyze();await f.analyze();await first;assert.equal(f.calls.filter(p=>p.function==='get_surfaces').length,1);
  for(const id of ['smtConvertBtn','smtThickness','smtSave'])assert.equal(f.ids[id].disabled,true);
  assert.ok(f.modes.every(m=>m.disabled));assert.equal(f.ids.smtSave.checked,false);f.dispose();
 });
 await test('direct conversion handler issues no native or HTTP write',async()=>{
  const f=fixture();await f.ids.smtConvertBtn.handlers.click();assert.equal(f.calls.length,0);assert.equal(f.bridgeCalls,0);
  assert.ok(f.core.events.some(e=>e.errorCode==='CHANNEL_BLOCKED'));f.dispose();
 });
 await test('localStorage mode/thickness preserved; stale save=true cleared',async()=>{
  const f=fixture({storage:{smt_mode:'shell',smt_thickness:'2.5',smt_save:'1'}});
  assert.equal(f.modes[1].checked,true);assert.equal(f.ids.smtThickness.value,'2.5');assert.equal(f.ids.smtSave.checked,false);assert.equal(f.values.get('smt_save'),'0');
  f.ids.smtSave.checked=true;f.ids.smtSave.handlers.change();assert.equal(f.ids.smtSave.checked,false);f.dispose();
 });
 await test('invalid saved thickness is cleared, never defaulted from bounds',async()=>{
  for(const raw of ['','0','-1','NaN','Infinity','20.1','0.099','1d','0x1','1,2','75.750']){
   const f=fixture({storage:{smt_thickness:raw}});assert.equal(f.ids.smtThickness.value,'');f.dispose();
  }
 });
 await test('explicit thickness boundaries remain available as stored parameters only',async()=>{
  for(const raw of ['0.1','1','20']){const f=fixture({storage:{smt_thickness:raw}});assert.equal(f.ids.smtThickness.value,raw);assert.equal(f.ids.smtThickness.disabled,true);f.dispose();}
 });
 await test('plugin-start connection retries then recovers without a write',async()=>{
  const f=fixture({startupFailures:2,fastTimers:true});await f.analyze();
  assert.equal(f.calls.filter(p=>p.function==='connect').length,3);assert.equal(f.ids.smtStatus.className,'ok');
  assert.equal(f.timerSchedules[0],3000);assert.equal(f.timerSchedules.filter(ms=>ms===1000).length,2);
  assert.equal(f.core.events.filter(e=>e.event==='connect_attempt_failed').length,2);f.record('startup-recovered');f.dispose();
 });
 await test('connection retry stops after four failures and reports unready service',async()=>{
  const f=fixture({startupFailures:99,fastTimers:true});await f.analyze();
  assert.equal(f.calls.length,4);assert.ok(f.calls.every(p=>p.function==='connect'));
  assert.match(f.ids.smtStatus.textContent,/服务未就绪/);assert.equal(f.ids.smtAnalyzeBtn.disabled,false);f.record('startup-exhausted');f.dispose();
 });
 await test('connection business failure is not blindly retried',async()=>{
  const f=fixture({business:'connection/connect',fastTimers:true});await f.analyze();assert.equal(f.calls.length,1);
  assert.match(f.ids.smtStatus.textContent,/CREOSON_ERROR/);f.dispose();
 });
 await test('all generic bridge keys are blocked without native access',async()=>{
  const f=fixture({coreOnly:true});
  Object.defineProperty(f.context,'external',{get(){throw new Error('native getter must not run');}});
  for(const bridgeKey of ['other-tool','sisw-smt',''])await assert.rejects(f.core.bridgeCall({bridgeKey,action:'analyze'}),/CHANNEL_BLOCKED/);
  assert.equal(f.bridgeCalls,0);f.dispose();
 });
 await test('legacy default session connection keeps one attempt and 30 second timeout',async()=>{
  const f=fixture({coreOnly:true,startupFailures:99,fastTimers:true});
  await assert.rejects(f.core.ensureSession());assert.equal(f.calls.length,1);assert.equal(f.timerSchedules[0],30000);f.dispose();
 });
 await test('legacy default request still preserves normal first-connection behavior',async()=>{
  const f=fixture({coreOnly:true});await f.core.call('bom','get_paths');
  assert.equal(f.calls.filter(p=>p.function==='connect').length,1);assert.equal(f.calls.at(-1).function,'get_paths');f.dispose();
 });
 await test('unit hint returns to unconfirmed when subsequent units read fails',async()=>{
  const options={units:'cm'},f=fixture(options);await f.analyze();assert.match(f.ids.smtThicknessUnit.textContent,/模型长度单位：cm/);
  options.business='file/get_length_units';await f.analyze();assert.match(f.ids.smtThicknessUnit.textContent,/单位待确认/);f.dispose();
 });
 if(process.argv[2])fs.writeFileSync(process.argv[2],records.map(e=>JSON.stringify(e)).join('\n')+'\n');
 console.log(`TOTAL ${checks} passed; simulated HTTP/DOM only; live CREOSON NOT RUN`);
})().catch(e=>{console.error(e);process.exitCode=1;});

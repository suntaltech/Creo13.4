import java.util.LinkedHashMap;
import java.util.Map;

/** TEST ONLY: no production entry point, SDK objects or model writes. */
public final class P1ClosedContract {
    private P1ClosedContract() {}
    static Map<String,Object> validate(Map<String,String> params) {
        try {
            if (params == null) throw new SmtInputError("INVALID_REQUEST", "缺少转换参数");
            if (params.containsKey("save") && !"false".equals(params.get("save"))) {
                throw new SmtInputError("SAVE_DISABLED", "当前版本禁止保存");
            }
            String mode = params.get("mode");
            if (!"driving".equals(mode) && !"shell".equals(mode)) {
                throw new SmtInputError("UNKNOWN_MODE", "请选择 driving 或 shell");
            }
            resolveConversionThickness(params);
            if (!"true".equals(params.get("confirm"))) {
                throw new SmtInputError("CONFIRM_REQUIRED", "需要明确确认测试副本且不保存");
            }
            return smtError("CHANNEL_BLOCKED", "仅离线契约，不提供原生转换入口");
        } catch (SmtInputError error) {
            return smtError(error.code, error.getMessage());
        }
    }
    private static final class SmtInputError extends IllegalArgumentException {
        final String code;
        SmtInputError(String code, String message) { super(message); this.code = code; }
    }

    private static double resolveConversionThickness(Map<String, String> params) {
        String raw = params.get("thickness");
        if (raw == null || !raw.trim().matches("(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)(?:[eE][+-]?[0-9]+)?")) {
            throw new SmtInputError("INVALID_THICKNESS", "板厚必须为 0.1–20 mm 的十进制数字");
        }
        double value;
        try { value = Double.parseDouble(raw.trim()); }
        catch (NumberFormatException error) {
            throw new SmtInputError("INVALID_THICKNESS", "板厚数值无效");
        }
        if (!Double.isFinite(value) || value < 0.1 || value > 20.0) {
            throw new SmtInputError("INVALID_THICKNESS", "板厚必须为 0.1–20 mm，禁止使用包围尺寸兜底");
        }
        return value;
    }

    private static Map<String, Object> smtError(String code, String message) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("ok", false);
        result.put("errorCode", code);
        result.put("message", message);
        result.put("nativeConvertReady", false);
        result.put("saved", false);
        return result;
    }

}

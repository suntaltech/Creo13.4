"use strict";
/* 系统工具模块：远程版本检查、受信任 GitHub 下载地址校验和调试模拟版本。 */
(function () {
  const UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/zcxkij/creo-tools/main/version.json";
  const MOCK_UPDATE_MANIFEST = {
    version: "9.9.9-mock",
    date: "2026-10-30",
    note: "【测试模拟】仅用于预览“发现新版本”提示和下载按钮，不会从远程下载，也不会覆盖当前程序。",
    download_url: "https://github.com/zcxkij/creo-tools/releases"
  };

  function createUpdatePanel(options) {
    const core = window.SiswCore;
    const versionLabel = core.el(options.versionLabel);
    const updateBtn = core.el(options.updateBtn);
    const mockBtn = core.el(options.mockBtn);
    const download = core.el(options.download);
    const info = core.el(options.info);
    const audit = options.audit || core.audit;
    const isBusy = options.isBusy || (() => false);
    const refreshButtons = options.refreshButtons || (() => { });

    let localVersion = options.fallbackVersion || "0.0.0";
    let updateChecking = false;
    let updateManifest = null;

    function validateUpdateManifest(manifest) {
      if (!manifest || typeof manifest.version !== "string" || typeof manifest.download_url !== "string")
        throw new Error("版本清单格式无效");
      if (manifest.note !== undefined && typeof manifest.note !== "string")
        throw new Error("更新说明格式无效");
      try {
        const parsedUrl = new URL(manifest.download_url);
        if (parsedUrl.protocol !== "https:" || !parsedUrl.hostname.endsWith("github.com"))
          throw new Error("host");
        return parsedUrl.href;
      } catch (_) {
        throw new Error("下载地址不是受信任的 GitHub HTTPS 地址");
      }
    }

    function resetUpdatePanel() {
      download.style.display = "none";
      info.style.display = "block";
      info.className = "info";
    }

    function renderUpdateStatus(manifest, downloadUrl, mock = false) {
      updateManifest = manifest;
      const result = core.compareVersions(manifest.version, localVersion);
      const dateText = manifest.date ? `（${manifest.date}）` : "";
      if (result > 0) {
        info.className = "ok";
        const badge = mock ? "【测试模拟】" : "";
        info.textContent = `${badge}发现新版本 v${manifest.version}${dateText}\n${manifest.note || "无更新说明"}\n下载完整安装包后，请退出 Creo 重新部署；网页不会自动覆盖当前插件类。`;
        download.href = downloadUrl;
        download.textContent = mock ? "演示：查看 Release 页面" : "下载完整安装包";
        download.style.display = "inline-flex";
        audit(mock ? "update_available_mock" : "update_available",
          { local: localVersion, remote: manifest.version, date: manifest.date, mock });
      } else if (result === 0) {
        info.className = "ok";
        info.textContent = `当前已是最新版本 v${localVersion}。`;
        audit("update_latest", { local: localVersion, remote: manifest.version, mock });
      } else {
        info.className = "info";
        info.textContent = `远程版本 v${manifest.version} 低于当前本地版本 v${localVersion}。`;
        audit("update_older", { local: localVersion, remote: manifest.version, mock });
      }
      refreshButtons();
    }

    async function checkUpdate(manual = true) {
      if (updateChecking) return;
      updateChecking = true;
      refreshButtons();
      resetUpdatePanel();
      info.textContent = "正在检查远程版本…";
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 10000);
      try {
        const response = await fetch(UPDATE_MANIFEST_URL, { signal: controller.signal, cache: "no-store" });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const manifest = await response.json();
        const downloadUrl = validateUpdateManifest(manifest);
        renderUpdateStatus(manifest, downloadUrl, false);
      } catch (error) {
        info.className = "err";
        info.textContent = manual
          ? `更新检查失败：${error.name === "AbortError" ? "网络超时" : error.message}。不影响业务功能。`
          : "";
        if (!manual) info.style.display = "none";
        audit("update_check_failed", { error: error.message, manual });
      } finally {
        clearTimeout(timer);
        updateChecking = false;
        refreshButtons();
      }
    }

    async function mockUpdate() {
      if (isBusy() || updateChecking) return;
      updateChecking = true;
      refreshButtons();
      resetUpdatePanel();
      info.textContent = "正在生成测试模拟版本…";
      try {
        await new Promise(resolve => setTimeout(resolve, 300));
        const downloadUrl = validateUpdateManifest(MOCK_UPDATE_MANIFEST);
        renderUpdateStatus(MOCK_UPDATE_MANIFEST, downloadUrl, true);
      } catch (error) {
        info.className = "err";
        info.textContent = `测试演示失败：${error.message}。`;
        audit("update_mock_failed", { error: error.message });
      } finally {
        updateChecking = false;
        refreshButtons();
      }
    }

    function refreshUpdateButtons() {
      updateBtn.disabled = isBusy() || updateChecking;
      mockBtn.style.display = core.debugMode ? "" : "none";
      if (core.debugMode) mockBtn.disabled = isBusy() || updateChecking;
    }

    async function init() {
      localVersion = await core.loadLocalVersion(versionLabel, options.fallbackVersion);
      refreshUpdateButtons();
      setTimeout(() => checkUpdate(false), 300);
    }

    updateBtn.addEventListener("click", () => checkUpdate(true));
    mockBtn.addEventListener("click", mockUpdate);

    return {
      init,
      checkUpdate,
      mockUpdate,
      refreshUpdateButtons,
      get localVersion() { return localVersion; },
      get updateManifest() { return updateManifest; }
    };
  }

  window.SiswUpdate = { createUpdatePanel };
})();

P1 第五轮离线补丁输入材料包
================================

用途：供 ChatGPT 核对 CREOSON 启动脚本、公共层 API 兼容性以及 about.html 文案修正。

包内文件：
1. runtime/creoson_run.bat
2. runtime/setvars.bat
3. web/rename.html
4. web/assets/js/rename.js
5. web/about.html
6. web/assets/js/update.js
7. SHA256_MANIFEST.txt

边界：
- 本包只含输入材料；不含生产 class、不含真实转换实现。
- runtime/creoson_run.bat 与 runtime/setvars.bat 默认只读核对，第五轮补丁不得直接修改。
- rename.js 的可选保存属于既有批量重命名流程，不等同于 P1 实体转钣金保存。
- 打包文件不代表真机启动、真实 CREOSON 连接或自动转钣金已经验收。
- 禁止在本轮新增 WCreateFeature、WRegenerate、模型 Save、原生浏览器桥接或 P1 保存入口。

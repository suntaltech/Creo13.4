set PROE_COMMON=D:\Program Files\PTC\Creo 13.4.0.0\Common Files
set PROE_ENV=x86e_win64

set JAVA_HOME=D:\creoson\jdk25\jdk-25.0.5+8

set JSON_PORT=9056

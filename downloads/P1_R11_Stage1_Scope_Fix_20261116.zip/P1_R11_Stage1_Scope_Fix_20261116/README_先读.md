# R11 Stage1 作用域隔离整改候选（2026-11-16）

本轮只修订配对逻辑及诊断保留。字段合同保持 v2，SHA256 仍为 ED3FFE8A6CE948B611BC6E27F40C2245AE605B21FB742B8B60F362270ABB4CF4；两个 PowerShell 文件与上一轮相同，哈希见 validation/source-relation.json。输入 V2 审核报告已经确认这些文件的本机 Parser、模板及提取门通过；**新配对器的真实校准仍需本机验收**。

先读 SCOPE_FIX_REVIEW.md。49 项测试通过，包含原有回归和新增作用域、基线保留与真实片段测试。PAIRING_CODE_REVIEW.diff 是核心 Python 差异供审阅；本包是完整源码候选，不部署、不覆盖已验收版本。

## 这次修正

- 只有目标 PID/代际/Irp 的当前未完成请求参与候选唯一性。其他 PID 的记录只作引用，不建目标锚点、不参与目标候选、不消耗或 taint 目标请求。
- 其他代际的旧挂起请求也不影响当前代际。正常配对消费后，同一 Irp 可顺序复用。
- 真正同作用域重叠仍保留歧义。ID24 没有 FileObject/FileKey/Offset/方向，不能拿这些请求侧字段或“最近一条”捏造完成侧的筛选条件。每个成功候选记录具体依据和序号。
- baseline-chain.jsonl 单独、不限采样地保留所见基线相关原始记录及配对/拒绝决策，即使普通诊断触限也保留。它只覆盖实际输入，不补事件。

## 本机审核与验收顺序

先复跑测试、PowerShell 语法检查和模板门：

```powershell
$ErrorActionPreference = 'Stop'
py -3 -m unittest discover -s tests -v
if ($LASTEXITCODE -ne 0) { throw '测试失败，停止' }
foreach ($ReviewTool in @('tools\Check-R11ProviderSchema.ps1','tools\Extract-R11.ps1')) {
    $ReviewTokens=$null
    $ReviewParseErrors=$null
    [void][System.Management.Automation.Language.Parser]::ParseFile(
        (Join-Path (Get-Location).Path $ReviewTool),[ref]$ReviewTokens,[ref]$ReviewParseErrors)
    if ($null -ne $ReviewParseErrors -and $ReviewParseErrors.Count -gt 0) { $ReviewParseErrors; throw '语法门失败' }
}
.\tools\Check-R11ProviderSchema.ps1 -OutputFile '.\provider-schema-scope-r1.json'
```

使用新输出目录，只读重放现存校准 ETL：

```powershell
$FormalEvidenceEtl='D:\creo-tools\build\p1-step41-r10-late-find-review-20261112\runtime-r11\formal.etl'
$CalibrationEvidenceEtl=Join-Path (Split-Path $FormalEvidenceEtl) 'calibrate.etl'
$OfflineReviewRoot='F:\P1_R11_Stage1_ScopeFix_20261116_R1'
.\tools\Extract-R11.ps1 -Etl $CalibrationEvidenceEtl -Mode calibration -OutputDirectory (Join-Path $OfflineReviewRoot 'cal-extract') -ProviderSchemaReport '.\provider-schema-scope-r1.json'
py -3 .\tools\pair_r11.py --input-dir (Join-Path $OfflineReviewRoot 'cal-extract') --output-dir (Join-Path $OfflineReviewRoot 'cal-pairs')
if ($LASTEXITCODE -ne 0) { throw '校准门未过，停止；保留诊断结果' }
```

也可先对上一轮已通过提取门的 V2 JSONL 做算法对照诊断（只读原目录，另写新输出目录）；哈希与合同门仍会逐项复核。不能把旧 v1 错字段提取件用于此目的。完整验收仍按本轮任务单要求先核模板、两遍提取，再配对。

校准所有验收门通过、accepted=true、calibration_gate=true、退出码 0 后，才读正式 ETL：

```powershell
.\tools\Extract-R11.ps1 -Etl $FormalEvidenceEtl -Mode formal -OutputDirectory (Join-Path $OfflineReviewRoot 'formal-extract') -ProviderSchemaReport '.\provider-schema-scope-r1.json'
py -3 .\tools\pair_r11.py --input-dir (Join-Path $OfflineReviewRoot 'formal-extract') --output-dir (Join-Path $OfflineReviewRoot 'formal-pairs') --calibration-report (Join-Path $OfflineReviewRoot 'cal-pairs\pairing-report.json')
if ($LASTEXITCODE -ne 0) { throw '正式验收门未通过，不升级结论' }
```

校准要求 offset 0 写完成 65B、offset 0 读完成 65B、offset 65 读操作以 EOF/0B 完成，且写完成先于读起始。EOF 不构成又读出 65B。输出目录存在就拒绝覆盖；不删除旧大日志，不重新采集，不改 Creo/配置/模型。

## 诊断保留口径（报告版本 3）

pairs、pending、baseline-chain 保留；目标作用域的 overlaps/unresolved/cross-context/missing-anchor 仍有每流 32MiB / 20,000 条上限。**目标必要诊断**省略仍使 diagnostic_details_complete=false、accepted=false、小计=null；不会靠调大上限或清空歧义强行通过。

其他 PID 的引用单独写 context-reference.jsonl，不再创建其操作图。该派生摘要可采样，计数和省略数明确登记，原 context-events.jsonl 全量保留且校验哈希。仅辅助摘要省略不关闭目标验收门；diagnostic_scope 明确此范围，ancillary_context_references_complete=false 仍如实报告。它不等于原始事件丢失，也不影响候选状态。与基线有关的原始记录/决定另入不采样的 baseline-chain。

计数 pairs/ambiguous/overlap/pending 现在仅描述目标 PID，不能直接与旧版混入其他 PID 的总数比较。foreign_context_records 另列，target_event_counts 仍须与原提取/正式基线逐项对齐。

## 最小回传

先发新校准 pairing-report.json、extraction.json、模板/语法门结果，以及 baseline-chain.jsonl（基线文件通常很小）。若链因真歧义较大，先发报告及首个基线拒绝点附近少量记录，完整链留本机，不删除。

若仍有 genuine same-scope 歧义，回传首次形成重叠时的请求、其先前未完成请求和对应完成；无需重采、无需发整份 ETL。正式 ETL 在校准未过前保持不读。

validation/scope-fragment-review.json 只重放本轮给出的六条事件，得到三个片段内候选。片段没有此前挂起历史和 Open 锚点，文件级成功字节仍为 null/不可确认，不能当作全量校准通过。交接的其他 PID 摘要缺时间戳/完整属性，没有被伪造成可运行原始事件。

# 当前审核入口

本轮请读 SCOPE_FIX_REVIEW.md 和 README_先读.md。上一轮字段布局核对保留在 reference/FIELD_LAYOUT_REVIEW_PREVIOUS.md，作为历史依据；本轮沿用已验证合同，不重猜字段。

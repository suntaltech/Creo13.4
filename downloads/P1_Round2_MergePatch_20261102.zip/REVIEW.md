# P1 第二轮：只读分析 + 安全阻断 + 合并适配

本包基于用户交接包中四个当前文件生成，输入五项 SHA-256 全部匹配。只修改：`BatchRename.java`、`web/assets/js/core.js`、`web/assets/js/sheetmetal.js`、`web/sheetmetal.html`。没有独立 P1Core/demo、额外生产 Java 包、生产 class 或 SDK 替身 class。未改 `.dat`、RBN、重命名页或关于页。

**本包用于代码审核及暂存编译，不是现场部署许可；未完成真实 SDK 编译和 Creo 验收。**

## 使用补丁

`P1_Round2.patch` 的路径相对于现有 package 目录，基线精确对应此次交接源码；先备份工作文件、核对 `input-sha256.json`，然后在副本内：

```sh
git apply --check P1_Round2.patch
git apply P1_Round2.patch
```

补丁需在有这四个基线文件的目录应用。若文件已改动，不强行覆盖，应先审查冲突。包内四个同路径源码是补丁应用后的结果，便于逐文件比较，不应盲目复制到现场运行目录。`SHA256SUMS.txt` 用于核对本包源文件、补丁、测试及证据；它不是第三方签名。

## 逐文件修改与理由

### BatchRename.java

- 保留默认包、`public static start()/stop()`、三个命令 ID、图标/消息键、浏览器窗口回退及 URL 守卫。普通零件 URL 增加 `modelMode=solid_part`，供前端首次渲染守卫使用；钣金标志检查失败、无默认体或文件名不符返回 unknown，不再按普通零件放行。
- `SHEETMETAL_BRIDGE_ENABLED=false` 不变。删除整个浏览器监听实现、后台桥接注册器、原生指针反射包装，以及相关 imports/字段；不存在 dormant 的原生注册分支。没有调用 AddBrowserMessageListener。
- 删除原元素树创建、最大平面自动选择、WFC 创建、重生成和保存代码，以及原生几何分析/包围厚度估算的桥接分支。同步删除只供这些代码使用的 SDK imports、辅助方法、类型和字段，避免悬空引用。仅保留三个命令和模式识别本来使用的 SDK 接口。
- `convertActivePart(Map<String,String>)` 直接位于原默认包主类：纯参数校验后返回 `{ok:false,errorCode:CHANNEL_BLOCKED,nativeConvertReady:false,saved:false}`；不能绕过“未注册监听”触发创建。无效参数分别返回 INVALID_REQUEST / SAVE_DISABLED / UNKNOWN_MODE / INVALID_THICKNESS / CONFIRM_REQUIRED。不得把此错误 envelope 再包成 `replyOk`；原 replyOk/bridge dispatcher 已一并删除。
- 两种模式统一显式十进制板厚 0.1–20 mm，拒绝空值、非有限数、十六进制、后缀等；不设置模式默认值、不使用任何包围尺寸兜底。`save` 缺省 false，非字面 `false`（包括 true）均拒绝。
- **关闭入口不读取原生对象**：不接受网页对模型/多实体/曲面的声明作为授权，所有模型在通道关闭时都被阻断。当前没有新增实体数查询或提供 NO_BODY/MULTI_BODY 专项转换诊断；相关 SDK 签名/模型状态检查仍需真实 SDK 与 UI 线程方案确认。不能把 CHANNEL_BLOCKED 误读为“多实体已检测通过”。
- 删除启动时最长约20秒的 CREOSON 网络探测/睡眠轮询和自动拉起外部进程。必须由用户现有启动器先运行 CREOSON；前端自动连接/重连保留。这是避免插件启动阻塞的明确行为变化，不是保留了服务自动启动能力。
- 日志器是主类内部辅助类，由首次 `start()` 日志懒初始化；只将文本/堆栈放入128条有界队列，后台线程不调用 Creo。`stop()` 先解除命令回调、记日志，再 `shutdown()`；不等待磁盘/队列，也不因丢弃或 IO 失败抛异常。后台退出追加 `audit_shutdown dropped=N`。再次 start 可建立新队列。无需部署额外 `creo.p1` 或接入旧 JsonlAudit。

这些删除消除了未验证写接口的编译依赖；完整编辑后源码已用**生成的最小 SDK 替身**编译并做行为测试，仍不能保证真实 otk.jar 编译通过。所有保留 SDK 调用主要来自原交接源码；没有据此声称 SDK 签名已经验证。

### web/assets/js/core.js

保留 `window.SiswCore` 现有对象 API、`request/call/ensureSession`、自动连接和既有一次通信失败重连、status、busy、storage、downloadLog、版本工具及通用 bridge API。仅增量：

- connected 审计不再存储 sessionId；审计递归遮蔽凭据键和当前 sessionId 文本。
- `bridgeCall` 对 `sisw-smt` 的 convert 请求在检查 `window.external` 之前就返回 CHANNEL_BLOCKED。其他已有桥接行为不变；钣金页面本轮完全不调用 bridgeCall。

没有为 P1 重建/替换公共层，也没有改变其他页面的 HTTP 重试策略。原有通用不确定错误重试及业务错误行为被保留；现场过期会话消息的具体处理仍应回归，未宣称所有会话错误形态都已解决。

### web/assets/js/sheetmetal.js

- 页面仍通过原 `SiswCore` 做连接、请求、重试、审计和 storage。
- P1 局部只读白名单：get_fileinfo、feature/list、get_surfaces、bound_box、get_length_units；连接由 core 管理。所有几何、特征、单位请求带首次读到的 `file`；结尾二次读取当前模型名及 revision，发生变化则拒绝结果。
- 新增真实单位读取，按返回字符串展示（如 mm/cm/inch）；读取失败/无效则显示“单位未确认”，仍可提供其他只读结果。绝不把未确认单位的包络尺寸显示为 mm。没有做单位转换或修改模型单位。
- 删除根据 WALL/FLAT 等特征类型猜测 IsSheetmetal 的判断；状态明确需原生确认。保留原布局的包络启发式展示，但改名为“启发式包络候选”，明确不是官方平面类型、不可作选择句柄。最小包络跨度标明“非正式壁厚”，不写入板厚，不自动选择转换方式。
- 首次渲染优先检查 need_part / sheetmetal，再检查 modelMode。转换方式、板厚、保存、转换继续禁用；直接调用点击处理器也只记 CHANNEL_BLOCKED，不发 HTTP 或原生写请求。
- 保留 smt_mode 和合法 smt_thickness 的本地记忆；非法板厚清空，不自动填1mm。历史 smt_save=true 清为 false。用户未输入的板厚保持未指定。
- 中文错误区分 NOT_PART、MODEL_CHANGED、INVALID_RESPONSE、TIMEOUT、NETWORK_ERROR、CREOSON_ERROR；不显示远端原始错误或堆栈。分析首尾和只读请求阶段使用同一 requestId。

### web/sheetmetal.html

只增加方式选择的初始 disabled、去掉默认板厚1mm、澄清候选/单位说明。保留 CSS `assets/css/base.css`、全部原 ID、DOM 布局和两个脚本引用。

## 离线验证与复跑

包内 `tests/` 是离线辅助工具，不部署到现场。Node测试加载实际修改后的 core.js 和 sheetmetal.js，检查公共 API 与行为；Java测试对**整个修改后的 BatchRename.java**用生成的 SDK 替身编译。替身只覆盖测试所需的声明，绝不能替代 otk.jar 做生产构建。

```sh
node --check web/assets/js/core.js
node --check web/assets/js/sheetmetal.js
node tests/test_round2.cjs /绝对路径/frontend-mock.jsonl
python3 tests/run_java.py --jdk /真实JDK目录 --output /新建且不存在的输出目录
```

预期：命令退出0；20项前端行为检查、49项Java替身行为检查；class major=61。Java覆盖参数拒绝、独立关闭入口、不访问原生对象、模式守卫、三个模拟命令回调，以及日志IO阻塞/队列溢出/卸载/重载。它**不是**三个 Ribbon 命令的真实 UI 无阻塞验收。

`evidence/summary.json` 记录本轮命令退出码、输入/输出源码哈希和未执行检查；所有 mock 日志明确标记测试上下文。由于压力测试故意制造队列溢出，Java审计可能不完整，`audit_shutdown dropped=N` 应非零；这用于验证退出不被日志丢弃阻断，不是持久审计完整性证明。

没有收到新版 rename.html/js、about.html/js 或 base.css；仅能保证未改这些文件，并验证公共 API 保留。**现有完整重命名页面与关于页面的现场回归未执行**。

## 现场暂存编译命令（本轮未执行）

先在源码副本应用补丁，将 `<输出目录>` 设为新暂存目录，禁止直接指向 `D:\creo-tools\jlink\classes`：

```powershell
& 'D:\creoson\jdk25\jdk-25.0.5+8\bin\javac.exe' --release 17 -encoding UTF-8 `
  -cp 'D:\Program Files\PTC\Creo 13.4.0.0\Common Files\text\java\otk.jar' `
  -d '<输出目录>' '.\BatchRename.java'
node --check .\web\assets\js\core.js
node --check .\web\assets\js\sheetmetal.js
```

预期退出0，但真实 Java SDK 编译尚无证据。classpath 唯一 otk.jar，不得混入 pfcasync.jar。使用JDK25编译release17不代表 Creo运行JVM支持JDK25。

## 后续声明式元素树规格（本轮不可执行）

根386 level0/null；其余 level1。共同387=32、1964特征名、6612真实默认体选择角色、3332显式正板厚；driving 的1131=15、5111真实驱动曲面；shell 的1131=24、73可选人工确认移除曲面。这里仅作规格描述，不构造 Selection/ElementTree，不调用 SDK。7185、6876、6284、6285 均不进入本轮可执行路径；材料侧499与切换侧3333不猜枚举值。

## 本轮未实现与真机前置条件

未实现 WFC 创建、真实选择句柄、抽壳移除面、材料侧方向、原生线程/参数通道、真实多实体诊断、真机转换、保存、备份恢复、现场class部署、A4批量转换。

进入后续阶段前必须：补丁审核；完整真实 SDK 编译退出0；真实 CREOSON2.8.2只读分析及单位确认；三命令真实 UI 无阻塞；新版重命名/关于页回归；在测试副本上确认独立原生命令动作方案。全过程保持通道关闭、saved=false，禁止直接修改原零件或启用转换。

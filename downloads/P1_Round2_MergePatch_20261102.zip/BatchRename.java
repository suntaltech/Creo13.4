import com.ptc.pfc.pfcCommand.DefaultUICommandActionListener;
import com.ptc.pfc.pfcCommand.UICommand;
import com.ptc.pfc.pfcModel.Model;
import com.ptc.pfc.pfcModel.ModelType;
import com.ptc.pfc.pfcSession.CreoCompatibility;
import com.ptc.pfc.pfcSession.Session;
import com.ptc.pfc.pfcSession.pfcSession;
import com.ptc.pfc.pfcSolid.SolidBody;
import com.ptc.pfc.pfcWindow.Window;
import com.ptc.pfc.pfcWindow.Windows;
import com.ptc.wfc.wfcSolid.WSolid;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Creo 13 同步 J-Link 入口：注册原生命令、打开内嵌页面，钣金仅作只读分析与安全阻断。
 * 不创建 AsyncConnection，不请求 CREOSON，不在命令回调中等待网络或启动子进程。
 * 必须使用本机 Creo 13 的同步 SDK archive 编译，不混入 pfcasync.jar。
 */
public final class BatchRename {
    private static final String MESSAGES = "batchrename.txt";
    private static final String RENAME_COMMAND = "SISWBatchRename";
    private static final String RENAME_PAGE = "http://localhost:9056/rename.html";
    private static final String RENAME_ICON = "batchrename.png";
    private static final String SMT_COMMAND = "SISWSheetMetal";
    private static final String SMT_PAGE = "http://localhost:9056/sheetmetal.html";
    private static final String SMT_ICON = "sheetmetal.png";
    private static final String ABOUT_COMMAND = "SISWAbout";
    private static final String ABOUT_PAGE = "http://localhost:9056/about.html";
    private static final String ABOUT_ICON = "about.png";
    // WFC AddBrowserMessageListener 在当前 Creo 13.4 同步会话中会长期占用 CIP 原生通道；
    // 先关闭原生浏览器监听，钣金页面通过 CREOSON HTTP 与后续可用的原生路径处理，避免阻塞 Ribbon 命令回调。
    private static final boolean SHEETMETAL_BRIDGE_ENABLED = false;

    private static Session session;
    private static final java.util.List<UICommand> commands = new java.util.ArrayList<>();
    private static final java.util.List<OpenPageListener> listeners = new java.util.ArrayList<>();
    private static boolean active;
    private static boolean opening;

    private BatchRename() { }

    /** 同步注册入口必须是 public static void 且无参数。 */
    public static void start() throws Exception {
        if (active) {
            log("start ignored: already active", null);
            return;
        }
        if (!listeners.isEmpty()) {
            throw new IllegalStateException("Previous listener detach failed; restart Creo before reloading");
        }
        log("start entered; java=" + System.getProperty("java.version"), null);
        try {
            // 显式设置兼容性，避免先用 GetProESession() 进入旧的 C3 兼容模式。
            session = pfcSession.GetCurrentSessionWithCompatibility(CreoCompatibility.C4Compatible);
            if (session == null) {
                throw new IllegalStateException("No synchronous Creo session");
            }
            log("synchronous session acquired", null);
            log("CREOSON must be started externally; startup does not wait for network", null);

            registerPageCommand(RENAME_COMMAND, new OpenPageListener(RENAME_COMMAND, RENAME_PAGE),
                    "SISW_BR_LABEL", "SISW_BR_HELP", "SISW_BR_DESC", RENAME_ICON);
            registerPageCommand(SMT_COMMAND, new OpenPageListener(SMT_COMMAND, SMT_PAGE),
                    "SISW_SMT_LABEL", "SISW_SMT_HELP", "SISW_SMT_DESC", SMT_ICON);
            registerPageCommand(ABOUT_COMMAND, new OpenPageListener(ABOUT_COMMAND, ABOUT_PAGE),
                    "SISW_ABOUT_LABEL", "SISW_ABOUT_HELP", "SISW_ABOUT_DESC", ABOUT_ICON);
            log("three native page commands registered", null);

            // 不包装原生会话，也不注册浏览器监听。
            ensureSheetmetalBridgeAsync();

            active = true;
            log("command designated", null);
            log("start returned", null);
            // 功能区位置由首次自定义导出的 .rbn 或用户现有 Ribbon 配置负责。
        } catch (Exception ex) {
            log("start failed", ex);
            detach();
            throw ex; // 让辅助应用程序显示真正的加载错误，而不是伪报启动成功。
        } catch (LinkageError ex) {
            log("JAR/class version or linkage error", ex);
            detach();
            throw ex;
        }
    }

    /** 停止时只解除回调，不退出 Creo，不关闭浏览器，不修改模型。 */
    public static void stop() {
        log("stop entered", null);
        active = false;
        detach();
        log("stop returned", null);
        closeLog();
    }

    /** 第二轮明确关闭：不创建 WFC 包装、不注册监听、不启动等待原生消息的线程。 */
    private static void ensureSheetmetalBridgeAsync() {
        log("sheetmetal native channel disabled; nativeConvertReady=false; saved=false", null);
    }

    private static UICommand registerPageCommand(String commandId, OpenPageListener pageListener,
                                                  String labelKey, String helpKey, String descriptionKey,
                                                  String iconName) throws Exception {
        UICommand pageCommand = session.UICreateCommand(commandId, pageListener);
        pageCommand.Designate(MESSAGES, labelKey, helpKey, descriptionKey);
        try {
            pageCommand.SetIcon(iconName);
            log("icon registered: " + commandId + " -> " + iconName, null);
        } catch (Exception | LinkageError iconError) {
            log("icon registration failed for " + commandId + "; command remains available with default icon", iconError);
        }
        commands.add(pageCommand);
        listeners.add(pageListener);
        return pageCommand;
    }

    private static void detach() {
        active = false;
        for (int i = 0; i < commands.size(); i++) {
            try {
                commands.get(i).RemoveActionListener(listeners.get(i));
            } catch (Exception ex) {
                log("listener detach failed; restart Creo before reloading", ex);
            }
        }
        commands.clear();
        listeners.clear();
        session = null;
    }

    /** 原生回调只发出本模块浏览器导航，随后立即把控制权交回 Creo。 */
    private static final class OpenPageListener extends DefaultUICommandActionListener {
        private final String commandId;
        private final String pageUrl;

        private OpenPageListener(String commandId, String pageUrl) {
            this.commandId = commandId;
            this.pageUrl = pageUrl;
        }

        @Override
        public void OnCommand() {
            if (!active) {
                log("OnCommand ignored: plugin inactive; target=" + pageUrl, null);
                return;
            }
            if (opening) {
                log("OnCommand ignored: previous navigation still running; target=" + pageUrl, null);
                return;
            }
            if (session == null) {
                log("OnCommand ignored: J-Link session null; target=" + pageUrl, null);
                return;
            }
            opening = true;
            String targetUrl = guardedPageUrl(commandId, pageUrl);
            log("OnCommand entered; command=" + commandId + "; target=" + targetUrl, null);
            try {
                Window window = null;
                try {
                    window = session.GetCurrentWindow();
                } catch (Throwable currentWindowError) {
                    log("GetCurrentWindow failed; trying window list", currentWindowError);
                }
                if (window == null) {
                    try {
                        Windows windows = session.ListWindows();
                        if (windows != null && windows.getarraysize() > 0) {
                            window = windows.get(0);
                            log("using first listed Creo window after current window was null", null);
                        }
                    } catch (Throwable listWindowsError) {
                        log("ListWindows fallback failed", listWindowsError);
                    }
                }
                if (window == null) {
                    log("No available Creo window; cannot open " + pageUrl, null);
                    return;
                }
                String currentUrl = null;
                try {
                    currentUrl = window.GetURL();
                } catch (Exception urlError) {
                    log("current window URL unavailable", urlError);
                }
                if (currentUrl == null || !currentUrl.equals(targetUrl)) {
                    window.SetURL(targetUrl);
                    log("browser navigation issued; target=" + targetUrl, null);
                } else {
                    log("browser tab already open; reusing existing tab", null);
                }
                window.SetBrowserSize(80.0);
                window.Activate();
                window.Refresh();
                log("browser activated; currentUrl=" + currentUrl + "; OnCommand returned", null);
            } catch (Exception ex) {
                log("open embedded browser failed", ex);
            } finally {
                opening = false;
            }
        }
    }

    private static String detectActiveModelMode() {
        if (session == null) {
            return "no_session";
        }
        Model model;
        try {
            model = session.GetActiveModel();
        } catch (Throwable detectionError) {
            log("active model detection failed", detectionError);
            return "unknown";
        }
        if (model == null) {
            return "no_model";
        }
        ModelType type;
        try {
            type = model.GetType();
        } catch (Throwable typeError) {
            log("active model type detection failed", typeError);
            return "unknown";
        }
        if (type == ModelType.MDL_ASSEMBLY) {
            return "assembly";
        }
        if (type == ModelType.MDL_DRAWING) {
            return "drawing";
        }
        if (type == ModelType.MDL_PART) {
            try {
                String fileName = model.GetFileName();
                if (fileName == null || !fileName.toLowerCase(java.util.Locale.ROOT).endsWith(".prt")) return "unknown";
                WSolid solid = (WSolid) model;
                SolidBody body = solid.GetDefaultBody();
                if (body == null) return "unknown";
                if (body.IsSheetmetal()) {
                    return "sheetmetal";
                }
            } catch (Throwable sheetmetalCheckIgnored) {
                log("sheetmetal flag check unavailable; fail closed as unknown", sheetmetalCheckIgnored);
                return "unknown";
            }
            return "solid_part";
        }
        return "other";
    }

    private static String guardedPageUrl(String commandId, String baseUrl) {
        String mode = detectActiveModelMode();
        if (RENAME_COMMAND.equals(commandId) && !"assembly".equals(mode)) {
            return appendPageQuery(baseUrl, "guard", "need_assembly", "modelMode", mode);
        }
        if (SMT_COMMAND.equals(commandId)) {
            if ("sheetmetal".equals(mode)) {
                return appendPageQuery(baseUrl, "state", "sheetmetal", "modelMode", mode);
            }
            if (!"solid_part".equals(mode)) {
                return appendPageQuery(baseUrl, "guard", "need_part", "modelMode", mode);
            }
            return appendPageQuery(baseUrl, "modelMode", mode);
        }
        return baseUrl;
    }

    private static String appendPageQuery(String baseUrl, String... pairs) {
        try {
            URL source = new URL(baseUrl);
            StringBuilder query = new StringBuilder(source.getQuery() == null ? "" : source.getQuery());
            for (int i = 0; i + 1 < pairs.length; i += 2) {
                if (query.length() > 0) {
                    query.append('&');
                }
                query.append(URLEncoder.encode(pairs[i], StandardCharsets.UTF_8));
                query.append('=');
                query.append(URLEncoder.encode(pairs[i + 1], StandardCharsets.UTF_8));
            }
            String result = source.getProtocol() + "://" + source.getHost()
                    + (source.getPort() == -1 ? "" : ":" + source.getPort()) + source.getPath();
            if (query.length() > 0) {
                result += "?" + query;
            }
            return result;
        } catch (Exception queryError) {
            log("guard query assembly failed; using base page url", queryError);
            return baseUrl;
        }
    }

    /** 纯参数校验，不读取 Creo 对象；关闭入口是独立于浏览器监听的第二道保护。 */
    private static Map<String, Object> convertActivePart(Map<String, String> params) {
        String requestId = java.util.UUID.randomUUID().toString();
        auditSmt(requestId, "request_received", "pending", "");
        try {
            if (params == null) throw new SmtInputError("INVALID_REQUEST", "缺少转换参数");
            if (params.containsKey("save") && !"false".equals(params.get("save"))) {
                throw new SmtInputError("SAVE_DISABLED", "当前版本禁止保存");
            }
            String mode = params.get("mode");
            if (!"driving".equals(mode) && !"shell".equals(mode)) {
                throw new SmtInputError("UNKNOWN_MODE", "请选择 driving 或 shell");
            }
            resolveConversionThickness(params);
            if (!"true".equals(params.get("confirm"))) {
                throw new SmtInputError("CONFIRM_REQUIRED", "需要明确确认测试副本且不保存");
            }
            auditSmt(requestId, "validation", "passed", "");
            // 不读取模型、不创建元素树，不信任网页提供的模型/实体/曲面状态。
            // 所有模型（含非当前零件、无默认体、多实体）在通道关闭时一律阻断。
            auditSmt(requestId, "native_channel", "blocked", "CHANNEL_BLOCKED");
            return smtError("CHANNEL_BLOCKED", "安全原生通道尚未验收，未创建特征、未保存");
        } catch (SmtInputError error) {
            auditSmt(requestId, "validation", "rejected", error.code);
            return smtError(error.code, error.getMessage());
        }
    }

    private static final class SmtInputError extends IllegalArgumentException {
        final String code;
        SmtInputError(String code, String message) { super(message); this.code = code; }
    }

    private static double resolveConversionThickness(Map<String, String> params) {
        String raw = params.get("thickness");
        if (raw == null || !raw.trim().matches("(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)(?:[eE][+-]?[0-9]+)?")) {
            throw new SmtInputError("INVALID_THICKNESS", "板厚必须为 0.1–20 mm 的十进制数字");
        }
        double value;
        try { value = Double.parseDouble(raw.trim()); }
        catch (NumberFormatException error) {
            throw new SmtInputError("INVALID_THICKNESS", "板厚数值无效");
        }
        if (!Double.isFinite(value) || value < 0.1 || value > 20.0) {
            throw new SmtInputError("INVALID_THICKNESS", "板厚必须为 0.1–20 mm，禁止使用包围尺寸兜底");
        }
        return value;
    }

    private static Map<String, Object> smtError(String code, String message) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("ok", false);
        result.put("errorCode", code);
        result.put("message", message);
        result.put("nativeConvertReady", false);
        result.put("saved", false);
        return result;
    }

    private static void auditSmt(String requestId, String stage, String outcome, String code) {
        Map<String, Object> event = new LinkedHashMap<>();
        event.put("schemaVersion", "1");
        event.put("timestamp", Instant.now().toString());
        event.put("source", "java-closed-entry");
        event.put("requestId", requestId);
        event.put("stage", stage);
        event.put("outcome", outcome);
        event.put("errorCode", code);
        event.put("nativeConvertReady", false);
        event.put("saved", false);
        log("P1_AUDIT " + toJson(event), null);
    }

    private static String toJson(Object value) {
        StringBuilder out = new StringBuilder();
        appendJson(out, value);
        return out.toString();
    }

    private static void appendJson(StringBuilder out, Object value) {
        if (value == null) {
            out.append("null");
        } else if (value instanceof String) {
            appendJsonString(out, (String) value);
        } else if (value instanceof Boolean) {
            out.append(value.toString());
        } else if (value instanceof Number) {
            out.append(value.toString());
        } else if (value instanceof Map) {
            out.append('{');
            boolean first = true;
            for (Map.Entry<?, ?> entry : ((Map<?, ?>) value).entrySet()) {
                if (!first) out.append(',');
                first = false;
                appendJsonString(out, String.valueOf(entry.getKey()));
                out.append(':');
                appendJson(out, entry.getValue());
            }
            out.append('}');
        } else if (value instanceof Iterable) {
            out.append('[');
            boolean first = true;
            for (Object item : (Iterable<?>) value) {
                if (!first) out.append(',');
                first = false;
                appendJson(out, item);
            }
            out.append(']');
        } else {
            appendJsonString(out, String.valueOf(value));
        }
    }

    private static void appendJsonString(StringBuilder out, String text) {
        out.append('"');
        for (char c : text.toCharArray()) {
            switch (c) {
                case '"' -> out.append("\\\"");
                case '\\' -> out.append("\\\\");
                case '\n' -> out.append("\\n");
                case '\r' -> out.append("\\r");
                case '\t' -> out.append("\\t");
                default -> {
                    if (c < 0x20) {
                        out.append(String.format("\\u%04x", (int) c));
                    } else {
                        out.append(c);
                    }
                }
            }
        }
        out.append('"');
    }

    private static LogWorker logWorker;

    /** 仅后台写日志；有界队列满时计数，卸载不等待 IO、不因丢弃/写入失败抛异常。 */
    private static final class LogWorker extends java.util.concurrent.ThreadPoolExecutor {
        final java.util.concurrent.atomic.AtomicLong dropped = new java.util.concurrent.atomic.AtomicLong();
        LogWorker() {
            super(1, 1, 0, java.util.concurrent.TimeUnit.SECONDS,
                    new java.util.concurrent.ArrayBlockingQueue<>(128), runnable -> {
                        Thread thread = new Thread(runnable, "sisw-diagnostic-log");
                        thread.setDaemon(true);
                        return thread;
                    }, new java.util.concurrent.ThreadPoolExecutor.AbortPolicy());
        }
        @Override protected void terminated() {
            writeLog("audit_shutdown dropped=" + dropped.get() + System.lineSeparator());
        }
    }

    private static synchronized void log(String message, Throwable error) {
        if (logWorker == null || logWorker.isShutdown()) logWorker = new LogWorker();
        String text = Instant.now() + " " + message + System.lineSeparator();
        if (error != null) {
            StringWriter buffer = new StringWriter();
            error.printStackTrace(new PrintWriter(buffer));
            text += buffer.toString();
        }
        final String entry = text;
        try { logWorker.execute(() -> writeLog(entry)); }
        catch (java.util.concurrent.RejectedExecutionException full) { logWorker.dropped.incrementAndGet(); }
    }

    private static synchronized void closeLog() {
        if (logWorker != null) logWorker.shutdown(); // 不 awaitTermination，不阻断插件卸载。
    }

    private static void writeLog(String text) {
        try { System.err.print("[BatchRename] " + text); } catch (Throwable ignored) { }
        try {
            Path folder = Paths.get(System.getProperty("user.home"), "CreoBatchRename");
            Files.createDirectories(folder);
            Files.write(folder.resolve("jlink.log"), text.getBytes(StandardCharsets.UTF_8),
                        StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Throwable ignored) {
            // IO 失败不影响卸载；stderr 为备用收集渠道，不递归写日志。
        }
    }
}

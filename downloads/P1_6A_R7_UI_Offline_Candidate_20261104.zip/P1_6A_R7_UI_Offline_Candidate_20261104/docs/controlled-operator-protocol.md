# R6操作者协议（未来只读观察，未执行）

本文件仅为操作者在明确授权后使用的计划，不提供命令、脚本、dat正文或自动操作。R6不激活配置、不启动应用、不触发宏、不执行模型回调、不添加按钮。固定声明：未编译、未加载、未部署、未证明UI可见、未证明OTK可行、未证明真实转钣金可用。

## 1. 单变量与会话前置记录

一次会话只改变一种资源layout、startup身份、路线A策略或路线B前提条件；C1/C2与C3/C4是不同实验，不合并为一条因果链。资源会话内缓存，改变消息文件、布局或身份后应新开受控会话。记录是否确实重启，不从计划restartRequired=true推断实际重启。

未来前置字段：命令ID、源码hash、受控dat hash、layout、classpath身份、模型模式、会话/用例关联。空白模板全部UNVERIFIED或空数组，不预填真实值。本机真实路径、备份哈希和配置恢复属于独立审核记录，不写入离线包。

## 2. L1/L2分开观察

对象解析结果与触发回调分开。真实L1需本会话对象/加载记录、源码/dat身份和命令ID；编译和历史记录不替代。L2需真实触发、requestId、回调阶段及日志引用；触发不证明L3/L4。失败时记录阶段、错误类别及是否触及WCreateFeature/WRegenerate/Save。

## 3. L3手动候选列表观察

未来操作者在明确授权的会话打开自定义功能区，记录完整搜索词、类别、当前/所有模式及命令是否可见。采集外部截图或日志引用；离线包不含这些文件。Designate返回和旧菜单返回均NOT_MODERN_TOOLKIT_LIST_EVIDENCE，不能填L3 PASS。

## 4. L4固定位置及反馈

只有另行明确授权后才手动Add。记录添加动作、固定位置、点击或只读反馈，并核对截图/操作记录/反馈属于同一命令与会话。旧菜单返回、L3列表出现或未点击按钮不替代L4。Schema只能检查字段和引用种类，不能认证截图内容或自动确认跨文件关联。

## 5. 路线A独立策略顺序

FILE_EXPLICIT_NULL_NEIGHBOR、APPLICATIONS_EXPLICIT_NEIGHBOR、CUSTOM_TOP_LEVEL_INFO_MENU分别使用独立计划和会话记录；前一项结果不推断下一项。源码三个策略及精确basename/neighbor规则保持冻结，无新增自由参数。按钮返回按ID记录，只描述调用，不升级现代列表或固定位置结论。

## 6. 路线B阻断

前提不足只记录BLOCKED_PREREQUISITES，不用A替代。七项前提及操作者记录骨架仍UNVERIFIED、evidenceRefs=[]；没有JAR、解锁、签名或许可命令。本地官方要求和许可是否满足由操作者提供真实证据，本包不认证。

## 7. 负向门禁及停止边界

逐例映射negative-case-plan.json。预定门禁未停止或观察到写模型调用，应停止后续流程并保留真实错误信息，不扩大成任意模型回调都只读。记录实际errorCode/failedPhase/completionClass和三项SDK调用是否触及，不以计划标签补写日志。

creationAttempt默认NO_ATTEMPT只是空白计划占位，不是“已观察未调用”。BLOCKED_BEFORE_ATTEMPT需真实门禁证据；FAILED_ATTEMPT只能由未来受控记录填写，需失败阶段/错误类别/三项调用触及信息，仍不得填featureCreated成功值。

## 8. 生产保护

本协议只引用概念字段，不包含生产绝对路径、配置片段、恢复脚本、安装/卸载命令、rbn手写说明或自动UI命令。历史受控配置何时恢复由操作者另行授权并记录；R6不处理该动作。

## R7交叉核对补充

未来C3每一策略独立使用route-a-policy记录，语义见route-a-policy-observation.md。证据保管记录按case/session/requestId/command关联，规则见evidence-custody-and-cross-reference.md；形状校验不替代操作者核对。R7不触发任何一项流程，不处理生产恢复。

# R6单变量会话计划

JSON计划位于evidence-template/session-plan-matrix.json，plannedClass/plannedStartup/plannedLayout是设计条件，不是已加载的配置。selectedLayout、actualRestartObserved、feasibility、evidenceRefs仍未填。

| 计划 | 设计条件 | 单一变量 | 离线状态 |
|---|---|---|---|
| C1 | BatchRename / java / root | 基线layout | UNVERIFIED |
| C2 | 同一业务源码 / java / usascii | 只改变资源layout | UNVERIFIED |
| C3 | JLinkUiProbe / java | 只选一个既有策略ID | UNVERIFIED |
| C4 | OtkUiProbe / otk_java | 前提状态核对 | BLOCKED_PREREQUISITES计划形态，非实际运行结果 |

所有计划restartRequired=true仅为协议，实际重启仍UNVERIFIED。一次会话只选一种layout/startup/API路线；修改资源或身份需独立新会话。C1/C2与C3/C4不构成同一单因素因果链。C4 noFallbackToRouteA=true、derivedFromRouteA=false；不得引用C3作为B可行性。

未来每例前置记录：命令ID、源码/dat hash、layout与textDir、classpath身份、模型模式、是否重启。L1对象与L2触发分开，L3手动列表与L4手动Add/位置/反馈分开；全部引用须由操作者核对同用例，离线模板为空。L5不在本轮验证范围。

路线A依次独立记录FILE_EXPLICIT_NULL_NEIGHBOR、APPLICATIONS_EXPLICIT_NEIGHBOR、CUSTOM_TOP_LEVEL_INFO_MENU。源代码三个策略不改；旧菜单API仅NOT_MODERN_TOOLKIT_LIST_EVIDENCE。未来所有手动Add、触发、会话切换及配置处理均需明确授权；本文无运行命令或配置正文。

## R7依赖与观察字段补充

C1/C2的plannedLayout仍只是条件，status/feasibility/actualRestartObserved均UNVERIFIED，evidenceRefs空，不继承对方结论。C3新增allowedPolicyIds三个精确值，仅policyId单值记录；requiredObservationFields只是字段名，不是实际值。

C4 satisfiedByPlanIds=[]，阻塞依赖仅APPLICATION_JAR、OFFICIAL_OTK_JAR_ON_CLASSPATH、UNLOCK_STATUS、SIGNATURE_STATUS、LICENSE_STATUS、REGISTRY_FIELDS，不引用C1/C2/C3的refs。RESOURCE_LOOKUP仍独立非阻塞观测，不能解除六项前提。C4 BLOCKED_PREREQUISITES仅计划门禁，feasibility仍UNVERIFIED，不能填POSSIBLE/READY/LIKELY。

source/dat/session/command及各证据是否同条件由evidence-custody记录人工核对；未执行的字段全部保持空白。新策略记录见route-a-policy-observation.md，不以旧菜单过程推断L3/L4。

# 路线B前提：未填、未运行

来源标记：`OFFICIAL_DOCUMENT_LOCATOR_FROM_AUDIT_NOT_CHATGPT_RESEARCH`。下列定位来自本机审核摘要和整改单，云端未读取本机官方HTML。仅使用文件名/章节主题；JSON中的主题锚点是审核定位标签，不冒称已验证为原HTML的真实id，也不编造本地行号。

| 条目ID | 官方文件/章节主题 | 所需证据种类 | 状态 |
|---|---|---|---|
| APPLICATION_JAR | Compatibility_with_J_Link.html / 应用JAR | 应用路径、SHA256、包含类清单 | UNVERIFIED |
| OFFICIAL_OTK_JAR_ON_CLASSPATH | Compatibility_with_J_Link.html / otk.jar classpath | 实际classpath条目、JAR SHA256 | UNVERIFIED |
| UNLOCK_STATUS | Unlocking_Running_and_Signing_the_Creo_Object_TOOLKIT_Java_Application.html / 解锁 | 操作者记录 | UNVERIFIED |
| SIGNATURE_STATUS | 同上 / 签名 | 操作者记录 | UNVERIFIED |
| LICENSE_STATUS | 同上 / 许可 | 操作者记录 | UNVERIFIED |
| REGISTRY_FIELDS | RegistryFile1.html / OTK注册 | dat路径、SHA256、startup行 | UNVERIFIED |
| RESOURCE_LOOKUP | Registry_File.html / text_dir | 资源SHA256、重启记录 | UNVERIFIED |

结构化清单位于evidence-template/route-b-prerequisite-checklist.json。七项status均UNVERIFIED，evidenceRefs均为空。前六项阻塞，RESOURCE_LOOKUP为非前提阻塞的独立运行观测，不能因该项标记非blocking而认定资源已解析。缺少阻塞前提只可记BLOCKED_PREREQUISITES；noFallbackToRouteA=true，不以路线A旧菜单、Designate返回或宏结果证明OTK可行。

业务类保持startup java。B只读入口为OtkUiProbe，不迁移业务逻辑；模板保留startup otk_java、toolkit object、creo_type parametric及应用JAR和官方otk.jar双占位符。解锁后二进制变更限制与签名规则须按本机适用官方流程核对。

本包不生成JAR、解锁文件、签名文件，不提供打包/解锁/签名命令或许可满足判断。所有真实路径、SDK适配和许可结果留在本机审核报告，不写入离线清单。

## R7阻断依赖矩阵

| 条目组 | blocking | 离线状态 | 可由其他计划满足吗 |
|---|---|---|---|
| APPLICATION_JAR、OFFICIAL_OTK_JAR_ON_CLASSPATH、UNLOCK_STATUS、SIGNATURE_STATUS、LICENSE_STATUS、REGISTRY_FIELDS | true | 全部UNVERIFIED，refs空 | 否；不接受C1/C2/C3或旧菜单refs |
| RESOURCE_LOOKUP | false | UNVERIFIED，refs空 | 仍需本项独立观察，不能解除前六项 |

C4 satisfiedByPlanIds为空，derivedFromRouteA=false、noFallbackToRouteA=true。BLOCKED_PREREQUISITES是计划阻断，不是本机已检查失败的实测结论；feasibility保持UNVERIFIED。不输出JAR构建、解锁、签名、许可或启动命令。

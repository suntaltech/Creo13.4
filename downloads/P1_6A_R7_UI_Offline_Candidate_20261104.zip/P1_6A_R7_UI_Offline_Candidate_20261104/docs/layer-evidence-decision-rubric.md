# R6分层判定口径

新受控记录采用UNVERIFIED/PASS/FAILED/BLOCKED，PASS不是候选自检状态。featureCreated仅UNVERIFIED/NOT_APPLICABLE，不存在R6创建成功结论。

| 层 | PASS最低输入 | 明确不足 |
|---|---|---|
| L1对象 | SDK_OUTCOME、命令ID、真实源码/dat身份、CLASS或LOG引用 | 编译、源码、自述、历史单次日志 |
| L2触发 | MACRO_CALLBACK类别的真实触发回调、requestId、阶段、LOG引用 | 宏语法、未执行按钮代码 |
| L3候选列表 | MANUAL_UI、准确搜索词/类别/可见性、SCREENSHOT或LOG引用 | Designate/菜单API返回、COMMAND_FOUND |
| L4固定按钮 | MANUAL_UI、手动Add、固定位置、只读反馈，SCREENSHOT与MANUAL_OPERATION_RECORD引用且由操作者核对同会话/命令 | 旧菜单返回、只看到候选项、未记录点击 |
| L5创建 | 本轮不允许PASS | 源码、编译、形状检查、计划标签 |

NO_ATTEMPT/BLOCKED_BEFORE_ATTEMPT/FAILED_ATTEMPT是独立creationAttempt字段。离线默认NO_ATTEMPT；它不是运行观测。FAILED_ATTEMPT需未来真实失败阶段、错误类别及WCreateFeature/WRegenerate/Save触及布尔记录，不升级featureCreated。新controlledCaseRecord的L5只可UNVERIFIED/BLOCKED，尝试失败信息单独描述，不将失败尝试写成L5功能结论。

## Schema兼容与边界

为保留R5的25项形状约束，既有observations中的VERIFIED与旧聚合字段保留为兼容形式，原来源/refs门禁不放宽。R6新模板不预填该值，新增采集使用PASS；两种词汇不自动相互升级。R6 PASS附加源码/dat上下文、命令及各层具体字段，FAILED条目需失败阶段/错误类别/调用触及。完整UNVERIFIED骨架不要求伪造引用。

L3/L4详尽记录由manualUiObservation定义检查；controlledCaseRecord在相应PASS时必须带配套手动观察。被Schema接受只说明形状，跨对象命令ID/hash/会话与引用是否真正匹配仍须操作者核对，不使用非标准JSON Schema等值扩展伪装自动认证。

runtimeEvidenceAuthenticated=false、evidenceAuthenticity=UNVERIFIED保持。Schema不认证截图、日志来源、许可、UI因果关系或模型结果；candidateSelfCheck与auditorLocalCompile也不替代任何真机层。

## R7兼容与保管说明

继续采用更严格的featureCreated=UNVERIFIED/NOT_APPLICABLE枚举，未为了加入阻断词汇而放宽既有R6断言。阻断可在record status或creationAttempt=BLOCKED_BEFORE_ATTEMPT独立表达，FAILED_ATTEMPT仍需实际失败证据。

路线A调用记录只限定旧API过程，独立MANUAL_UI证据才可能形成L3/L4决策。证据保管模板的匹配PASS是操作者未来核对声明，Schema不读取文件或自动比较hash、会话和命令；shape验证状态与runtime认证保持分离。

# C1/C2资源观察字段字典（未执行）

root-layout/text与usascii-layout/text/usascii保持独立且字节一致，清单selectedLayout=false，未选择优胜目录。静态结构/键覆盖不证明text_dir实际解析。

| 字段 | 离线默认 | 未来含义 |
|---|---|---|
| plannedLayout | C1 root-layout；C2 usascii-layout | 设计条件，不是已加载结果 |
| selectedLayout | UNVERIFIED | 实际使用并核对的布局，不能由计划赋值 |
| textDir | UNVERIFIED | 外部受控记录的相对/概念身份，包内不写本机绝对位置 |
| actualRestartObserved | UNVERIFIED | 是否确实新开会话；restartRequired=true不替代观察 |
| messageKeyLookupOutcome | UNVERIFIED | 区分调用未发生、未抛异常、抛异常、状态栏为空、文本不符 |
| displayMessageExceptionClass | UNVERIFIED | 未来原始异常类，不猜测值 |

C1/C2只改变layout并新开会话；不复制结论，不用资源结果满足C4。消息文件会话内缓存，修改后需重启，但本包不启动或切换配置。

UIDisplayMessage第三参数仍null，没有stringseq.create()分支，RUNTIME_STRINGSEQ_ACCEPTANCE_UNVERIFIED保持。历史特定消息单次返回不外推全部上下文；返回未抛异常、可见文本和预期内容匹配分别记录。没有真实运行引用或目录选择写入离线模板。

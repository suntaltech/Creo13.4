# 证据保管与交叉核对（空白协议）

新增evidence-custody-record-template.json只定义来源和关联核对类型。它与受控用例、UI观察、路线A策略记录各司其职，不复制运行内容；caseId/sessionId/commandId、源码相对名/hash、匹配结论全为UNVERIFIED，requestIds和evidenceRefs为空。

未来操作者按以下关系独立核对：

1. 源码相对名和hash对应本次实际加载版本，而非同名旧源码；sourceHashMatch需实际比较。
2. dat、会话记录、命令ID与本次用例对应；sessionMatch/commandIdMatch不能由文件同名推断。
3. 触发存在时才核对真实requestId；未触发的L1观察不虚构回调ID。
4. 截图、日志、手动操作记录来自同一次条件，不拼接不同会话/策略/命令。
5. 引用只用相对证据名，并核对实际内容与hash；本机真实位置只留在本机审核报告。

sourceHashMatch、sessionMatch、commandIdMatch及referenceIntegrityCheckedByOperator均为操作者声明，不由JSON Schema自动计算。若未来把operator完整性标为PASS，形状门禁要求匹配字段为PASS、身份非空并含SOURCE、DAT、SESSION_RECORD及LOG/SCREENSHOT引用；但字段齐备仍不证明内容真实或跨文件相等。

schemaValidatedEvidence=true（或SHAPE_VALIDATED）只说明形状；它既不填充操作者匹配结论，也不替代referenceIntegrityCheckedByOperator。runtimeEvidenceAuthenticated=false与evidenceAuthenticity=UNVERIFIED保持，不能因形状通过自动认证。

模板没有实际路径、截图/日志文件名、回调ID或真实hash。Schema相对路径规则仅检查字符串形状，不读取文件、不解析外部证据、不认证许可、UI因果或模型结果。

# 路线A单策略观察（未来记录，未执行）

新增route-a-policy-record-template.json只覆盖C3的一个策略和调用结果；与通用手动UI观察类型分开。policyId初始UNVERIFIED，运行身份/hash、返回/异常、L3/L4及refs均未填，source=NOT_EXECUTED。

| policyId | 独立记录边界 |
|---|---|
| FILE_EXPLICIT_NULL_NEIGHBOR | 只按本策略会话记录，不继承Applications或自定义策略结果 |
| APPLICATIONS_EXPLICIT_NEIGHBOR | 只按本策略会话记录，不继承File或自定义策略结果 |
| CUSTOM_TOP_LEVEL_INFO_MENU | 先前置菜单调用的过程与后续按钮结果分列，不推断现代列表 |

源码完全冻结，三个精确策略、basename和neighbor检查不变。每次只有一个policyId字符串，不合并成策略列表。前一按钮/策略的返回不能填入后一条，C3不能满足C4。

oldMenuEvidenceOnly=true、notModernToolkitListEvidence=true及NOT_MODERN_TOOLKIT_LIST_EVIDENCE是固定语义：只限定旧菜单API结果，不是UI可见性。callOutcome、exceptionClass和returnedValueObserved不能转换成L3/L4状态。

若未来在该策略会话额外进行独立手动UI观察，L3 PASS需MANUAL_UI、准确搜索/类别、源码/dat/命令身份及SCREENSHOT/LOG引用；不是旧菜单返回的升级。L4 PASS必须再接manualUiObservation，后者记录手动Add、固定位置与只读反馈，并有SCREENSHOT和MANUAL_OPERATION_RECORD。当前模板没有重复嵌入整份手动记录，未来有相应证据才可附加。

Schema只约束形状；实际策略、会话、命令和引用是否匹配由操作者通过证据保管记录核对。离线包不采集、不认证、不触发探针或业务回调。

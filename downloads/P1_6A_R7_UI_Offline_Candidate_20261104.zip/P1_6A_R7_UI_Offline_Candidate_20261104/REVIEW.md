# P1 6A R7 UI Offline 证据记录收敛候选

日期：2026-11-04。R7是离线材料轮次，不是发布版本，不升级产品版本号。

固定边界：未编译、未加载、未部署、未证明UI可见、未证明OTK可行、未证明真实转钣金可用；没有验证资源目录或消息API的运行语义。

## 改动白名单与冻结契约

允许变更：checks/*.py、evidence-template/*.json、docs/*.md、evidence/*.json、REVIEW.md、SHA256SUMS。白名单外新增、删除、修改均失败。

BatchRename.java、三个探针、六份资源、三份注册模板共13项，以及R4历史patch，合计14项保持R6/R5/R4字节。历史patch仅为历史材料，不冒充R7更新补丁。本轮没有Java、资源、注册或转换实现改动。

R6 ZIP SHA256：`938da958b193190cb8c7a6afd7af64fc086f8770d6a5f017fc10fe0d4620bf59`。
业务源码SHA256：`9dbd71f36e403c3ed1a027d810a70befb57d3973c67aedca821f7b31df802400`。

新r6-baseline-files.json从实际R6离线ZIP生成，固定内容摘要；此前R4/R5基线检查仍保留。只包含候选文本文件哈希，不含class/日志/截图运行哈希。

## 两处约束衔接

1. 冻结业务源码包含既有历史服务默认路径。完整冻结与删除该字面量不能同时满足，因此本轮不改源码，对其按原字节列为显式基线例外。可变材料全面拒绝机器路径，其他文件也不能新增路径。text-hygiene-audit.json只列相对文件名、规则和基线相等结论，不输出原路径。不能将该检查表述为“全包没有历史路径字面量”。
2. 继续采用原R6更严格的featureCreated=UNVERIFIED/NOT_APPLICABLE枚举，不为新增BLOCKED词汇放宽旧断言。阻断用record status或creationAttempt独立表达，仍无L5成功值。

## 最小新增记录类型

| 新文件 | 现有模板不能替代的职责 | 离线默认 |
|---|---|---|
| route-a-policy-record-template.json | 将C3单一policyId、旧菜单调用结果与独立UI观察明确分开；通用手动UI模板不描述策略/API返回边界 | source=NOT_EXECUTED，policy/hash/返回/异常/L3/L4均UNVERIFIED，refs空，旧菜单证据标签固定 |
| evidence-custody-record-template.json | 关联源码、dat、会话、命令与引用的操作者保管核对；不是新的运行结果记录 | case/session/command/相对源名/hash/匹配结论UNVERIFIED，requestIds/refs空，认证false |

只新增这两类采集模板；L4仍复用现有manualUiObservation定义，需要真实证据后才附加，不在空白策略记录重复嵌入整份手动模板。新增两份说明文档分别对应这两个独立职责，其余内容优先更新原文档。

oldMenuEvidenceOnly=true、notModernToolkitListEvidence=true及NOT_MODERN_TOOLKIT_LIST_EVIDENCE只限定旧API结果，绝不表示UI可见。未来策略会话若另有独立MANUAL_UI证据，才能按原L3/L4门禁采集；不是把旧菜单返回升级为PASS。

## Schema与交叉核对

新routeAPolicyRecord保持一个policyId，仅三个精确策略。L3 PASS需MANUAL_UI、搜索/类别、身份与非空SCREENSHOT/LOG引用；L4另需manualUiObservation及其手动Add/位置/反馈和相应引用。空白模板没有这些运行值。

新evidenceCustodyRecord只允许未来相对引用。操作者完整性PASS要求sourceHashMatch/sessionMatch/commandIdMatch及相应身份、SOURCE/DAT/SESSION_RECORD和LOG/SCREENSHOT引用；Schema不读取文件、不计算hash相等或跨记录身份匹配。schemaValidatedEvidence=true或SHAPE_VALIDATED不能自动填operator完整性PASS，runtimeEvidenceAuthenticated仍false，evidenceAuthenticity仍UNVERIFIED。

原R6的PASS/FAILED/BLOCKED、旧VERIFIED兼容形式、失败阶段/错误类别/SDK触及和L5门禁全部保留。新形状用例不构造完整运行证据，不伪造文件、hash、requestId、截图或日志。

## 现有计划的收敛

C1/C2 plannedLayout保留设计值，实际selectedLayout、重启、可行性与refs仍未填，不复制结论。C3仅增加allowedPolicyIds及requiredObservationFields，仍一次一个policyId。C4 satisfiedByPlanIds=[]，阻塞依赖只能是B六项前提；不引用C1/C2/C3 refs，feasibility仍UNVERIFIED、derivedFromRouteA=false、noFallbackToRouteA=true。

12个负向caseId保持不变，只增加stopOrder、expectedGuardStage、mustNotTouch等计划元数据。原“计划字段严格集”断言扩展为明确列出的元数据字段，原12项/空状态和字段完整性要求不减少；新增断言单独校验元数据。板厚两例thicknessInputOutcome=UNVERIFIED，不预定null/异常/原生框拦截/Java路径。

CREOSON_UNAVAILABLE仍仅辅助服务观察，不能推断原生门禁。若未来未在预定点停止或触及写调用，应停止后续流程；计划只读不是任意模型回调都只读的保证。

## 检查范围与反例

保留R6全部161项主覆盖、23个反例和44项形状约束，只叠加。新增覆盖R6契约、14项冻结、策略记录标签、C4依赖、保管空状态、认证分离、停止元数据、机器路径/运行时间值、术语及新Schema定义。

新增检查有对应临时反例；原源码/白名单反例同时检查R6新增冻结门禁。错误文本只在临时目录构造，不执行Java或错误路径操作，不写入正式模板。路径反例和时间反例不输出其值，仅记录检测结果。

check_checker.py另在两个独立临时目录运行相同主检查，逐字节比较离线JSON报告。正式输出只含相对报告名与相等结论，无时间戳、用户名或临时目录。check_package.py继续只读验证清单覆盖和哈希，SHA256SUMS重新生成，不沿用旧清单。

## candidateSelfCheck与auditorLocalCompile

candidateSelfCheck只涵盖本轮Python文本/JSON/模板/schema/白名单/反例/确定性与文件哈希；不是SDK执行或UI验收。

auditorLocalCompile是本机审核者使用真实同步SDK/Java17的独立动作，不属于候选自述。R6报告记载的4+5类major61只作为输入事实，R7无编译结果、class或新运行证据。

## 生产保护与未执行事项

- `config.proUnchanged=true (design promise; ChatGPT cannot verify machine state)`
- `productionFilesUntouched=true (design promise)`

设计承诺不是机器状态核验；不处理历史R2配置恢复。无配置片段、恢复/安装/卸载脚本、部署步骤、自动UI命令或rbn手写内容。

未执行javac、javap、jar、Creo、macro、进程查看、运行日志查看、许可查询、浏览器、deployment、feature creation、HTTP或SDK Mock/Stub。无class/jar/dat/bat/rbn/html/js/log、截图、解锁、签名或许可结论。UIDisplayMessage第三参数仍null，RUNTIME_STRINGSEQ_ACCEPTANCE_UNVERIFIED保留。

静态准备与形状通过不能升级L1/L2、L3/L4、OTK、资源解析、消息接受性或L5。详细计数以evidence中的自查结果为准。

## 本轮candidateSelfCheck结果

175/175主断言、36/36临时文本反例、55/55 schema形状检查通过，原R6的161/23/44覆盖保留。两个独立临时目录的离线JSON报告逐字节一致。14项冻结材料不变，R6白名单外差异为空；可变材料路径与时间值扫描无违反项，历史冻结源码例外单列。这些结果不构成auditorLocalCompile、真机或证据认证结论。

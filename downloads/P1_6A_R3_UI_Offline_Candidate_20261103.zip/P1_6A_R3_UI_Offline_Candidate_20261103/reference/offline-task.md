# P1 6A R2 UIEntry 下一轮 ChatGPT 离线整改单

生成日期：2026-11-03  
适用基线：`P1_6A_R2_UIEntry_Candidate_20261103`  
基线源码 SHA256：`47C7ACF6F37121B23B952A5A04489CEC9F6EDD2F07714E28830EC56BA9E0DC0C`  
上一 R2 基线源码 SHA256：`3CA71CEAC03FC67C9A1F8CB1BEE2A5CF4DF2C421A7D910B9A42A915AEF142C71`

## 1. 本轮整改边界

### 1.1 目标

只解决“命令对象已注册、宏可触发，但 Customize Ribbon 的 TOOLKIT Commands 列表、命令搜索和固定按钮未暴露”的离线诊断与源码准备问题。

下一轮仍属于：

- 离线源码补丁；
- 静态一致性检查；
- 受控实验设计；
- 只读探针设计；
- 本机隔离编译所需源码准备。

### 1.2 明确禁止

- 禁止输出 `.class`、`.jar`、`.dat`、`.bat`、`.rbn`、`.html`、`.js` 运行或发布产物。
- 禁止切换 `config.pro`、复制文件到 `D:\creo-tools\jlink`、启动 Creo、执行宏、操作真实模型。
- 禁止宣称 UI 已修复、命令已可见、OTK Java 已可行、真实转钣金已可用。
- 禁止修改 `WCreateFeature`、`WRegenerate`、抽壳分支、`Save()`、`AddBrowserMessageListener`、CREOSON 写模型路径。
- 禁止手写二进制 `toolkitribbonui.rbn`。
- ChatGPT 不得运行 `javac`、`javap`、Creo、进程查看、日志查看，不得伪造编译结果、真机成功结果、特征 ID、堆栈或许可状态。

## 2. 已确认事实，下一轮不得推翻

| 事实 | 本机依据 | 对整改的约束 |
|---|---|---|
| `UICreateCommand` 返回非空只代表对象层注册 | R2 只读探针四个命令 `COMMAND_FOUND` | 不能写成“UI 已注册可见” |
| 宏 `~ Command 'SISWSheetMetalConvert'` 可进入 `OnCommand` | R2 宏 harness 输出 `RUNMACRO_RETURNED` | 只能证明触发层，不能证明按钮可见 |
| 官方文档：未调用 `Designate` 的命令不会出现在 Toolkit Commands 列表 | `Designating_the_Command.html` 第 41-42 行 | 保留 Designate 方向，但它不是充分条件 |
| `Designate` 的 Label、Help、Description 必须来自消息文件 | 官方文档第 44-47 行 | 静态检查必须覆盖每个 Designate 键 |
| 消息文件必须位于 `<text_path>/text` 或 `<text_path>/text/<language>` | 官方文档第 55 行 | 两种资源布局只能作为受控变量，不能合并 |
| 消息文件每组四行：键、替换文本、可空译文、预留空行 | `Contents_of_the_Message_File.html` 第 39-44 行 | 静态脚本必须校验四行结构 |
| 文件名不超过 30 字符、小写、扩展名三字符；键全局唯一；会话内只加载一次，改动需重启 | `Restrictions_on_the_Text_Message_File.html` 第 40-52 行 | 资源命名和重启要求写入 README |
| J-Link 应用转 OTK Java 需 JAR、解锁、classpath 含 `otk.jar`、`startup otk_java` | `Compatibility_with_J_Link.html` 第 38-42 行 | 路线 B 只能列前提，不能在源码中直接迁移业务类 |
| 本地旧菜单示例显示 neighbor 语义不统一 | `RunDisplayExamples.java`、`ParamEditor.java`、`pfcExamplesMenu.java`、`pfcAsyncFullExample.java` | 路线 A 探针不得默认 `null` neighbor |

## 3. 证据分层口径

下一轮源码、日志模板和 README 必须使用以下互斥标签，禁止合并：

| 层级 | 允许证据 | 不能证明 |
|---|---|---|
| L1 对象层 | `UICreateCommand` 非空、`UIGetCommand` 非空、类已加载 | TOOLKIT 列表可见、按钮可见 |
| L2 触发层 | 宏执行后 `OnCommand` 进入、回调 requestId 生成 | UI 暴露、特征创建 |
| L3 候选列表层 | Customize Ribbon > TOOLKIT Commands 出现命令；命令搜索命中 | 按钮已固定到 Ribbon |
| L4 固定按钮层 | 用户手动 Add 后 Ribbon 出现按钮；截图记录位置 | 真实转换成功 |
| L5 转换创建层 | `IsSheetmetal()`、特征 ID/名称/状态、`WRegenerate` 成功回读 | 本轮不得要求或伪造 |

日志中建议固定字段：`objectRegistered`、`macroDispatchable`、`uiListed`、`ribbonVisible`、`featureCreated`；前四项默认 `UNVERIFIED`，只有对应证据出现后才能由操作者填写，源码不得自动置为 true。

## 4. 源码整改要求

### 4.1 业务类注册审计

当前 `designateUiCommand` 硬编码 `MESSAGES`，且 `uiRegistrationAudit` 也固定记录 `MESSAGES`。下一轮改为：

1. 将方法签名参数化：

```java
private static void designateUiCommand(String id, String messageFile, UICommand command,
                                       String labelKey, String helpKey, String descriptionKey)
```

2. 调用 `command.Designate(messageFile, labelKey, helpKey, descriptionKey)`。
3. 审计事件必须记录：
   - `commandId`；
   - `messageFile`；
   - `labelKey`、`helpKey`、`descriptionKey`；
   - `stage=UICreateCommand|Designate|SetIcon`；
   - `outcome=ATTEMPT|RETURNED_NON_NULL|RETURNED|THROWN|SKIPPED`；
   - `messageLookup=MESSAGE_LOOKUP_UNVERIFIED`；
   - `uiVisibility=UNVERIFIED`。
4. 删除代码中的 `attach_selected_dat_and_classpath_manifest_from_test_operator` 这类占位文本；改为单独生成 `evidence-template/registration-context.json`，由受控操作者后续填写。
5. 业务类仍保持 `startup java`，不得为路线 B 把 `BatchRename` 改成 OTK Java 启动方式。

### 4.2 消息资源静态一致性检查

当前静态脚本只校验四行结构和少量固定键，下一轮必须增加“源码使用键 ↔ 资源文件键”双向核对：

1. 从 `BatchRename.java` 提取每个 Designate 调用的三元组：消息文件、Label 键、Help 键、Description 键。
2. 分别检查：
   - `root-layout/text/*.txt`；
   - `usascii-layout/text/usascii/*.txt`。
3. 对每个资源文件检查：
   - 总行数为 4 的倍数；
   - 第 1 行键匹配 `[A-Z0-9_]+`；
   - 第 2 行非空；
   - 第 3 行允许为空；
   - 第 4 行为空；
   - 键在单个布局内唯一；
   - 文件名小写、扩展名三字符、总长不超过 30；
   - 源码引用的 Label/Help/Description 键全部存在。
4. 明确区分两类资源：
   - UI Designate 资源：`p1_6a_ui_commands.txt`；
   - 转换状态消息资源：`p1_6a_r2.txt`。
5. 若某个状态消息键未用于 Designate，不得混入 UI 候选列表资源；反之亦然。
6. 输出 `evidence/resource-coverage.json`，包含每个命令、每个键、所在文件、布局、是否缺失。

### 4.3 路线 A 探针修正

当前 `UiExposureProbe` 路线 A 固定调用：

```java
session.UIAddButton(command, menu, null, labelKey, helpKey, MESSAGES);
```

问题是：`null` neighbor 只对部分本地示例成立；自定义菜单还需要先 `UIAddMenu`。下一轮要求：

1. 新增环境变量 `SISW_UI_PROBE_NEIGHBOR`，不得默认 `null`。
2. 建立显式允许表，未命中即拒绝启动并输出 `ROUTE_A_MENU_POLICY_REJECTED`：

| 菜单 | neighbor | 前置动作 | 本地示例依据 |
|---|---|---|---|
| `File` | `null` | 不调用 `UIAddMenu` | `jlinkexamples\RunDisplayExamples.java` |
| `Applications` | `Applications.psh_util_pproc` | 不调用 `UIAddMenu` | `jlink_elev\source\parameditor\ParamEditor.java` |
| 自定义菜单 | 由示例参数决定 | 必须先调用 `UIAddMenu` | `pfcExamplesMenu.java`、`pfcAsyncFullExample.java` |

3. 若选择自定义菜单，必须新增 `SISW_UI_PROBE_CREATE_MENU=1`，并在 `UIAddButton` 前调用 `session.UIAddMenu(menuId, parentMenu, messageFile, neighbor)`；禁止只设置菜单 ID 而不创建菜单。
4. 日志必须记录：`menu`、`neighbor`、`uiAddMenuCalled=true|false`、`sourceExamplePath`、`menuPolicy`。
5. `UIAddButton` 返回成功只能标记为 `LEGACY_MENU_CALL_RETURNED`，同时固定标注 `NOT_MODERN_TOOLKIT_LIST_EVIDENCE`。
6. 探针仍不得调用 `BatchRename`、模型 API、特征创建、浏览器打开或 CREOSON 服务。

### 4.4 路线 B 探针与 OTK 前提

路线 B 只允许保留只读探针和前提清单，不得迁移业务类：

1. `OtkUiProbe` 继续只调用 `UICreateCommand` + `Designate`，不调用 `UIAddButton`。
2. 新增 `docs/route-b-otk-prerequisites.md`，逐项列出：
   - 应用需打包为 JAR；
   - JAR 需解锁/签名，本机许可状态由操作者提供证据；
   - classpath 必须包含 `otk.jar`；
   - dat 使用 `startup otk_java`、`toolkit object`、`creo_type parametric`；
   - `text_dir` 指向资源父目录；
   - 未验证项不得写成已支持。
3. 路线 B 模板中的 classpath 占位符必须明确拆成“应用 JAR”和“官方 `otk.jar`”两部分，不得只写一个通用目录。
4. 不得生成真实 JAR、解锁文件或许可证声明。

### 4.5 `UIDisplayMessage(messageFile, key, null)` 第三参数

当前转换状态提示使用 `session.UIDisplayMessage(CONVERSION_MESSAGES, key, null)`，第三参数是否被运行时接受尚未验证。

下一轮要求：

1. 本轮不得把它改成新的 API 调用，除非 ChatGPT 能引用本地 SDK 方法签名和官方示例；ChatGPT 无法运行 `javap`，不得自行断言。
2. 代码中保留 `RUNTIME_STRINGSEQ_ACCEPTANCE_UNVERIFIED` 审计标签。
3. README 增加待验证项：`UIDisplayMessage` 第三参数 `null` 与空 `stringseq` 的差异，由本机操作者在受控测试中记录。
4. 不得因该问题改动 `NO_MODEL`、单位门禁、板厚输入或特征创建分支。

### 4.6 资源布局实验要求

1. 保留两套互不合并的布局：
   - `resources/root-layout/text/*.txt`；
   - `resources/usascii-layout/text/usascii/*.txt`。
2. 静态脚本必须证明两套文件内容一致，并分别通过四行结构检查。
3. README 明确：一次受控会话只选择一种布局；切换布局必须重启 Creo，因为消息文件会话内只加载一次。
4. `text_dir` 指向哪个父目录、`usascii` 子目录是否参与查找，列为待运行证据，不得在源码中猜测结论。

## 5. 受控实验矩阵（只设计，不执行）

| 用例 | 类 | startup | 资源布局 | 注册 API | 唯一变量 | 允许采集证据 |
|---|---|---|---|---|---|---|
| C1 | `BatchRename` | `java` | root-layout/text | Designate | 业务类 root 资源 | L1/L3/L4 与 NO_MODEL 状态行 |
| C2 | `BatchRename` | `java` | usascii-layout/text/usascii | Designate | 业务类 usascii 资源 | 与 C1 对比列表差异 |
| C3 | `JLinkUiProbe` | `java` | 探针资源 | UIAddButton | 旧菜单路径 | 旧菜单位置，禁止当作现代 TOOLKIT 列表证据 |
| C4 | `OtkUiProbe` | `otk_java` | 探针资源 | Designate | OTK 注册前提 | 前提满足后的 L1/L3 证据；前提不足时记录阻塞项 |

禁止在同一次会话中同时改变注册模式、资源布局、探针身份和转换逻辑。

## 6. 下一轮候选包结构要求

建议结构：

```text
P1_6A_R3_UI_Offline_Candidate_YYYYMMDD/
  BatchRename.java
  probes/
    JLinkUiProbe.java
    OtkUiProbe.java
    UiExposureProbe.java
  resources/
    root-layout/text/
    usascii-layout/text/usascii/
  registration/
    business-java.dat.template
    route-a-java.dat.template
    route-b-otk-java.dat.template
  checks/
    static_check.py
  evidence-template/
    registration-context.json
    runtime-evidence-schema.json
  docs/
    route-b-otk-prerequisites.md
    controlled-experiment-matrix.md
  REVIEW.md
```

硬性要求：

- 包内不得出现编译产物或二进制运行文件。
- `REVIEW.md` 必须写明：本包未编译、未加载、未部署、未验证真机 UI。
- 必须给出相对 UIEntry 基线的 diff 摘要：新增文件、修改方法、未修改块、未执行项。
- 静态脚本输出 `evidence/static-claims.json`，`notExecuted` 列表必须包含 `javac`、`javap`、`jar`、`Creo`、`macro`、`deployment`、`feature creation`。
- 不得把“静态检查通过”写成“功能通过”。

## 7. 复制即用 ChatGPT 提示词

```text
你是 Creo 13.4 J-Link/OTK Java 的离线代码补丁编写助手。本机助手负责规划、审核、隔离编译和受控测试；你只输出源码、静态检查脚本、资源文件、模板和文档，不运行 javac、javap、Creo、宏、进程或日志，不伪造运行结果。

任务：基于 P1_6A_R2_UIEntry_Candidate_20261103 基线，输出下一轮 UI 暴露诊断离线候选包，目标是区分对象注册、宏触发、TOOLKIT Commands 列表、固定按钮和特征创建五层证据。

必须遵守：
1. 业务类 BatchRename 仍保持 startup java；不得切换为 startup otk_java。
2. 保留现有 NO_MODEL、单位门禁、板厚输入、失败诊断和未证明的 WCreateFeature 分支；禁止修改 Save、抽壳、AddBrowserMessageListener、CREOSON 写模型路径。
3. 将 designateUiCommand 参数化，记录实际 messageFile、labelKey、helpKey、descriptionKey；不得硬编码单一消息文件。
4. 静态脚本必须双向核对源码 Designate 键与 root-layout、usascii-layout 两套资源；校验四行消息格式、文件名小写/长度/三字符扩展名、键唯一性和缺失键。
5. 路线 A 探针不得默认 null neighbor；增加 SISW_UI_PROBE_NEIGHBOR 和显式菜单策略表；自定义菜单必须先 UIAddMenu；UIAddButton 成功只能标记为旧菜单证据，不是现代 TOOLKIT Commands 列表证据。
6. 路线 B 只保留只读 OtkUiProbe，并输出 OTK Java 前提文档：JAR、解锁/签名、otk.jar classpath、startup otk_java、toolkit object、creo_type parametric；不得生成 JAR、解锁文件或许可声明。
7. 保留 UIDisplayMessage 第三参数 null 的未验证标签，不得断言运行时接受。
8. 两套资源布局保持分离；一次受控实验只允许改变一个因素。
9. 候选包只能包含源码、资源、模板、静态脚本和 Markdown/JSON 文档；禁止 class、jar、dat、bat、rbn、html、js 等运行或发布产物。
10. REVIEW.md 必须明确：未编译、未加载、未部署、未证明 UI 可见、未证明真实转钣金可用。
11. 输出 diff 摘要、静态检查设计、运行证据 schema、未决风险和禁止项；所有未验证状态使用 UNVERIFIED，不得写成 true。

不要给出安装命令、不要覆盖生产目录、不要手写 rbn、不要声称修复完成。
```

## 8. 本机复核标准

下一轮候选到达后，本机只做以下离线复核：

1. ZIP 无运行产物；
2. 静态脚本在隔离副本复跑并输出通过数；
3. 本机真实 `otk.jar --release 17` 隔离编译，记录 major 版本和 class 哈希；
4. 源码 diff 确认转换生命周期块未被改动；
5. 资源键覆盖报告完整；
6. 路线 A 探针菜单策略不再默认 null；
7. 路线 B 前提文档未把未验证项写成可行；
8. 审核报告继续区分“离线有条件通过”和“真机 UI/部署发布不通过”。

## 9. 当前未决问题（不得由 ChatGPT 提前下结论）

1. `startup java + Designate` 在本机是否足以进入现代 TOOLKIT Commands 列表。
2. `root-layout/text` 与 `text/usascii` 哪种资源路径被 Designate 正确解析。
3. `UIAddButton` 旧菜单结果是否能在当前 Creo 13.4 Ribbon 中出现。
4. OTK Java JAR、解锁、许可和 classpath 前提在本机是否满足。
5. `UIDisplayMessage(messageFile, key, null)` 运行时是否被接受。
6. 命令可见后，`SISWSheetMetalConvert` 的 `NO_MODEL` 分支是否仍在特征创建前停止。

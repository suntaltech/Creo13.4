# T1 受控测试准备：业务类 startup java + root-layout 资源

状态：**材料已准备，未激活、未修改 `config.pro`、未启动 Creo、未覆盖生产目录**。

## 1. 测试目的

只改变一个因素：验证 UIEntry 候选业务类在 `startup java` 下使用 `root-layout/text` 四行资源后，命令是否进入 Customize Ribbon 的 TOOLKIT Commands 列表。

本测试不验证 `startup otk_java`，不验证探针 A/B，不验证真实钣金转换。

## 2. 目录与文件

| 项目 | 路径 / 内容 |
|---|---|
| 准备根目录 | `D:\creo-tools\build\review-p1-6a-r2-uientry-20261103\controlled-t1-root-layout-prep` |
| 候选 dat | `sisw_uientry_t1_root_layout.dat` |
| class 目录 | `classes\`，4 个业务 class，均 `major=61` |
| 资源目录 | `text\p1_6a_ui_commands.txt`、`text\p1_6a_r2.txt` |
| 图标目录 | `text\resource\about.png`、`batchrename.png`、`sheetmetal.png` |
| 哈希清单 | `manifest.json` |

dat 声明字段：

| 字段 | 值 |
|---|---|
| `startup` | `java` |
| `java_app_class` | `BatchRename` |
| `java_app_classpath` | 本目录 `classes` |
| `text_dir` | 本目录 `text` |
| `java_app_start` | `start` |
| `java_app_stop` | `stop` |

## 3. 已排除内容

- 不包含 `.jar`、`.rbn`、`.bat`、`.html`、`.js`。
- 不包含探针资源 `p1_6a_ui_probe.txt`。
- 不包含旧 `batchrename.txt`。
- 不复制生产 class、生产 dat、生产 Web 文件、生产 rbn。
- 不打包、不发布、不手写 rbn。

## 4. 激活前检查（未执行）

1. 确认 Creo 已关闭。
2. 备份当前 `config.pro` 与当前受控 dat；当前 `config.pro` 仍指向 R2 受控 dat，不能直接覆盖生产备份。
3. 将当前受控 `protkdat` 行改为指向本目录 `sisw_uientry_t1_root_layout.dat`，或在受控测试脚本中切换；切换前记录旧行哈希。
4. 重启 Creo，不导出新 rbn，不点击生产安装目录覆盖操作。

## 5. 必须采集的运行证据

| 编号 | 观察项 | 通过证据 | 失败记录要求 |
|---|---|---|---|
| E1 | 启动注册日志 | 四个命令均出现 `UICreateCommand RETURNED_NON_NULL`、`Designate RETURNED`、`SetIcon RETURNED` 或明确图标异常但命令保留 | 记录阶段、异常类、完整堆栈和命令 ID |
| E2 | TOOLKIT 候选列表 | File > Options > Customize Ribbon > TOOLKIT Commands 中可见四个业务命令标签；当前模式与所有模式均截图 | 记录列表为空、筛选词、模式切换状态 |
| E3 | 命令搜索 | 搜索 `SISWSheetMetalConvert`、`Convert Solid to Sheet Metal 6A` 均有明确结果或明确无结果 | 记录搜索词和截图 |
| E4 | 手动触发转换命令 | 开始页无模型时进入 `NO_MODEL`，`CREATE_NOT_DISPATCHED`，`modelMayHaveChanged=false` | 记录 requestId、failedPhase、异常类、反馈键 |
| E5 | 无写操作 | 日志无 `WCreateFeature`、`WRegenerate`、`Save` 调用记录；状态栏提示特征创建前停止 | 若出现创建/重生成记录，立即停止并保留完整日志 |

## 6. 判定口径

| 结果 | 允许结论 |
|---|---|
| E1 通过但 E2/E3 为空 | 只能说明对象注册/编译通过，不能说明 UI 暴露修复 |
| E2/E3 出现命令且 E4 为预期 NO_MODEL | 可判定 T1 资源格式路线在 `startup java` 下“候选列表暴露有改善证据”，仍不能宣称 OTK 必要性被排除 |
| E4 出现创建或保存记录 | 超出本测试边界，立即停止受控测试并保留证据 |
| 列表仍为空 | 继续保留 `startup otk_java`、`UIAddMenu/UIAddButton` 旧菜单、资源路径作为后续 A/B 因素，不得归因到单一原因 |

## 7. 后续顺序

1. T1：`startup java + root-layout`（本目录）。
2. T2：仅替换为 `usascii-layout/text/usascii` 资源，重启新会话；注册模式保持 `startup java`。
3. 路线 A 探针：仅在选定本地官方示例支持的内置菜单参数后执行；自定义菜单需先补 `UIAddMenu`。
4. 路线 B 探针：仅在有效 OTK JAR、classpath、许可/解锁前提核实后执行。
5. 只有真机 UI 暴露链路成立后，才讨论业务类注册方式收敛；在此之前不得打包发布。

## 8. 回退要求

- 测试结束后先注释或移除 T1 `protkdat` 行，再按备份恢复受控或生产注册链路。
- 恢复后复核生产 `BatchRename.class` 与 `batchrename.dat` 哈希。
- 不删除本准备目录；它只作为离线受控证据。

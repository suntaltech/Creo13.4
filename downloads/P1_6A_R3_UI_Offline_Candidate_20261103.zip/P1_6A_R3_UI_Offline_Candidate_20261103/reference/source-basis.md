# 依据范围

本轮主要依据为reference/offline-task.md的本机官方文档摘录及签名事实。未运行javap，未访问Windows原始SDK/示例HTML，未读取运行日志。

- Designating_the_Command.html：Designate是TOOLKIT候选列表必要条件但非充分条件；三类键来自消息文件，text/语言路径需验证。
- Contents_of_the_Message_File.html、Restrictions_on_the_Text_Message_File.html：四行消息、文件名约束、键唯一性、会话内缓存；本轮由文本脚本检查可静态验证部分。
- Compatibility_with_J_Link.html：OTK前提含应用JAR、解锁/签名、otk.jar classpath、startup otk_java等；本机适用许可状态仍UNVERIFIED。
- RunDisplayExamples.java、ParamEditor.java：任务给出File/null与Applications/Applications.psh_util_pproc组合。
- pfcExamplesMenu.java、pfcAsyncFullExample.java：任务要求自定义先UIAddMenu，但未提供完整参数元组。本包自定义菜单ID为自有消息键P1_UI_CUSTOM_MENU，其parent/neighbor及示例核对均须显式提供，不声称示例固定使用该ID。
- UIAddMenu(menuId,parentMenu,messageFile,neighbor)使用任务明确给出的调用签名/角色；实际语义仍需本机隔离编译与受控检查。

T1材料为本机准备状态清单，不能证明R3或原UIEntry已执行。上传README自身哈希和输入候选来源已核对，未上传的class/dat/图标仅保留声明边界。

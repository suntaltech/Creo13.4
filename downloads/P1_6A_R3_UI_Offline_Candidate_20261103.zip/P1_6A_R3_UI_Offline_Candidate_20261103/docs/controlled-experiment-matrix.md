# 受控实验矩阵（仅设计，未执行）

L1对象层、L2触发层、L3候选列表层、L4固定按钮层、L5转换创建层分别记录。对象非空/Designate返回不代表L3或L4。宏进入回调只属L2，探针回调不属业务转换；本轮不安排L5。

| 用例 | 入口类 | startup | layout选择及text_dir意图 | API路线 | 对比边界 |
|---|---|---|---|---|---|
| C1 | BatchRename | java | root-layout/text；text_dir指向该text目录 | Designate | R3业务候选起点，保存L1/L3/L4及手动NO_MODEL结果 |
| C2 | BatchRename | java | usascii-layout/text/usascii；text_dir指向该layout的text目录 | Designate | 相对C1只变资源布局；同一R3编译产物，新干净会话 |
| C3 | JLinkUiProbe | java | 固定选择一种探针资源layout | UIAddButton；自定义策略先UIAddMenu | 独立旧菜单实验；非业务回调、非现代TOOLKIT验收，不与C1/C2混称单变量结果 |
| C4 | OtkUiProbe | otk_java | 固定同一种探针资源layout | Designate | 仅前提满足时测试OTK只读探针；与C3不同身份/API，不能仅据二者差异判定唯一根因 |

一次会话只选择一种layout和一种入口；任何消息文件/资源位置/注册方式变更后重启Creo，因消息文件会话内只加载一次。两套资源不合并。注册中的text_dir应指向哪个父目录、usascii子目录是否实际参与查找，必须记录实际生效配置和结果，不能从目录存在推断。

## 路线 A 显式策略

以下是源码允许表，不代表本机运行已通过。SISW_UI_PROBE_MENU、SISW_UI_PROBE_NEIGHBOR均必填；字符串`null`是显式选择原生null，不是默认值。

| menu | neighbor变量值 | UIAddMenu | 依据声明 |
|---|---|---|---|
| File | null（字面字符串） | 不调用；CREATE_MENU只能缺省或0 | jlinkexamples/RunDisplayExamples.java |
| Applications | Applications.psh_util_pproc | 不调用；CREATE_MENU只能缺省或0 | jlink_elev/source/parameditor/ParamEditor.java |
| P1_UI_CUSTOM_MENU | 由本机已核对示例明确提供，必要时显式null | 必须CREATE_MENU=1，且先于任何按钮 | pfcExamplesMenu.java或pfcAsyncFullExample.java |

自定义菜单只允许本包提供资源标题的P1_UI_CUSTOM_MENU，其他菜单ID一律ROUTE_A_MENU_POLICY_REJECTED，避免指向不存在的资源键。它是本包菜单标识，不冒称官方示例中的固定ID。自定义还需显式提供SISW_UI_PROBE_PARENT_MENU、SISW_UI_PROBE_MENU_NEIGHBOR、SISW_UI_PROBE_SOURCE_EXAMPLE和SISW_UI_PROBE_CUSTOM_POLICY_CONFIRMED=1。确认值仅表示操作者已核对参数元组的声明；源码不读取示例原文，不证明参数语义。

日志记录menu、neighbor、uiAddMenuCalled、sourceExamplePath和menuPolicy。uiAddMenuCalled只表示确实进入该调用，不代表菜单可见或调用成功；结果另看UIAddMenu阶段。UIAddButton返回仅写LEGACY_MENU_CALL_RETURNED与NOT_MODERN_TOOLKIT_LIST_EVIDENCE。

本文件没有安装、构建或启动命令；所有实际切换和启动由本机受控流程安排。当前不修改config.pro、生产dat/class/text/Web/脚本，不输出或编辑rbn。

## T1输入边界

附件T1 README与manifest声明activated=false、configProModified=false、productionFilesOverwritten=false，记录的是已准备而非已执行。manifest对应UIEntry旧基线SHA256 47c7acf6…，不能直接当作本轮R3源码或未来新编译class的哈希。若本机决定采用R3，需独立审核、重新隔离编译与新的manifest，不在现有T1准备材料中混入新旧class后沿用旧校验值。

本轮只核对附件README自身哈希与manifest条目，以及候选来源源码/ZIP哈希；未提供的class、dat、图标和Windows路径未独立访问，不把清单声明写成云端验证。

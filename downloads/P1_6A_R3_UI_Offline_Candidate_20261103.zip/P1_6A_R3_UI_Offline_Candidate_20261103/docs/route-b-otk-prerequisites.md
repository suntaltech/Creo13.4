# 路线 B：OTK Java 只读探针前提（全部待本机验证）

本轮仅提供 OtkUiProbe/UiExposureProbe 源码和含占位符注册模板，不迁移 BatchRename。没有生成应用JAR、解锁文件、签名、许可声明或可加载dat。

| 前提 | 本轮状态 | 本机应提供的证据 |
|---|---|---|
| 应用类打包为JAR，包含入口和共享探针类 | UNVERIFIED | 隔离构建产物清单、入口类、JAR哈希 |
| 官方要求的解锁/签名及许可条件 | UNVERIFIED | 本机官方文档适用条款、实际工具结果与许可状态；不得从文件存在推断授权 |
| classpath包含应用JAR | UNVERIFIED | 实际应用JAR路径和哈希 |
| classpath包含官方otk.jar | UNVERIFIED | 与当前Creo匹配的SDK路径和版本；不可混入pfcasync.jar |
| 注册startup otk_java、toolkit object、creo_type parametric | UNVERIFIED | 实际受控dat全文和哈希，字段匹配模板 |
| text_dir与所选资源父目录关系 | UNVERIFIED | 实际text_dir、root/usascii布局及搜索结果；模板text_dir指向所选layout的text目录，子目录参与查找仍待证据 |
| 应用加载与同步会话获取 | UNVERIFIED | 启动日志，失败时保留原始错误，不改为成功文案 |
| Designate消息解析和TOOLKIT候选列表 | UNVERIFIED | 对象API记录、资源文件与键名、列表/搜索截图 |

模板使用`@ABSOLUTE_APPLICATION_JAR_PATH@;@ABSOLUTE_OFFICIAL_OTK_JAR_PATH@`明确区分两个classpath条目。分号表示目标Windows路径列表意图，具体注册语法、空格路径与官方版本要求须本机审核，模板不可直接加载。

若未满足解锁、许可、SDK或注册条件，记录阻塞项；不回退到startup java或旧菜单结果来宣称OTK成功。即使只读探针B出现按钮，也不能证明业务类已完成OTK迁移或钣金转换。

依据为输入整改单对Compatibility_with_J_Link.html第38–42行、RegistryFile1.html等的本机摘录；本轮未读取原始官方HTML、未运行javap，未核实本机许可。不能把“解锁/签名”理解为任一方式都必然满足所有版本要求，以本机适用官方规则为准。

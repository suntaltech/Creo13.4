/** Route B entry only. This source does not package, unlock or authorize an OTK application. */
public final class OtkUiProbe {
    private OtkUiProbe() { }
    public static void start() throws Throwable { UiExposureProbe.start("B"); }
    public static void stop() { UiExposureProbe.stop(); }
}

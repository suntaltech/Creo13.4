import com.ptc.pfc.pfcCommand.DefaultUICommandActionListener;
import com.ptc.pfc.pfcCommand.UICommand;
import com.ptc.pfc.pfcSession.CreoCompatibility;
import com.ptc.pfc.pfcSession.Session;
import com.ptc.pfc.pfcSession.pfcSession;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Read-only UI exposure experiment. Never delegates to BatchRename or a model API. */
public final class UiExposureProbe {
    private static final String MESSAGES = "p1_6a_ui_probe.txt";
    private static Session session;
    private static String route;
    private static String registrationId;
    private static boolean active;
    private static MenuPolicy menuPolicy;
    private static final List<UICommand> commands = new ArrayList<>();
    private static final List<ProbeListener> listeners = new ArrayList<>();
    private UiExposureProbe() { }

    public static void start(String selectedRoute) throws Throwable {
        if (!"A".equals(selectedRoute) && !"B".equals(selectedRoute)) {
            throw new IllegalArgumentException("Route must be A or B");
        }
        if (session != null || !commands.isEmpty()) {
            throw new IllegalStateException("Stop the prior probe or restart Creo before loading another route");
        }
        route = selectedRoute;
        menuPolicy = null;
        registrationId = UUID.randomUUID().toString();
        event("REGISTRY_DECLARATION", null, "startup=" + ("A".equals(route) ? "java" : "otk_java")
                + "; toolkit=" + ("A".equals(route) ? "NOT_DECLARED" : "object")
                + "; creo_type=" + ("A".equals(route) ? "NOT_DECLARED" : "parametric")
                + "; expectedClasspath=" + ("A".equals(route) ? "DIRECTORY" : "APPLICATION_JAR_AND_LOCAL_SDK")
                + "; source=TEMPLATE_DECLARATION_NOT_EFFECTIVE_REGISTRY_VERIFICATION", null, null);
        try {
            session = pfcSession.GetCurrentSessionWithCompatibility(CreoCompatibility.C4Compatible);
            if (session == null) throw new IllegalStateException("No synchronous session");
            menuPolicy = "A".equals(route) ? resolveMenuPolicy() : null;
            if (menuPolicy != null && menuPolicy.createMenu) {
                event("UIAddMenu", null, "ATTEMPT", null, null);
                try {
                    menuPolicy.uiAddMenuCalled = true;
                    session.UIAddMenu(menuPolicy.menu, menuPolicy.parentMenu, MESSAGES, menuPolicy.menuNeighbor);
                    event("UIAddMenu", null, "RETURNED; ACTUAL_MENU_VISIBILITY_UNVERIFIED", null, null);
                } catch (Throwable menuError) {
                    event("UIAddMenu", null, "THROWN", null, menuError);
                    throw menuError;
                }
            }
            for (String suffix : new String[] { "Rename", "SheetMetal", "About", "Convert" }) {
                register(suffix);
            }
            active = true;
            event("START", null, "RETURNED; 4 read-only callbacks installed; UI_VISIBILITY_UNVERIFIED", null, null);
        } catch (Throwable error) {
            event("START", null, "THROWN; no alternate registration route attempted", null, error);
            stop();
            throw error;
        }
    }

    private static void register(String suffix) throws Throwable {
        String id = "SISWUIProbe" + route + suffix;
        String key = "P1_UI_" + route + "_" + suffix.toUpperCase(java.util.Locale.ROOT);
        ProbeListener listener = new ProbeListener(id);
        UICommand command;
        try {
            event("UICreateCommand", id, "ATTEMPT", null, null);
            command = session.UICreateCommand(id, listener);
            event("UICreateCommand", id, command == null ? "RETURNED_NULL" : "RETURNED_NON_NULL", null, null);
            if (command == null) throw new IllegalStateException("Null command");
        } catch (Throwable error) {
            event("UICreateCommand", id, "THROWN", null, error);
            throw error;
        }
        // Track before later SDK calls so partial registrations are included in stop cleanup.
        commands.add(command);
        try { listeners.add(listener); }
        catch (Throwable trackingError) {
            commands.remove(commands.size() - 1);
            try { command.RemoveActionListener(listener); }
            catch (Throwable detachError) { trackingError.addSuppressed(detachError); }
            throw trackingError;
        }
        if ("B".equals(route)) {
            try {
                event("Designate", id, "ATTEMPT; keys=" + key, null, null);
                command.Designate(MESSAGES, key + "_LABEL", key + "_HELP", key + "_DESC");
                event("Designate", id, "RETURNED; MESSAGE_LOOKUP_UNVERIFIED", null, null);
            } catch (Throwable error) {
                event("Designate", id, "THROWN", null, error);
                throw error;
            }
            event("UIAddButton", id, "NOT_REQUESTED_ROUTE_B", null, null);
        } else {
            event("Designate", id, "NOT_REQUESTED_ROUTE_A", null, null);
            try {
                event("UIAddButton", id, "ATTEMPT; label=" + key + "_LABEL; help=" + key + "_HELP", null, null);
                session.UIAddButton(command, menuPolicy.menu, menuPolicy.neighbor,
                        key + "_LABEL", key + "_HELP", MESSAGES);
                event("UIAddButton", id, "LEGACY_MENU_CALL_RETURNED; NOT_MODERN_TOOLKIT_LIST_EVIDENCE; ACTUAL_LOCATION_UNVERIFIED", null, null);
            } catch (Throwable error) {
                event("UIAddButton", id, "THROWN", null, error);
                throw error;
            }
        }
        String icon = System.getenv("SISW_UI_PROBE_ICON");
        if (icon == null || icon.isBlank()) {
            event("SetIcon", id, "SKIPPED_NO_ICON_CONFIGURED", null, null);
        } else {
            try {
                command.SetIcon(icon);
                event("SetIcon", id, "RETURNED; icon=" + icon, null, null);
            } catch (Throwable error) {
                event("SetIcon", id, "THROWN; default icon retained", null, error);
            }
        }
    }

    private static final class MenuPolicy {
        final String menu;
        final String neighbor;
        final boolean createMenu;
        final String parentMenu;
        final String menuNeighbor;
        final String sourceExamplePath;
        final String name;
        boolean uiAddMenuCalled;
        MenuPolicy(String menu, String neighbor, boolean createMenu, String parentMenu,
                   String menuNeighbor, String sourceExamplePath, String name) {
            this.menu = menu;
            this.neighbor = neighbor;
            this.createMenu = createMenu;
            this.parentMenu = parentMenu;
            this.menuNeighbor = menuNeighbor;
            this.sourceExamplePath = sourceExamplePath;
            this.name = name;
        }
    }

    private static MenuPolicy resolveMenuPolicy() {
        String menu = requiredPolicyValue("SISW_UI_PROBE_MENU");
        String neighborToken = requiredPolicyValue("SISW_UI_PROBE_NEIGHBOR");
        String createToken = System.getenv("SISW_UI_PROBE_CREATE_MENU");
        boolean create = "1".equals(createToken);
        if (createToken != null && !createToken.isBlank() && !"0".equals(createToken) && !create) {
            throw policyRejected("CREATE_MENU must be absent, 0, or 1");
        }
        if ("File".equals(menu)) {
            if (!"null".equals(neighborToken) || create) {
                throw policyRejected("File requires explicit neighbor token null and no UIAddMenu");
            }
            return new MenuPolicy(menu, null, false, null, null,
                    "jlinkexamples/RunDisplayExamples.java", "FILE_EXPLICIT_NULL_NEIGHBOR");
        }
        if ("Applications".equals(menu)) {
            if (!"Applications.psh_util_pproc".equals(neighborToken) || create) {
                throw policyRejected("Applications requires Applications.psh_util_pproc and no UIAddMenu");
            }
            return new MenuPolicy(menu, neighborToken, false, null, null,
                    "jlink_elev/source/parameditor/ParamEditor.java", "APPLICATIONS_EXPLICIT_NEIGHBOR");
        }
        if (!"P1_UI_CUSTOM_MENU".equals(menu)) throw policyRejected("Menu is outside the explicit allowlist: File, Applications, P1_UI_CUSTOM_MENU");
        if (!create) throw policyRejected("Custom menu requires SISW_UI_PROBE_CREATE_MENU=1");
        String parent = requiredPolicyValue("SISW_UI_PROBE_PARENT_MENU");
        String menuNeighborToken = requiredPolicyValue("SISW_UI_PROBE_MENU_NEIGHBOR");
        String source = requiredPolicyValue("SISW_UI_PROBE_SOURCE_EXAMPLE").replace('\\', '/');
        if (!(source.equals("pfcExamplesMenu.java") || source.endsWith("/pfcExamplesMenu.java")
                || source.equals("pfcAsyncFullExample.java") || source.endsWith("/pfcAsyncFullExample.java"))) {
            throw policyRejected("Custom policy requires pfcExamplesMenu.java or pfcAsyncFullExample.java reference");
        }
        // Custom example parameter values were not supplied. Require an explicit operator declaration;
        // this is NOT an automatic check of the example file or its parameter semantics.
        if (!"1".equals(System.getenv("SISW_UI_PROBE_CUSTOM_POLICY_CONFIRMED"))) {
            throw policyRejected("Custom parameter tuple requires explicit local-example confirmation");
        }
        return new MenuPolicy(menu, explicitNullableToken(neighborToken), true, parent,
                explicitNullableToken(menuNeighborToken), source, "CUSTOM_EXPLICIT_EXAMPLE_DECLARATION");
    }

    private static String requiredPolicyValue(String variable) {
        String value = System.getenv(variable);
        if (value == null || value.isBlank()) throw policyRejected("Missing explicit value: " + variable);
        return value.trim();
    }

    private static String explicitNullableToken(String value) {
        return "null".equals(value) ? null : value;
    }

    private static IllegalArgumentException policyRejected(String reason) {
        event("MENU_POLICY", null, "ROUTE_A_MENU_POLICY_REJECTED; " + reason, null, null);
        return new IllegalArgumentException("ROUTE_A_MENU_POLICY_REJECTED: " + reason);
    }

    public static void stop() {
        active = false;
        for (int i = commands.size() - 1; i >= 0; i--) {
            try {
                commands.get(i).RemoveActionListener(listeners.get(i));
                event("RemoveActionListener", listeners.get(i).id, "RETURNED; UNREGISTRATION_UNVERIFIED", null, null);
                commands.remove(i);
                listeners.remove(i);
            } catch (Throwable error) {
                event("RemoveActionListener", listeners.get(i).id, "THROWN; disabled pair retained; restart before reloading", null, error);
            }
        }
        session = null;
    }

    private static final class ProbeListener extends DefaultUICommandActionListener {
        private final String id;
        private ProbeListener(String id) { this.id = id; }
        @Override
        public void OnCommand() {
            String requestId = UUID.randomUUID().toString();
            event("OnCommand", id, "ENTERED; modelMayHaveChanged=false; saved=false; readonlyProbe=true", requestId, null);
            if (!active || session == null) {
                event("OnCommand", id, "INACTIVE_OR_NO_SESSION; no SDK called", requestId, null);
                return;
            }
            try {
                session.UIDisplayMessage(MESSAGES, "P1_UI_PROBE_CALLBACK", null);
                event("UIDisplayMessage", id, "RETURNED; key=P1_UI_PROBE_CALLBACK; no model API called", requestId, null);
            } catch (Throwable error) {
                event("UIDisplayMessage", id, "THROWN; key=P1_UI_PROBE_CALLBACK; no model API called", requestId, error);
            }
        }
    }

    private static void event(String stage, String id, String outcome, String requestId, Throwable error) {
        String text = Instant.now() + " UI_PROBE; registrationId=" + registrationId
                + "; route=" + route + "; commandId=" + id + "; requestId=" + requestId
                + "; stage=" + stage + "; messageFile=" + MESSAGES
                + "; messageLookup=MESSAGE_LOOKUP_UNVERIFIED; outcome=" + outcome
                + "; objectRegistered=UNVERIFIED; macroDispatchable=UNVERIFIED; uiListed=UNVERIFIED"
                + "; ribbonVisible=UNVERIFIED; featureCreated=UNVERIFIED"
                + "; runtimeStringseqAcceptance=RUNTIME_STRINGSEQ_ACCEPTANCE_UNVERIFIED"
                + "; menu=" + (menuPolicy == null ? "N/A" : menuPolicy.menu)
                + "; neighbor=" + (menuPolicy == null ? "N/A" : menuPolicy.neighbor)
                + "; uiAddMenuCalled=" + (menuPolicy != null && menuPolicy.uiAddMenuCalled)
                + "; sourceExamplePath=" + (menuPolicy == null ? "N/A" : menuPolicy.sourceExamplePath)
                + "; menuPolicy=" + (menuPolicy == null ? "N/A" : menuPolicy.name)
                + "; exampleVerification=OPERATOR_DECLARATION_NOT_FILE_VERIFICATION";
        // A whole error record is emitted together; never print process environment or credentials.
        if (error != null) {
            java.io.StringWriter stack = new java.io.StringWriter();
            error.printStackTrace(new java.io.PrintWriter(stack));
            text += System.lineSeparator() + stack;
        }
        System.err.println(text);
    }
}

/** Route A entry only. Use a clean session and the J-Link template. */
public final class JLinkUiProbe {
    private JLinkUiProbe() { }
    public static void start() throws Throwable { UiExposureProbe.start("A"); }
    public static void stop() { UiExposureProbe.stop(); }
}

# P1 6A R3 UI Offline 源码候选（2026-11-03）

本包未编译、未加载、未部署、未验证真机UI，也未证明真实转钣金可用。只包含源码、消息资源、含占位符模板、静态脚本和Markdown/JSON证据设计；没有class/jar/dat/bat/rbn/html/js产物。本轮没有安装、启动或生产目录覆盖命令。

## 输入基线及T1材料

UIEntry基线源码SHA256：`47c7acf6f37121b23b952a5a04489cec9f6edd2f07714e28830ec56ba9e0dc0c`。
UIEntry基线ZIP SHA256：`0839aca66fa6fdcdac50f9ba64465b3d1db97c67b1156dadbe7dc4af224f95b4`。

附件T1 README与manifest描述已准备、未激活、未修改config.pro、未覆盖生产文件。已核对上传README的字节数/SHA256与manifest一致，且manifest中的基线ZIP/源码哈希与本地保留的输入匹配。Windows上的class/dat/图标、major版本与路径仅为输入声明，未独立读取或执行；没有读取运行日志或查看进程。

T1不是R3运行证据。R3源码改变后不得沿用T1旧class哈希，若本机采用本候选必须重新独立审核和隔离编译、生成新的manifest。现有T1准备材料不自动变成R3安装目录。

## 修改清单与相对基线diff摘要

| 项目 | 修改 |
|---|---|
| BatchRename.registerPageCommand | 向创建、Designate和图标审计传递实际messageFile与三类键；业务命令ID、页面URL及导航不变 |
| BatchRename.registerConversionCommand | 仅更新注册辅助方法和审计的参数；监听器启用、追踪和失败清理保持原样 |
| BatchRename.createUiCommand | 接受消息文件和三类键，结果分为ATTEMPT、RETURNED_NON_NULL、THROWN；空返回以异常如实记录，不推断可见性 |
| BatchRename.designateUiCommand | 参数化为id、messageFile、command、labelKey、helpKey、descriptionKey；实际调用command.Designate(messageFile,...)，不再硬编码MESSAGES |
| BatchRename.uiRegistrationAudit | 独立字段记录实际文件与三类键；stage/outcome分离；移除操作者填写说明占位文本；增加五层UNVERIFIED状态与RUNTIME_STRINGSEQ_ACCEPTANCE_UNVERIFIED标签 |
| UiExposureProbe | 强制显式neighbor、菜单允许表、策略拒绝日志；自定义先UIAddMenu；日志记录策略/来源及调用阶段；L1至L5观察字段均为UNVERIFIED，不从API返回升级可见性 |
| probe消息资源 | 删除路线A未使用的4个DESC键；新增自定义菜单标题P1_UI_CUSTOM_MENU，避免向UIAddMenu传不存在的标题键 |
| OTK模板 | classpath拆分为应用JAR与官方otk.jar两个显式占位符；不迁移业务类 |
| 新增/重写审核资料 | checks/static_check.py、evidence/resource-coverage.json、证据模板与schema、OTK前提/实验矩阵/本说明、输入一致性与未决风险 |

JLinkUiProbe/OtkUiProbe入口包装源码、业务java模板、A模板、业务UI和状态消息正文均保持基线。根目录与usascii布局分别保留，不合并；资源内容相同。

## 明确未修改的业务块

静态脚本逐块比较基线：SmtConvertListener、ConversionFailure、convertPreselectedPlane、WFC实体/会话适配器、face归属、requireConfirmedMillimetres、板厚路径、7节点树、WCreateFeature/WRegenerate及其前后回读、失败子特征诊断、showConversionMessage、nativeAudit、track/untrack/detach、OpenPageListener、URL守卫和模式识别、start/stop及CREOSON后台启动函数。

本轮不改NO_MODEL、单位、板厚、特征创建或保存分支，不改材料侧或选项，不恢复桥接。日志五层默认字段仅用于UI注册/只读探针的观察状态；R2已有转换trace里的真实featureCreated等技术字段不被覆盖。

业务类仍为startup java。UI registration日志没有读取有效dat的SDK能力，datStartup等保持UNVERIFIED_REGISTRY_NOT_READ；实际字段在`evidence-template/registration-context.json`由操作者填写，源码中不放“attach...”填表说明。

## 双向资源检查设计

脚本不是Java编译器，支持当前有限、明确的注册源码结构：解析字符串常量和registerPageCommand实际调用，绑定包装方法参数后解析其designateUiCommand调用；再解析转换命令直接调用。每个业务命令的文件、label/help/description键来自源码解析，不由资源表反向猜测。若新增不支持的表达式或绕过辅助方法的额外Designate，检查失败并报告未解析表达式。

探针通过源码中的有限suffix集合及已核对的key生成表达式展开A/B两组引用；B有三类Designate键，A只有UIAddButton的label/help，另记录UIAddMenu标题键及回调状态键。其余未支持的动态表达式需要扩展检查器，不能冒称通用Java静态分析。

每个layout单独检查四行组（键正则、非空正文、可空译文、空预留行）、布局内键唯一性、文件名小写/三字符扩展名/不超过30字符、全部引用存在和全部资源键被引用；UI Designate资源与转换状态资源独立分类。输出`evidence/resource-coverage.json`包含命令、键角色、文件、layout、行号、缺失状态及未引用项。两个layout同名文件逐字节比较。

当前每个layout：业务UI12键48行、转换状态6键24行、探针22键88行。每个layout40个资源键全部有用途。四行格式需要EOF末尾空行，禁止自动删除或使用git apply --whitespace=fix；补丁可用--whitespace=nowarn保留字节并抑制预期空白告警。

## 路线A菜单策略

详见docs/controlled-experiment-matrix.md。菜单只允许File、Applications或本包自定义P1_UI_CUSTOM_MENU；neighbor从SISW_UI_PROBE_NEIGHBOR读取且必填。File只有显式字面字符串null可转为原生null，Applications必须为Applications.psh_util_pproc。不存在默认null neighbor。

自定义必须CREATE_MENU=1，并提供parent/menu-neighbor/示例路径/明确本机参数核对声明；UIAddMenu在按钮注册前调用。只接受已提供的两种自定义菜单示例文件名，源码不假装已读取原始示例或验证参数。示例名和确认值只是策略声明；仍需本机核对。

不匹配即ROUTE_A_MENU_POLICY_REJECTED，不静默回退。UIAddButton正常返回仅标记LEGACY_MENU_CALL_RETURNED、NOT_MODERN_TOOLKIT_LIST_EVIDENCE；uiAddMenuCalled只记录是否调用，不证明可见或成功。

## 路线B与消息参数

OTK路线仅保留只读OtkUiProbe；见docs/route-b-otk-prerequisites.md。应用JAR、解锁/签名、许可、官方otk.jar、注册字段、text_dir关系均为UNVERIFIED，由操作者提供实际证据。不生成JAR、许可声明或解锁文件。

UIDisplayMessage第三参数仍为null，不引入新API。R3注册与探针审计含RUNTIME_STRINGSEQ_ACCEPTANCE_UNVERIFIED。此前输入报告记录P1_6A_FAILED单次提示成功，不推翻该限定事实；该证据不能替代其他上下文及null与空stringseq差异的受控比较。本轮不执行这种比较。

## 五层证据与实验边界

L1对象、L2宏/回调触发、L3候选列表/搜索、L4固定Ribbon按钮、L5转换创建分别记录。UI注册与探针代码的objectRegistered、macroDispatchable、uiListed、ribbonVisible、featureCreated观察字段默认UNVERIFIED，不能自动置true。

`evidence-template/runtime-evidence-schema.json`限定记录形状，并要求VERIFIED/FAILED观察有证据文件哈希；L5本轮只允许UNVERIFIED或NOT_APPLICABLE。schema不认证截图真实性，不推断根因，也不以一个层级替代另一个层级。原始模板不是真机证据。

C1/C2使用同一R3业务编译产物，只改变资源layout且新开干净会话；text_dir父目录与语言子目录实际查找均待记录。C3、C4是独立的探针条件，不把不同身份/API/注册方式变化混称单因素因果证明。消息文件会话内只加载一次，变更后必须重启。

## 实际验证与未执行项

实际执行仅Python文本静态检查、资源覆盖检查、输入哈希核对、补丁文本回放与归档检查。检查结果见evidence/static-claims.json和patch-replay.json；不等于Java语法、SDK兼容性或功能通过。

未执行：javac、javap、jar、Creo、macro、deployment、feature creation、进程查看、运行日志查看、node --check、浏览器、Mock/Stub。未切换config.pro、未复制到生产路径、未启动服务或操作真实模型。

本机可在其独立审核流程中复跑文本脚本、使用真实同步otk.jar与--release 17隔离编译，并核对新class清单及major=61；这些均不是本包已经完成的结果。许可、UI可见、手工NO_MODEL回归和生产恢复仍需实际证据。

## 本轮文本验证结果

- 主检查84/84通过；四个业务Designate调用均解析，两个layout的引用覆盖无缺失、无未引用键。
- 两个临时文本反例（删除被引用键、添加多余键）均使检查器按预期退出1；这只验证文本检查器，不执行Java或SDK，也不是SDK Mock/Stub。
- JSON Schema Draft 2020-12结构检查通过；不代表任何运行证据已认证。
- 统一源码/资源/注册模板补丁修改5个目标文件，回放后连同8个保持不变目标共13/13逐字节一致。补丁不替代单独交付的审核说明与静态脚本；相对文件清单见evidence/diff-summary.json。

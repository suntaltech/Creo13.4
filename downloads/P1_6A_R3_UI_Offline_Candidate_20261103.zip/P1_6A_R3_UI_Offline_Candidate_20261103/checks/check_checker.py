"""Negative text fixtures for the source/resource checker; never runs Java or SDK."""
from pathlib import Path
import json,shutil,subprocess,sys,tempfile
out=Path(__file__).resolve().parents[1];baseline=Path(sys.argv[1]).resolve();results=[]
for mutation in ['missing_referenced_key','unreferenced_extra_key']:
 with tempfile.TemporaryDirectory(prefix='p1-r3-text-fixture-') as td:
  target=Path(td)/'candidate';target.mkdir()
  for name in ['BatchRename.java','probes','resources','registration','checks']:
   p=out/name
   if p.is_dir():shutil.copytree(p,target/name)
   else:shutil.copyfile(p,target/name)
  (target/'evidence').mkdir()
  p=target/'resources/root-layout/text/p1_6a_ui_commands.txt';lines=p.read_text().splitlines()
  if mutation=='missing_referenced_key':p.write_text('\n'.join(lines[4:])+'\n')
  else:p.write_text(p.read_text()+'P1_UNREFERENCED_FIXTURE\nExtra static-only fixture key\n\n\n')
  run=subprocess.run([sys.executable,str(target/'checks/static_check.py'),str(baseline)],capture_output=True,text=True)
  report=json.loads((target/'evidence/static-claims.json').read_text())
  expected='coverage_no_missing_root-layout' if mutation=='missing_referenced_key' else 'coverage_no_unreferenced_root-layout'
  passed=run.returncode==1 and report['checks'].get(expected) is False
  results.append({'mutation':mutation,'expectedFailedAssertion':expected,'checkerExitCode':run.returncode,'detected':passed})
assert all(x['detected'] for x in results)
(out/'evidence/checker-negative-fixtures.json').write_text(json.dumps({'scope':'temporary text-only resource mutations; not SDK mocks or runtime tests','results':results,'allDetected':True},indent=2)+'\n')
print(json.dumps({'textNegativeFixturesDetected':len(results),'total':len(results)}))

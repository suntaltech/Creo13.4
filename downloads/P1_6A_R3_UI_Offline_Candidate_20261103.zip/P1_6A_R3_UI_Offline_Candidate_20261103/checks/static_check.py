"""Text-only source/resource consistency. Does not execute Java, SDK or runtime commands."""
from pathlib import Path
import hashlib,json,re,sys
out=Path(__file__).resolve().parents[1]; baseline=Path(sys.argv[1]); s=(out/'BatchRename.java').read_text(); b=baseline.read_text()
checks={}; unresolved=[]
def check(name,value):checks[name]=bool(value)
def strip(text):
 return re.sub(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|//[^\n]*|/\*[\s\S]*?\*/',lambda m:''.join('\n' if c=='\n' else ' ' for c in m.group()),text)
def block(text,marker):
 clean=strip(text); start=text.index(marker); pos=clean.index('{',start); depth=1;i=pos+1
 while depth:
  depth+=(clean[i]=='{')-(clean[i]=='}');i+=1
 return text[start:i]
def split_args(text):
 parts=[];start=0;depth=0;quote=None;escape=False
 for i,c in enumerate(text):
  if quote:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c==quote:quote=None
  elif c in '\"\'':quote=c
  elif c in '([{':depth+=1
  elif c in ')]}':depth-=1
  elif c==',' and depth==0:parts.append(text[start:i].strip());start=i+1
 parts.append(text[start:].strip());return parts
def calls(text,name):
 clean=strip(text)
 for m in re.finditer(r'\b'+name+r'\s*\(',text):
  # String/comment matches are masked, declarations have '{' after their argument list.
  if not clean[m.start():m.start()+len(name)].strip():continue
  op=text.index('(',m.start());depth=1;i=op+1
  while depth:
   depth+=(clean[i]=='(')-(clean[i]==')');i+=1
  tail=text[i:].lstrip()
  if tail.startswith('throws ') or tail.startswith('{'):continue
  yield split_args(text[op+1:i-1])
def resolve(expr,env):
 expr=expr.strip()
 if re.fullmatch(r'"(?:\\.|[^"\\])*"',expr):return json.loads(expr)
 if expr in env:return env[expr]
 raise ValueError('unresolved expression: '+expr)
constants={m.group(1):json.loads(m.group(2)) for m in re.finditer(r'private static final String (\w+)\s*=\s*("(?:\\.|[^"\\])*")\s*;',s)}
check('baseline_sha256',hashlib.sha256(baseline.read_bytes()).hexdigest()=='47c7acf6f37121b23b952a5a04489cec9f6edd2f07714e28830ec56ba9e0dc0c')
markers=['private static final class SmtConvertListener','private static final class ConversionFailure','private static Map<String,Object> convertPreselectedPlane','private static void verifyFaceInDefaultBody','private static boolean showConversionMessage','private static void requireConfirmedMillimetres','private static boolean readFeatureMetadata','private static void readFailedFeatureChildren','private static void ensureWfcSession','private static void recordNativeObject','private static long nativePointer','private static boolean sameModel','private static void addElement','private static void nativeAudit','private static void trackCommand','private static void untrackCommand','private static void detach','private static final class OpenPageListener','private static String guardedPageUrl','private static String detectActiveModelMode','private static String appendPageQuery','private static synchronized void ensureCreosonRunningAsync','private static WSession createWfcSession','public static void start()','public static void stop()']
for marker in markers:check('unchanged_'+marker.split('(')[0].split()[-1],block(s,marker)==block(b,marker))
a='    private static WSolid wrapAsWSolid(Model model)';z='    /** Reuse the baseline WSession'
check('solid_wrappers_unchanged',s[s.index(a):s.index(z)]==b[b.index(a):b.index(z)])
check('no_registry_placeholder_in_code','attach_selected_dat_and_classpath_manifest_from_test_operator' not in s)
check('parameterized_designate', 'command.Designate(messageFile, labelKey, helpKey, descriptionKey)' in s)
check('parameterized_audit',all('event.put("'+key+'", '+key+')' in s for key in ['messageFile','labelKey','helpKey','descriptionKey']))
check('audit_outcomes_are_separate',all(v in s for v in ['"ATTEMPT"','"RETURNED_NON_NULL"','"RETURNED"','"THROWN"']))
check('runtime_null_acceptance_unverified','RUNTIME_STRINGSEQ_ACCEPTANCE_UNVERIFIED' in s)
check('no_registration_evidence_promoted',all('event.put("'+key+'", "UNVERIFIED")' in s for key in ['objectRegistered','macroDispatchable','uiListed','ribbonVisible','featureCreated']))
# Expand the page-registration wrapper with the values from its actual call sites.
page=block(s,'private static UICommand registerPageCommand'); entries=[]
for args in calls(s,'registerPageCommand'):
 try:
  env=dict(constants)
  for name,index in [('commandId',0),('labelKey',2),('helpKey',3),('descriptionKey',4)]:env[name]=resolve(args[index],env)
  nested=list(calls(page,'designateUiCommand'))
  if len(nested)!=1:raise ValueError('page helper must designate once')
  vals=nested[0]
  values=[resolve(vals[i],env) for i in [0,1,3,4,5]]
  entries.append(dict(zip(['commandId','messageFile','labelKey','helpKey','descriptionKey'],values),usage='Designate'))
 except (ValueError,IndexError) as e:unresolved.append(str(e))
# Direct literal/constant calls outside the known page helper must resolve too.
without_page=s.replace(page,'')
for args in calls(without_page,'designateUiCommand'):
 try:
  values=[resolve(args[i],constants) for i in [0,1,3,4,5]]
  entries.append(dict(zip(['commandId','messageFile','labelKey','helpKey','descriptionKey'],values),usage='Designate'))
 except (ValueError,IndexError) as e:unresolved.append(str(e))
check('four_business_designate_sites_resolved',len(entries)==4 and not unresolved)
# Check all raw business Designate calls are routed through the parameterized helper.
check('single_raw_business_designate_call',len(list(calls(s,'Designate')))==1)
statefile=constants['CONVERSION_MESSAGES']; uifile=constants['MESSAGES']
# Six state literals are passed directly or selected by the feedback ternary, not inferred from resource keys.
statekeys=set(re.findall(r'"(P1_6A_[A-Z0-9_]+)"',s))
check('state_resource_separate',statefile!=uifile)
probe=(out/'probes/UiExposureProbe.java').read_text();pc=strip(probe)
check('explicit_neighbor_required','requiredPolicyValue("SISW_UI_PROBE_NEIGHBOR")' in probe)
check('route_a_allowlist',all(v in probe for v in ['"File".equals(menu)','"Applications".equals(menu)','"P1_UI_CUSTOM_MENU".equals(menu)','ROUTE_A_MENU_POLICY_REJECTED','Applications.psh_util_pproc']))
check('custom_menu_creation_before_buttons',probe.index('session.UIAddMenu(')<probe.index('register(suffix)') and 'menuPolicy.createMenu' in probe)
check('custom_policy_parameters_explicit',all('requiredPolicyValue("'+v+'")' in probe for v in ['SISW_UI_PROBE_PARENT_MENU','SISW_UI_PROBE_MENU_NEIGHBOR','SISW_UI_PROBE_SOURCE_EXAMPLE']))
check('no_default_null_button_neighbor','session.UIAddButton(command, menuPolicy.menu, menuPolicy.neighbor,' in probe and 'UIAddButton(command, menu, null' not in probe)
check('legacy_not_modern','LEGACY_MENU_CALL_RETURNED; NOT_MODERN_TOOLKIT_LIST_EVIDENCE' in probe)
check('probe_readonly',not re.search(r'\.(?:GetActiveModel|GetCurrentModel|WCreateFeature|WRegenerate|Save|OpenFile|Navigate|CreateModelItemSelection)\s*\(',pc) and 'BatchRename.' not in pc)
check('probe_b_no_button_fallback','if ("B".equals(route))' in probe and 'NOT_REQUESTED_ROUTE_B' in probe)
check('probe_observation_defaults',all(k+'=UNVERIFIED' in probe for k in ['objectRegistered','macroDispatchable','uiListed','ribbonVisible','featureCreated']))
check('probe_example_sources',all(n in probe for n in ['RunDisplayExamples.java','ParamEditor.java','pfcExamplesMenu.java','pfcAsyncFullExample.java']))
# The finite route/suffix generator is validated before expanding its actual key expressions.
check('supported_probe_key_generator','String key = "P1_UI_" + route + "_" + suffix.toUpperCase(java.util.Locale.ROOT);' in probe)
m=re.search(r'for \(String suffix : new String\[\] \{([^}]+)\}',probe)
suffixes=re.findall(r'"([A-Za-z]+)"',m.group(1)) if m else []
check('four_probe_suffixes',len(suffixes)==4 and len(set(suffixes))==4)
probe_entries=[]
for mode in ['A','B']:
 for suffix in suffixes:
  base='P1_UI_'+mode+'_'+suffix.upper()
  item={'commandId':'SISWUIProbe'+mode+suffix,'messageFile':'p1_6a_ui_probe.txt','labelKey':base+'_LABEL','helpKey':base+'_HELP','usage':'UIAddButton' if mode=='A' else 'Designate'}
  if mode=='B':item['descriptionKey']=base+'_DESC'
  probe_entries.append(item)
references={uifile:{},statefile:{},'p1_6a_ui_probe.txt':{}}
for item in entries+probe_entries:
 for role in ['labelKey','helpKey','descriptionKey']:
  if role in item:references[item['messageFile']].setdefault(item[role],[]).append({'commandId':item['commandId'],'role':role,'usage':item['usage']})
for key in statekeys:references[statefile][key]=[{'commandId':'SISWSheetMetalConvert','role':'status','usage':'UIDisplayMessage'}]
for key,usage in [('P1_UI_PROBE_CALLBACK','UIDisplayMessage'),('P1_UI_CUSTOM_MENU','UIAddMenu')]:
 check('probe_literal_reference_'+key,'"'+key+'"' in probe)
 references['p1_6a_ui_probe.txt'][key]=[{'commandId':'READONLY_PROBE','role':'callbackStatus' if usage=='UIDisplayMessage' else 'customMenuLabel','usage':usage}]
coverage={'scope':'text source/reference coverage; not runtime message lookup','businessCommands':entries,'probeCommands':probe_entries,'unresolvedSourceExpressions':unresolved,'layouts':[]}
for layout,folder in [('root-layout',out/'resources/root-layout/text'),('usascii-layout',out/'resources/usascii-layout/text/usascii')]:
 item={'layout':layout,'files':[],'missingKeys':[],'unreferencedKeys':[],'missingFiles':[]};allkeys=[]
 paths={p.name:p for p in folder.glob('*.txt')}
 for name in references:
  if name not in paths:item['missingFiles'].append(name)
 for name,p in sorted(paths.items()):
  lines=p.read_text(encoding='ascii').splitlines();keys=lines[::4];lookup={key:i*4+1 for i,key in enumerate(keys)}
  check('filename_'+layout+'_'+name,bool(re.fullmatch(r'[a-z0-9_]+\.[a-z]{3}',name)) and len(name)<=30)
  check('four_lines_'+layout+'_'+name,len(lines)%4==0 and all(re.fullmatch(r'[A-Z0-9_]+',k) for k in keys) and all(lines[i+1].strip() and lines[i+3]=='' for i in range(0,len(lines)-3,4)))
  allkeys+=keys
  expected=references.get(name,{})
  rows=[{'key':key,'file':name,'layout':layout,'line':lookup.get(key),'missing':key not in lookup,'sourceReferences':uses} for key,uses in sorted(expected.items())]
  item['missingKeys'] +=[{'file':name,'key':key} for key in expected if key not in lookup]
  item['unreferencedKeys'] +=[{'file':name,'key':key} for key in keys if key not in expected]
  item['files'].append({'file':name,'role':'UI_DESIGNATE' if name==uifile else 'CONVERSION_STATUS' if name==statefile else 'READONLY_UI_PROBE','lines':len(lines),'keys':len(keys),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'coverage':rows})
 check('keys_unique_'+layout,len(allkeys)==len(set(allkeys)))
 check('coverage_no_missing_'+layout,not item['missingKeys'] and not item['missingFiles'])
 check('coverage_no_unreferenced_'+layout,not item['unreferencedKeys'])
 check('ui_status_disjoint_'+layout,not(set(references[uifile])&set(references[statefile])))
 coverage['layouts'].append(item)
for name in references:
 check('layout_identical_'+name,(out/'resources/root-layout/text'/name).read_bytes()==(out/'resources/usascii-layout/text/usascii'/name).read_bytes())
for p in [out/'BatchRename.java',*sorted((out/'probes').glob('*.java'))]:
 code=strip(p.read_text());stack=[];pairs={')':'(',']':'[','}':'{'};ok=True
 for c in code:
  if c in '([{':stack.append(c)
  elif c in ')]}':
   if not stack or stack.pop()!=pairs[c]:ok=False;break
 check('balanced_delimiters_only_'+p.name,ok and not stack)
 check('forbidden_api_'+p.name,not re.search(r'\.(?:Save|AddBrowserMessageListener)\s*\(|window\.external|PRO_E_SHELL_SRF',code))
business_template=(out/'registration/business-java.dat.template').read_text();bt=(out/'registration/route-b-otk-java.dat.template').read_text()
check('business_remains_java','startup java\n' in business_template and 'otk_java' not in business_template)
check('b_separate_classpath_parts','@ABSOLUTE_APPLICATION_JAR_PATH@;@ABSOLUTE_OFFICIAL_OTK_JAR_PATH@' in bt and 'startup otk_java' in bt and 'java_app_class OtkUiProbe' in bt)
check('no_runtime_artifacts',not any(p.suffix.lower() in {'.class','.jar','.dat','.bat','.rbn','.html','.js'} for p in out.rglob('*') if p.is_file()))
(out/'evidence/resource-coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
report={'scope':'text-only static checks; not Java compilation, UI verification or runtime evidence','baselineSha256':hashlib.sha256(baseline.read_bytes()).hexdigest(),'sourceSha256':hashlib.sha256((out/'BatchRename.java').read_bytes()).hexdigest(),'checks':checks,'allPassed':all(checks.values()),'notExecuted':['javac','javap','jar','Creo','macro','deployment','feature creation','node --check','process inspection','runtime log inspection','browser','Mock/Stub']}
(out/'evidence/static-claims.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':sum(checks.values()),'total':len(checks),'failed':[k for k,v in checks.items() if not v],'unresolved':unresolved},ensure_ascii=False))
raise SystemExit(0 if report['allPassed'] else 1)

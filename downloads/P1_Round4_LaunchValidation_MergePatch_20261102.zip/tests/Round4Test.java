import com.ptc.pfc.pfcCommand.*;
import com.ptc.pfc.pfcModel.*;
import com.ptc.pfc.pfcSession.*;
import com.ptc.pfc.pfcSolid.*;
import com.ptc.pfc.pfcWindow.*;
import com.ptc.wfc.wfcSolid.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.*;
import java.nio.file.*;

/** Stubs verify edited source logic only. This is NOT SDK compilation or native UI validation. */
public final class Round4Test {
 static int checks, nativeReads;
 static Thread owner = Thread.currentThread();
 static void check(boolean ok,String name){if(!ok)throw new AssertionError(name);checks++;System.out.println("PASS "+name);}
 static void ui(){if(Thread.currentThread()!=owner)throw new AssertionError("mock native call off owner");}
 static class Body implements SolidBody {boolean smt;boolean bad;public boolean IsSheetmetal(){ui();if(bad)throw new RuntimeException("failed flag");return smt;}}
 static class ModelMock implements WSolid {
  ModelType type=ModelType.MDL_PART;String file="test.prt";Body body=new Body();
  public ModelType GetType(){ui();return type;}public String GetFileName(){ui();return file;}
  public SolidBody GetDefaultBody(){ui();return body;}
 }
 static class Win implements Window {
  String url;int navigations;
  public String GetURL(){ui();return url;}public void SetURL(String x){ui();url=x;navigations++;}
  public void SetBrowserSize(double x){ui();}public void Activate(){ui();}public void Refresh(){ui();}
 }
 static class Cmd implements UICommand {
  DefaultUICommandActionListener listener;Cmd(DefaultUICommandActionListener x){listener=x;}
  public void Designate(String a,String b,String c,String d){ui();}public void SetIcon(String x){ui();}
  public void RemoveActionListener(DefaultUICommandActionListener x){ui();listener=null;}
 }
 static class Sess implements Session {
  ModelMock model=new ModelMock();Win win=new Win();Map<String,Cmd> commands=new LinkedHashMap<>();
  public UICommand UICreateCommand(String id,DefaultUICommandActionListener x){ui();Cmd c=new Cmd(x);commands.put(id,c);return c;}
  public Window GetCurrentWindow(){ui();return win;} public Windows ListWindows(){ui();return null;}
  public Model GetActiveModel(){ui();nativeReads++;return model;}
 }
 static Method method(String name,Class<?>...args)throws Exception{Method m=BatchRename.class.getDeclaredMethod(name,args);m.setAccessible(true);return m;}
 static Object field(String name)throws Exception{Field f=BatchRename.class.getDeclaredField(name);f.setAccessible(true);return f.get(null);}
 static Map<String,String> valid(){return new LinkedHashMap<>(Map.of("mode","driving","thickness","1","confirm","true","model","test.prt"));}
 @SuppressWarnings("unchecked")
 static Map<String,Object> convert(Map<String,String> p)throws Exception{return P1ClosedContract.validate(p);}
 static void rejected(Map<String,String> p,String code)throws Exception{Map<String,Object> r=convert(p);System.out.println("CONTRACT_TEST {\"executionContext\":\"test_only_contract\",\"expected\":\""+code+"\",\"errorCode\":\""+r.get("errorCode")+"\",\"saved\":false}");check(Boolean.FALSE.equals(r.get("ok"))&&code.equals(r.get("errorCode"))&&Boolean.FALSE.equals(r.get("saved")),code);}
 static void rejectDirectory(Method validator,String requested,List<Path> approved,String name)throws Exception{
  try{validator.invoke(null,requested,approved);throw new AssertionError(name);}
  catch(InvocationTargetException error){check(error.getCause() instanceof java.io.IOException,name);}
 }
 public static void main(String[]args)throws Exception{
  Sess s=new Sess();pfcSession.mock=s;
  java.io.PrintStream realErr=System.err;
  CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1),launchEntered=new CountDownLatch(1),releaseLaunch=new CountDownLatch(1);
  System.setErr(new java.io.PrintStream(java.io.OutputStream.nullOutputStream()){
   @Override public void print(String text){if(Thread.currentThread()==owner)throw new AssertionError("logger IO on owner");entered.countDown();try{release.await(10,TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}}
  });
  Object firstWorker=null;
  try{
   BatchRename.start();check(entered.await(2,TimeUnit.SECONDS),"background log worker active");
   check(s.commands.keySet().equals(new LinkedHashSet<>(List.of("SISWBatchRename","SISWSheetMetal","SISWAbout"))),"three command IDs preserved");
   BatchRename.start();check(s.commands.size()==3,"active start idempotent");
   for(Cmd c:s.commands.values())c.listener.OnCommand();
   check(s.win.navigations==3,"three simulated UI command callbacks return while log IO blocked");
   Thread actualLauncher=(Thread)field("creosonLauncher");if(actualLauncher!=null)actualLauncher.join(2000);
   check(field("creosonLauncher")==null,"Linux mock startup does not execute a Windows launcher");
   java.util.concurrent.atomic.AtomicInteger launchCount=new java.util.concurrent.atomic.AtomicInteger();
   java.util.concurrent.atomic.AtomicReference<Thread> launchOwner=new java.util.concurrent.atomic.AtomicReference<>();
   Runnable pendingLaunch=()->{launchCount.incrementAndGet();launchOwner.set(Thread.currentThread());launchEntered.countDown();try{releaseLaunch.await(10,TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}};
   long launchStart=System.nanoTime();method("launchCreosonAsync",Runnable.class).invoke(null,pendingLaunch);
   check(System.nanoTime()-launchStart<TimeUnit.SECONDS.toNanos(1)&&launchEntered.await(2,TimeUnit.SECONDS)&&launchOwner.get()!=owner,"launcher task is detached from command thread");
   method("launchCreosonAsync",Runnable.class).invoke(null,pendingLaunch);
   check(launchCount.get()==1,"duplicate startup while pending does not launch twice");
   check(field("SHEETMETAL_BRIDGE_ENABLED").equals(false),"bridge flag stays false");
   Method guard=method("guardedPageUrl",String.class,String.class);
   String base="http://localhost:9056/sheetmetal.html";
   check(guard.invoke(null,"SISWSheetMetal",base).toString().contains("modelMode=solid_part"),"solid part guard query emitted");
   s.model.body.smt=true;check(guard.invoke(null,"SISWSheetMetal",base).toString().contains("state=sheetmetal"),"sheetmetal guard");s.model.body.smt=false;
   for(ModelType type:List.of(ModelType.MDL_ASSEMBLY,ModelType.MDL_DRAWING,ModelType.MDL_OTHER)){
    s.model.type=type;check(guard.invoke(null,"SISWSheetMetal",base).toString().contains("guard=need_part"),"nonpart guard "+type);
   }
   s.model.type=ModelType.MDL_PART;s.model.body.bad=true;
   check(guard.invoke(null,"SISWSheetMetal",base).toString().contains("modelMode=unknown"),"IsSheetmetal failure fails closed");s.model.body.bad=false;
   Body original=s.model.body;s.model.body=null;
   check(guard.invoke(null,"SISWSheetMetal",base).toString().contains("modelMode=unknown"),"no default body fails closed");s.model.body=original;
   s.model.file="fake.asm";check(guard.invoke(null,"SISWSheetMetal",base).toString().contains("modelMode=unknown"),"part filename mismatch fails closed");s.model.file="test.prt";
   ModelMock originalModel=s.model;s.model=null;
   check(guard.invoke(null,"SISWSheetMetal",base).toString().contains("modelMode=no_model"),"no active model guard");s.model=originalModel;
   check(Arrays.stream(BatchRename.class.getDeclaredMethods()).noneMatch(m->m.getName().toLowerCase(java.util.Locale.ROOT).contains("convert")),"production class contains no conversion contract or entry");
   rejected(null,"INVALID_REQUEST");
   for(String raw:List.of(""," ","0","-1","0.099","20.01","NaN","Infinity","1,2","0x1","1d","75.750")){
    var p=valid();p.put("thickness",raw);rejected(p,"INVALID_THICKNESS");
   }
   var absent=valid();absent.remove("thickness");rejected(absent,"INVALID_THICKNESS");
   for(String raw:List.of("0.1","1","20")){var p=valid();p.put("thickness",raw);rejected(p,"CHANNEL_BLOCKED");}
   for(String mode:List.of("driving","shell")){var p=valid();p.put("mode",mode);rejected(p,"CHANNEL_BLOCKED");}
   for(String save:List.of("true","1","TRUE","", "garbage")){var p=valid();p.put("save",save);rejected(p,"SAVE_DISABLED");}
   var p=valid();p.put("save","false");rejected(p,"CHANNEL_BLOCKED");
   p=valid();p.put("confirm","false");rejected(p,"CONFIRM_REQUIRED");
   p=valid();p.put("mode","auto");rejected(p,"UNKNOWN_MODE");
   int before=nativeReads;rejected(valid(),"CHANNEL_BLOCKED");check(nativeReads==before,"closed conversion never reads native objects");
   Path scratch=Files.createDirectories(Path.of(System.getProperty("user.home"),"path-tests"));
   Path approved=Files.createDirectory(scratch.resolve("approved"));Files.writeString(approved.resolve("creoson_run.bat"),"@echo off");
   Method validateDirectory=method("validateLaunchDirectory",String.class,List.class);
   check(validateDirectory.invoke(null,approved.toString(),List.of(approved)).equals(approved.toRealPath()),"approved real installation root accepted");
   Path denied=Files.createDirectory(scratch.resolve("not-approved"));Files.writeString(denied.resolve("creoson_run.bat"),"@echo off");
   rejectDirectory(validateDirectory,"relative-path",List.of(approved),"relative directory rejected");
   rejectDirectory(validateDirectory,scratch.resolve("missing").toString(),List.of(approved),"missing directory rejected");
   rejectDirectory(validateDirectory,approved.resolve("creoson_run.bat").toString(),List.of(approved),"file instead of directory rejected");
   rejectDirectory(validateDirectory,denied.toString(),List.of(approved),"unapproved root rejected");
   Path nested=Files.createDirectory(approved.resolve("nested"));Files.writeString(nested.resolve("creoson_run.bat"),"@echo off");
   rejectDirectory(validateDirectory,nested.toString(),List.of(approved),"approved root does not approve children");
   rejectDirectory(validateDirectory,approved.resolve("..").resolve("approved").toString(),List.of(approved),"parent traversal rejected");
   Path noScript=Files.createDirectory(scratch.resolve("no-script"));
   rejectDirectory(validateDirectory,noScript.toString(),List.of(noScript),"missing bat rejected");
   Path dirLink=Files.createSymbolicLink(scratch.resolve("linked-root"),approved);
   rejectDirectory(validateDirectory,dirLink.toString(),List.of(dirLink),"symbolic root rejected even when approved");
   Path script=approved.resolve("creoson_run.bat");Files.delete(script);Files.createSymbolicLink(script,denied.resolve("creoson_run.bat"));
   rejectDirectory(validateDirectory,approved.toString(),List.of(approved),"linked bat rejected");Files.delete(script);Files.writeString(script,"@echo off");
   Path outputLog=approved.resolve("p1_launch_stdout.log");Files.createSymbolicLink(outputLog,denied.resolve("creoson_run.bat"));
   rejectDirectory(validateDirectory,approved.toString(),List.of(approved),"linked output log rejected");Files.delete(outputLog);
   Files.createDirectory(outputLog);rejectDirectory(validateDirectory,approved.toString(),List.of(approved),"directory as output log rejected");Files.delete(outputLog);
   check(validateDirectory.invoke(null,denied.toString(),List.of(denied)).equals(denied.toRealPath()),"explicit custom approved root accepted");
   firstWorker=field("logWorker");
   Method log=method("log",String.class,Throwable.class);
   for(int i=0;i<300;i++)log.invoke(null,"queue pressure",null);
   ThreadPoolExecutor executor=(ThreadPoolExecutor)firstWorker;
   Field dropped=firstWorker.getClass().getDeclaredField("dropped");dropped.setAccessible(true);
   check(executor.getQueue().size()<=128&&((java.util.concurrent.atomic.AtomicLong)dropped.get(firstWorker)).get()>0,"bounded async log records drops");
   long start=System.nanoTime();BatchRename.stop();
   check((System.nanoTime()-start)<TimeUnit.SECONDS.toNanos(1),"stop returns without waiting for blocked log IO or throwing on drops");
   check(s.commands.values().stream().allMatch(c->c.listener==null),"stop detaches all command listeners");
   Thread pending=(Thread)field("creosonLauncher");releaseLaunch.countDown();if(pending!=null)pending.join(2000);
   check(field("creosonLauncher")==null,"launcher completes independently after stop");
   method("log",String.class,Throwable.class).invoke(null,"late launcher diagnostics",null);
   check(field("logWorker")==firstWorker&&executor.isShutdown(),"late startup logging does not reopen worker after stop");
   release.countDown();check(executor.awaitTermination(5,TimeUnit.SECONDS),"audit queue drains in background after IO resumes");
   System.setErr(realErr);
   check(Files.readString(Path.of(System.getProperty("user.home"),"CreoBatchRename","jlink.log")).contains("audit_shutdown dropped="),"shutdown writes dropped-count summary");
   BatchRename.start();check(field("logWorker")!=firstWorker,"reload creates a fresh log worker");BatchRename.stop();
   ((ThreadPoolExecutor)field("logWorker")).awaitTermination(5,TimeUnit.SECONDS);
   System.out.println("TOTAL "+checks+" passed; SDK STUBS only; real otk.jar/Creo NOT RUN");
  }finally{releaseLaunch.countDown();release.countDown();System.setErr(realErr);BatchRename.stop();}
 }
}

from pathlib import Path
import argparse,subprocess,struct,json
p=argparse.ArgumentParser();p.add_argument('--jdk',required=True,type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args()
a.output.mkdir(parents=True,exist_ok=False);src=a.output/'stubs';src.mkdir();classes=a.output/'classes';classes.mkdir()
stubs={
'com/ptc/pfc/pfcCommand/DefaultUICommandActionListener.java':'package com.ptc.pfc.pfcCommand; public class DefaultUICommandActionListener { public void OnCommand() {} }',
'com/ptc/pfc/pfcCommand/UICommand.java':'package com.ptc.pfc.pfcCommand; public interface UICommand { void Designate(String a,String b,String c,String d) throws Exception; void SetIcon(String x) throws Exception; void RemoveActionListener(DefaultUICommandActionListener x) throws Exception; }',
'com/ptc/pfc/pfcModel/ModelType.java':'package com.ptc.pfc.pfcModel; public enum ModelType {MDL_PART, MDL_ASSEMBLY, MDL_DRAWING, MDL_OTHER}',
'com/ptc/pfc/pfcModel/Model.java':'package com.ptc.pfc.pfcModel; public interface Model { ModelType GetType() throws Exception; String GetFileName() throws Exception; }',
'com/ptc/pfc/pfcSolid/SolidBody.java':'package com.ptc.pfc.pfcSolid; public interface SolidBody {boolean IsSheetmetal() throws Exception;}',
'com/ptc/wfc/wfcSolid/WSolid.java':'package com.ptc.wfc.wfcSolid; public interface WSolid extends com.ptc.pfc.pfcModel.Model {com.ptc.pfc.pfcSolid.SolidBody GetDefaultBody() throws Exception;}',
'com/ptc/pfc/pfcSession/CreoCompatibility.java':'package com.ptc.pfc.pfcSession; public enum CreoCompatibility {C4Compatible}',
'com/ptc/pfc/pfcSession/Session.java':'package com.ptc.pfc.pfcSession; public interface Session {com.ptc.pfc.pfcCommand.UICommand UICreateCommand(String id, com.ptc.pfc.pfcCommand.DefaultUICommandActionListener x) throws Exception; com.ptc.pfc.pfcWindow.Window GetCurrentWindow() throws Exception;com.ptc.pfc.pfcWindow.Windows ListWindows() throws Exception; com.ptc.pfc.pfcModel.Model GetActiveModel() throws Exception;}',
'com/ptc/pfc/pfcSession/pfcSession.java':'package com.ptc.pfc.pfcSession; public class pfcSession {public static Session mock; public static Session GetCurrentSessionWithCompatibility(CreoCompatibility c){return mock;}}',
'com/ptc/pfc/pfcWindow/Window.java':'package com.ptc.pfc.pfcWindow; public interface Window {String GetURL() throws Exception;void SetURL(String x) throws Exception;void SetBrowserSize(double x) throws Exception;void Activate() throws Exception;void Refresh() throws Exception;}',
'com/ptc/pfc/pfcWindow/Windows.java':'package com.ptc.pfc.pfcWindow; public interface Windows {int getarraysize() throws Exception;Window get(int i) throws Exception;}'
}
for name,data in stubs.items():
 dest=src/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(data)
root=Path(__file__).resolve().parents[1]
source_root=root/'updated' if (root/'updated').is_dir() else root
commands=[[a.jdk/'bin/javac','--release','17','-encoding','UTF-8','-d',classes,*sorted(src.rglob('*.java')),source_root/'BatchRename.java',root/'tests/Round4Test.java',root/'tests/P1ClosedContract.java'],[a.jdk/'bin/java','-Duser.home='+str(a.output/'home'),'-cp',classes,'Round4Test']]
results=[]
try:
 for i,cmd in enumerate(commands):
  r=subprocess.run([str(x) for x in cmd],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60)
  (a.output/('compile.log' if i==0 else 'java-tests.log')).write_text(r.stdout)
  results.append({'command':[str(x) for x in cmd],'exitCode':r.returncode})
  print('stub compilation' if i==0 else 'mock behavior tests','exit=',r.returncode)
  if r.returncode: print(r.stdout)
  assert r.returncode==0
 for f in classes.rglob('*.class'):assert struct.unpack('>H',f.read_bytes()[6:8])[0]==61
finally:
 (a.output/'summary.json').write_text(json.dumps({'executionContext':'generated_sdk_stubs','realSdkCompile':'not_run','nativeUiRegression':'not_run','results':results},indent=2)+'\n')

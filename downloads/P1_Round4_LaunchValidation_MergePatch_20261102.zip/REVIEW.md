# P1 第四轮：目录批准校验、启动诊断、全桥接关闭

本轮基于第三轮交付源码，按用户“确认”继续最小整改。生产变更仍仅四个文件；保持插件后台拉起服务、只读分析、nativeConvertReady=false、saved=false，未部署 class，未启用任何转换或保存。

## 补丁选择

- `P1_Round4_from_Round3.patch`：用于已应用第三轮的隔离源码。
- `P1_Round4_from_Production.patch`：用于最初交接的四文件生产基线（审核报告称现场尚未应用此前轮次）。

**二选一，不叠加。** 先核对对应 input-sha256 JSON，备份源码，并在副本内执行 `git apply --check <补丁>`；成功后 `git apply`。若现场文件已变化，不能强制覆盖。两份补丁都已在精确输入上应用，输出四文件逐字节核对。

包内根目录四个文件是最终源码。tests 内新增 P1ClosedContract.java 是**仅测试辅助类**，不属于生产源码，也不应复制到运行目录。没有新增生产 Java 包或独立 demo。

## 逐项整改

### 1. 服务目录与批准根分离

请求目录解析优先级不变：JVM `creo.batchrename.serverDir` → 环境变量 `CREO_BR_SERVER_DIR` → 默认 `D:\creoson\CreosonServerWithSetup-2.8.2-win64`。

默认安装根以外的目录必须另由本地运维明确批准：JVM `creo.batchrename.approvedServerRoots` 或环境变量 `CREO_BR_APPROVED_SERVER_ROOTS`，以分号分隔。**只设置请求目录不代表批准该目录**；批准根不从网页、HTTP、URL或localStorage读取。只允许规范化真实目录的精确匹配，批准父目录不会放行任意子目录。

校验拒绝：相对路径、父目录跳转、不存在路径、非目录、路径任一段符号链接、真实路径与规范化路径不同的别名/重解析路径、目录不可读写、未批准根；脚本必须为批准根内可读普通文件，禁止链接；已有stdout/stderr日志必须为同根内可写普通文件，禁止链接或目录。创建日志需要目录可写。无效显式批准项使本次验证失败，不静默放宽范围。

示例仅表示配置格式，应由有权限的现场运维审核实际安装目录后设置：

```powershell
$env:CREO_BR_SERVER_DIR = 'E:\CreoServices\CREOSON'
$env:CREO_BR_APPROVED_SERVER_ROOTS = 'E:\CreoServices\CREOSON'
# 在同一受控启动环境启动Creo，使其继承变量；这里不启动/部署任何现场程序。
```

这不是 .bat 签名/内容认证或 Windows ACL 审计；批准根及脚本应由现场运维控制写权限。Linux离线文件系统测试不能替代Windows junction、驱动器别名、ACL行为验证。路径检查与执行之间仍不是文件系统原子事务；不声称能抵抗本机高权限用户同时替换目录。

### 2. 启动可观测性与责任

仍由插件daemon后台任务负责一次启动尝试，UI只提交任务，不 waitFor、不 Thread.sleep、不等待端口/服务；后台不访问 Creo 对象。后台完成后清空creosonLauncher引用，重复pending任务继续去重。流程：

1. Windows检查；Linux明确记录 unsupported，不启动进程。
2. 校验安装目录、脚本及日志目标；失败记录 directory/rejected + INVALID_LAUNCH_DIRECTORY，并将异常堆栈写入jlink诊断日志，不提交启动。
3. directory/validated 记录最终真实serverDir、script、stdout、stderr完整路径。
4. 后台单次500ms探测9056；occupied_unverified仅表示监听存在，跳过重复启动，明确要求前端验证CREOSON身份；not_confirmed不代表已确定无进程，也不代表VPN或网络状态。
5. 提交原 detached cmd/start 启动请求；launch_request/submitted 记录外层shellPid与ready=false，失败记录 LAUNCH_REQUEST_FAILED 和堆栈。shellPid不是服务PID，不把ProcessBuilder返回当作服务启动成功。
6. 前端连接成功记录connected；通信重试耗尽记录connect_exhausted/SERVICE_NOT_READY，并引导检查p1_launch_stderr.log、jlink.log和9056端口占用进程。不得据“端口开着”返回成功分析。

LAUNCH_AUDIT JSON包含时间、requestId、stage、outcome、source与saved=false。它是诊断事件，不是持久审计或真实创建日志。所有Windows detached/bat/输出继承/pause-NUL/慢启动/进程存活行为仍需真机验证；本轮未执行，未获部署批准。

### 3. 公共层连接策略收敛

`ensureSession()` 默认恢复为原公共层的单次连接、请求超时30秒；`call()` 通信不确定时仍保留原来的一次重连/重试。只有P1页面显式 `ensureSession({startupRetry:true})` 时，初次连接才采用4次×3秒、间隔1秒的启动预算（通常最大约15秒，不是实时调度保证）。业务错误立即失败，不按启动失败反复重试。

| 场景 | 默认公共层（重命名/关于等） | P1显式启动重试 |
|---|---|---|
| 服务正常 | 一次连接后继续原业务 | 一次连接后只读分析 |
| 首次未启动/网络连接失败 | 默认单次30秒请求；失败提示检查服务 | 最多4次，可能启动恢复；耗尽后可再次点分析 |
| CREOSON业务错误 | 不盲目重试业务错误 | 同样立即失败 |
| 已连接后请求不确定失败 | 保留原core.call一次重连及请求重试 | 同一core.call机制，不新增写请求或原生调用 |

这保留公共API并恢复默认连接时序；错误文案、审计及全桥接关闭仍是已说明的公共层变化。未收到最新rename/about页面源码，不能证明这两页所有现场行为无回归；仍需现场验证。未改变现有core.call对不确定请求的遗留重试策略，也不将它扩展成P1写通道。

### 4. 全部原生浏览器桥接关闭

删除通用window.external.ptc执行、回调注册及超时分支。保留SiswCore.bridgeCall接口名供兼容诊断，但**任意bridgeKey、任意action均返回CHANNEL_BLOCKED**。不存在调试key绕过。P1页面不调用bridgeCall。报告称当前无其他调用方；若现场另有依赖通用桥接的模块，须单独审核，本包不声称保留原生桥接功能。

### 5. 测试契约从生产主类移除

删除主类内 validateClosedConversionContractForTests、SmtInputError、板厚/保存/确认校验及相关假转换返回方法。纯校验迁入 tests/P1ClosedContract.java；生产BatchRename不引用它。测试仍验证显式0.1–20mm、禁save、confirm、CHANNEL_BLOCKED，但**这是测试契约，不是生产后端实现**。当前生产根本没有转换入口，前端参数也不提交；后续若新增真实通道，必须重新设计并接入生产校验，不能宣称已有生产转换校验闭环。

保留生产JSON序列化仅用于启动诊断，不用于创建/保存。原ensureSheetmetalBridgeAsync改名recordNativeChannelDisabled，避免误解为后台注册桥接。

### 6. 日志策略明确

继续选择best-effort诊断：队列128条，stop的磁盘等待预算0ms，不同步排空、不因dropped/IO错误阻断卸载；JVM退出可能丢尾部，不能称完整持久审计。关闭后晚到的启动诊断只计入丢弃，不重新创建日志工作线程；下次start明确重新开放日志。已终止后才到达的消息可能来不及纳入已写出的shutdown计数，计数也不构成完整性保证。需要可靠审计须由外部收集/退出流程处理。

### 7. 展示清理

页面浏览器标题和section标题改为“钣金适用性分析/转换未开放”；原ID、CSS与脚本引用保留。板厚说明标明“仅本地参数记忆位，未提交、未换算”；契约仍0.1–20mm，模型单位单独展示，不静默换算。分析只读白名单、模式守卫、单位读取、错误映射和禁用控件均保留。

## 验证与复跑

```sh
node --check web/assets/js/core.js
node --check web/assets/js/sheetmetal.js
node tests/test_round4.cjs /新日志目录/frontend.jsonl
python3 tests/run_java.py --jdk /JDK目录 --output /新建且不存在的输出目录
```

本轮：两项语法检查退出0；27项前端模拟检查；68项Java SDK替身/纯Java文件系统检查；完整编辑后主类对替身编译退出0、major61。测试覆盖拒绝路径/链接/越界、精确批准、主类无转换契约、关闭后日志不复活、后台启动去重与回调及时返回、全key桥接阻断、默认公共层30秒单次连接与P1显式重试。

`evidence/summary.json`记录命令、退出码、源码哈希与未执行项；contract-tests.jsonl仅为测试辅助契约结果，launcher-mock.jsonl仅为替身启动诊断，不是Windows启动成功证据。日志压力测试会故意造成丢弃。

## 真实SDK暂存编译（本轮未执行）

```powershell
& 'D:\creoson\jdk25\jdk-25.0.5+8\bin\javac.exe' --release 17 -encoding UTF-8 `
  -cp 'D:\Program Files\PTC\Creo 13.4.0.0\Common Files\text\java\otk.jar' `
  -d '<新的暂存目录>' '.\BatchRename.java'
node --check .\web\assets\js\core.js
node --check .\web\assets\js\sheetmetal.js
```

不编译tests作为生产代码，不混入pfcasync.jar，不输出到现场jlink/classes。期望真实编译退出0、major61；**本云端无真实otk.jar/Windows，本轮真实SDK编译无退出码、无实测生产class major。** 用户审核报告确认的是第三轮真实SDK编译，不能替代第四轮证据。

## 仍未实现/放行前提

未执行Windows实际启动、真实CREOSON连接、三Ribbon命令和五模式真机回归、重命名/关于页完整回归、Windows目录/ACL/日志继承验证或现场部署。真实WFC创建、重生成、保存、真实选择对象、材料侧、shell移除面、生产参数通道、A4批量转换均未实现。不得把任何Mock/编译/端口结果表述为自动转钣金可用。

补丁离线通过后仍需现场审核、第四轮真实SDK暂存编译和只读启动回归。未经单独放行不得覆盖生产源码、现场class或真实原模型；真实转换实验须另立任务、使用测试副本。

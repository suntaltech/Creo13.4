# R4受控实验矩阵（设计，未执行）

L1对象、L2触发、L3候选列表、L4固定按钮、L5转换创建分别记录；API返回、编译或宏进入回调不升级为L3/L4。L5本轮仅UNVERIFIED或NOT_APPLICABLE。

下表六个待填字段对每个用例独立记录；UNVERIFIED不是缺失待伪造的数据。

| 用例 / 入口 | selectedLayout | textDirAbsoluteValue | messageFileSha256 | startupLine | resourceLookupStatus | restartedAfterLayoutChange |
|---|---|---|---|---|---|---|
| C1 BatchRename / java / Designate | UNVERIFIED（计划root-layout） | UNVERIFIED | UNVERIFIED | UNVERIFIED（计划startup java） | UNVERIFIED | UNVERIFIED |
| C2 BatchRename / java / Designate | UNVERIFIED（计划usascii-layout） | UNVERIFIED | UNVERIFIED | UNVERIFIED（计划startup java） | UNVERIFIED | UNVERIFIED |
| C3 JLinkUiProbe / java / 旧菜单 | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED（计划startup java） | UNVERIFIED | UNVERIFIED |
| C4 OtkUiProbe / otk_java / Designate | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED（计划startup otk_java） | UNVERIFIED | UNVERIFIED |

C1保存L1/L3/L4及受控NO_MODEL状态行，不能证明真实转换。C2同一业务源码与编译产物，仅变资源布局并新开会话；不预判哪种目录被解析。C3保存旧菜单调用与实际位置，不代表现代TOOLKIT候选列表。C4先核对前提清单，前提不足记BLOCKED_PREREQUISITES，不回退C3冒称OTK成功。

一次会话只选择一种layout、一种startup、一种API路线。消息文件会话内只加载一次，改变资源或布局必须重启；两套layout不合并。text_dir与语言子目录搜索语义列为运行待证，不以静态文件存在代替查找证据。C3与C4有身份/API差异，不将其结果混称单因素因果证明。

## 路线A的三个精确策略

SISW_UI_PROBE_POLICY_ID、SISW_UI_PROBE_MENU、SISW_UI_PROBE_NEIGHBOR、SISW_UI_PROBE_SOURCE_EXAMPLE均为显式必填。null表示环境变量的字面字符串；仅精确策略转换为原生null，无缺省neighbor。

| policyId | menu | neighbor | parentMenu | menuNeighbor | UIAddMenu | sourceExampleBasename |
|---|---|---|---|---|---|---|
| FILE_EXPLICIT_NULL_NEIGHBOR | File | null | 不适用 | 不适用 | 不调用 | RunDisplayExamples.java |
| APPLICATIONS_EXPLICIT_NEIGHBOR | Applications | Applications.psh_util_pproc | 不适用 | 不适用 | 不调用 | ParamEditor.java |
| CUSTOM_TOP_LEVEL_INFO_MENU | P1_UI_CUSTOM_MENU | null | Info | null | 必须先调用 | pfcExamplesMenu.java |

自定义还要求SISW_UI_PROBE_CREATE_MENU=1、SISW_UI_PROBE_PARENT_MENU=Info、SISW_UI_PROBE_MENU_NEIGHBOR=null。内置策略拒绝自定义parent/menuNeighbor，CREATE_MENU仅可缺省或0。示例来源只接受与策略匹配的三个精确basename，不接受目录、绝对路径、后缀拼接、其他示例名或任意子菜单参数。未知配置一律ROUTE_A_MENU_POLICY_REJECTED。

自有菜单键P1_UI_CUSTOM_MENU已有资源标题；这是本包标识，不声称官方示例固定使用该键。UIAddMenu实参顺序是menuId,parentMenu,messageFile,menuNeighbor；UIAddButton实参顺序是command,menu,neighbor,labelKey,helpKey,messageFile。

日志的uiAddMenuCalled和uiAddButtonReturned仅为实际调用过程记录，后者按命令ID分别维护，不把前一个按钮的返回状态用于后一个按钮。返回保持LEGACY_MENU_CALL_RETURNED; NOT_MODERN_TOOLKIT_LIST_EVIDENCE; ACTUAL_LOCATION_UNVERIFIED。sourceExampleBasename是来源声明，不代表读取或验证过本机示例全文。

实际测试、配置切换及恢复由本机受控流程管理；本包不提供安装、config.pro片段、恢复脚本或自动UI调用。

# 路线B OTK前提（全部UNVERIFIED）

依据定位来自输入整改单中的本机官方文档摘录。本轮未读取原始SDK文档全文、未运行javap或许可查询，未生成JAR、解锁、签名或许可结果。

| 前提 | 官方依据定位（输入提供） | R4状态与待填证据 |
|---|---|---|
| 应用打包为JAR并进入classpath | Compatibility_with_J_Link 第39行 | UNVERIFIED；应用JAR实际路径、哈希与包含类 |
| JAR必须解锁 | Compatibility 第40行；Unlocking 第39–42行 | UNVERIFIED；适用解锁流程及本机实际结果 |
| classpath包含官方otk.jar | Compatibility 第41行 | UNVERIFIED；与Creo版本匹配的SDK条目及哈希，模板仅占位 |
| startup otk_java | Compatibility 第42行；RegistryFile1 第44行 | UNVERIFIED；实际受控dat |
| toolkit object、creo_type parametric | RegistryFile1 第41行示例 | UNVERIFIED；实际字段与加载记录 |
| 解锁/运行许可要求 | Unlocking 第40–42、87–90行 | UNVERIFIED；操作者提供实际许可证据，不能推断已满足 |
| 解锁后二进制不可随意修改；签名规则 | Unlocking 第82、103行 | UNVERIFIED；只记录规则适用性，签名由规定解锁流程或jarsigner处理，本轮不执行 |
| text_dir资源位置 | Registry_File 第51行；RegistryFile1 第41行 | UNVERIFIED；实际绝对值、所选layout与查找结果 |

`evidence-template/route-b-prerequisite-checklist.json`为未填写清单，所有状态UNVERIFIED且evidenceRefs为空。未取得证据不能填写PASS、虚构路径或哈希。模板classpath分别保留应用JAR、官方otk.jar两个占位符，不提供真实安装路径。

前提不足时，C4只能记录BLOCKED_PREREQUISITES，不从C3旧菜单、对象非空或宏触发结果推断OTK可行。OtkUiProbe只保留只读注册/提示回调，不迁移业务类，不创建特征。

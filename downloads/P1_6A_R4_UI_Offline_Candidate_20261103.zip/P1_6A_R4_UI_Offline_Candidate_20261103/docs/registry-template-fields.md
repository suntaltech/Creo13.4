# 注册模板字段（仅占位，未激活）

三个文件均为`.dat.template`，不可直接加载。没有生成真实dat，也没有安装或切换指令。

| 字段 | 模板含义 | 未来受控记录 |
|---|---|---|
| name @DAT_NAME@ | 操作者填写独立受控应用名 | 实际name和dat哈希 |
| startup java | 业务类与路线A保持J-Link身份 | 实际startupLine |
| startup otk_java / toolkit object / creo_type parametric | 仅路线B的OTK身份声明 | 前提核实与实际加载结果；不迁移业务类 |
| java_app_class | 分别BatchRename/JLinkUiProbe/OtkUiProbe | 入口、隔离编译来源与class清单 |
| java_app_classpath | 业务/A分别隔离class目录；B为应用JAR与官方otk.jar两个占位符 | 各条目实际值及哈希，Windows分隔符/空格语法由本机核对 |
| java_app_start start / java_app_stop stop | 原有入口方法名 | 实际生命周期结果，返回不等于UI可见 |
| allow_stop @ALLOW_STOP_TRUE@ | 受控时操作者填写true | 实际值，不从字段存在推断监听器注销成功 |
| delay_start @DELAY_START_FALSE@ | 自动加载受控会话建议填写false | 若另做手动启动实验须独立值、独立会话并记录 |
| text_dir @ABSOLUTE_SELECTED_RESOURCE_LAYOUT_TEXT_DIRECTORY@ | 仅填写受控隔离资源目录 | selectedLayout、绝对值、查找结果、重启记录 |
| end | 结束标记，最后一行 | 完整文件及字段顺序 |

模板不允许生产目录、固定SDK安装绝对路径、pfcasync.jar或路线身份混用。根布局与usascii布局不可合并。text_dir指向的父目录与语言子目录实际参与方式仍是UNVERIFIED，不能从模板意图直接认定运行查找成功。

本机历史config.pro可能仍是R2受控状态；实际恢复由本机操作者管理，本包不含config.pro片段、恢复脚本或自动安装命令。

# P1 6A R4 UI Offline 源码与审核材料候选

日期：2026-11-03。本包未编译、未加载、未部署、未证明UI可见、未证明OTK可行、未证明真实转钣金可用。只补齐离线完整性；静态通过不等于功能通过。

## 基线与输入事实

R3 ZIP SHA256：`04d41dbfb1f61f77d5f383e68c8d6437d22a27a19f81d7c233c56c2acbdc55ef`。
R3业务源码SHA256：`9dbd71f36e403c3ed1a027d810a70befb57d3973c67aedca821f7b31df802400`。

输入整改单记载R3已由本机复跑84/84静态检查、2/2反例，并用真实同步SDK/Java17隔离编译业务4个class和探针5个class、major=61。这些是输入给出的本机事实，本轮不重新运行编译、不虚构新class或许可结果，也不将既有编译结论升级为UI可见。

本轮BatchRename.java整体逐字节保持R3基线，SHA256相同。没有变更转换、反馈、页面导航、注册审计或CREOSON启动行为。原有业务路径的运行风险继续保留。

## 生产保护设计承诺

- `config.proUnchanged=true (design promise; ChatGPT cannot verify machine state)`
- `productionFilesUntouched=true (design promise)`

以上为本候选设计承诺，不是对本机当前config.pro或生产哈希的远程核验。历史R2受控状态何时恢复属于本机操作者动作；本包没有config.pro片段、恢复脚本、生产目录写入说明或自动安装命令。

## 相对R3的修改

| 文件/范围 | 改动 |
|---|---|
| probes/UiExposureProbe.java | 菜单策略只允许FILE_EXPLICIT_NULL_NEIGHBOR、APPLICATIONS_EXPLICIT_NEIGHBOR、CUSTOM_TOP_LEVEL_INFO_MENU。示例来源仅精确basename，不接受路径或后缀匹配；自定义固定Info父菜单、两个显式null，拒绝自由元组和子菜单。新增policyId/parentMenu/menuNeighbor/uiAddButtonReturned/sourceExampleBasename日志；按钮返回按ID分别记录。 |
| 三个registration/*.dat.template | 补齐name、allow_stop、delay_start占位符与固定字段顺序；业务/A仍java，B仍otk_java/object/parametric及应用JAR+官方SDK双占位符。 |
| checks/static_check.py | 保留R3资源解析与覆盖断言，扩展完整业务文件冻结、14个受保护块及规范化哈希、模板逐字段/顺序/禁止模式审计、递归禁止调用计数、未执行标记、路径及schema/前提模板一致性检查。 |
| checks/check_checker.py | 保留原资源缺键/多余键反例，增加字段缺失、错误启动方式、禁用SDK、生产路径、受保护板厚块变更和新增源码禁止调用等临时文本反例。 |
| evidence-template/runtime-evidence-schema.json | 增补命令、资源、Designate键、菜单API/策略、NULL_STRINGSEQ及附件类型；VERIFIED/FAILED仍要求refs，L5仍不允许填写成功。 |
| evidence-template/registration-context.json | 增补allow_stop/delay_start、三策略字段、layout/textDir/hash/startup/资源查找/重启待填项。 |
| 新增前提与文档 | route-b-prerequisite-checklist.json、registry-template-fields.md、runtime-feedback-checklist.md；重写OTK前提与实验矩阵，补官方定位和UNVERIFIED状态。 |
| evidence/*.json | 输出模板审计、保护块哈希、资源覆盖、调用计数、静态结果、反例与schema结果、diff摘要和未决风险。仅为本轮实际离线文本检查证据。 |

JLinkUiProbe.java、OtkUiProbe.java及全部六份资源文件与R3逐字节相同。资源布局不合并，每布局仍为业务UI12键、转换状态6键、只读探针22键。UIEntry独立标签键与消息文件名保留。

## 冻结与调用扫描

`evidence/protected-blocks.json`输出14项的unchanged布尔值、基线与候选规范化SHA256。规范化仅处理行尾，保留源代码内部空白；unchanged使用原始提取文本严格比较。另有整个业务文件相等检查，不能仅靠规范化哈希掩盖改动。

冻结范围覆盖SmtConvertListener.OnCommand、转换主链、面归属、单位门禁、板厚读取校验、addElement及实际7节点树段、创建/重生成/钣金回读前后逻辑、失败特征子特征诊断、反馈函数、CREOSON后台启动、模式识别与URL守卫。

递归源码扫描先屏蔽注释与字面量，再统计实际Java令牌中的Save、AddBrowserMessageListener、window.external和抽壳节点标识，要求计数0。保留的WCreateFeature=1、WRegenerate=1、IsSheetmetal=4只属于冻结候选旧路径，均标记notExecuted=true，未被执行。文本扫描不是完整Java语义分析或SDK编译器。

## 模板审计与路径边界

`evidence/template-audit.json`逐模板记录必需字段、值与顺序、禁止模式及pass结果。allow_stop与delay_start保持未解析占位符；实际true/false和启动实验由操作者在独立受控配置中记录。本包不生成真实dat。

业务/A禁止OTK身份字段；B禁止java身份与单一通用classpath占位符。全部模板禁止绝对Windows配置路径、生产根目录、固定SDK安装路径及pfcasync.jar。另扫描可执行源码/模板中的指定生产路径。检查脚本的临时反例仅在临时目录构造错误文本，不将错误配置或禁止调用夹带到候选文件中。

## 路线与证据层级

路线A配置必须精确命中表；SISW_UI_PROBE_SOURCE_EXAMPLE仅接受对应策略的RunDisplayExamples.java、ParamEditor.java或pfcExamplesMenu.java。不读取示例原文或推断本机参数兼容。自定义菜单先UIAddMenu，其返回或按钮返回都不能证明现代TOOLKIT列表可见。

UIAddButton返回保持`LEGACY_MENU_CALL_RETURNED; NOT_MODERN_TOOLKIT_LIST_EVIDENCE; ACTUAL_LOCATION_UNVERIFIED`。uiAddMenuCalled、uiAddButtonReturned仅描述调用过程，观察状态objectRegistered、macroDispatchable、uiListed、ribbonVisible、featureCreated仍默认UNVERIFIED。

路线B仅只读探针及前提文档；应用JAR、解锁、签名、官方SDK classpath、注册字段、许可和资源位置逐项待证。前提不足时C4记BLOCKED_PREREQUISITES，不以C3结果替代。模板没有生成JAR、解锁、签名、许可或运行结论。

L1对象、L2触发、L3候选列表、L4固定按钮、L5创建层分开。Schema只验证形状，不能认证截图、类来源、许可或UI因果关系；UNVERIFIED不要求伪造refs，VERIFIED/FAILED观察要求至少一个refs附件；featureCreated仅UNVERIFIED/NOT_APPLICABLE，L5观察同样限制。

## 资源与反馈

两种layout内容保持一致，每次会话只选一种layout、startup、API路线；改变消息或位置后须重启。实验矩阵逐例列出selectedLayout、textDirAbsoluteValue、messageFileSha256、startupLine、resourceLookupStatus和restartedAfterLayoutChange待填值。静态检查不认定哪个资源目录被原生解析。

UIDisplayMessage第三参数原样保留null，RUNTIME_STRINGSEQ_ACCEPTANCE_UNVERIFIED标签保持。未来观察项仅列在runtime-feedback-checklist.md；不增加空stringseq分支，也不因提示接口待证改变NO_MODEL、单位、板厚、面选择或转换判断。历史报告中单次特定消息返回的证据不被推翻，也不外推为全部上下文通过。

## 实际验证与未执行事项

实际执行：Python文本/JSON检查、临时文本反例、schema结构与约束检查、补丁文本应用及字节核对、归档哈希检查。具体计数与证据见evidence目录；检查器不是Java编译器。

未执行：javac、javap、jar、Creo、macro、deployment、feature creation、进程查看、运行日志查看、许可查询、浏览器、HTTP测试、Mock/Stub。没有截图、日志导出、解锁或签名文件，没有class/jar/dat/bat/rbn/html/js。

本机后续审核仍需独立复跑静态检查、真实SDK/Java17隔离编译及diff，并分别判定离线层、L3/L4、OTK、L5与发布层。本文不提供安装或启动命令，不把审核计划写成已执行结果。

## 本轮离线结果

- 静态主检查118/118通过，其中14项受保护块均unchanged，三份模板审计通过；四类禁止调用计数均0。
- 9/9临时文本反例被检出，包含原有资源缺键与多余键；没有编译或执行反例中的Java文本。
- JSON Schema Draft 2020-12结构校验及4个约束用例通过，不构成真实证据认证。
- 补丁修改1份只读探针和3份注册模板；其余9个源码/资源目标不变，回放13/13逐字节一致。单独交付的检查器、schema与文档不由源码补丁替代。

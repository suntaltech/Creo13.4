# R11 问题与离线修正交接包

请先阅读 review/REVIEW_AND_MINIMAL_FIX_20261113.md，再审查 candidate/review_operations.py 和测试。

已确认的问题：
1. 旧分析脚本将非读写完成的 ExtraInformation 计为字节。
2. 旧抽取脚本用 IRP 集合成员关系标记 paired，没有按操作时序消耗请求。
3. 永久 IRP/对象路径映射及跨 PID 映射存在复用误归风险。
4. 旧 unpaired 指标混入非目标路径，不能代表全局配对失败率。

交接目标：只审核关联逻辑与证据边界。candidate 是独立的离线候选组件，不是已验收的三个旧脚本替换版，更不是插件补丁。

当前结论：旧统计不可靠，尚未确定命令未进入 TOOLKIT 列表的根因。单文件片段的 516/544/460 只为局部候选；合并片段后存在 IRP 歧义，不能沿用为全局结果。正式丢事件计数未知，+07:59 偏移未核实。

目录：
- input/：收到的原始交接资料、三个旧脚本与原 SHA256SUMS，保持不变。
- candidate/：新离线候选和回归测试。
- review/：审核报告、合并事件检查及单文件范围检查结果。
- TEST_RESULTS.txt：本包实际测试输出。
- MANIFEST.json / SHA256SUMS：逐文件大小及 SHA256 校验。

复核：在包根目录运行 python -m unittest discover -s candidate -p test_review_operations.py -v。
复现合并检查：在 candidate 目录运行 python review_operations.py --input ../input/R11/r11-event-chains.json --format chains --target-pid 23636 --output ../review/replay-new.json。输出文件必须尚不存在。

范围：不修改插件、UI、配置或模型，不部署，不重采，不执行转换，不自动提交 PTC。原始 ETL 未随包提供；不宣称全量 ETL 回放或正式采集质量验收通过。请返回具体源码审核意见和未决证据项，不重复采集既有工具链版本，不把文件读取等同于 UI 枚举成功。

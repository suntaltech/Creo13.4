"""Conservative offline Kernel-File operation candidates; never an ETL decoder.

XML input must be a pre-existing tracerpt XML. JSON input is the supplied,
already filtered chain subset and cannot recover events omitted upstream.
Only same execution-context candidates with an explicit open path anchor
contribute to success-byte subtotals. These are not capture-wide totals.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

FILE_GUID = "{edd08927-9cc4-4e65-b970-c2560fb5c289}"
NS = {"e": "http://schemas.microsoft.com/win/2004/08/events/event"}
NAMES = {0: "STATUS_SUCCESS", 0xC0000011: "STATUS_END_OF_FILE",
         0xC0000034: "STATUS_OBJECT_NAME_NOT_FOUND",
         0xC000003A: "STATUS_OBJECT_PATH_NOT_FOUND",
         0x80000005: "STATUS_BUFFER_OVERFLOW", 0x80000006: "STATUS_NO_MORE_FILES",
         0x8000001A: "STATUS_NO_MORE_ENTRIES",
         0xC0000010: "STATUS_INVALID_DEVICE_REQUEST", 0xC0000120: "STATUS_CANCELLED"}
OPS = {"12": "Open/Create", "13": "Cleanup", "14": "Close",
       "15": "ReadFile", "16": "WriteFile"}


def number(v):
    try:
        return int(str(v), 16 if str(v).lower().startswith("0x") else 10)
    except (ValueError, TypeError):
        return None


def pointer(v):
    n = number(v)
    return n if n not in (None, 0) else None


def status(v):
    n = number(v)
    return {"raw": v, "name": NAMES.get(n, "unresolved"),
            "severity": ("success", "informational", "warning", "error")[(n >> 30) & 3]
            if n is not None and 0 <= n <= 0xFFFFFFFF else "unknown",
            "exact_zero": n == 0,
            "interpretation": "operation-specific; severity alone is not completion success"}


def xml_events(path):
    # Remove completed Event elements from their parent to keep streaming bounded.
    stack = []
    sequence = 0
    for kind, el in ET.iterparse(path, events=("start", "end")):
        if kind == "start":
            stack.append(el)
            continue
        if el.tag == "{" + NS["e"] + "}Event":
            sequence += 1
            provider = el.find("e:System/e:Provider", NS)
            if provider is not None and provider.get("Guid", "").lower() == FILE_GUID:
                def content(name):
                    item = el.find("e:System/e:" + name, NS)
                    return item.text if item is not None else None
                execution = el.find("e:System/e:Execution", NS)
                clock = el.find("e:System/e:TimeCreated", NS)
                yield {"event_id": content("EventID"), "version": content("Version"),
                       "opcode": content("Opcode"), "source_sequence": sequence,
                       "provider_guid": provider.get("Guid"),
                       "execution_pid": execution.get("ProcessID") if execution is not None else None,
                       "execution_tid": execution.get("ThreadID") if execution is not None else None,
                       "system_time": clock.get("SystemTime") if clock is not None else None,
                       "data": {d.get("Name"): d.text or "" for d in el.findall("e:EventData/e:Data", NS)}}
            if len(stack) > 1:
                stack[-2].remove(el)
            el.clear()
        stack.pop()


def chain_events(path):
    source = json.loads(path.read_text(encoding="utf-8-sig"))
    events, seen = [], set()
    for chain in source["chains"]:
        for field in ("paired_completion_events", "unpaired_completion_events_kept_raw", "other_events"):
            for event in chain[field]:
                # Input's 'paired' classification and assigned path are not trusted.
                identity = json.dumps(event, sort_keys=True)
                if identity in seen:
                    raise ValueError("duplicate raw events across chains: cannot infer identity")
                seen.add(identity)
                events.append(event)
    # Old extractor lost source sequence. Accept only fixed precision/offset and
    # unique timestamps; otherwise sorting would invent an ordering.
    clocks = [e.get("system_time", "") for e in events]
    pattern = r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{9}[+-]\d{2}:\d{2}"
    if not clocks or not all(re.fullmatch(pattern, t) for t in clocks):
        raise ValueError("chain time format requires explicit review")
    if len({t[-6:] for t in clocks}) != 1 or len(set(clocks)) != len(clocks):
        raise ValueError("mixed offsets or tied timestamps without original sequence")
    return sorted(events, key=lambda e: e["system_time"])


def analyze(events, target_pid):
    pending, anchors = {}, {}
    pairs, unresolved, pending_without_irp = [], [], []
    generations = Counter()
    offsets = Counter()
    last_clock = None
    # Never assume PID is an issuing identity or discard other completion contexts.
    # IRP candidates are global within this one provider and input window.
    for seq, e in enumerate(events, 1):
        if e.get("provider_guid", "").lower() != FILE_GUID:
            continue
        t = e.get("system_time") or ""
        signature = (len(t), t[-6:])
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{9}[+-]\d{2}:\d{2}", t):
            raise ValueError("unreviewed clock format; refusing implicit conversion")
        offsets[t[-6:]] += 1
        if last_clock and (signature != last_clock[0] or t < last_clock[1]):
            raise ValueError("clock regression/format change: no implicit reorder")
        last_clock = (signature, t)
        d, eid, pid = e["data"], str(e["event_id"]), str(e.get("execution_pid"))
        irp, fo = pointer(d.get("Irp")), pointer(d.get("FileObject"))
        anchor_key = (pid, fo)
        if eid == "24":
            request = pending.pop(irp, None) if irp is not None else None
            if request is None:
                unresolved.append({"reason": "no_pending_request_in_input", "completion": e})
                continue
            if isinstance(request, list):
                unresolved.append({"reason": "overlapping_irp_generations", "requests": request,
                                   "completion": e})
                # Keep an ambiguity tombstone: remaining completions cannot be guessed.
                pending[irp] = request
                continue
            same_context = request["event"].get("execution_pid") == e.get("execution_pid")
            operation = request["event"]["event_id"]
            raw = d.get("ExtraInformation")
            extra = number(raw)
            iosize = number(request["event"]["data"].get("IOSize"))
            eligible = (same_context and request["path"] is not None and
                        operation in ("15", "16") and number(d.get("Status")) == 0 and
                        extra is not None and iosize is not None and 0 <= extra <= iosize)
            pairs.append({**request, "completion": e, "status": status(d.get("Status")),
                          "same_execution_context": same_context,
                          "completion_information_raw": raw,
                          "successful_transfer_bytes_candidate": extra if eligible else None})
            # A failed open cannot establish a successful persistent path anchor.
            if operation == "12" and number(d.get("Status")) != 0:
                key = (str(request["event"].get("execution_pid")),
                       pointer(request["event"]["data"].get("FileObject")))
                if anchors.get(key) == request["anchor"]:
                    anchors.pop(key, None)
            continue
        path = None
        if eid == "12" and fo is not None and d.get("FileName"):
            generations[anchor_key] += 1
            anchors[anchor_key] = (d["FileName"], generations[anchor_key])
        anchor = anchors.get(anchor_key) if fo is not None else None
        if anchor:
            path = anchor[0]
        request = {"event": e, "path": path, "anchor": anchor,
                   "operation": OPS.get(eid, "unknown_operation_raw"), "input_position": seq}
        if eid == "14":
            anchors.pop(anchor_key, None)
        if irp is None:
            pending_without_irp.append(request)
        elif irp in pending:
            previous = pending[irp]
            pending[irp] = (previous if isinstance(previous, list) else [previous]) + [request]
        else:
            pending[irp] = request
    rows = defaultdict(lambda: {"successful_read_bytes_candidate": 0,
                               "successful_write_bytes_candidate": 0, "read_pairs": 0,
                               "nonread_completion_information_raw": []})
    for p in pairs:
        if str(p["event"].get("execution_pid")) != str(target_pid) or not p["path"]:
            continue
        row = rows[p["path"]]
        op = p["event"]["event_id"]
        if op == "15":
            row["read_pairs"] += 1
        if op not in ("15", "16"):
            row["nonread_completion_information_raw"].append(p["completion_information_raw"])
        value = p["successful_transfer_bytes_candidate"]
        if value is not None:
            row["successful_read_bytes_candidate" if op == "15" else "successful_write_bytes_candidate"] += value
    return {"schema": "r11-operation-candidates/2", "target_execution_pid": str(target_pid),
            "formal_capture_loss_counters": None, "observed_offsets_unmodified": dict(offsets),
            "limitations": ["Candidates within provided input; not complete ETL totals or unique bytes.",
                            "No cross-context candidate contributes bytes; both PID/TID retained.",
                            "No process lifetime proof; PID reuse remains unresolved.",
                            "No FileKey/IRP path fallback. Missing opens remain unresolved.",
                            "No +07:59 correction; formal capture quality unknown."],
            "files": dict(rows), "pairs": pairs, "unresolved_completions": unresolved,
            "pending_requests": list(pending.values()), "events_without_irp": pending_without_irp}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--format", choices=("chains", "xml"), required=True)
    parser.add_argument("--target-pid", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    events = chain_events(args.input) if args.format == "chains" else xml_events(args.input)
    result = analyze(events, args.target_pid)
    result["input_format"] = args.format
    h = hashlib.sha256()
    with args.input.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    result["input_sha256"] = h.hexdigest()
    with args.output.open("x", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
        f.write("\n")


if __name__ == "__main__":
    main()

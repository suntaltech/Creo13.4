import json
from pathlib import Path
import tempfile
import unittest

from review_operations import analyze, chain_events, FILE_GUID, status, xml_events


def event(n, eid, pid="1", **data):
    return {"provider_guid": FILE_GUID, "event_id": str(eid),
            "system_time": f"2026-11-12T15:26:02.{n:09d}+07:59",
            "execution_pid": pid, "execution_tid": "8", "data": data}


class OperationTests(unittest.TestCase):
    def test_reused_irp_separates_open_info_from_read_bytes(self):
        r = analyze([event(1, 12, Irp="0x1", FileObject="0x2", FileName="a"),
                     event(2, 24, Irp="0x1", Status="0x0", ExtraInformation="1"),
                     event(3, 15, Irp="0x1", FileObject="0x2", IOSize="4096"),
                     event(4, 24, Irp="0x1", Status="0x0", ExtraInformation="258")], "1")
        self.assertEqual(r["files"]["a"]["successful_read_bytes_candidate"], 258)
        self.assertEqual(r["files"]["a"]["nonread_completion_information_raw"], ["1"])

    def test_cross_context_completion_preserved_not_counted(self):
        r = analyze([event(1, 12, FileObject="2", FileName="a"),
                     event(2, 15, Irp="3", FileObject="2", IOSize="100"),
                     event(3, 24, pid="0", Irp="3", Status="0", ExtraInformation="10")], "1")
        self.assertFalse(r["pairs"][0]["same_execution_context"])
        self.assertEqual(r["files"]["a"]["successful_read_bytes_candidate"], 0)
        self.assertEqual(r["pairs"][0]["completion"]["execution_pid"], "0")

    def test_overlapping_irp_never_guessed(self):
        r = analyze([event(1, 15, Irp="1"), event(2, 15, pid="2", Irp="1"),
                     event(3, 24, Irp="1", Status="0", ExtraInformation="10"),
                     event(4, 24, Irp="1", Status="0", ExtraInformation="10")], "1")
        self.assertEqual(r["pairs"], [])
        self.assertEqual(len(r["unresolved_completions"]), 2)

    def test_close_and_pid_scope_remove_stale_path(self):
        r = analyze([event(1, 12, FileObject="2", FileName="a"),
                     event(2, 14, FileObject="2"),
                     event(3, 15, FileObject="2", Irp="3", IOSize="10"),
                     event(4, 24, Irp="3", Status="0", ExtraInformation="10"),
                     event(5, 15, pid="2", FileObject="2", Irp="4", IOSize="10"),
                     event(6, 24, pid="2", Irp="4", Status="0", ExtraInformation="10")], "1")
        self.assertTrue(all(p["path"] is None for p in r["pairs"]))

    def test_unknown_operation_and_missing_request_remain_raw(self):
        r = analyze([event(1, 22, Irp="1"),
                     event(2, 24, Irp="1", Status="0", ExtraInformation="999"),
                     event(3, 24, Irp="2", Status="0", ExtraInformation="999")], "1")
        self.assertIsNone(r["pairs"][0]["successful_transfer_bytes_candidate"])
        self.assertEqual(len(r["unresolved_completions"]), 1)

    def test_status_and_clock_fail_closed(self):
        self.assertEqual(status("0x80000005")["name"], "STATUS_BUFFER_OVERFLOW")
        self.assertEqual(status("0x216")["name"], "unresolved")
        with self.assertRaises(ValueError):
            analyze([event(2, 15), event(1, 24)], "1")

    def test_xml_preserves_header_and_original_order(self):
        xml = '''<Events xmlns="http://schemas.microsoft.com/win/2004/08/events/event">
<Event><System><Provider Guid="%s"/><EventID>15</EventID><Version>3</Version>
<Opcode>7</Opcode><TimeCreated SystemTime="2026-11-12T15:26:02.000000001+07:59"/>
<Execution ProcessID="1" ThreadID="8"/></System><EventData>
<Data Name="Irp">0x1</Data></EventData></Event></Events>''' % FILE_GUID
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "input.xml"
            p.write_text(xml)
            e = list(xml_events(p))[0]
            self.assertEqual((e["version"], e["opcode"], e["source_sequence"]), ("3", "7", 1))

    def test_supplied_three_message_subsets(self):
        source = Path(__file__).resolve().parents[1] / "input/R11/r11-event-chains.json"
        if not source.exists():
            self.skipTest("original handoff fixture not available")
        expected = {"p1_fc.txt": 516, "p1_readonly_model_info.txt": 544,
                    "p1_readonly_ping.txt": 460}
        original = json.loads(source.read_text())
        for chain in original["chains"]:
            name = chain["path"].split("\\")[-1]
            if name not in expected:
                continue
            with tempfile.TemporaryDirectory() as d:
                fixture = Path(d) / "one-chain.json"
                fixture.write_text(json.dumps({"chains": [chain]}))
                r = analyze(chain_events(fixture), "23636")
            self.assertEqual(r["files"][chain["path"]]["successful_read_bytes_candidate"], expected[name])
            self.assertEqual(len(r["pending_requests"]), 1)
        # Broader input exposes reuse after missing completions. Do not clear
        # ambiguity just to reproduce the narrower per-file subtotals.
        broader = analyze(chain_events(source), "23636")
        self.assertTrue(any(isinstance(p, list) for p in broader["pending_requests"]))


if __name__ == "__main__":
    unittest.main()

# PTC 技术支持最小复现包请求：Pro/TOOLKIT 命令可注册/可 Designate/可 Find，但不进入 TOOLKIT 定制命令列表

> 性质：离线只读核验材料索引。本包不构成正式发布包；未现场部署、未打包发布、未宣称真实实体转钣金可用。探针未点击 body 命令、未打开/选择/保存/转换模型。

## 1. 问题一句话

在同一 Creo 会话中，三个 Pro/TOOLKIT 命令经 `ProCmdActionAdd`、`ProCmdDesignate` 返回码均为 0，`ProCmdCmdIdFind` 可按名回查、命令 ID 在初始化基线与晚期快照间保持一致；但其中一个命令不显示在"选项→定制→键盘快捷方式 / 快速访问工具栏"的 TOOLKIT 命令候选列表中，另外两个可见。

## 2. 环境与版本（可核验项）

| 项 | 值 | 证据 |
|---|---|---|
| Creo 版本 | 13.4.0.0，中文界面 | `config.pro` 安装路径 `D:\Program Files\PTC\Creo 13.4.0.0\Common Files\text\config.pro` |
| SDK | 同版 `protoolkit`（`Common Files\protoolkit`） | 离线编译 include 路径 |
| 构建工具链 | Visual Studio 2022 Developer Command Prompt v17.14.41，x64 | `build\vcvars.log` |
| 并行插件 | `p1s23`（Java J-Link，对照，未停用） | step23 DAT |
| 会话 PID / load_token | 27872 / 8128968（R10 探针会话） | `runtime-review.json` |

> MSVC 编译器与 Windows SDK 具体小版本以本机工具链为准；编译日志横幅未留痕，本包不转述不可核验的版本号。

## 3. 复现前提（受控、只读）

- 两个 `protkdat` 同时在 `config.pro` 生效：step23（J-Link）与 R10（DLL 探针）。
- R10 DLL 在 `user_initialize` 阶段对三条命令执行 ActionAdd → Designate → Find 基线；在可见的 `p1_readonly_ping` action 回调内做一轮晚期 Find 快照（一次性门闩，每 DLL 加载最多 3 次）。
- 观测方式：探针写本地 JSONL；GUI 由人工在 TOOLKIT 命令列表观察；另用本机 ETW Kernel-File/Process 做只读文件访问观测。

## 4. 三条命令对照事实（R10 探针，同一会话 PID 27872）

| 逻辑命令名 | SDK action 名 | ActionAdd | Designate | Find 错误 | ActionAdd ID | Find 回查 ID | ID 匹配 | 终止期 Access 调用 | UI 列表 |
|---|---|---:|---:|---:|---|---|---|---:|---|
| `p1_readonly_body_face_count` | `p1_readonly_fc` | 0 | 0 | 0 | `0x28667f136e8` | `0x28667f136e8` | true | 0 | **不可见** |
| `p1_readonly_model_info` | `p1_readonly_model_info` | 0 | 0 | 0 | `0x28667f11748` | `0x28667f11748` | true | 14 | 可见 |
| `p1_readonly_ping` | `p1_readonly_ping` | 0 | 0 | 0 | `0x28667f139c8` | `0x28667f139c8` | true | 19 | 可见 |

晚期 Find 快照（on-demand ping action，ordinal 1/2/3）：三条 `find_pro_error=0`，晚期 ID 与基线 ActionAdd ID、基线 Find ID 双匹配，`found_id_null=false`。

- 初始化阶段三条 Access `total_calls=0`；终止期 flush 计数见上表。body wrapper 全程 0 次调用，未观测到其返回 `INVISIBLE`/`REMOVE`/`UNAVAILABLE`。
- 探针未提供 UI 成员资格回读（`UI_membership_read_back=false`）；Find 成功不证明具备定制列表成员资格。

## 5. 已排除的环节

### 5.1 R10 探针已排除

- 排除"初始化之后命令身份丢失、被注销、指针改变或按名不可查"：晚期 Find 仍可回查且 ID 与基线一致。
- 探针无 `TRACE_IO_FAILED`、格式化失败或其他错误事件；DLL 干净终止（INIT/TERM 事件齐全，返回码 0）。

### 5.2 R11 ETW 文件访问观测（PID 23636 xtop，23 进程族；配对复核进行中）

- 三条消息 `.txt`（chinese_cn）事件链已做候选配对复核：各 open 2、读请求 4、完成 8；读完成候选 516 / 544 / 460 字节（文件大小 ×2，两次成功读 + 一次 EOF），旧聚合各混入 6 字节打开/清理/关闭完成信息；各有 1 个读请求未在子集内配对完成。三文件均有路径明确的打开、读请求与成功读完成候选，**不支持"Body 文件完全没被读取"**；但该观测不证明消息被 GUI 成功解析。
- 两个插件 DAT、`config.pro`、Roaming/Temp `.ui`、R10 DLL 的请求-完成配对尚未逐条验收；R10 DLL 是否被主进程实际加载、各 PID 读取用途暂不归类。
- 采集前后基线哈希零差异只证明会话结束时最终内容一致，不证明期间无写入或写后被恢复；`.ui` 写请求去向待复核，不预先归类为缓存。
- 标准位置探测 DAT 返回 `0xC0000034`（对象名未找到，正常路径探测）。

结论：仅消息文件读取环节有事件链观测证据；配置 / `.ui` / DAT / DLL 的打开、读取或加载环节**尚未完成配对复核，不能据此判定已排除差异**。文件访问观测本身不下钻到 Creo 内部命令注册 → UI 列表筛选环节。

## 6. 尚未定位、需 PTC 答复的问题

1. 命令可注册、可 Designate、可 Find 且晚期 ID 一致，但不进入 Screen Customization / QAT 的 TOOLKIT 命令候选列表，剩余可能卡在哪些环节：命令类别/上下文声明、Designate 消息元数据、内部命令表枚举，还是 Ribbon/QAT 成员关系？
2. `ProCmdCmdIdFind` 查询的对象表，与定制界面枚举命令表是否不是同一套结构？
3. Access 回调是否只对当前已渲染/已放置的控件求值，而不对定制对话框候选列表中的全部命令求值？
4. 是否存在本地 SDK 头未暴露、但使命令进入候选列表所必需的额外 SDK 调用或声明（类别、上下文、消息元数据等）？本地未发现回读"命令是否在定制列表中"的接口。
5. 下一个只读诊断应优先观测哪一层：消息资源解析路径、命令类别/上下文、Designate 元数据，还是内部枚举顺序？

## 7. 证据索引

完整机读清单（28 条，含路径、字节数、SHA256、类别与说明）见：

- `PTC_REPRO_PACKAGE_MANIFEST.json`

分类概览：

| 类别 | 关键文件 |
|---|---|
| 插件注册与资源 | R10 DAT、DLL、`entry.cpp`、三条 chinese_cn 消息；step23 对照 DAT |
| 探针运行证据 | `runtime.jsonl`（80 事件，SHA256 `195841DE…B1869BA8`）、`runtime-review.json`、`R10_RUNTIME_FINDINGS.md`、`audit.json` |
| UI 观察截图 | 辅助应用列表、点 Ping 前/后 TOOLKIT 列表、键盘快捷方式类别列表（共 4 张） |
| R11 文件访问观测 | `formal.etl` 原始证据、`formal-file-access.json`、两份基线、启停状态、校准门结论、`R11_FORMAL_OBSERVATION_FINDINGS.md`、采集执行卡 |

## 8. 边界与未做项

- 未部署正式发布包、未打包发布、未宣称真实实体转钣金可用。
- 未点击 body 命令；未打开、选择、保存或转换模型；未修改资源、DAT、Access、顺序、优先级、标志、图标或按钮放置；未停用 p1s23 做对照试错。
- 状态码 `0xC000000F`、`0x216` 未逐项解码；IOFlags 位定义、InfoClass 数值映射未建表；CSV/XML PID 口径偏移风险未消除；正式采集丢事件计数尚未从 `formal.etl` 会话头读取。上述缺口下，第 5.2 节仅陈述已观测事实，不作文件层排除结论。

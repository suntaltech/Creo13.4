# R11 只读文件访问观测方案（离线准备，v2 修正）

## 1. 定位与边界

- 本轮只做**离线观测方案准备**：确认现有工具能否按 Creo 实际进程 PID，记录配置 / `.ui` / 消息文件的打开、读取结果与完整路径；明确启动读取与保存写入的区别。
- **本轮不写 R11 插件代码**；方案经单独授权后，再进行一次受控观测。
- 保持插件、配置、资源、UI 布局不变；不清缓存、不停用 p1s23；不部署、不打包、不宣称真实实体转钣金可用。
- 机读清单：`r11-file-access-observation-plan.json`；生成脚本：`build_r11_observation_plan.py`。

## 2. 进程与插件生命周期必须分开

- **插件生命周期**：探针 `INIT_ENTER`、注册、`TERM_BEFORE_RETURN` 等事件跟踪的是 DLL 插件生命周期。
- **进程生命周期**：进程创建、父子关系、退出是操作系统层事实，来自 Kernel-Process 事件或进程枚举。
- **关键规则**：`TERM_*` 探针事件**不代表** `xtop.exe` 已退出；插件终止不能等同于进程退出。

## 3. 实测进程族（观测主键）

实测于 2026-11-12。探针自报 PID `27872` 对应 **`xtop.exe` 主进程**，不是 `parametric.exe`。观测主键必须覆盖整个进程族。

| PID | 进程 | 角色 | OS 父 PID | 命令行 `-ppid` |
|---:|---|---|---:|---:|
| 28988 | `parametric.exe` | 启动器 | 29520 | — |
| 27872 | `xtop.exe` | 主进程（探针 PID） | 3012 | 28988 |
| 23812 | `creoagent.exe` | 主进程子代理 | 27872 | — |
| 10000 | `java.exe` | p1s23 J-Link 子进程 | 27872 | — |

### 3.1 进程记录字段

每条进程记录分别保存：

- `collect_timestamp`：采集时刻（墙钟时间）；
- `create_timestamp`：进程创建时刻；
- `os_parent_pid`：操作系统上报的父 PID；
- `cmdline_ppid`：从命令行解析的 `-ppid` 值，**与 `os_parent_pid` 分开保存**；
- `pid`、`process_name`、`executable_path`、`command_line`。

会话对齐口径：PID + 启动时刻 + 窗口标题 + 插件 `load_token`/tid。

## 4. 采集策略：启动前有界采集，不按旧 PID 预过滤

- **启动前开始有界采集**：在启动新 Creo 会话之前就开始采集，先保留进程创建记录，再按新进程身份筛选。
- **禁止按旧 PID 预过滤**：不能用上一会话的 PID（如 27872）预先过滤；否则会漏掉启动阶段的配置 / `.ui` / 消息读取。
- 理由：启动读取发生在新 PID 已知之前，按旧 PID 过滤会排除掉最需要的事件。

## 5. ETW 字段映射校准门（R11CalTrace，2026-11-12 已完成：通过但带约束）

校准会话 `R11CalTrace` 已提权启停并导出 ETL/CSV/XML；用一次已知"写后读"基准文件反推事件方向。机读结果：`runtime-r11/calibration-gate-result.json`。

**实测事件映射（以 XML 真实 EventID 为准；CSV 把事件折叠成 0/1，不足以单独判定三层）：**

| XML EventID | 操作 | 关键字段 |
|---:|---|---|
| 12 | 打开 / CreateFile | `FileName`、`FileObject`、`FileKey`、`CreateOptions`、`ShareAccess`、`CreateAttributes` |
| 15 | ReadFile（实测） | `IOSize`、`IOFlags`、`ByteOffset`、`FileObject`、`FileKey`、`Irp` |
| 16 | WriteFile（实测） | 同 15 |
| 13 | Cleanup | `FileKey`、`FileObject`、`Irp` |
| 14 | Close | 同 13 |
| 24 | IRP 完成 | `Status`（NTSTATUS，`0x0`=成功）、`ExtraInformation`（实际传输字节） |
| 17/18/19/22/23/31/32/34 | 属性 / 信息查询 | `InfoClass`、`ExtraInformation` |
| 20/25 | 目录 / 枚举查询 | `FileName`、`Length`、`InfoClass` |
| 进程 1 / 2 | 进程创建 / 退出汇总 | `ProcessID`、`ParentProcessID`、`CreateTime`、`ImageName` / `ExitCode`、读写计数 |

**已验证可得：**

- `ProcessId` / `ThreadId` 在 `System/Execution` 中已填充（CSV 的 PID 为十六进制字符串）。
- 完整路径只出现在 `FileName` 字段；为 NT 设备路径 `\Device\HarddiskVolumeX\...`，需映射回盘符。
- 读写字节数：15/16 的 `IOSize`；完成事件 24 的 `ExtraInformation` 为实际传输字节。
- 完成状态：24 的 `Status` NTSTATUS。
- 事件 schema 版本 16；会话头 `EventsLost=0`、`BuffersLost=0`。

**方向实测证据：** 基准文件 65 字节；ID16 WriteFile `IOSize=0x41=65` 与文件长度一致，ID15 ReadFile `IOSize=0x1000=4096` 缓冲读。据此判定 **15=读、16=写**，为本机实测反推，未引用外部 schema。

**约束与缺口：**

- 路径只在打开/重解析/枚举事件出现；后续 IO 与完成事件须按 `FileObject`/`Irp` 关联回打开事件。完成事件 24 只带 `Irp`，不带 `FileObject`。
- `FileObject`/`FileKey` 指针在系统内跨进程复用，关联必须先限定 PID，不能只按句柄匹配。
- Kernel-File 为系统级提供者，`logman` 不支持按 PID 预过滤；PID 与目录前缀过滤只能在后处理做。
- IOFlags 位定义未逐项解码；InfoClass 数值到具体查询类型未建表；盘符映射需在正式采集时按挂载关系重建。

## 6. 三层结果必须分开

| 层 | 含义 | 可得性 |
|---|---|---|
| **文件打开** | CreateFile，含访问模式、共享模式、创建选项；打开不等于读取或写入 | 文件访问层可得 |
| **实际读取及其状态** | ReadFile，含字节数与完成状态；写权限打开不等于发生写入，读写方式打开也可能只读取 | 文件访问层可得 |
| **Creo 解析成功** | Creo 是否成功解析消息键 / 标签 | **文件访问层不可得**；须由消息 API 返回码或 UI 呈现层另判 |

## 7. 工具能力矩阵（本机实测，已修正）

| 手段 | PID 关联 | 完整路径 | 打开事件 | 读取事件 | 读取结果 | 写入区分 | 权限 | 现状与局限 |
|---|---|---|---|---|---|---|---|---|
| **ETW Kernel-File + Kernel-Process**（内置 `logman`/`tracerpt`/`wpr`） | 是 | 是（已校准；路径在 `FileName`，需按 PID+句柄/IRP 关联） | 是（EventID 12） | 是（EventID 15 读 / 16 写） | 否：文件访问层不判定消息键/标签是否被 GUI 解析 | 分开记录打开访问模式与实际 ReadFile/WriteFile；请求写权限不等于写入发生 | 需管理员提升；当前 shell 非管理员 | 2026-11-12 经 R11CalTrace 校准通过（带约束）；完整路径/完成状态需解析 XML；瞬态打开即关闭也能捕获；不解析文件内容 |
| **Process Monitor（ProcMon）** | 是 | 是 | 是：实时采集文件/进程/线程事件 | 是 | 否 | 记录打开访问模式与实际读写事件 | 视运行方式 | **ProcMon 是事件采集工具（驱动/过滤回调记录事件），不是句柄轮询**；本机未安装；若使用仍需过字段映射校准门 |
| 句柄枚举快照（Sysinternals `handle.exe`） | 是 | 是 | 部分：仅轮询时刻仍打开的句柄 | 否 | 否 | 部分 | 视工具 | 只轮询时刻句柄；抓不到瞬态打开即关闭的读取，**不能替代瞬态读取证据**；本机未装 |
| FileSystemWatcher（.NET 内置；Python watchdog 未装） | 否：事件不带 PID | 是 | 否 | 否 | 否 | 部分：Created/Changed/Renamed/Deleted | 普通用户 | 仅目录事件与时间戳；不区分打开/读取，不记读结果，**不能替代瞬态读取证据** |
| Creo 自身日志（`std.out`/`traceback.log`/`hs_err_pid*.log`） | 部分：hs_err 文件名含 PID | 部分 | 否 | 否 | 否 | 否 | 普通用户 | 错误/退出输出，不记录读到了哪个配置/`.ui` 路径；`APPL_STARTUP_LOG` 环境变量为空，未生成 applstarter.log |
| 插件内 SDK 回调（后续 R11 候选，**本轮不写**） | 是：同进程 | 部分：仅应用 text_dir/消息目录；未发现返回加载 `.ui`/配置目录路径的 SDK 接口 | 否 | 否 | 部分：可记消息 API 返回码 | 否 | 无额外权限 | `ProConfigoptArrayGet` 只取选项值，不返回来源文件路径；不能替代外部文件访问观测 |
| `openfiles.exe`（内置） | 受限 | 受限 | 否 | 否 | 否 | 否 | 普通用户 | 只跟踪网络共享打开文件；本地 `.ui`/配置不适用 |

**结论**：能同时按 PID 记录完整路径、区分打开/读取/写入的首选手段是 **ETW Kernel-File + Kernel-Process**（ProcMon 为同类事件采集备选）；其缺口是拿不到"Creo 解析成功"。Watcher 与句柄快照无法替代所需的瞬态读取证据。

## 8. 启动与读取 vs 保存与写入

### 8.1 启动 / 读取（只读访问）

- 目标：`config.pro`、`config.win`、`menu_def.pro`、`creo_parametric_customization.ui`、消息 `.txt` 资源、`protk.dat/creotk.dat/prodev.dat`。
- ETW 特征：无写权限的 CreateFile → ReadFile，无 WriteFile。

### 8.2 保存 / 写入（含 Creo 自然写入）

- 目标：`.ui` 回写、`mapkeys.pro` 保存、trail 文件、`std.out`、`hs_err_pid*.log`。
- ETW 特征：写权限 CreateFile → WriteFile；**仅请求写权限不计为写入**。

## 9. 配置路径四级（install.pdf 第 53–54 页）

启动时按序读取，最后读取项覆盖前面冲突项，但不能覆盖 `config.sup`：

1. `<creo_loadpoint>\Common Files\text`（安装目录）
2. `HOME` 环境变量目录
3. `PTC_CREO_ALT_SETTINGS_PATH` 指向的 Alternate Path
4. 启动 / 工作目录（最后读取）

现场环境变量 `HOME`、`PTC_CREO_ALT_SETTINGS_PATH`、`PROTKDAT`、`APPL_STARTUP_LOG` 均为空。

## 10. 自然写入如实记录

- 不主动修改配置或布局，但**不能保证** Creo 启停时不自动写 `.ui`；这类自然写入必须如实记录。
- 记录内容：实际写入事件、文件前后哈希、丢事件 / 刷新缺口、解码缺失或字段缺失、采集范围（覆盖的目录、进程、时间窗）。

## 11. 推荐观测链路（待授权后执行）

0. **基线快照**：进程族清单；每个候选配置/`.ui`/消息文件的哈希与时间戳；环境变量 `HOME`/Alt Path/`PROTKDAT`/`APPL_STARTUP_LOG`。
1. **授权门**：ETW 采集需管理员会话；约定观测时间，由用户手动启动与退出 Creo。
2. **字段映射校准门**：已完成（R11CalTrace，见第 5 章）；事件版本、完整路径、PID/TID、字节数、NTSTATUS 均已验证可用。
3. **启动前有界采集**：先保留进程创建记录，再按新进程身份筛选；不按旧 PID 预过滤。
4. 用户启动 Creo，打开 选项 → 自定义功能区 / TOOLKIT Commands 列表；**不拖放保存、不主动回写 `.ui`**。
5. 退出 Creo，停止 ETW 会话，`tracerpt` 把 ETL 转 CSV/XML。
6. 按 PID 抽取文件事件与完整路径，对照基线归档；自然写入记录前后哈希、丢事件、解码缺失与采集范围；不改现场。
7. **采集范围控制**：校准会话约 36 秒即产生 54.3 万文件事件（ETL 130MB / CSV 438MB / XML 1.44GB）。正式采集须尽量缩短时间窗；先按新会话进程族 PID + 候选目录前缀在后处理过滤；不要把整份 ETL 转 XML，优先 CSV 初筛，仅对目标 PID/时间窗转 XML 取打开/读/写/状态字段。
8. **降级预案**：若 ETW 权限不可用，明确记录该缺口；降级为句柄快照轮询 + watcher 目录事件，并注明二者都不能证明读取结果，也不能替代瞬态读取证据。

## 12. 证据记录字段与判定口径

- 每条记录字段：`timestamp_utc`、`pid`、`process_name`、`os_parent_pid`、`cmdline_ppid`、`file_path`、`operation`、`access_mode`、`read_result_status`、`source_tool`。
- 判定：某路径被某 PID 命中 = 该进程访问过该文件；文件访问层**不判定**消息/标签是否被 GUI 成功解析。
- 打开、实际读取及状态、Creo 解析成功三层分开，不合并。
- 配置无引用 ≠ 无候选资格。
- **R10 历史 `.ui` 来源保持"未知"，不再补推断。**

## 13. 若观测后 Body 与两条可见命令差异仍不可解释

**最小复现包要素**：

- SDK / Creo 版本 13.4.0.0；
- 两个生效 DAT；
- 消息资源哈希；
- 三条命令 ActionAdd/Designate/Find 返回码；
- R10 探针 jsonl 与现场截图；
- 本方案及其采集到的证据。

**向 PTC 核查的问题**：

1. 命令 `ProCmdDesignate` 返回 `NO_ERROR`、且 `ProCmdCmdIdFind` 可按名回查，为何仍不进入 `TOOLKIT Commands` 候选列表？可能的排除条件是什么？
2. 消息元数据解析、命令类别/上下文声明、内部枚举顺序，是否为可能的排除环节？

**停止堆叠探针**：不再新增 Find/Access 探针。注册层、Designate 层、Find 层返回码在三条命令上已一致，继续加这类探针难提供新信息。

## 14. 不变项与待授权事项

- 不变项：插件、配置、资源、UI 布局不变；不清缓存；不停用 p1s23；观测工具不落交付包；ETW 会话临时起停，不写系统配置；本轮不写 R11 代码。
- 待授权：ETW 内核文件事件采集需管理员提升；受控观测需用户配合手动启动/退出 Creo。

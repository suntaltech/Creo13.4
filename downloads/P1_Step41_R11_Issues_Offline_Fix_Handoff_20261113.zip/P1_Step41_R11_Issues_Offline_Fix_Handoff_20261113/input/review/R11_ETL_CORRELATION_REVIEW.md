# R11 ETL 处理脚本与操作级事件链口径复核（2026-11-13，只读）

> 范围：复核已有 ETL 处理脚本与少量操作级事件链（打开→读请求→对应完成→关闭）。
> 边界：不重采、不上传整份大 ETL、不新增插件探针；不改插件/配置/模型。脚本实现归 ChatGPT，本记录只定规则、记录审核结论与待补项。
> 证据来源：`runtime-r11\formal-file-access.json`、`formal-xml-probe.json`、`calibration-gate-result.json`、`formal-start/stop.json`、`analyze_formal_xml.py`、`scan_formal_targets_xml.py`；NTSTATUS 定义以 MS-ERREF / MS-SMB 官方页为准。

## 1. 四条缺口核对结论

### 1.1 状态码误标：`0x80000005`

- **现有记录**：`R11_FORMAL_OBSERVATION_FINDINGS.md` 第 6 节把 `0x80000005` 标为 `STATUS_NO_MORE_ENTRIES（枚举结束，非致命）`。
- **官方定义**：
  - `0x80000005 = STATUS_BUFFER_OVERFLOW`（数据过大装不下指定缓冲；输出缓冲在全部项返回前被填满）。
  - `0x80000006 = STATUS_NO_MORE_FILES`（文件枚举无更多匹配项）。
  - 旧报告使用的 `STATUS_NO_MORE_ENTRIES` 名称为误标，已弃用；本采集分布中未单独标注该名对应的码值。
- **JSON 实测状态分布**（candidate_files 完成事件 Status 集合，按出现次数）：`0x0` 104、`0xC0000011` 45、`0xC0000034` 37、`0xC000003A` 15、`0x80000005` 12、`0xC0000010` 8、`0xC01C0004` 5、`0x80000006` 4、`0xC000000D` 2。
- **纠正规则**：
  1. `0x80000005` 改注 `STATUS_BUFFER_OVERFLOW`，语义为缓冲不足/枚举截断，**不能直接判为加载失败**；需结合触发该状态的操作类型（读取缓冲、目录枚举、属性查询）解释。
  2. `0xC0000010 = STATUS_INVALID_DEVICE_REQUEST`（非 CANCELLED）；`STATUS_CANCELLED = 0xC0000120`（本次分布未出现）。`0xC000003A`（OBJECT_PATH_NOT_FOUND）、`0xC01C0004`、`0xC000000D`（INVALID_PARAMETER）、`0x80000006`（NO_MORE_FILES）未逐项复核前，不据此下成功/失败结论。
  3. 脚本侧应补 NTSTATUS 字典（码值→名称→严重级→是否可视为成功），报告引用字典结果，不在正文手写映射。

### 1.2 请求量与完成量混用

- **脚本现状**（`analyze_formal_xml.py`）：
  - ID15 读 / ID16 写：`read_bytes/write_bytes` 累加 `IOSize`（请求字节量）。
  - ID24 完成：`transferred_bytes` 累加 `ExtraInformation`（实际传输字节）。
  - 两个字段在 JSON 内部分列，脚本未在同一字段内相加；但 **ID24 完成事件只携带 IRP（无 FileObject/FileKey）**，脚本按文件聚合 `ExtraInformation`，**未把每条完成关联回具体的读/写请求**，存在对所有完成事件一律按传输字节累加的风险。
- **报告现状**：各对照表"读字节"列使用 `read_bytes`（IOSize 请求量），未标注该列是请求量还是完成量；消息文件 `read_bytes=16384` 即读请求缓冲量，`transferred_bytes` 才是完成传输（三文件分别 522 / 550 / 466）。
- **纠正规则**：
  1. 报告与机读件分列两个口径：`request_bytes`（IOSize 请求量）与 `transferred_bytes`（ExtraInformation 完成量），禁止把请求量称作"读字节/已读字节"。
  2. 完成量必须经 IRP（必要时配合 FileObject/FileKey，先严格限定 PID）关联回具体 ID15/16 请求；**无法配对的 ExtraInformation 保留为原始操作信息，不能直接算作完成传输字节**，单列"未配对完成"，不并入某文件的完成字节合计。
  3. ID24 仅带 IRP 是校准门已确认的字段事实（`calibration-gate-result.json` `path_correlation`），配对键以 IRP 为主。
  4. **PID 上下文区分**：ID15/16 请求事件的发起上下文 PID 与 ID24 完成事件的执行上下文 PID 可能不同；关联不能仅凭事件头 PID 硬过滤。FileObject/FileKey/IRP 指针存在跨进程、跨时段复用，须在会话时间窗内按 IRP 配对，并保留请求与完成两侧的原始 PID/TID 供复核；跨 PID 句柄匹配一律标为可疑，不并入聚合。

### 1.3 报告与 JSON 不一致：Roaming `.ui` 读写计数

- **JSON 实测**（`formal-file-access.json` candidate_files，PID 23636）：

| 文件 | 打开 | 读次数 | 读请求字节 | 写次数 | 写请求字节 | 完成传输字节 | 状态 |
|---|---:|---:|---:|---:|---:|---:|---|
| `...\Roaming\PTC\ProENGINEER\Wildfire\.wf\.Settings\creo_parametric_customization.ui` | 14 | 11 | 421,888 | 12 | 100,486 | 491,324 | 0x80000005, 0xC0000011, 0x0 |
| `...\Temp\d829u7mh.ui`（临时布局） | 6 | 10 | 565,248 | 4 | 1,067,852 | 189,440 | 0x80000005, 0xC0000034, 0x0 |

- **报告 4.4 现状**：Roaming `.ui` 记为打开 14、读 5、读字节 319,488、写 12、写字节 100,486。**读次数 5≠11、读字节 319,488≠421,888**；写 12 与 JSON 一致。Temp `.ui` 未列计数。CSV 初筛件不含 `.ui` 明细，报告 5 次读数属早期摘录，未从最终 JSON 回算。
- **写请求明细**：`candidate_write_hits` 中 `.ui` 共 16 条（Roaming 12 条 + Temp 4 条），与上表 write_n 一致。
- **纠正规则**：
  1. 报告对照表数字一律以最终 `formal-file-access.json` 回算为准；差异项先回算再落文，不沿用早期摘录。
  2. "前后基线哈希一致"只证明会话结束时最终内容与采集前一致，**不能证明期间没有写入，也不能证明写入后被恢复/回滚**；JSON 已记录会话内存在对该 `.ui` 的 12 条写请求。
  3. 表述从"会话无持久自然写入"收紧为："采集后基线哈希零差异；会话内观测到对 Roaming `.ui` 的写请求，最终落盘内容是否被改写需以最终文件哈希与写完成状态为准，现有观测不判定其持久化结果。"

### 1.4 解码质量：时区偏移与丢事件口径

- **时区**：JSON 事件时间戳形如 `2026-11-12T15:25:24.392561000+07:59`。本机北京时区应为 `+08:00`；`+07:59` 偏离整 1 分钟，需核对是 ETL 时钟源、tracerpt 时区偏移解析，还是本机系统时钟。`formal-start/stop.json` 的 `start_utc/stop_utc` 为 UTC（Z 后缀），事件本地时间与 UTC 两套基准需对齐后再做时长/先后判断。脚本当前原样取用 XML `TimeCreated SystemTime`，未做时区校验。
- **丢事件**：`EventsLost=0 / BuffersLost=0 / BuffersWritten=1980` 出自**校准采集 R11CalTrace**（`calibration-gate-result.json` `session_header`），**不是正式采集 R11FileTrace**。正式 `formal.etl` 的会话头丢事件数尚未读取记录；不得用校准采集的零丢事件代替正式采集的统计结论。
- **纠正规则**：
  1. 正式采集的事件头（EventsLost / BuffersLost / BuffersWritten）需从 `formal.etl` 头部单独读取并落机读件；读取前，正式采集的事件完整性标注为"未核验"。
  2. 时间戳在报告中同时给出 UTC 基准；本地偏移异常项标注待核，不用于精确先后排序结论。

### 1.5 三条消息文件事件链复核实测（PID 23636，源自 `r11-event-chains.json`）

> 配对口径：IRP 候选关联；ID24 完成仅带 IRP，FileObject/FileKey/IRP 存在复用，配对为候选而非严格一一对应。下列 ExtraInformation 已按阶段（打开/读/清理/关闭）拆分，非读完成不计入读取字节。

| 消息文件（大小） | 打开 | 读请求 | 完成事件 | 读完成 ExtraInformation（成功×2 + EOF×1） | 读完成候选字节 | 混入非读完成字节 | 未配对读请求 | 旧聚合合计 |
|---|---:|---:|---:|---|---:|---:|---:|---:|
| p1_fc.txt（258B） | 2 | 4 | 8 | 0x102 + 0x102 + 0x0 | 516（258×2） | 6（open 0x1×2、cleanup 0x2×2、close 0x0） | 1 | 522 = 516 + 6 |
| p1_readonly_model_info.txt（272B） | 2 | 4 | 8 | 0x110 + 0x110 + 0x0 | 544（272×2） | 6（同上） | 1 | 550 = 544 + 6 |
| p1_readonly_ping.txt（230B） | 2 | 4 | 8 | 0xE6 + 0xE6 + 0x0 | 460（230×2） | 6（同上） | 1 | 466 = 460 + 6 |

- **实测确认**：旧聚合完成合计把打开/清理/关闭完成的 ExtraInformation 一并累加进了"读完成候选"，每份混入 6 字节非读完成；读完成候选字节恰为文件大小 ×2（两次成功读，第三次 EOF 返回 0）。
- **未配对**：每份各有 1 个读请求在所给事件子集内未找到对应完成记录；该读请求持有的 IRP 未落在本链 open IRP 上，属跨句柄/复用候选，单列未配对。因此读完成候选字节**不能当作完整读取总量**。
- **可确认事实**：三个目标文件均有路径明确的打开、读请求及成功读完成候选；现有证据**不支持"Body 文件完全没被读取"的解释**。
- **边界（不得外推）**：以上仅文件访问层事实，不证明消息被 GUI 成功解析，也不据此判定整个文件层已排除差异；未配对读请求、IRP/句柄复用、正式采集丢事件缺口仍在。

## 2. 操作级事件链复核需保留的原始事件头与关联字段

按校准门字段映射（`calibration-gate-result.json` `file_event_mapping_xml_eventid`），每条目标事件链应保留下列原始字段，不二次丢弃：

| 阶段 | EventID | 必留字段 | 关联键 |
|---|---|---|---|
| 打开/创建 | 12 | FileName, FileObject, FileKey, Irp, IssuingThreadId, CreateOptions, CreateAttributes, ShareAccess | FileObject / FileKey / Irp |
| 读请求 | 15 | ByteOffset, IOSize, IOFlags, ExtraFlags, FileObject, FileKey, Irp, IssuingThreadId | FileObject / FileKey / Irp |
| 写请求 | 16 | ByteOffset, IOSize, IOFlags, ExtraFlags, FileObject, FileKey, Irp, IssuingThreadId | FileObject / FileKey / Irp |
| 属性/枚举查询 | 17–23, 25, 31, 32, 34 | ExtraInformation, InfoClass, FileKey, FileObject, Irp, IssuingThreadId | FileObject / FileKey / Irp |
| 完成 | 24 | Irp, Status, ExtraInformation | **仅 Irp**（无 FileObject/FileKey） |
| 清理 | 13 | FileKey, FileObject, Irp, IssuingThreadId | FileObject / FileKey / Irp |
| 关闭 | 14 | FileKey, FileObject, Irp, IssuingThreadId | FileObject / FileKey / Irp |

关联规则：先严格限定 PID，再按 Irp / FileObject / FileKey 回填路径；FileObject/FileKey 指针跨进程复用，**禁止跨 PID 句柄匹配**。事件链顺序：ID12 打开 → ID15/16 请求 → ID24 完成（同 Irp）→ ID13 清理 → ID14 关闭；无法在 PID 内配对的键单独标注，不并入聚合。

## 3. 脚本待补规则清单（实现归 ChatGPT，审核按此验收）

1. 补 NTSTATUS 字典：码值→名称→严重级→是否可视为成功；`0x80000005` 纠正为 `STATUS_BUFFER_OVERFLOW`；未解码项显式标"未解码"。
2. 机读件分列 `request_bytes`（IOSize）与 `transferred_bytes`（ExtraInformation）；完成事件按 IRP 配对回请求，未配对完成单列。
3. 报告所有计数/字节从最终 JSON 回算；`.ui` 两条文件记录均入对照表。
4. 读取正式 `formal.etl` 会话头丢事件计数并落机读件；校准零丢事件不外推到正式采集。
5. 时间戳时区核对：对齐 UTC 与本地偏移，异常偏移标注待核。
6. 保留每条事件链原始事件头（EventID、时间戳、PID/TID、Irp、FileObject、FileKey、Status、IOSize、ExtraInformation、路径），供离线复核重放。
7. **现有脚本缺陷（重写时修正，实现归 ChatGPT）**：
   - `scan_formal_targets_xml.py` 的 `fo_path/fk_path/irp_path` 为全局字典，未按 PID 分层，存在跨进程句柄/指针复用泄漏；`analyze_formal_xml.py` 已按 PID 分层，重写以分层版为准。
   - 两脚本 ID24 完成事件均未区分请求发起上下文 PID 与完成执行上下文 PID；ID24 仅带 IRP，须按 IRP 在会话窗内配对，保留两侧 PID/TID。
   - 两脚本对 ExtraInformation 未做请求-完成配对即累加进传输字节；未配对完成须单列，不计入完成传输合计。

## 4. 未决项（不据此下结论）

- `0xC000000F`、`0x216`、`0xC000003A`、`0xC0000010`、`0xC01C0004`、`0xC000000D`、`0x80000006` 未逐项解码。
- IOFlags 位定义、InfoClass 数值到查询类型映射未建表。
- CSV/XML PID 列口径偏移风险仍在；XML 关联以 Execution/ProcessID 为准。
- `formal.xml` / `formal.csv` 派生件已永久清除；如需事件链重放，只能从保留的 `formal.etl` 本地只读转换目标 PID/时间窗，不重采、不上传整份 ETL。

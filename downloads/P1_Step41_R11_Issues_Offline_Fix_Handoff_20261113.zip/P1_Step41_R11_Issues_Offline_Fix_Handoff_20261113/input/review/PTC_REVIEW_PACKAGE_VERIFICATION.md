# PTC 支持审核包外部链接核验记录（2026-11-12）

## 1. 核验对象

- 下载源：`https://github.com/suntaltech/Creo13.4/raw/03b268204eba3ddada5af083af5da75b529449fe/downloads/P1_PTC_Support_Review_20261112.zip`
- 校验文件：同名 `.zip.sha256`
- 包内 6 个文件：`PTC_EVIDENCE_INDEX_REVIEWED.json`、`PTC_SUPPORT_REQUEST_REVIEWED.md`、`README.md`、`REVIEW_STATUS.json`、`SHA256SUMS`、`verified-available-evidence.json`

## 2. 完整性核验（通过）

| 校验项 | 结果 |
|---|---|
| zip 实际 SHA256 | `c3e787c97cf8ddd086b14be833fedbd28114dc9a0db411a2af01022d4c7b60ac` |
| sidecar 期望值 | `c3e787c97cf8ddd086b14be833fedbd28114dc9a0db411a2af01022d4c7b60ac` |
| 包体匹配 | 一致（match=True） |
| 包内 5 个实体文件 vs `SHA256SUMS` | 逐条一致，内部自洽 |

## 3. 证据一致性核验（通过）

- 包内索引 27 条记录的类别、字节数、SHA256，与本机 `PTC_REPRO_PACKAGE_MANIFEST.json`（27 条）逐条比对：**无仅单侧条目、无字节不一致**。
- 本机 27 个证据文件回读复核：无缺失、无哈希差异。
- `verified-available-evidence.json` 列示 12 项已匹配历史 R10 附件，其哈希与本机对应记录一致。

## 4. 事实与边界核对（一致，未越界）

- R10 会话 PID 27872 / load_token 8128968 / 80 事件；Access 计数 Body 0、ModelInfo 14、Ping 19；三命令 ActionAdd/Designate/Find 返回 0——与 `runtime-review.json`、`R10_RUNTIME_FINDINGS.md` 一致。
- 草稿明确区分 R10（PID 27872）与 R11（PID 23636）会话，未合并；未用 R11 记录补造 R10 历史路径。
- 未宣称独立最小复现成立、未宣称真实实体转钣金可用、未声称已联系/提交 PTC；未部署、未改插件/配置/模型。

## 5. 包内已标注、需随附说明的注意点

- **包不含证据实体**：无 DLL、无 SDK、无 R11 ETL、无 R11 结果 JSON；索引 `actually_attached_to_PTC_submission=false`，属草稿/索引交接包。
- **R11 载荷未随包**：`formal-file-access.json`、`calibration-gate-result.json`、`formal-start/stop.json`、`R11_FORMAL_OBSERVATION_FINDINGS.md` 等仅列索引；草稿第 54 行列为"先补 R11 小文件、原 ETL 暂留本机"。
- **新鲜度存疑条目**：`ui-toolkit-list-fresh.png` 与早期 R7/R5 图同哈希，草稿已标注不作为独立新鲜的 R10 点前证据；键盘快捷方式截图未随包附复核。
- **DLL 哈希**：已在本机独立重算，与记录值一致（match=True，SHA256 `4517F0C63006B28206716BBD80C8566307CA407CC2164FF87B81C66A3C465FE9`）。

## 7. 离线提交目录（本轮归拢，未发送/未部署）

- 目录：`ptc-submission-package\`，含 6 份 R11 小文件（结果、进程抽样、校准门、起停状态、结论报告）、`MANIFEST.json`、`SHA256SUMS`、`README.md`。
- 6 份实体文件哈希与本机证据记录全部匹配；`SHA256SUMS` 回算自洽；目录内无 ETL、DLL、LIB、EXP。
- 历史 R10 证据以 15 条索引哈希引用、另有 3 份 R11/请求文档列入 `other_referenced_index_only`（未复制实体）；约 232MB `formal.etl` 与 DLL 实体未纳入，原因见 `MANIFEST.json` 的 `omitted` 段。
- 边界：离线准备目录，未联系/发送 PTC，未部署、未改插件/配置/模型，不构成正式发布包。
- 草稿保留的审慎边界：两时点 ID 一致不能证明期间未重建/复用 ID；Access 计数不是候选成员资格回读；OS 文件访问成功不证明内容解析/选项生效/UI 元数据接受。

## 8. R11 小文件与同会话 PID 关联本机复核（2026-11-13，只读）

- **小文件在位与哈希**：`formal-file-access.json`、`formal-xml-probe.json`、`calibration-gate-result.json`、`formal-start.json`、`formal-stop.json`、`R11_FORMAL_OBSERVATION_FINDINGS.md` 及前后基线快照均在位，实算哈希与 `PTC_REPRO_PACKAGE_MANIFEST.json` 记录一致。
- **PID 族闭合**：`formal-file-access.json` 的 `process_family` 共 23 PID；主进程 `23636 xtop.exe`（parent `8388 cmd`），族内含 `12152 parametric`、`23236 creoagent`、`9572/26956 java`、`26352 pro_comm_msg`、`22440 nmsd`、`7392 genlwsc` 及 9 个 `zbcefr`、`25552/25876 prod_dcu`、`27080/21492 qualityagent`、`24272 PTCHardwareCheck`、`25788 mcp_applet_async`；父子链与 `formal-xml-probe.json` 进程抽样可对照。
- **会话身份**：`formal-start.json` 会话名 `R11FileTrace`，`admin=true`，`start_utc=2026-11-12T07:24:09Z`，providers 为 Kernel-File 与 Kernel-Process。
- **命中口径**：三消息 `.txt` 记录 `open=2 / read_n=4 / read_bytes=16384 / write_n=0`，状态码 `0xC0000011`（EOF）+ `0x0`（SUCCESS），实际传输字节按文件分别记录；DAT 枚举条目含 `0xC0000034`（未命中），不计为读取成功；34 条候选写命中当时暂归为平台缓存类（如 `GenLWSC/.../AppsData.txt`）；**该缓存归类已被第 9 节撤回**，写请求去向待事件链复核，不预先判定为持久写入或缓存。
- **边界**：本轮为只读复核，未复制文件、未生成压缩包、未改插件/配置/模型；R11 载荷对外渠道尚未收到。

## 9. ETL 处理脚本与操作级事件链口径复核（2026-11-13）

- **复核范围**：已有 ETL 处理脚本与少量操作级事件链（打开→读请求→对应完成→关闭）；未重采、未上传整份大 ETL、未新增插件探针。详见 `R11_ETL_CORRELATION_REVIEW.md`。
- **第一轮缺口纠正**：
  1. 状态码：`0x80000005` 纠正为 `STATUS_BUFFER_OVERFLOW`（缓冲不足/枚举截断），原误标 `STATUS_NO_MORE_ENTRIES`；不能直接判加载失败。`0x80000006` 为 `STATUS_NO_MORE_FILES`。
  2. 字节口径：`16384` 等为 ID15/16 IOSize **请求量**；ID24 ExtraInformation 才是**完成传输量**；完成量须经 IRP 配对回具体请求，未配对完成单列，不并入合计。
  3. 报告-JSON 不一致：Roaming `.ui` 以 JSON 回算为准——打开 14、读 11、读请求 421,888、写 12、写请求 100,486、完成传输 491,324；Temp `.ui` 打开 6、读 10、写 4。基线哈希一致不证明期间无写入。
  4. 解码质量：事件时间戳偏移 `+07:59` 待核对时钟源/时区转换；零丢事件计数出自校准采集 R11CalTrace，不能代替正式采集 R11FileTrace 统计；正式采集丢事件头尚未读取。
- **第二轮补充纠正（验收口径）**：
  1. `0xC0000010 = STATUS_INVALID_DEVICE_REQUEST`；`STATUS_CANCELLED = 0xC0000120`（本次分布未出现）。此前 `0xC0000010` 被误归未解码/误指 CANCELLED，已更正。
  2. 未配对的 ExtraInformation 保留为原始操作信息，**不能直接算作完成传输字节**；抽取件中未配对完成单列，不并入任何完成字节合计。
  3. PID 关联须区分请求发起上下文与完成事件执行上下文；FileObject/FileKey/IRP 存在复用，不能仅凭事件头 PID 硬过滤；IRP 匹配仅为候选关联，非严格一一配对。
  4. 旧"文件层已排除资源读取/加载差异"与"写入全部属于平台缓存"两条结论**已撤回**；文件层是否可排除，待事件链重放与配对验收后再定。
- **事件链样本产物**：`runtime-r11\r11-event-chains.json`（718,804B，SHA256 `8F7E162BA7B1060065A81B271BB8DC2CF7696E28FD62F6419F7588F0874E55F6`），从保留的 `formal.etl` 本地只读局部转换抽取，13 条目标文件链，保留完整事件头（EventID/SystemTime/ProviderGuid/PID/TID/Irp/FileObject/FileKey/Status/IOSize/ExtraInformation/路径）与完成记录；临时派生 XML 已清除，未上传整份 ETL。
- **材料修订**：`R11_FORMAL_OBSERVATION_FINDINGS.md` 已按上述口径纠正并补入三消息文件事件链复核拆分，11,684B，SHA256 `808FFCA1081ED0F98D99DE0ABDF99C4AAC48BD96B672D02411C23220C5CF8DB1`；本机清单（28 条，missing=0）与离线提交目录已同步重建，7 份附件 SUMS 自洽、与本机记录全匹配。
- **三消息文件事件链复核结论**：fc/model_info/ping 三链各 2 次打开、4 次读请求、8 次完成；读完成候选 516（258×2）/544（272×2）/460（230×2），旧聚合各混入 6 字节打开/清理/关闭完成信息（522=516+6、550=544+6、466=460+6）；各有 1 个读请求未在子集内配对完成。三文件均有路径明确的打开、读请求与成功读完成候选，**不支持"Body 文件完全没被读取"**；但不证明 GUI 解析成功，也不判定文件层已排除差异。
- **外部包未同步**：已推 GitHub 的审核包按旧 findings 哈希核验，未随本次本地修订更新；对外重发前需重新打包并复核哈希。
- **待复核项**：DLL 读取/加载结论、R10 DAT 与 `C:\Users\DELL\config.pro` 偏大的完成传输量，需从保留的 `formal.etl` 本地只读重放事件链后定稿；未解码状态码、IOFlags、InfoClass 映射仍为缺口。现有 `analyze_formal_xml.py`、`scan_formal_targets_xml.py` 存在未配对 ExtraInformation 累加、句柄字典未按 PID 分层等缺陷，已在复核记录标注，实现整改归 ChatGPT。
- **离线交接包（仅本地打包，未发送）**：`D:\creo-tools\build\P1_Step41_R11_Offline_Submission_20261113.zip`，44,505B，SHA256 `F466640531FC1D095C0C40D5F9156E05A2E059A9A9C889AAFCDD015676EC228C`；含 10 条目（R11 七份附件 + MANIFEST.json + README.md + SHA256SUMS），包内附件哈希与本机 SUMS 全匹配；未混入 formal.etl/DLL/LIB/EXP 实体。该包为离线交接草稿，未部署、未对外发送。
- **完整复核交接包（仅本地打包，未发送）**：`D:\creo-tools\build\P1_Step41_R11_Review_Handoff_20261113.zip`；19 条目（`R11/` 七份附件、`scripts/` 三个交付脚本、`review/` 七份复核记录/草稿/清单、README.md、SHA256SUMS）；包内实体哈希与 SUMS 全匹配，未混入 formal.etl/calibrate.etl/DLL/LIB/EXP，未纳入 runtime-r11 调试探针脚本。包内记录件含本机绝对路径/PID/TID，对外提交 PTC 前需脱敏；zip 自身 SHA256 以最终交付清单为准（包内核验记录不回填自引用哈希）。

## 6. 结论

外部审核包完整、未被篡改；索引与本机证据一致；请求草稿事实准确、边界合规。包定位为离线草稿与索引交接，不构成对外复现包；R11 小文件补证与是否实际发送由用户决定。

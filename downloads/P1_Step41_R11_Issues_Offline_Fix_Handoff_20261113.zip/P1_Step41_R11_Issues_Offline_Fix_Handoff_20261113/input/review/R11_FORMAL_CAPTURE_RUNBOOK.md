# R11 正式受控采集执行卡（R11FileTrace）

> 只读文件访问观测。本轮不写插件代码、不改配置/资源/UI 布局、不部署不打包。ETW 会话临时起停，不写系统配置。

## 1. 前置条件（已核对）

- 现场无残留 Creo 进程；无残留 ETW 会话。
- 干净基线已采集：`runtime-r11\r11-preformal-baseline.json`（19 个候选文件哈希、0 进程；与历史残留会话基线哈希零差异）。
- 校准门已通过（带约束）：`runtime-r11\calibration-gate-result.json`。
- D 盘剩余 6.78GB；校准可再生产物已清除，`calibrate.etl` 原始证据保留。
- 脚本：`r11_trace_start.ps1`（提权启动）、`r11_trace_stop.ps1`（提权停止导出）。

## 2. 正式采集文件命名（runtime-r11）

| 用途 | 路径 |
|---|---|
| ETW 会话名 | `R11FileTrace` |
| ETL 原始证据 | `runtime-r11\formal.etl` |
| 启动状态 | `runtime-r11\formal-start.json` |
| 停止/导出状态 | `runtime-r11\formal-stop.json` |
| 提供者清单 | `runtime-r11\formal-providers.txt` |
| CSV（初筛，可选） | `runtime-r11\formal.csv` |
| XML（仅目标 PID/时间窗需要时转） | `runtime-r11\formal.xml` |
| 后处理结果 | `runtime-r11\formal-file-access.json` |
| 采集后基线 | `runtime-r11\r11-postformal-baseline.json` |

## 3. 执行步骤

### 步骤 A：提权启动有界采集（助手执行，UAC 需用户桌面确认）

- 调用 `r11_trace_start.ps1`，参数：
  - `SessionName=R11FileTrace`
  - `EtlPath=...\runtime-r11\formal.etl`
  - `StatePath=...\runtime-r11\formal-start.json`
  - `ProvidersFile=...\runtime-r11\formal-providers.txt`
  - `Mode=formal`
- 提权方式：ps51 `Start-Process -Verb RunAs -Wait -PassThru`；UAC 弹窗由用户点"是"。
- 启动后核对 `formal-start.json`：`admin=true`、`status=running`、`create_start` 退出码 0。
- **不在启动前按旧 PID（27872 等）预过滤**；启动读取发生在新 PID 已知之前。

### 步骤 B：用户手动 GUI 操作（用户执行，助手不代点）

1. 启动新的 Creo Parametric 会话，等待辅助应用（p1s23、p1_step41_r10）加载完成。
2. 打开 选项 → 自定义功能区 / TOOLKIT Commands 命令列表。
3. 观察三条命令在候选列表中的可见情况：`p1_readonly_body_face_count`、`p1_readonly_model_info`、`p1_readonly_ping`。
4. **禁止**：拖放按钮到备用区、保存布局、主动回写 `.ui`、点击原生转换、保存模型、停用 p1s23、清缓存。

### 步骤 C：退出 Creo（用户执行）

- 正常退出 Creo，等待进程族（`parametric.exe`/`xtop.exe`/`creoagent.exe`/`java.exe`）全部退出。

### 步骤 D：提权停止并导出（助手执行，UAC 需用户确认）

- 调用 `r11_trace_stop.ps1`，参数：
  - `SessionName=R11FileTrace`
  - `EtlPath=...\runtime-r11\formal.etl`
  - `StatePath=...\runtime-r11\formal-stop.json`
  - `CsvPath=...\runtime-r11\formal.csv`
  - `XmlPath=...\runtime-r11\formal.xml`
  - `Mode=formal`
- 核对 `formal-stop.json`：`stop`/`tracerpt_csv` 退出码 0，`status=exported`。
- 体积约束：不要默认全量转 XML；先 CSV 粗筛，仅对目标 PID/时间窗转 XML。

### 步骤 E：采集后基线与自然写入核对（助手执行，只读）

- 采集后再跑一次基线快照到 `r11-postformal-baseline.json`。
- 与 `r11-preformal-baseline.json` 逐文件比对哈希；任何哈希变化记为自然写入，记录前后哈希、时间戳与命中进程，不回滚、不删除。

### 步骤 F：后处理（助手执行，离线只读）

1. 从 Kernel-Process 创建事件识别新会话进程族 PID（`parametric`/`xtop`/`creoagent`/`java`，含父/子链）。
2. 严格先限定 PID，再按 `FileObject`/`FileKey`/`Irp` 关联：ID12 打开 → 文件名；ID15 读 / ID16 写；ID24 完成（`Status` NTSTATUS、`ExtraInformation` 传输字节）。
3. 候选路径前缀过滤：`config.pro`、`config.win`、`menu_def.pro`、`creo_parametric_customization.ui`、消息 `.txt`、`protk.dat/creotk.dat/prodev.dat`。
4. 输出 `formal-file-access.json`：每条含时间戳、PID、进程名、父 PID、路径、操作、访问模式、读/写字节、完成状态、来源工具。

## 4. 三层判定口径（不合并）

| 层 | 可得性 | 说明 |
|---|---|---|
| 文件打开 | 文件访问层可得 | ID12，含访问/共享/创建选项；打开不等于读或写 |
| 实际读取及其状态 | 文件访问层可得 | ID15 + ID24 状态；写权限打开不等于发生写入 |
| Creo 解析成功 | 文件访问层不可得 | 须由消息 API 返回码或 UI 呈现层另判 |

- 某路径被某 PID 命中 = 该进程访问过该文件；文件访问层不判定消息/标签是否被 GUI 解析。
- 配置无引用 ≠ 无候选资格。
- R10 历史 `.ui` 来源保持"未知"，不补推断。

## 5. 边界与缺口记录

- 未知项：IOFlags 位定义未逐项解码；InfoClass 数值到查询类型未建表；`HarddiskVolumeX` → 盘符映射在采集时按挂载关系重建。
- 记录口径：丢事件/刷新缺口、解码或字段缺失、采集覆盖的目录/进程/时间窗，均写入后处理结果。
- 若观测后 Body 与两条可见命令差异仍不可解释：整理最小复现包向 PTC 核查；不再堆叠 Find/Access 探针。

# P1 Step41 R11 离线复核交接包（本地草稿，未部署、未对外发送）

> 性质：Step41 R11 文件访问观测的离线复核与 PTC 案例准备材料索引。
> 边界：未现场部署、未打包发布、未宣称真实实体转钣金可用；探针未点击 body 命令，未打开/选择/保存/转换模型。

## 目录结构

- `R11/`：R11 正式采集机读结果与事件链样本（7 份附件）。
- `scripts/`：三个交付处理脚本（PID 限定三层关联主脚本、目标扫描脚本、事件链抽取辅助脚本）。脚本存在已知缺陷，整改归 ChatGPT，详见 `review/R11_ETL_CORRELATION_REVIEW.md` 第 3 节。
- `review/`：复核记录、观测结论、核验记录、PTC 请求草稿、离线输入清单、采集执行卡、观测方案、本机证据索引清单。

## 哈希口径

- `SHA256SUMS` 记录包内每个条目的 SHA256（大写十六进制），路径为包内相对路径。
- `R11/R11_FORMAL_OBSERVATION_FINDINGS.md` 与事件链样本为当前复核口径；旧聚合字节与读完成候选的拆分见复核记录 1.5 节与结论 4.1 节。

## 未纳入本包

- `formal.etl`、`calibrate.etl` 原始证据；DLL/LIB/EXP 二进制实体。
- runtime-r11 目录下的调试/探针辅助脚本（debug/probe/scan_calibrate 等）。

## 对外发送前待办

- 包内 `review/PTC_REPRO_PACKAGE_MANIFEST.json` 及部分记录含本机绝对路径、PID/TID；对外提交 PTC 前需按目标受众脱敏。
- 正式采集丢事件计数（EventsLost/BuffersLost）尚未从 `formal.etl` 会话头读取；未解码状态码、IOFlags/InfoClass 映射仍是缺口，不据此下文件层排除结论。

生成时间（本地）：2026-11-13 15:13:51

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Target-file event detail scan over formal.xml (single pass).

Collects per-file PID / open / read / write / completion evidence for the
plugin DLLs, DATs, message txts and config/.ui files of interest.
"""
import xml.etree.ElementTree as ET
import os, json, collections

BASE = r"D:\creo-tools\build\p1-step41-r10-late-find-review-20261112\runtime-r11"
XML_PATH = os.path.join(BASE, "formal.xml")
OUT = os.path.join(BASE, "formal-target-files.json")
ns = {"e": "http://schemas.microsoft.com/win/2004/08/events/event"}
FILE_GUID = "{EDD08927-9CC4-4E65-B970-C2560FB5C289}".lower()

TARGETS = ("step41_r10", "p1-step23", "p1_fc.txt", "model_info.txt", "ping.txt",
           "config.pro", "config.win", "customization.ui", "menu_def.pro")

fo_path = {}
fk_path = {}
irp_path = {}
files = {}

def bucket(pid, path):
    k = (pid, path)
    if k not in files:
        files[k] = {"pid": pid, "path": path, "open": 0, "read_n": 0, "read_bytes": 0,
                    "write_n": 0, "write_bytes": 0, "statuses": set(), "transferred": 0}
    return files[k]

def resolve(fo, fk, irp):
    for mp, key in ((fo_path, fo), (fk_path, fk), (irp_path, irp)):
        if key and key in mp:
            return mp[key]
    return None

context = ET.iterparse(XML_PATH, events=("end",))
for _, elem in context:
    if not elem.tag.endswith("Event"):
        continue
    prov = elem.find(".//e:Provider", ns)
    eid_el = elem.find(".//e:EventID", ns)
    if prov is None or eid_el is None:
        elem.clear(); continue
    if (prov.get("Guid") or "").lower() != FILE_GUID:
        elem.clear(); continue
    pid_el = elem.find(".//e:Execution", ns)
    pid = pid_el.get("ProcessID") if pid_el is not None else ""
    eid = eid_el.text.strip()
    data = {d.get("Name"): (d.text or "").strip() for d in elem.findall(".//e:Data", ns)}
    fo, fk, irp = data.get("FileObject", ""), data.get("FileKey", ""), data.get("Irp", "")
    path = data.get("FileName", "")
    low = path.lower()
    targeted = any(t in low for t in TARGETS)

    if eid == "12":
        if path:
            fo_path[fo] = path; fk_path[fk] = path; irp_path[irp] = path
            if targeted:
                bucket(pid, path)["open"] += 1
    elif eid in ("15", "16"):
        p = resolve(fo, fk, irp)
        if p:
            b = bucket(pid, p)
            try:
                iosize = int(data.get("IOSize", "0"), 16) if data.get("IOSize", "").startswith("0x") else int(data.get("IOSize", "0") or 0)
            except ValueError:
                iosize = 0
            if eid == "15":
                b["read_n"] += 1; b["read_bytes"] += iosize
            else:
                b["write_n"] += 1; b["write_bytes"] += iosize
    elif eid == "24":
        p = resolve(fo, fk, irp)
        if p:
            b = bucket(pid, p)
            b["statuses"].add(data.get("Status", ""))
            try:
                extra = data.get("ExtraInformation", "")
                b["transferred"] += int(extra, 16) if extra.startswith("0x") else int(extra or 0)
            except ValueError:
                pass
    elem.clear()

out = []
for (pid, path), b in files.items():
    b["statuses"] = sorted(b["statuses"])
    out.append(b)
out.sort(key=lambda x: (x["path"], x["pid"]))

with open(OUT, "w", encoding="utf-8") as fh:
    json.dump(out, fh, ensure_ascii=False, indent=2)

for b in out:
    print(json.dumps({k: b[k] for k in ("pid", "path", "open", "read_n", "read_bytes", "write_n", "write_bytes", "statuses")}, ensure_ascii=False))
print("distinct target file-rows:", len(out), "->", OUT)

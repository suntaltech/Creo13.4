#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""PID-scoped three-layer file-access correlation for the formal R11 capture.

Pass 1: identify the new Creo session process family from Kernel-Process ID1.
Pass 2: correlate Kernel-File events strictly per PID:
  ID12 open -> FileObject/FileKey/Irp -> FileName
  ID15 read / ID16 write -> IOSize, back-fill path via handle/IRP
  ID24 completion -> Status (NTSTATUS), ExtraInformation transferred bytes
Candidate config/.ui/message/.dat paths are aggregated; directory prefixes are
summarized for the family. Read-only; does not modify any file.
"""
import xml.etree.ElementTree as ET
import os, json, re, collections

BASE = r"D:\creo-tools\build\p1-step41-r10-late-find-review-20261112\runtime-r11"
XML_PATH = os.path.join(BASE, "formal.xml")
OUT_PATH = os.path.join(BASE, "formal-file-access.json")

ns = {"e": "http://schemas.microsoft.com/win/2004/08/events/event"}
FILE_GUID = "{EDD08927-9CC4-4E65-B970-C2560FB5C289}".lower()
PROC_GUID = "{22FB2CD6-0E7B-422B-A0C7-2FAD1FD0E716}".lower()

VOL_MAP = {"\\Device\\HarddiskVolume3\\": "C:\\", "\\Device\\HarddiskVolume4\\": "D:\\"}

# Family image-name tokens (lower-case) that belong to the Creo session tree.
FAMILY_TOKENS = (
    "parametric.exe", "xtop.exe", "creoagent.exe", "java.exe", "pro_comm_msg.exe",
    "msd.exe", "genlwsc.exe", "zbcefr.exe", "prod_dcu.exe", "qualityagent.exe",
    "pthardwarecheck.exe", "mcp_applet_async.exe",
)
FAMILY_PATH_TOKENS = ("\\program files\\ptc\\", "\\creoson\\", "\\program files\\common files\\ptc\\")

CANDIDATE_SUFFIX = (".pro", ".win", ".dat", ".ui", ".txt", "menu_def")
# Message resource files of interest (R10/R11 probes).
MSG_FILES = ("p1_fc.txt", "p1_readonly_model_info.txt", "p1_readonly_ping.txt")
DAT_FILES = ("protk.dat", "creotk.dat", "prodev.dat")


def normalize_path(p):
    if not p:
        return ""
    for vol, drive in VOL_MAP.items():
        if p.lower().startswith(vol):
            return drive + p[len(vol):]
    return p


def is_family_image(img):
    low = img.lower()
    if any(t in low for t in FAMILY_TOKENS):
        return True
    if any(t in low for t in FAMILY_PATH_TOKENS):
        return True
    return False


def first_pass_processes():
    procs = {}
    context = ET.iterparse(XML_PATH, events=("end",))
    for _, elem in context:
        if not elem.tag.endswith("Event"):
            continue
        prov = elem.find(".//e:Provider", ns)
        eid_el = elem.find(".//e:EventID", ns)
        if prov is None or eid_el is None:
            elem.clear(); continue
        if (prov.get("Guid") or "").lower() != PROC_GUID:
            elem.clear(); continue
        if eid_el.text.strip() != "1":
            elem.clear(); continue
        data = {d.get("Name"): (d.text or "").strip() for d in elem.findall(".//e:Data", ns)}
        pid = data.get("ProcessID", "")
        procs[pid] = {
            "image": data.get("ImageName", ""),
            "parent": data.get("ParentProcessID", ""),
            "create_time": data.get("CreateTime", ""),
            "elevated": data.get("ProcessTokenIsElevated", ""),
            "family": is_family_image(data.get("ImageName", "")),
        }
        elem.clear()
    return procs


def second_pass(family_pids):
    # Per-PID handle/IRP -> path maps.
    fo_path = collections.defaultdict(dict)
    fk_path = collections.defaultdict(dict)
    irp_path = collections.defaultdict(dict)
    files = {}  # (pid, path) -> aggregate
    dir_prefix = collections.Counter()
    family_event_counts = collections.Counter()
    write_hits = []

    def bucket(pid, path):
        key = (pid, path)
        if key not in files:
            files[key] = {"pid": pid, "path": path, "open": 0, "read_n": 0, "read_bytes": 0,
                          "write_n": 0, "write_bytes": 0, "statuses": set(), "transferred_bytes": 0,
                          "first_ts": None, "last_ts": None, "create_options": "", "share_access": ""}
        return files[key]

    def resolve(pid, fo, fk, irp):
        for mp, key in ((fo_path[pid], fo), (fk_path[pid], fk), (irp_path[pid], irp)):
            if key and key in mp:
                return mp[key]
        return None

    context = ET.iterparse(XML_PATH, events=("end",))
    for _, elem in context:
        if not elem.tag.endswith("Event"):
            continue
        prov = elem.find(".//e:Provider", ns)
        eid_el = elem.find(".//e:EventID", ns)
        if prov is None or eid_el is None:
            elem.clear(); continue
        if (prov.get("Guid") or "").lower() != FILE_GUID:
            elem.clear(); continue
        pid_el = elem.find(".//e:Execution", ns)
        pid = pid_el.get("ProcessID") if pid_el is not None else ""
        if pid not in family_pids:
            elem.clear(); continue
        eid = eid_el.text.strip()
        family_event_counts[eid] += 1
        data = {d.get("Name"): (d.text or "").strip() for d in elem.findall(".//e:Data", ns)}
        tc = elem.find(".//e:TimeCreated", ns)
        ts = tc.get("SystemTime") if tc is not None else ""
        fo, fk, irp = data.get("FileObject", ""), data.get("FileKey", ""), data.get("Irp", "")
        path = normalize_path(data.get("FileName", ""))

        if eid == "12":
            if path:
                fo_path[pid][fo] = path
                fk_path[pid][fk] = path
                irp_path[pid][irp] = path
                b = bucket(pid, path)
                b["open"] += 1
                b["create_options"] = data.get("CreateOptions", b["create_options"])
                b["share_access"] = data.get("ShareAccess", b["share_access"])
                b["first_ts"] = b["first_ts"] or ts
                b["last_ts"] = ts
                # directory prefix aggregation (first 4 path segments)
                parts = [s for s in path.split("\\") if s]
                dir_prefix["\\".join(parts[:4])] += 1
        elif eid in ("15", "16"):
            p = resolve(pid, fo, fk, irp)
            iosize = int(data.get("IOSize", "0"), 16) if data.get("IOSize", "").startswith("0x") else (int(data.get("IOSize", "0") or 0) if data.get("IOSize", "").isdigit() else 0)
            if p:
                b = bucket(pid, p)
                if eid == "15":
                    b["read_n"] += 1; b["read_bytes"] += iosize
                else:
                    b["write_n"] += 1; b["write_bytes"] += iosize
                    if p.lower().endswith(CANDIDATE_SUFFIX):
                        write_hits.append({"pid": pid, "path": p, "iosize": iosize, "ts": ts})
                b["last_ts"] = ts
        elif eid == "24":
            p = resolve(pid, fo, fk, irp)
            if p:
                b = bucket(pid, p)
                b["statuses"].add(data.get("Status", ""))
                extra = data.get("ExtraInformation", "")
                try:
                    b["transferred_bytes"] += int(extra, 16) if extra.startswith("0x") else int(extra or 0)
                except ValueError:
                    pass
        elem.clear()

    return files, dir_prefix, family_event_counts, write_hits


def main():
    procs = first_pass_processes()
    family_pids = {pid for pid, v in procs.items() if v["family"]}
    files, dir_prefix, fec, write_hits = second_pass(family_pids)

    # Candidate config/.ui/message/.dat hits.
    candidate = []
    for (pid, path), b in files.items():
        low = path.lower()
        if low.endswith(CANDIDATE_SUFFIX) or any(m in low for m in MSG_FILES) or any(d in low for d in DAT_FILES):
            candidate.append({k: (list(v) if isinstance(v, set) else v) for k, v in b.items()})
    candidate.sort(key=lambda x: (x["path"], x["pid"]))

    # Message-file specific lookup (the three R10 commands).
    msg_hits = [c for c in candidate if any(m in c["path"].lower() for m in MSG_FILES)]
    dat_hits = [c for c in candidate if any(d in c["path"].lower() for d in DAT_FILES)]

    result = {
        "schema": "r11-formal-file-access/1",
        "process_family": [
            {"pid": pid, **procs[pid]} for pid in sorted(family_pids, key=lambda x: int(x, 16) if x else -1)
        ],
        "all_processes": [{"pid": pid, **v} for pid, v in sorted(procs.items())],
        "family_file_event_counts": dict(fec.most_common()),
        "candidate_files": candidate,
        "message_file_hits": msg_hits,
        "dat_file_hits": dat_hits,
        "candidate_write_hits": write_hits,
        "directory_prefix_top": dir_prefix.most_common(30),
        "totals": {
            "family_pid_count": len(family_pids),
            "distinct_files_family": len(files),
            "candidate_file_count": len(candidate),
            "candidate_write_hit_count": len(write_hits),
        },
    }

    with open(OUT_PATH, "w", encoding="utf-8") as fh:
        json.dump(result, fh, ensure_ascii=False, indent=2)

    print("family PIDs:", len(family_pids))
    for pid in sorted(family_pids, key=lambda x: int(x, 16) if x else -1):
        print(" ", pid, procs[pid]["image"])
    print("family file event counts:", dict(fec.most_common()))
    print("distinct files in family:", len(files))
    print("candidate files:", len(candidate), "msg:", len(msg_hits), "dat:", len(dat_hits))
    print("candidate write hits:", len(write_hits))
    print("OK ->", OUT_PATH)


if __name__ == "__main__":
    main()

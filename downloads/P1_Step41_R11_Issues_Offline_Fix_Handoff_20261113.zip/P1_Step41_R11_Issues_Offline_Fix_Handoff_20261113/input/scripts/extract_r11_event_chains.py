#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Extract a small number of original R11 file-access event chains from formal.xml.

Read-only post-processing over the locally converted XML (derived from the kept
formal.etl). No re-capture, no whole ETL export, no plugin change.

Correlation rules (see R11_ETL_CORRELATION_REVIEW.md):
- PID scope is fixed first; FileObject/FileKey/IRP pointers are reused system-wide.
- ID12 Open/Create establishes Fo/Fk/Irp -> FileName.
- ID15 Read / ID16 Write carry Fo/Fk/Irp; ID24 completion carries Irp + Status +
  ExtraInformation only.
- Request (ID15/16) issuing-context PID/TID and completion (ID24) execution-context
  PID/TID are both kept raw; matching is by IRP within the session window.
- An ExtraInformation that cannot be paired back to a request is kept as raw
  operation info only; it is NOT counted as completed transferred bytes.
"""
import xml.etree.ElementTree as ET
import os, json, collections

BASE = r"D:\creo-tools\build\p1-step41-r10-late-find-review-20261112\runtime-r11"
XML_PATH = r"C:\Users\DELL\AppData\Local\Temp\p1-r11-chain\formal.xml"  # local temp copy consumed, not shipped
OUT = os.path.join(BASE, "r11-event-chains.json")
ns = {"e": "http://schemas.microsoft.com/win/2004/08/events/event"}
FILE_GUID = "{EDD08927-9CC4-4E65-B970-C2560FB5C289}".lower()

TARGET_PID = "23636"  # xtop main process
# Keyword lower-case substrings identifying evidence files of interest.
TARGET_KEYWORDS = (
    "p1_fc.txt", "model_info.txt", "ping.txt",
    "customization.ui", "config.pro", "step41_r10", "p1-step23", "step23.dat",
)

# NTSTATUS dictionary (subset verified against MS-ERREF; unresolved codes left blank).
NTSTATUS = {
    "0x0": "STATUS_SUCCESS",
    "0xc0000011": "STATUS_END_OF_FILE",
    "0xc0000034": "STATUS_OBJECT_NAME_NOT_FOUND",
    "0xc000003a": "STATUS_OBJECT_PATH_NOT_FOUND",
    "0x80000005": "STATUS_BUFFER_OVERFLOW",
    "0x80000006": "STATUS_NO_MORE_FILES",
    "0xc0000010": "STATUS_INVALID_DEVICE_REQUEST",
    "0xc0000120": "STATUS_CANCELLED",
}

OP = {"12": "Open/Create", "13": "Cleanup", "14": "Close",
      "15": "ReadFile", "16": "WriteFile", "24": "IRP completion"}

fo_path, fk_path, irp_path = {}, {}, {}
chains = collections.defaultdict(lambda: {"events": []})
unpaired_id24_total = 0
unpaired_id24_samples = []
id24_total = 0
event_total = 0


def path_of(fo, fk, irp):
    for mp, key in ((fo_path, fo), (fk_path, fk), (irp_path, irp)):
        if key and key in mp:
            return mp[key]
    return None


def target(path):
    low = (path or "").lower()
    return any(k in low for k in TARGET_KEYWORDS)


def event_record(elem, eid, data):
    se = elem.find(".//e:System", ns)
    time_el = se.find(".//e:TimeCreated", ns) if se is not None else None
    exec_el = se.find(".//e:Execution", ns) if se is not None else None
    return {
        "event_id": eid,
        "operation": OP.get(eid, "unknown"),
        "system_time": time_el.get("SystemTime") if time_el is not None else "",
        "provider_guid": (se.find(".//e:Provider", ns).get("Guid") if se is not None and se.find(".//e:Provider", ns) is not None else ""),
        "execution_pid": exec_el.get("ProcessID") if exec_el is not None else "",
        "execution_tid": exec_el.get("ThreadID") if exec_el is not None else "",
        "data": data,
    }


ctx = ET.iterparse(XML_PATH, events=("end",))
for _, elem in ctx:
    if not elem.tag.endswith("Event"):
        continue
    prov = elem.find(".//e:Provider", ns)
    eid_el = elem.find(".//e:EventID", ns)
    exec_el = elem.find(".//e:Execution", ns)
    if prov is None or eid_el is None:
        elem.clear(); continue
    if (prov.get("Guid") or "").lower() != FILE_GUID:
        elem.clear(); continue
    pid = exec_el.get("ProcessID") if exec_el is not None else ""
    if pid != TARGET_PID:
        elem.clear(); continue
    event_total += 1
    eid = eid_el.text.strip()
    data = {d.get("Name"): (d.text or "").strip() for d in elem.findall(".//e:Data", ns)}
    fo, fk, irp = data.get("FileObject", ""), data.get("FileKey", ""), data.get("Irp", "")

    if eid == "12":
        path = data.get("FileName", "")
        if path:
            fo_path[fo] = path; fk_path[fk] = path; irp_path[irp] = path
            if target(path):
                rec = event_record(elem, eid, data)
                chains[path]["events"].append(rec)
    elif eid in ("15", "16"):
        p = path_of(fo, fk, irp)
        if p and target(p):
            rec = event_record(elem, eid, data)
            chains[p]["events"].append(rec)
    elif eid == "24":
        id24_total += 1
        p = path_of(fo, fk, irp)
        if p and target(p):
            rec = event_record(elem, eid, data)
            chains[p]["events"].append(rec)
        else:
            unpaired_id24_total += 1
            if len(unpaired_id24_samples) < 20:
                unpaired_id24_samples.append(event_record(elem, eid, data))
    elif eid in ("13", "14"):
        p = path_of(fo, fk, irp)
        if p and target(p):
            rec = event_record(elem, eid, data)
            chains[p]["events"].append(rec)
    elem.clear()

# Assemble output: pair completion ExtraInformation only when its IRP appears in a
# request on the same chain; otherwise mark raw/unpaired.
result = {
    "schema": "r11-event-chains/1",
    "scope": {
        "target_pid": TARGET_PID,
        "source_etl_sha256": "AEDDC77D8ED97FEA4606C18E67512D20507C99DAACF46FAE81C949D3D932BAD5",
        "note": "Derived locally from formal.etl via tracerpt XML; no re-capture, no whole ETL shipped.",
        "correlation_rules": [
            "PID fixed before handle/IRP matching; pointers reused across processes.",
            "Request issuing-context and completion execution-context PID/TID kept raw.",
            "Unpaired ExtraInformation is raw operation info, not completed transferred bytes.",
            "IRP/FileObject are reused within the session; IRP match is a candidate correlation, not a strict one-to-one pairing. ExtraInformation is never summed into a completed-bytes total here.",
        ],
    },
    "totals": {
        "pid_scope_file_events": event_total,
        "id24_completion_total": id24_total,
        "id24_unpaired_total": unpaired_id24_total,
    },
    "unpaired_completion_samples_kept_raw": unpaired_id24_samples,
    "chains": [],
}

for path, ch in chains.items():
    evs = ch["events"]
    if not evs:
        continue
    req_irp = {e["data"].get("Irp", "") for e in evs if e["event_id"] in ("15", "16")}
    paired = [e for e in evs if e["event_id"] == "24" and e["data"].get("Irp", "") in req_irp]
    unpaired = [e for e in evs if e["event_id"] == "24" and e["data"].get("Irp", "") not in req_irp]
    statuses = sorted({e["data"].get("Status", "") for e in evs if e["data"].get("Status", "")})
    result["chains"].append({
        "path": path,
        "event_count": len(evs),
        "event_sequence": [e["operation"] for e in evs],
        "statuses": [{"code": s, "name": NTSTATUS.get(s.lower(), "unresolved")} for s in statuses],
        "pairing_basis": "IRP match within target PID; IRP/FileObject reuse means this is candidate correlation only",
        "paired_completion_events": paired,
        "unpaired_completion_events_kept_raw": unpaired,
        "other_events": [e for e in evs if e["event_id"] != "24"],
    })

result["totals"]["target_files"] = len(result["chains"])
result["chains"].sort(key=lambda c: (-c["event_count"], c["path"]))
with open(OUT, "w", encoding="utf-8") as fh:
    json.dump(result, fh, ensure_ascii=False, indent=2)

print("target files:", len(result["chains"]))
print("id24 total:", id24_total, "unpaired:", unpaired_id24_total)
for c in result["chains"][:20]:
    print(f"  {c['event_count']:4} ev  {c['path']}")
print("written:", OUT)

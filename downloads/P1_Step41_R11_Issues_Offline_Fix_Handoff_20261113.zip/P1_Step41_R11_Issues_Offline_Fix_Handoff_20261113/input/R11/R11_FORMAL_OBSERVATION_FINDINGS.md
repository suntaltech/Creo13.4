# R11 正式受控文件访问观测结论（R11FileTrace）

> 阶段：Step41 R11 诊断 R11 阶段。只读文件访问观测；本轮未改插件代码、未改配置/资源/UI 布局、未部署未打包。
> 结论口径：文件访问层（打开/读取/写入/完成状态）。文件访问层不判定消息/标签是否被 GUI 解析。

## 1. 采集概况

| 项 | 值 |
|---|---|
| 会话名 | R11FileTrace |
| 启动 UTC | 2026-11-12 07:24:09 |
| 停止 UTC | 2026-11-12 07:28:54 |
| 提供者 | Kernel-File（0x3F0）、Kernel-Process（0x10）、Kernel-General |
| 产物 | formal.etl 232.38MB（保留原始证据）；formal.csv、formal.xml 为派生件，已永久清除（见第 8 节） |
| 采集前/后基线 | 19 个候选文件哈希零差异；基线哈希一致只证明会话结束时最终内容与采集前一致，不证明期间无写入或写后恢复。正式采集丢事件计数尚未核验（校准采集零丢事件不外推） |
| GUI 复核 | 截图确认 TOOLKIT 命令列表可见 `p1_readonly_model_info`、`p1_readonly_ping`，仍未见 `p1_readonly_body_face_count`（与 R10 一致） |

## 2. 新会话进程族（XML Kernel-Process ID1）

启动器 `parametric.exe` 12152 → `xtop.exe` 23636（主进程）→ 子进程：

| PID（十进制） | 映像 | 角色 |
|---|---|---|
| 12152 | parametric.exe | 启动器 |
| 23636 | xtop.exe | 主进程（探针目标对应 R10 的 27872） |
| 23236 | creoagent.exe | 辅助应用代理 |
| 9572 / 26956 | java.exe（creoson jdk25） | J-Link（p1s23） |
| 26352 | pro_comm_msg.exe | 消息通信 |
| 22440 | msd.exe | 辅助 |
| 7392 | genlwsc.exe → 多个 zbcefr.exe | 平台 Web 辅助 |
| 25552 / 25876 | prod_dcu.exe；27080 / 21492 qualityagent.exe；24272 PTCHardwareCheck.exe；25788 mcp_applet_async.exe | 诊断/辅助 |

族内共 23 个 PID；族内文件事件：完成 200993、读 66659、打开 36706、清理 30629、关闭 28075、写 3660。上述计数来自 XML 关联后聚合；正式采集事件完整性（丢事件头）尚未核验，计数不排除事件丢失影响。

## 3. 三层关联口径（校准门实测映射）

- ID12 打开：建立 FileObject/FileKey/IRP → FileName；含 CreateOptions/ShareAccess。
- ID15 读 / ID16 写：IOSize 请求字节；经 FileObject/FileKey/IRP 回填路径。
- ID24 完成：Status（NTSTATUS）、ExtraInformation 实际传输字节。
- 关联**先严格限定 PID**，再按句柄/IRP 匹配；FileObject/FileKey 指针跨进程复用，不做跨 PID 句柄匹配。
- 卷映射：HarddiskVolume3 = C:，HarddiskVolume4 = D:（按本机挂载关系重建）。

## 4. 关键证据对照（PID 23636 xtop，除非另注）

### 4.1 三条命令消息文件（chinese_cn）

> 字节口径：`读请求字节`为 ID15 IOSize 请求缓冲量；`完成传输`为 ID24 ExtraInformation 实际传输字节，二者不可混用。下表"完成传输"为旧聚合把该文件全部 ID24 完成 ExtraInformation 相加的合计，**含打开/清理/关闭等非读完成信息**，不等于读取字节。

| 消息文件 | 打开 | 读次数 | 读请求字节(IOSize) | 旧聚合完成合计 | 写 | 完成状态 |
|---|---|---|---|---|---|---|
| p1_fc.txt（body/fc，258B） | 2 | 4 | 16384 | 522 | 0 | 0xC0000011, 0x0 |
| p1_readonly_model_info.txt（272B） | 2 | 4 | 16384 | 550 | 0 | 0xC0000011, 0x0 |
| p1_readonly_ping.txt（230B） | 2 | 4 | 16384 | 466 | 0 | 0xC0000011, 0x0 |

**事件链复核拆分**（源自 `r11-event-chains.json`，PID 23636，IRP 候选关联）：

| 消息文件 | 完成事件 | 读完成 ExtraInformation（成功×2 + EOF×1） | 读完成候选字节 | 混入的非读完成字节 | 未配对读请求 |
|---|---|---|---|---|---|
| p1_fc.txt | 8 | 0x102 + 0x102 + 0x0 | 516（258×2） | 6（open 0x1×2、cleanup 0x2×2、close 0x0） | 1 |
| p1_readonly_model_info.txt | 8 | 0x110 + 0x110 + 0x0 | 544（272×2） | 6（同上） | 1 |
| p1_readonly_ping.txt | 8 | 0xE6 + 0xE6 + 0x0 | 460（230×2） | 6（同上） | 1 |

- 旧聚合合计 = 读完成候选 + 6 非读完成：522=516+6、550=544+6、466=460+6。每份各有 1 个读请求在所给事件子集内未找到对应完成记录，因此右列读完成候选也**不能当作完整读取总量**。
- **可确认事实**：三个目标文件均有路径明确的打开、读请求及成功读完成候选（两次成功读 + 一次 EOF）；现有证据**不支持"Body 文件完全没被读取"的解释**。
- **边界**：以上仅为文件访问层事实，不证明消息被 GUI 成功解析，也不据此判定整个文件层已排除差异；未配对读请求、IRP/句柄复用与丢事件缺口仍在。
- usascii 三个消息文件未被访问（语言目录优先 chinese_cn）。

### 4.2 插件 DAT

| DAT | 打开 | 读次数 | 读请求字节(IOSize) | 完成传输(ExtraInformation) | 写 | 完成状态 |
|---|---|---|---|---|---|---|
| p1-step23.dat（J-Link，可见命令所在） | 3 | 4 | 16384 | 435 | 0 | 0x80000005, 0xC0000011, 0x0 |
| p1_step41_r10_late_find_snapshot.dat（R10 DLL） | 3 | 4 | 16384 | 57173（完成量配对待事件链复核） | 0 | 0x80000005, 0xC0000011, 0x0 |

两个 DAT 读取链路一致；R10 DAT 完成传输量偏大，需在事件链重放时核对 ExtraInformation 是否与具体读请求一一配对。标准目录（安装 text、x86e_win64/text、usascii 等）探测的 protk/creotk/prodev.dat 均返回 `0xC0000034`（对象名未找到），属正常路径探测，非加载失败。

### 4.3 R10 DLL 加载

> 下表来自早期单独 DLL 扫描件；派生 XML 已清除，当前机读 `formal-file-access.json` 不含 DLL 记录，数字待从保留的 `formal.etl` 重放事件链复核。字节同样需区分 IOSize 请求量与 ExtraInformation 完成量。

| PID | 打开 | 读次数 | 读字节（口径待核） | 写 | 完成状态 |
|---|---|---|---|---|---|
| 23636（xtop） | 8 | 545 | 4,772,352 | 0 | 0x0, 0x80000005 |
| 5172 | 7 | 37 | 1,159,168 | 0 | 0x0, 0x216, 0x80000005 |
| 1640 | 0 | 551 | 2,256,896 | 0 | 0x0 |

> 上表计数/字节来自 `formal-file-access.json` 旧聚合口径，请求量与完成量尚未逐条配对；其余 PID 对该 DLL 的读取用途暂不归类。DLL 是否被主进程实际加载、各 PID 读取性质，均待事件链重放复核后再定稿，本轮不下"非插件加载"或"缓存旁路"结论。

### 4.4 配置与定制 UI

> 字节口径：读/写请求字节为 IOSize；完成传输为 ExtraInformation。下表计数与字节均按 `formal-file-access.json` 回算。

| 文件 | PID | 打开 | 读次数 | 读请求字节 | 完成传输 | 写次数 | 写请求字节 | 状态 |
|---|---|---|---|---|---|---|---|---|
| D:\PTC\Pro_Stds-D\00_config-12\config.pro | 23636 | 1 | 4 | 16384 | 1 | 0 | 0 | 0x0 |
| 安装目录 Common Files\text\config.pro | 23636 | 1 | 3 | 12288 | 2,907 | 0 | 0 | 0x0 |
| C:\Users\DELL\config.pro | 23636 | 5 | 2 | 12,288 | 421,872（完成量配对待核） | 0 | 0 | 0xC0000034（探测未找到）, 0x0 |
| Roaming\...\creo_parametric_customization.ui | 23636 | 14 | 11 | 421,888 | 491,324 | 12 | 100,486 | 0x80000005, 0xC0000011, 0x0 |
| Temp\d829u7mh.ui（临时布局） | 23636 | 6 | 10 | 565,248 | 189,440 | 4 | 1,067,852 | 0x80000005, 0xC0000034, 0x0 |

Roaming `.ui` 会话内观测到 12 条写请求、Temp `.ui` 4 条写请求；采集后基线哈希零差异只证明最终内容一致，**不能证明期间无写入或写后被恢复**。这些写是否持久化改变 `.ui`，需以最终文件哈希与写完成状态为准，现有观测不判定其持久化结果。

## 5. 文件访问层判定

1. **以下"文件层已排除资源读取/加载差异"的旧结论予以撤回**：DAT、config/.ui、DLL 的请求-完成配对、请求/完成上下文 PID 区分尚未验收；在完成事件链重放复核前，不能据此判定这些对象的读取或加载环节已排除差异。
2. 已观测到的事实：三条消息 .txt 已完成候选配对复核（见 4.1），均有路径明确的打开、读请求与成功读完成候选，不支持"Body 文件完全没被读取"；两 DAT、config.pro、Roaming/Temp `.ui` 的打开/读/写请求计数与 IOSize 请求缓冲见 4.2–4.4；标准位置 DAT 探测返回 `0xC0000034`。消息文件复核仍受未配对读请求、IRP/句柄复用与丢事件缺口约束，不证明 GUI 解析成功。
3. 会话内观测到对 Roaming/Temp `.ui` 的写请求；基线哈希零差异只证明最终内容一致，不判定这些写是否持久化。**旧"写入全部属于平台缓存"的结论一并撤回**：写请求的去向与完成状态待事件链复核，不预先归类为缓存。
4. R10 DLL 读取/加载结论待事件链重放复核（见 4.3），本轮不据此定稿。
5. 文件访问观测本身无法下钻到 Creo 内部命令注册 → UI 列表筛选环节；该层结论以 R10 探针事实为准，不与文件访问层判定互相替代。

## 6. 状态码口径与未解码缺口

| 状态码 | 含义（MS-ERREF/MS-SMB 官方定义） |
|---|---|
| 0x0 | STATUS_SUCCESS |
| 0xC0000011 | STATUS_END_OF_FILE（缓冲读到末尾） |
| 0xC0000034 | STATUS_OBJECT_NAME_NOT_FOUND（路径探测未找到） |
| 0xC000003A | STATUS_OBJECT_PATH_NOT_FOUND（未逐项复核，不据此下结论） |
| 0xC0000010 | STATUS_INVALID_DEVICE_REQUEST |
| 0xC0000120 | STATUS_CANCELLED（本次采集分布未出现） |
| 0x80000005 | **STATUS_BUFFER_OVERFLOW**（数据过大装不下缓冲/枚举缓冲被填满；非"枚举结束"，不能直接判加载失败，需结合操作解释） |
| 0x80000006 | STATUS_NO_MORE_FILES（文件枚举无更多匹配项） |
| 0xC000000F、0x216、0xC01C0004、0xC000000D | 未逐项解码，不据此下结论 |

未解码缺口：IOFlags 位定义未逐项解码；InfoClass 数值到查询类型未建表；CSV 与 XML 的 PID 列口径存在偏移风险，XML 关联以 Execution/ProcessID 为准。时间戳本地偏移记为 `+07:59`（北京应为 `+08:00`），待核对 ETL 时钟源与 tracerpt 时区转换；正式采集丢事件计数（EventsLost/BuffersLost）尚未从 `formal.etl` 会话头读取，校准采集的零丢事件不外推到正式采集。

## 7. 下一步建议

- **撤回"文件访问层已排除资源读取/加载差异"的表述**：先完成操作级事件链（打开→读请求→对应完成→关闭）重放与配对验收，再决定文件层是否可排除；在此之前，body/fc 不可见的根因方向仅作为待验证假设，收敛到 Creo 内部命令注册后向 TOOLKIT 命令列表的筛选/暴露规则。
- 若离线静态复核仍无法解释，按既定边界整理最小复现包（版本、两 DAT、消息资源哈希、三层返回码、探针 jsonl、截图、本次观测证据）向 PTC 核查"Designate 成功但 TOOLKIT 列表缺项"；不再堆叠 Find/Access 探针。

## 8. 产物与证据索引

- 机读结果：`runtime-r11\formal-file-access.json`（族 PID、候选文件、消息/DAT 命中、写命中、目录前缀）
- 进程/事件抽样：`runtime-r11\formal-xml-probe.json`；CSV 初筛：`formal-csv-firstpass.json`
- 启停状态：`formal-start.json`、`formal-stop.json`；基线：`r11-preformal-baseline.json`、`r11-postformal-baseline.json`
- 原始证据：`formal.etl`（保留）；`calibrate.etl`（校准门原始证据，保留）
- 回收站清理记录：`purge-r11-scan.json`（扫描匹配）、`purge-r11-purge.json`（永久清除三对 $I/$R，failed=0）
- 已永久清除的可再生产物：`formal.xml`、`formal.csv`、`formal-target-files.json`（回收站 $I/$R 对已删，空间已释放）

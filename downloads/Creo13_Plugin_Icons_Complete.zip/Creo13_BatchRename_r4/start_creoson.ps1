﻿# 启动既有 CREOSON 发行脚本，实际检查 HTTP 和 Creo 会话，不改服务器 JAR。
[CmdletBinding()]
param(
    [string]$CreosonDir = 'D:\creoson\CreosonServerWithSetup-2.8.2-win64',
    [string]$ServerJdk = 'D:\creoson\jdk25\jdk-25.0.5+8',
    [ValidateRange(1,65535)][int]$Port = 9056,
    [ValidateRange(3,120)][int]$WaitSeconds = 30
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$base = 'http://localhost:' + $Port
function Has-Listener {
    return @([Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners() | Where-Object { $_.Port -eq $Port }).Count -gt 0
}
function Api([string]$Command, [string]$Function, [string]$Id = '') {
    $body = @{sessionId=$Id;command=$Command;function=$Function;data=@{}} | ConvertTo-Json -Compress
    $result = Invoke-RestMethod -Uri ($base + '/creoson') -Method Post -ContentType 'application/json' -Body $body -TimeoutSec 5
    if (-not $result.status -or $result.status.error -isnot [bool]) { throw '此端口未返回有效 CREOSON 状态，可能被其他程序占用。' }
    if ($result.status.error) { throw ([string]$result.status.message) }
    return $result
}
try {
    if (Has-Listener) {
        Write-Host ('端口 ' + $Port + ' 已监听，正在核对是否为可用 CREOSON。')
    } else {
        $runner = Join-Path $CreosonDir 'creoson_run.bat'
        if (-not (Test-Path -LiteralPath $runner -PathType Leaf)) { throw ('找不到发行启动脚本：' + $runner) }
        if (-not (Test-Path -LiteralPath (Join-Path $CreosonDir 'setvars.bat') -PathType Leaf)) { throw '缺少 setvars.bat，请先运行发行包 CreosonSetup.exe。' }
        if (-not (Test-Path -LiteralPath (Join-Path $ServerJdk 'bin\java.exe') -PathType Leaf)) { throw ('找不到服务端 Java：' + $ServerJdk) }
        $env:JAVA_HOME = $ServerJdk
        # setvars.bat 可能覆盖 JAVA_HOME/JSON_PORT；不自动改写它，最终以健康检查结果为准。
        $outLog = Join-Path $CreosonDir 'batchrename_server_stdout.log'
        $errLog = Join-Path $CreosonDir 'batchrename_server_stderr.log'
        $process = Start-Process -FilePath $env:ComSpec -ArgumentList @('/d','/c','creoson_run.bat') -WorkingDirectory $CreosonDir -RedirectStandardOutput $outLog -RedirectStandardError $errLog -PassThru -WindowStyle Minimized
        Write-Host ('已发出服务启动请求，进程 PID=' + $process.Id)
        $limit = (Get-Date).AddSeconds($WaitSeconds)
        while (-not (Has-Listener)) {
            if ((Get-Date) -ge $limit) { throw ('等待端口超时，请查看：' + $errLog) }
            $process.Refresh()
            if ($process.HasExited) { throw ('服务启动器已退出，请查看：' + $errLog) }
            Start-Sleep -Milliseconds 500
        }
    }
    # TCP 监听后 HTTP 路由仍可能未初始化。先等待必需的页面就绪，再连接一次会话。
    # HTTP GET 可重试；不循环创建 connection/connect 会话。
    $httpLimit = (Get-Date).AddSeconds($WaitSeconds)
    while ($true) {
        try {
            $page = Invoke-WebRequest -UseBasicParsing -Uri ($base + '/rename.html') -TimeoutSec 5
            if ($page.StatusCode -ne 200 -or $page.Content -notmatch 'id="executeBtn"' -or $page.Content -notmatch 'onlysession: true') {
                throw 'rename.html 不是预期的会话改名页面，请检查部署路径。'
            }
            break
        } catch {
            if ((Get-Date) -ge $httpLimit) { throw ('改名页面未就绪：' + $_.Exception.Message) }
            Start-Sleep -Milliseconds 500
        }
    }
    # 监听不等于 CREOSON 可用；实际 POST 验证服务器及 Creo 连接。
    $connect = Api 'connection' 'connect'
    $id = [string]$connect.sessionId
    if (-not $id) { throw 'CREOSON 未返回 sessionId。' }
    try {
        $files = Api 'file' 'list' $id
        if (-not $files.data -or -not ($files.data.PSObject.Properties.Name -contains 'files') -or $files.data.files -isnot [array] -or @($files.data.files | Where-Object { $_ -isnot [string] }).Count -gt 0) { throw 'Creo 文件列表返回异常。' }
        Write-Host '验证通过：CREOSON API 可用，Creo 会话查询成功。'
        Write-Host ('页面已验证：' + $base + '/rename.html')
    } finally {
        try { $null = Api 'connection' 'disconnect' $id } catch { Write-Warning '验证会话未能断开；未关闭 Creo 或服务器。' }
    }
    exit 0
} catch {
    Write-Error -ErrorAction Continue $_
    Write-Host '未确认服务可用。请先打开 Creo，检查发行包 setvars.bat、Java 与 J-Link 原生库路径。'
    Write-Host '若端口属于其他进程，本脚本不会终止该进程，也不会再启动一个重复服务器。'
    exit 1
}

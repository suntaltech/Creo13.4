﻿# Windows PowerShell 5.1；仅部署本插件，保留其他插件和配置。
[CmdletBinding()]
param(
    [string]$CreoCommon = 'D:\Program Files\PTC\Creo 13.4.0.0\Common Files',
    [string]$PluginDir = 'D:\creoson\jlink',
    [string]$CreosonDir = 'D:\creoson\CreosonServerWithSetup-2.8.2-win64',
    [string]$ConfigPath = '',
    [string]$CompilerJdk = '',
    [string]$JlinkJava = '',
    [switch]$ManualStart
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Read-PreservedText([string]$Path) {
    $bytes = [IO.File]::ReadAllBytes($Path)
    $offset = 0
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 239 -and $bytes[1] -eq 187 -and $bytes[2] -eq 191) {
        $encoding = New-Object Text.UTF8Encoding($true); $offset = 3
    } elseif ($bytes.Length -ge 2 -and $bytes[0] -eq 255 -and $bytes[1] -eq 254) {
        $encoding = [Text.Encoding]::Unicode; $offset = 2
    } elseif ($bytes.Length -ge 2 -and $bytes[0] -eq 254 -and $bytes[1] -eq 255) {
        $encoding = [Text.Encoding]::BigEndianUnicode; $offset = 2
    } else {
        $strictUtf8 = New-Object Text.UTF8Encoding($false, $true)
        try { $null = $strictUtf8.GetString($bytes); $encoding = New-Object Text.UTF8Encoding($false) }
        catch { $encoding = [Text.Encoding]::GetEncoding([Globalization.CultureInfo]::CurrentCulture.TextInfo.ANSICodePage) }
    }
    return @{ Text = $encoding.GetString($bytes, $offset, $bytes.Length - $offset); Encoding = $encoding }
}
function Ensure-Backup([string]$Path) {
    if (Test-Path -LiteralPath $Path) {
        $backup = $Path + '.batchrename.' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.' + [guid]::NewGuid().ToString('N').Substring(0, 8) + '.bak'
        Copy-Item -LiteralPath $Path -Destination $backup -Recurse
        Write-Host ('已备份：' + $backup)
    }
}
try {
    if ([IO.Path]::GetFullPath($PluginDir).TrimEnd('\') -eq [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')) {
        throw '请将交付包解压到独立目录后安装；不要在已部署 PluginDir 内原地编译覆盖，以便保留旧 class 备份。'
    }
    if (-not $ConfigPath) { $ConfigPath = Join-Path $CreoCommon 'text\config.pro' }
    if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) { throw ('找不到 config.pro：' + $ConfigPath) }
    if (-not (Test-Path -LiteralPath (Join-Path $CreosonDir 'web') -PathType Container)) { throw ('找不到 CREOSON web 目录：' + $CreosonDir) }
    if (-not $CompilerJdk) {
        if ($env:CREO_BR_JDK) { $CompilerJdk = $env:CREO_BR_JDK }
        elseif (Test-Path -LiteralPath 'D:\creoson\jdk25\jdk-25.0.5+8\bin\javac.exe') { $CompilerJdk = 'D:\creoson\jdk25\jdk-25.0.5+8' }
    }
    if ($CompilerJdk -and -not (Test-Path -LiteralPath (Join-Path $CompilerJdk 'bin\javac.exe'))) { throw 'CompilerJdk 不是有效的 JDK 目录。' }
    if ($JlinkJava -and -not (Test-Path -LiteralPath $JlinkJava -PathType Leaf)) { throw 'JlinkJava 指向的 java.exe 不存在。' }
    # 先在解压目录对真实 SDK 编译，通过后才写 Creo 配置。
    $env:CREO_BR_COMMON = $CreoCommon
    if ($CompilerJdk) { $env:CREO_BR_JDK = $CompilerJdk }
    & (Join-Path $PSScriptRoot 'build.cmd')
    if ($LASTEXITCODE -ne 0) { throw '真实 SDK 编译失败；尚未修改 config.pro，请查看 build.log。' }
    foreach ($class in @('BatchRename.class', 'BatchRename$OpenPageListener.class', 'BatchRenameSmoke.class')) {
        if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot ('classes\' + $class)))) { throw ('编译输出不完整：' + $class) }
    }
    $settings = Read-PreservedText $ConfigPath
    Ensure-Backup $ConfigPath
    New-Item -ItemType Directory -Force -Path $PluginDir | Out-Null
    # 更新既有安装前保留将被覆盖的源码、类、资源和注册文件；包括自定义 RBN。
    foreach ($name in @('BatchRename.java','BatchRenameSmoke.java','build.cmd','classes','text','batchrename.dat','batchrename_manual.dat','smoke.dat')) {
        Ensure-Backup (Join-Path $PluginDir $name)
    }
    if ([IO.Path]::GetFullPath($PluginDir).TrimEnd('\') -ne [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')) {
        foreach ($name in @('BatchRename.java','BatchRenameSmoke.java','build.cmd','classes','text')) {
            Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination $PluginDir -Force -Recurse
        }
    }
    # 无论目标目录如何设置，都生成与实际路径一致的注册项。
    foreach ($item in @(@('batchrename.dat','BatchRename','false'),@('batchrename_manual.dat','BatchRename','true'),@('smoke.dat','BatchRenameSmoke','true'))) {
        $className = $item[1]
        $name = if ($className -eq 'BatchRenameSmoke') { 'sisw_batchrename_smoke' } else { 'sisw_batchrename' }
        $dat = @("name $name",'startup java',"java_app_class $className",("java_app_classpath " + (Join-Path $PluginDir 'classes')),'java_app_start start','java_app_stop stop','allow_stop true',("delay_start " + $item[2]),("text_dir " + (Join-Path $PluginDir 'text')),'end')
        [IO.File]::WriteAllLines((Join-Path $PluginDir $item[0]), $dat, (New-Object Text.UTF8Encoding($false)))
    }
    $webTarget = Join-Path $CreosonDir 'web\rename.html'
    Ensure-Backup $webTarget
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'web\rename.html') -Destination $webTarget -Force

    $newline = if ($settings.Text.Contains("`r`n")) { "`r`n" } else { "`n" }
    $lines = New-Object 'Collections.Generic.List[string]'
    $oldPaths = @((Join-Path $PluginDir 'batchrename.dat'),(Join-Path $PluginDir 'batchrename_manual.dat'),(Join-Path $PluginDir 'smoke.dat'), 'D:\creoson\jlink\batchrename.dat')
    foreach ($line in [regex]::Split($settings.Text, '\r?\n')) {
        $trimmed = $line.Trim()
        if ($trimmed -eq '! BatchRename native J-Link registration') { continue }
        if ($trimmed -match '^(?i:protkdat)\s+(.+?)\s*$') {
            $value = $Matches[1].Trim().Trim('"')
            if ($oldPaths -contains $value) { continue }
        }
        if ($trimmed -eq 'browser_homepage http://localhost:9056/rename.html') { continue }
        if ($trimmed -eq 'mapkey rename @MAPKEY_NAME批量重命名;~Command `ProCmdBrowser`;') { continue }
        # 仅用户显式指定同步 JVM 时才更换已有全局 JVM 配置。
        if ($JlinkJava -and $trimmed -match '^(?i:jlink_java_command)\s+') { continue }
        $lines.Add($line)
    }
    $registration = if ($ManualStart) { 'batchrename_manual.dat' } else { 'batchrename.dat' }
    $lines.Add('! BatchRename native J-Link registration')
    $lines.Add('protkdat ' + (Join-Path $PluginDir $registration))
    if ($JlinkJava) { $lines.Add('jlink_java_command ' + $JlinkJava) }
    $newText = ($lines -join $newline).TrimEnd("`r", "`n") + $newline
    # 同目录临时文件写入后原子替换；失败时原 config.pro 保留，备份亦保留。
    $temporary = $ConfigPath + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    try {
        [IO.File]::WriteAllText($temporary, $newText, $settings.Encoding)
        [IO.File]::Replace($temporary, $ConfigPath, $null)
    } finally {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force }
    }
    Write-Host '安装完成：已部署原生 J-Link 注册项，没有添加 mapkey。'
    Write-Host ('页面：' + $webTarget)
    Write-Host '请重启 Creo。首次还需在自定义功能区放置 TOOLKIT 命令并导出 toolkitribbonui.rbn。'
    if (-not $JlinkJava) { Write-Host '未改动全局 jlink_java_command；请核对现有同步 JVM 是否受 Creo 13.4 支持。' }
    exit 0
} catch {
    Write-Error -ErrorAction Continue $_
    Write-Host '安装没有完整成功。若为 Program Files 写入权限不足，可在具备权限的终端重试；配置备份已保留。'
    exit 1
}

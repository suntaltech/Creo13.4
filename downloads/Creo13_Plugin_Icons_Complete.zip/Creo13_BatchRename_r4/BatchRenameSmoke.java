import com.ptc.pfc.pfcSession.CreoCompatibility;
import com.ptc.pfc.pfcSession.pfcSession;

/** 最小同步加载探针；不注册按钮，不访问浏览器或 CREOSON。 */
public final class BatchRenameSmoke {
    public static void start() throws Exception {
        System.err.println("[BatchRenameSmoke] start java=" + System.getProperty("java.version"));
        if (pfcSession.GetCurrentSessionWithCompatibility(CreoCompatibility.C4Compatible) == null) {
            throw new IllegalStateException("No synchronous Creo session");
        }
        System.err.println("[BatchRenameSmoke] synchronous session OK; start returned");
    }
    public static void stop() {
        System.err.println("[BatchRenameSmoke] stop returned");
    }
}

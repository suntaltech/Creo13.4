"""跨平台交付文件哈希校验；不执行插件，不修改 Creo 配置。"""
from pathlib import Path
import hashlib
import json
import sys


def main():
    root = Path(__file__).resolve().parent.parent
    manifest = json.loads((root / 'manifest.json').read_text(encoding='utf-8'))
    failures = []
    for item in manifest['files']:
        path = (root / item['path']).resolve()
        if root != path and root not in path.parents:
            failures.append({'path': item['path'], 'reason': 'path outside package'})
            continue
        if not path.is_file():
            failures.append({'path': item['path'], 'reason': 'missing'})
            continue
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != item['sha256'] or len(data) != item['bytes']:
            failures.append({'path': item['path'], 'reason': 'hash or size mismatch'})
    result = {'package_version': manifest['version'], 'checked': len(manifest['files']),
              'failures': failures, 'passed': not failures,
              'creo_test': 'not_run', 'sdk_compile': 'not_run'}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return int(bool(failures))


if __name__ == '__main__':
    raise SystemExit(main())

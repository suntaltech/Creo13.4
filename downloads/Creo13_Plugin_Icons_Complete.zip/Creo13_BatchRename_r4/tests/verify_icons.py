"""Read-only structural checks for the deployed 16-colour Windows BMP icons."""
from pathlib import Path
import hashlib
import json
import struct
import sys

STANDARD16 = {bytes.fromhex(c) for c in (
    '000000', '800000', '008000', '808000', '000080', '800080', '008080', 'C0C0C0',
    '808080', 'FF0000', '00FF00', 'FFFF00', '0000FF', 'FF00FF', '00FFFF', 'FFFFFF')}

def validate(path, size):
    data = path.read_bytes()
    assert data[:2] == b'BM', 'not a BMP'
    assert struct.unpack_from('<I', data, 2)[0] == len(data), 'wrong file size'
    offset = struct.unpack_from('<I', data, 10)[0]
    header, width, height, planes, bpp, compression, image_bytes, _, _, used, important = struct.unpack_from('<IiiHHIIiiII', data, 14)
    assert (header, width, height, planes) == (40, size, size, 1), 'wrong DIB header or dimensions'
    assert bpp == 4, f'expected 4-bit indexed BMP, got {bpp}-bit'
    assert compression == 0, 'compressed bitmap'
    assert used == 16 and important in (0,16), 'expected 16 palette entries'
    assert offset == 14 + 40 + 16 * 4, 'wrong palette/pixel offset'
    palette = {bytes((data[i+2], data[i+1], data[i])) for i in range(54, offset, 4)}
    assert palette == STANDARD16, 'palette is not the standard Windows 16 colours'
    assert all(data[i+3] == 0 for i in range(54, offset, 4)), 'palette reserved byte must be zero'
    stride = ((size * 4 + 31) // 32) * 4
    assert image_bytes == stride * size and len(data) == offset + stride * size, 'wrong scanline size/padding'
    return {'file':str(path), 'width':width, 'height':height, 'bits_per_pixel':bpp,
            'compression':compression, 'palette_entries':used, 'palette':'Windows standard 16 colours',
            'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest()}

if __name__ == '__main__':
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent
    results = [validate(root/'text/resource'/name,size) for name,size in
               [('batchrename.bmp',32),('batchrename_16.bmp',16)]]
    print(json.dumps({'passed':True,'checks':results,'creo_visual_test':'not_run'},indent=2))

// Node VM + DOM/HTTP 替身测试，不替代 Creo 内嵌浏览器实测。
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(process.env.CREO_REVIEW_PAGE || require('node:path').join(__dirname, '../web/rename.html'),'utf8').match(/<script>([\s\S]*?)<\/script>/)[1];
class Element {
  constructor() { this.style={}; this.dataset={}; this.children=[]; this.value=''; this.checked=false; this.disabled=false; this.textContent=''; }
  appendChild(child) { this.children.push(child); }
  replaceChildren() { this.children=[]; }
  setAttribute() {} addEventListener() {} remove() {} click() {}
}
function setup() {
  const ids={};
  for(const id of ['mode','prefix','suffix','startNum','digits','onlyPrt','rowPrefix','rowSuffix','status','tree','previewBtn','executeBtn','connectBtn','logBtn']) ids[id]=new Element();
  Object.assign(ids.mode,{value:'prefix'}); ids.prefix.value='VAL_';ids.suffix.value='_NEW';ids.startNum.value='1';ids.digits.value='3';ids.onlyPrt.checked=true;
  const files=['ROOT.ASM','A.PRT','SUB.ASM','B.PRT'];
  let active='ROOT.ASM'; const payloads=[];
  const bom=()=>({file:active,children:{file:active,children:[{file:files.find(f=>f==='A.PRT')||'VAL_001.PRT',path:[10]},
    {file:'SUB.ASM',path:[20],children:[{file:files.find(f=>f==='B.PRT')||'VAL_002.PRT',path:[20,30]},
    {file:files.find(f=>f==='A.PRT')||'VAL_001.PRT',path:[20,40]}]}]}});
  const context=vm.createContext({document:{getElementById:id=>ids[id],createElement:()=>new Element(),querySelectorAll:()=>[],body:new Element()},
    console,AbortController,setTimeout,clearTimeout,Blob,URL,confirm:()=>true,
    fetch:async(_,options)=>{
      const request=JSON.parse(options.body);payloads.push(request);let data={};
      if(request.function==='connect')return {ok:true,json:async()=>({status:{error:false},sessionId:'session'})};
      if(request.function==='get_active')data={file:active};
      if(request.function==='get_paths')data=bom();
      if(request.function==='list')data={files:[...files]};
      if(request.function==='rename') {assert.equal(request.data.onlysession,true);files[files.indexOf(request.data.file.toUpperCase())]=request.data.new_name.toUpperCase();data={file:request.data.new_name};}
      return {ok:true,json:async()=>({status:{error:false},data})};
    }});
  vm.runInContext(source,context);
  return {context,ids,files,payloads,setActive:value=>{active=value;}};
}
let passed=0;
async function test(name,fn){await fn();console.log('OK '+name);passed++;}
(async()=>{
 await test('BOM root excluded, DFS and repeated model deduplicated',async()=>{
  const t=setup();await vm.runInContext('preview()',t.context);
  assert.equal(vm.runInContext('rows.map(r=>r.oldName).join(",")',t.context),'A.PRT,B.PRT');
  assert.equal(vm.runInContext('rows[0].newName',t.context),'VAL_001.PRT');
 });
 await test('all descendants includes subassembly, excludes root',async()=>{
  const t=setup();t.ids.onlyPrt.checked=false;await vm.runInContext('preview()',t.context);
  assert.equal(vm.runInContext('rows.map(r=>r.oldName).join(",")',t.context),'A.PRT,SUB.ASM,B.PRT');
 });
 await test('suffix mode preserves original base',async()=>{
  const t=setup();t.ids.mode.value='suffix';await vm.runInContext('preview()',t.context);
  assert.equal(vm.runInContext('rows[0].newName',t.context),'A_NEW.PRT');
 });
 await test('both mode',async()=>{
  const t=setup();t.ids.mode.value='both';await vm.runInContext('preview()',t.context);
  assert.equal(vm.runInContext('rows[0].newName',t.context),'VAL_001_NEW.PRT');
 });
 await test('start zero is preserved',async()=>{
  const t=setup();t.ids.startNum.value='0';await vm.runInContext('preview()',t.context);
  assert.equal(vm.runInContext('rows[0].newName',t.context),'VAL_000.PRT');
 });
 await test('invalid integer rejects preview',async()=>{
  const t=setup();t.ids.startNum.value='1.2';await vm.runInContext('preview()',t.context);
  assert.equal(vm.runInContext('plan',t.context),null);
 });
 await test('digit overflow is excluded',async()=>{
  const t=setup();t.ids.startNum.value='999';await vm.runInContext('preview()',t.context);
  assert.equal(vm.runInContext('rows[1].included',t.context),false);
 });
 await test('case-insensitive session conflict excluded',async()=>{
  const t=setup();t.files.push('val_001.prt');await vm.runInContext('preview()',t.context);
  assert.equal(vm.runInContext('rows[0].included',t.context),false);
 });
 await test('preview targets frozen and single-use execution',async()=>{
  const t=setup();await vm.runInContext('preview()',t.context);t.ids.prefix.value='CHANGED_';
  await vm.runInContext('execute()',t.context);await vm.runInContext('execute()',t.context);
  const rename=t.payloads.filter(p=>p.function==='rename');
  assert.equal(rename.length,2);assert.equal(rename[0].data.new_name,'VAL_001.PRT');
  assert.equal(vm.runInContext('plan',t.context),null);
 });
 await test('excluded row keeps later numbering',async()=>{
  const t=setup();await vm.runInContext('preview()',t.context);vm.runInContext('rows[0].included=false',t.context);
  await vm.runInContext('execute()',t.context);
  assert.equal(t.payloads.find(p=>p.function==='rename').data.new_name,'VAL_002.PRT');
 });
 await test('changed active assembly prevents writes',async()=>{
  const t=setup();await vm.runInContext('preview()',t.context);t.setActive('OTHER.ASM');await vm.runInContext('execute()',t.context);
  assert.equal(t.payloads.filter(p=>p.function==='rename').length,0);
 });
 await test('communication loss stops further writes and marks uncertain',async()=>{
  const t=setup();await vm.runInContext('preview()',t.context);
  const real=t.context.fetch;t.context.fetch=async(u,o)=>{if(JSON.parse(o.body).function==='rename')throw new Error('network lost');return real(u,o);};
  await vm.runInContext('execute()',t.context);
  assert.equal(vm.runInContext('rows[0].state',t.context),'待核查');
  assert.equal(vm.runInContext('rows[1].state',t.context),'未执行');
 });
 await test('invalid connection response does not create session',async()=>{
  const t=setup();t.context.fetch=async()=>({ok:true,json:async()=>({status:{error:true,message:'no Creo'}})});
  await vm.runInContext('connect()',t.context);assert.equal(vm.runInContext('sessionId',t.context),'');
 });
 await test('busy guard rejects duplicate submissions',async()=>{
  const t=setup();await vm.runInContext('preview()',t.context);await Promise.all([vm.runInContext('execute()',t.context),vm.runInContext('execute()',t.context)]);
  assert.equal(t.payloads.filter(p=>p.function==='rename').length,2);
 });

 for (const failure of ['malformed-list', 'list-business-error', 'rename-business-error']) {
  await test(`post-dispatch ${failure} stops batch as uncertain`,async()=>{
   const t=setup();await vm.runInContext('preview()',t.context);
   const real=t.context.fetch;let dispatched=false;let injected=false;
   t.context.fetch=async(u,o)=>{
    const request=JSON.parse(o.body);
    const response=await real(u,o);
    if(request.function==='rename') {
     dispatched=true;
     if(failure==='rename-business-error') return {ok:true,json:async()=>({status:{error:true,message:'rename failed after side effect'}})};
    }
    if(dispatched && request.function==='list' && !injected) {
     injected=true;
     if(failure==='malformed-list') return {ok:true,json:async()=>({status:{error:false},data:{files:null}})};
     if(failure==='list-business-error') return {ok:true,json:async()=>({status:{error:true,message:'session query failed'}})};
    }
    return response;
   };
   await vm.runInContext('execute()',t.context);
   assert.equal(t.payloads.filter(p=>p.function==='rename').length,1);
   assert.equal(vm.runInContext('rows[0].state',t.context),'待核查');
   assert.equal(vm.runInContext('rows[1].state',t.context),'未执行');
   assert.equal(vm.runInContext('plan',t.context),null);
   assert.equal(vm.runInContext('events.some(e=>e.event==="uncertain")',t.context),true);
  });
 }
 await test('BOM change in same active assembly prevents writes',async()=>{
  const t=setup();await vm.runInContext('preview()',t.context);
  const real=t.context.fetch;t.context.fetch=async(u,o)=>{
   if(JSON.parse(o.body).function==='get_paths')return {ok:true,json:async()=>({status:{error:false},data:{children:{file:'ROOT.ASM',children:[{file:'OTHER.PRT'}]}}})};
   return real(u,o);
  };
  await vm.runInContext('execute()',t.context);
  assert.equal(t.payloads.filter(p=>p.function==='rename').length,0);
 });
 await test('target introduced after preview is skipped',async()=>{
  const t=setup();await vm.runInContext('preview()',t.context);t.files.push('val_001.prt');
  await vm.runInContext('execute()',t.context);
  const renames=t.payloads.filter(p=>p.function==='rename');
  assert.equal(renames.length,1);assert.equal(renames[0].data.file,'B.PRT');
  assert.equal(vm.runInContext('rows[0].state',t.context),'跳过');
 });
 await test('cancel confirmation issues no requests and retains plan',async()=>{
  const t=setup();await vm.runInContext('preview()',t.context);
  const before=t.payloads.length;t.context.confirm=()=>false;
  await vm.runInContext('execute()',t.context);
  assert.equal(t.payloads.length,before);assert.notEqual(vm.runInContext('plan',t.context),null);
 });
 console.log(`PASS ${passed} page tests`);
})().catch(error=>{console.error(error);process.exitCode=1;});

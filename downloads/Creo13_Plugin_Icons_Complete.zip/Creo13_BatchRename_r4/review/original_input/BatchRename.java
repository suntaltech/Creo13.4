import com.ptc.pfc.pfcCommand.DefaultUICommandActionListener;
import com.ptc.pfc.pfcCommand.UICommand;
import com.ptc.pfc.pfcSession.CreoCompatibility;
import com.ptc.pfc.pfcSession.Session;
import com.ptc.pfc.pfcSession.pfcSession;
import com.ptc.pfc.pfcWindow.Window;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.Instant;

/**
 * Creo 13 同步 J-Link 入口：只注册原生命令并打开已有页面。
 * 不创建 AsyncConnection，不请求 CREOSON，不在回调中等待网络或启动子进程。
 * 必须使用本机 Creo 13 的同步 SDK archive 编译，不混入 pfcasync.jar。
 */
public final class BatchRename {
    private static final String COMMAND = "SISWBatchRename";
    private static final String MESSAGES = "batchrename.txt";
    private static final String PAGE = "http://localhost:9056/rename.html";
    private static Session session;
    private static UICommand command;
    // 保持强引用，避免回调对象在插件生命周期内被回收。
    private static OpenPageListener listener;
    private static boolean active;
    private static boolean opening;

    private BatchRename() { }

    /** 同步注册入口必须是 public static void 且无参数。 */
    public static void start() throws Exception {
        if (active) {
            log("start ignored: already active", null);
            return;
        }
        if (listener != null) {
            throw new IllegalStateException("Previous listener detach failed; restart Creo before reloading");
        }
        log("start entered; java=" + System.getProperty("java.version"), null);
        try {
            // 显式设置兼容性，避免先用 GetProESession() 进入旧的 C3 兼容模式。
            session = pfcSession.GetCurrentSessionWithCompatibility(CreoCompatibility.C4Compatible);
            if (session == null) {
                throw new IllegalStateException("No synchronous Creo session");
            }
            log("synchronous session acquired", null);
            ensureCreosonRunning();
            listener = new OpenPageListener();
            command = session.UICreateCommand(COMMAND, listener);
            log("native command registered", null);
            command.Designate(MESSAGES, "SISW_BR_LABEL", "SISW_BR_HELP", "SISW_BR_DESC");
            active = true;
            log("command designated", null);
            log("start returned", null);
            // 不调用已弃用的 UIAddButton/UIAddMenu，也不在此打开浏览器。
            // 功能区位置由首次自定义导出的 .rbn 或用户现有 Ribbon 配置负责。
        } catch (Exception ex) {
            log("start failed", ex);
            detach();
            throw ex; // 让辅助应用程序显示真正的加载错误，而不是伪报启动成功。
        } catch (LinkageError ex) {
            log("JAR/class version or linkage error", ex);
            detach();
            throw ex;
        }
    }

    /** 停止时只解除回调，不退出 Creo，不关闭浏览器，不修改模型。 */
    public static void stop() {
        log("stop entered", null);
        active = false;
        detach();
        log("stop returned", null);
    }

    private static void ensureCreosonRunning() {
        try {
            java.net.Socket s = new java.net.Socket();
            s.connect(new java.net.InetSocketAddress("localhost", 9056), 1000);
            s.close();
            log("CREOSON already running on 9056", null);
            return;
        } catch (Exception e) {
            log("CREOSON not running, starting...", null);
        }
        try {
            ProcessBuilder pb = new ProcessBuilder(
                "cmd.exe", "/c", "D:\\creoson\\CreosonServerWithSetup-2.8.2-win64\\creoson_run.bat");
            pb.directory(new java.io.File("D:\\creoson\\CreosonServerWithSetup-2.8.2-win64"));
            pb.inheritIO().redirectOutput(ProcessBuilder.Redirect.DISCARD);
            pb.redirectError(ProcessBuilder.Redirect.DISCARD);
            Process p = pb.start();
            log("CREOSON started, pid=" + p.pid(), null);
            for (int i = 0; i < 20; i++) {
                Thread.sleep(1000);
                try {
                    java.net.Socket s = new java.net.Socket();
                    s.connect(new java.net.InetSocketAddress("localhost", 9056), 1000);
                    s.close();
                    log("CREOSON ready after " + (i+1) + "s", null);
                    return;
                } catch (Exception ignored) {}
            }
            log("CREOSON did not become ready in 20s", null);
        } catch (Exception e) {
            log("Failed to start CREOSON", e);
        }
    }

    private static void detach() {
        active = false;
        if (command != null && listener != null) {
            try {
                command.RemoveActionListener(listener);
                listener = null;
            } catch (Exception ex) {
                log("listener detach failed; restart Creo before reloading", ex);
                // 保留引用以便诊断；该回调受 active=false 保护。
            }
        }
        session = null;
    }

    /** 原生回调只发出浏览器导航，随后立即把控制权交回 Creo。 */
    private static final class OpenPageListener extends DefaultUICommandActionListener {
        @Override
        public void OnCommand() {
            if (!active || opening || session == null) {
                return;
            }
            opening = true;
            log("OnCommand entered", null);
            try {
                Window window = session.GetCurrentWindow();
                if (window == null) {
                    log("No current window; open a model window first", null);
                    return;
                }
                window.SetURL(PAGE);
                window.SetBrowserSize(80.0);
                log("browser navigation issued; OnCommand returned", null);
            } catch (Exception ex) {
                log("open embedded browser failed", ex);
            } finally {
                opening = false;
            }
        }
    }

    /** 不调用任何 Creo API 的诊断日志；日志失败不影响退出回调。 */
    private static void log(String message, Throwable error) {
        String text = Instant.now() + " " + message + System.lineSeparator();
        if (error != null) {
            StringWriter buffer = new StringWriter();
            error.printStackTrace(new PrintWriter(buffer));
            text += buffer.toString();
        }
        System.err.print("[BatchRename] " + text);
        try {
            Path folder = Paths.get(System.getProperty("user.home"), "CreoBatchRename");
            Files.createDirectories(folder);
            Files.write(folder.resolve("jlink.log"), text.getBytes(StandardCharsets.UTF_8),
                        StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception ignored) {
            // System.err 仍可供 Creo/JVM 日志收集，不递归记录日志错误。
        }
    }
}

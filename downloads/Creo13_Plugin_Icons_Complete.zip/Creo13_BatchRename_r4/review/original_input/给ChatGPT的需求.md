# Creo J-Link 插件 - 添加图标需求

## 当前状态
已完成一个 Creo 13 J-Link 插件，功能是"批量重命名"。插件能在 Creo Ribbon 上显示按钮，点击后在内嵌浏览器打开 HTML 页面。

## 需要你做的
给 Ribbon 按钮加自定义图标。

## 相关文件
- `BatchRename.java` - J-Link 主程序，用 `command.Designate(MESSAGES, "SISW_BR_LABEL", "SISW_BR_HELP", "SISW_BR_DESC")` 注册命令
- `batchrename.dat` - 注册文件
- `text/batchrename.txt` - 中文文字资源
- 编译命令：`javac --release 17 -cp "otk.jar" -d classes BatchRename.java`

## 问题
当前按钮显示默认图标，需要自定义一个蓝色圆角图标（32x32 BMP），上面有白色"R"字。

## 要求
1. 修改 BatchRename.java，让命令使用自定义图标
2. 提供图标文件生成方式（或直接给 BMP）
3. 说明 .dat 文件或 text 目录需要什么配置
4. 编译后能用 `command.Designate()` 正常加载

## 技术环境
- Creo 13.4.0.0
- JDK 25 编译，`--release 17` 目标
- otk.jar（同步 J-Link SDK）
- Windows 11

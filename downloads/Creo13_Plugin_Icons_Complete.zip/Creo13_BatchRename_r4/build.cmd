@echo off
setlocal
cd /d "%~dp0"
rem 允许由环境变量提供本机 SDK 与 JDK；不自动更改系统 JAVA_HOME。
if not defined CREO_BR_COMMON set "CREO_BR_COMMON=D:\Program Files\PTC\Creo 13.4.0.0\Common Files"
rem Creo 13 官方同步安装测试使用 otk.jar；保留旧版 pfc.jar 回退。
set "CREO_BR_JAR=%CREO_BR_COMMON%\text\java\otk.jar"
if not exist "%CREO_BR_JAR%" set "CREO_BR_JAR=%CREO_BR_COMMON%\text\java\pfc.jar"
if not exist "%CREO_BR_JAR%" (
  echo ERROR: synchronous SDK otk.jar/pfc.jar not found: "%CREO_BR_JAR%"
  echo Install J-Link or set CREO_BR_COMMON. Do not substitute pfcasync.jar.
  exit /b 2
)
set "CREO_BR_JAVAC=javac.exe"
if defined CREO_BR_JDK set "CREO_BR_JAVAC=%CREO_BR_JDK%\bin\javac.exe"
if not exist classes mkdir classes
"%CREO_BR_JAVAC%" -version > build.log 2>&1
if errorlevel 1 (
  type build.log
  echo ERROR: javac.exe not found. Set CREO_BR_JDK to the verified local JDK path.
  exit /b 3
)
"%CREO_BR_JAVAC%" --release 17 -encoding UTF-8 -classpath "%CREO_BR_JAR%" -d classes BatchRename.java BatchRenameSmoke.java >> build.log 2>&1
if errorlevel 1 (
  type build.log
  echo BUILD FAILED. See build.log.
  exit /b 1
)
echo BUILD OK. Deploy the entire classes folder, including the listener class.
type build.log
endlocal

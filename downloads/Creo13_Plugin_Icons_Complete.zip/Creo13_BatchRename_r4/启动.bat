@echo off
chcp 65001 >nul
setlocal
title Creo 批量重命名 - 服务检查
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0start_creoson.ps1" %*
set "CREO_BR_EXIT=%errorlevel%"
if not "%CREO_BR_EXIT%"=="0" echo 操作失败，请查看上方错误信息。
pause
exit /b %CREO_BR_EXIT%

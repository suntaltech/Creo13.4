# 16色BMP导出（r4）

默认32px和备用16pxBMP现为：4位索引色、16项Windows标准调色板、BITMAPINFOHEADER、无压缩BI_RGB。源PNG仍是高色彩设计稿，不作为修订BMP的显示验收图。

使用 ImageMagick（本次已执行），以r3的BMP为输入，标准调色板在 windows16_palette.ppm：

```sh
magick original_32.bmp +dither -remap assets/windows16_palette.ppm -type Palette -compress None BMP3:text/resource/batchrename.bmp
magick original_16.bmp +dither -remap assets/windows16_palette.ppm -type Palette -compress None BMP3:text/resource/batchrename_16.bmp
```

可从保留的 assets/batchrename_source.png 先按原需求缩放并合成不透明背景后再映射此调色板；重新生成文件必须执行 `python tests/verify_icons.py`，不可仅凭文件后缀或“-colors 16”参数判断为4位BMP。重新生成结果可能与本次文件哈希不同。

4位索引色=最多16色，不是16位色深。默认32×32文件630字节，备用16×16文件246字节，具体SHA256见review/evidence/icon_format.json。16色转换会改变原蓝色和抗锯齿边缘，实际视觉以部署BMP为准。

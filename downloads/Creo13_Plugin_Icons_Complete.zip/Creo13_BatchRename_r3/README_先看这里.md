# Creo 13.4 批量重命名插件：图标与稳定性修订 r3

本包按本次上传的新版 BatchRename.java 审核修订，并整合上一版 r2 网页、安装/启动器。先读 `review/审核报告.md`。它是待实机验证的源码包，不含真实 SDK 编译的 class，也不保证 Ribbon 已完成布局。上传包没有实际 jlink.log/build.log，本次只能依据源码及替身测试判断，不能认定已解决实机卡死。

## 图标和目录

- `text/resource/batchrename.bmp`：32×32、24 位未压缩 Windows BMP，蓝色圆角白 R，代码通过 `command.SetIcon("batchrename.bmp")` 引用。
- `text/resource/batchrename_16.bmp`：16×16 备用尺寸；不宣称 Creo 会自动选择这个文件。需要时在测试副本中替换默认图标文件，或改 SetIcon 文件名后重新编译。
- `assets/batchrename_32.png`：透明背景预览；`assets/batchrename_source.png`：生成的高分辨率源图。
- BMP 是不带透明通道的 24 位格式，外角已合成到 #F0F0F0 浅灰底；深色 Creo 主题可能看到浅色角边。PNG 保留透明，能否直接用 PNG 仍需目标 SDK/Creo 验证。
- `text/batchrename.txt` 与 `text/chinese_cn/batchrename.txt` 保留上传的三条中文文字资源内容。

`.dat` 不添加任何臆造的 icon 配置键，保持 startup java、java_app_classpath 和 text_dir。默认 `.dat` 的 text_dir 是 `D:\creoson\jlink\text`，因此对应图标部署到 `D:\creoson\jlink\text\resource\batchrename.bmp`。安装器会随整个 text 目录复制；自定义 PluginDir 时会生成对应路径注册文件。command.Designate 负责文字资源，SetIcon 负责图标；不是仅修改 Designate 参数就能指定图片。

## 受控安装

1. 关闭 Creo，备份配置和既有插件。解压到 **目标 PluginDir 以外** 的独立目录。先核对 Creo 13.4 真实 SDK、受支持的同步 JVM；JDK25 编译 --release17 不等于 Creo 支持 JDK25 运行。
2. 建议首次禁用 Java 自动拉起服务：在启动 Creo 的同一个 CMD 设置 `set "CREO_BR_AUTOSTART=false"`，使用现有 `启动.bat` 验证服务；确认后再评估开启。已运行的 Creo 不会自动继承新变量。
3. 编译：运行 `build.cmd`，它使用真实安装的 otk.jar（或 pfc.jar 回退），以 `--release 17 -encoding UTF-8` 编译整个源码。可先设 `CREO_BR_COMMON` 和 `CREO_BR_JDK` 指向实际路径，完整日志在 build.log。不要用 pfcasync.jar 代替同步 SDK。
4. 编译通过后可用 `安装.bat -ManualStart -CompilerJdk "你的JDK目录"` 部署到指定测试目录/配置（参数见 install_native.ps1）；不要先改生产配置。安装器会再次编译，备份旧配置、网页及插件文件。脚本仍是多文件部署，不是整体原子事务，Windows 5.1 解析/执行与恢复尚待实测。
5. 在 Creo 辅助应用程序中先用 smoke.dat，随后 batchrename_manual.dat 测试。确认已有按钮的命令名为 SISWBatchRename；停止/重新加载插件或完整重启 Creo，观察蓝色 R。已有 Ribbon 可能需要重新放置命令/重启刷新；本包不自动重置用户 Ribbon、不附造假的 .rbn。
6. 图标失败会记录日志并保留默认图标。若真实编译提示 SetIcon 不存在，请提供 build.log 及本机 SDK 的 UICommand 方法信息；不要通过注释所有错误、把 mock JAR 当 SDK 或盲改签名来宣布成功。
7. 打开装配测试副本，运行启动.bat，再点按钮测试网页。网页发送 onlysession:true，不主动保存；随后用户保存可能写盘。标准件、外购件、族表与图纸策略未接入，需人工排除。记录实际会话与磁盘前后结果。

## 服务与日志配置

默认保留上传版“尝试自动启动服务”行为，但现在在后台执行；后台不调用 Creo/J-Link API，服务初始化不再阻塞插件入口。只通过本机 HTTP 识别页面，不自动创建额外 Creo 连接来验证会话。生产是否采用该方式需实测；可改用独立启动器。

| 环境变量（启动 Creo 前设置） | 默认/作用 | 等效 Java system property（优先级更高） |
| --- | --- | --- |
| CREO_BR_AUTOSTART | true；设 false 禁用插件拉起/探测服务 | creo.batchrename.autostart |
| CREO_BR_SERVER_DIR | D:\creoson\CreosonServerWithSetup-2.8.2-win64 | creo.batchrename.creosonDir |
| CREO_BR_LOG_DIR | 用户主目录下 CreoBatchRename | creo.batchrename.logDir |

插件日志：`%USERPROFILE%\CreoBatchRename\jlink.log`（或 CREO_BR_LOG_DIR）；服务输出：CREOSON 目录下 `batchrename_server_stdout.log`、`batchrename_server_stderr.log`。日志写入异步且有界：队列满会丢弃并在后续记录 dropped；JVM 突然退出可能丢失尾部，不能当成持久审计。文件暂未轮转，长期运行应收集归档。插件 stop 仅中断后台等待，不等待它退出，不杀已有/已启动的服务进程。

## 本包自检与结果

- `python tests/verify_package.py`：当前包哈希/大小核验，不执行插件。
- `node tests/test_page.cjs`：20 项页面模拟测试，继承 r2 并重新运行。
- `python tests/run_java_mock_tests.py <ecj-3.40.0.jar路径>`：21 项 Java mock/辅助检查；会绑定随机回环端口，测试 JVM 禁止真正启动 CREOSON。ECJ 不包含在本包，编译器来源和校验记录在 review/evidence/toolchain.json。
- 实际命令、退出码和完整测试输出在 review/evidence；Windows 脚本、真实 otk.jar、Creo Ribbon 图标、嵌入式浏览器及后台进程拉起均未实机执行。
- 原始上传文件在 review/original_input，修改补丁在 review/BatchRename_changes.patch；原仓库未修改、未推送。

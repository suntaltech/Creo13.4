# 图标来源与导出

按本次要求由图像生成工具制作蓝色圆角、白色大写R图标。源图保存在 batchrename_source.png；部署BMP已提供，不要求目标机安装图像工具。

本次用 ImageMagick 7 实际执行：

```sh
magick assets/batchrename_source.png -resize 32x32 -background '#F0F0F0' -alpha remove -alpha off -type TrueColor -depth 8 BMP3:text/resource/batchrename.bmp
magick assets/batchrename_source.png -resize 16x16 -background '#F0F0F0' -alpha remove -alpha off -type TrueColor -depth 8 BMP3:text/resource/batchrename_16.bmp
magick assets/batchrename_source.png -resize 32x32 assets/batchrename_32.png
```

上述为POSIX shell示例；Windows CMD请用双引号替换单引号，并从包根目录执行。BMP3表示Windows BITMAPINFOHEADER，最终头部验证为24位、无压缩；8-bit是每通道深度，并非8位索引色。BMP背景不透明；PNG保留源图透明度。实际尺寸/位深/哈希见 review/evidence/icon_format.json。

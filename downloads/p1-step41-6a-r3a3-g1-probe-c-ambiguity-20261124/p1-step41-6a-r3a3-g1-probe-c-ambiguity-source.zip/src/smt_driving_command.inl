// Synchronous driving-surface conversion in the creation candidate.
alignas(8) volatile LONG64 smt6a_sequence = 0;
volatile LONG smt6a_busy = 0;
AccessTrace smt6a_access_trace = {"p1_smt_drv_conv", "p1_smt_drv_conv", 0, {}, {}};

struct Smt6aContext {
    ULONGLONG id = static_cast<ULONGLONG>(InterlockedIncrement64(&smt6a_sequence));
    ULONGLONG started = GetTickCount64();
    bool thickness_valid = false, face_valid = false;
    bool face_id_valid = false, face_type_valid = false, feedback_failed = false;
    double thickness_mm = 0.0, thickness_model = 0.0, area = 0.0;
    int face_id = -1, face_type = -1;
    char model_json[model_name_json_capacity] = "null";
    char unit_from[256] = "null", unit_to[256] = "null";
    char scale[64] = "null", offset[64] = "null";
    bool tree_ready = false, create_called = false, create_valid = false;
    bool regen_called = false, regen_valid = false, cleanup_failed = false;
    ProError create_status = PRO_TK_NO_ERROR, regen_status = PRO_TK_NO_ERROR;
    int feature_id = -1, feature_type = 0;
    bool feature_type_valid = false;
    char feature_json[256] = "null";
    const char* sheetmetal = "null";
    const char* result = "INTERNAL_ERROR";
    const char* stage = "enter";
};

void smt6a_checked_event(const char* event, const char* facts, int n, size_t capacity) noexcept
{
    if (n > 0 && static_cast<size_t>(n) < capacity) trace_event(event, facts);
    else trace_failure("smt6a_event_format", ERROR_INSUFFICIENT_BUFFER);
}

bool smt6a_call(Smt6aContext& c, const char* api, ProError code) noexcept
{
    PreserveLastError preserve;
    char facts[384] = {};
    const int n = std::snprintf(facts, sizeof(facts),
        "{\"operation_id\":%llu,\"api\":\"%s\",\"called\":true,"
        "\"pro_error\":%d,\"element_id\":-1,\"create_called\":%s}",
        static_cast<unsigned long long>(c.id), api, static_cast<int>(code),
        c.create_called ? "true" : "false");
    smt6a_checked_event("SMT_CONV_API_RETURN", facts, n, sizeof(facts));
    return code == PRO_TK_NO_ERROR;
}

void smt6a_api_gate(Smt6aContext& c, const char* event, const char* api,
    int element_id, const ProError* returned, bool exception) noexcept
{
    PreserveLastError preserve;
    char code[24] = "null";
    if (returned) std::snprintf(code, sizeof(code), "%d", static_cast<int>(*returned));
    char facts[384] = {};
    const int n = std::snprintf(facts, sizeof(facts),
        "{\"operation_id\":%llu,\"stage\":\"%s\",\"api\":\"%s\","
        "\"element_id\":%d,\"pro_error\":%s,\"exception\":%s}",
        static_cast<unsigned long long>(c.id), c.stage, api, element_id, code,
        exception ? "true" : "false");
    smt6a_checked_event(event, facts, n, sizeof(facts));
}

template<class Call>
ProError smt6a_sdk(Smt6aContext& c, const char* api, Call call, int element_id = -1)
{
    smt6a_api_gate(c, "SMT_CONV_API_START", api, element_id, nullptr, false);
    try {
        const ProError status = call();
        smt6a_api_gate(c, "SMT_CONV_API_DONE", api, element_id, &status, false);
        return status;
    } catch (...) {
        smt6a_api_gate(c, "SMT_CONV_API_DONE", api, element_id, nullptr, true);
        throw;
    }
}

template<class Call>
void smt6a_cleanup(Smt6aContext& c, const char* api, Call call) noexcept
{
    try {
        if (smt6a_sdk(c, api, call) != PRO_TK_NO_ERROR) c.cleanup_failed = true;
    } catch (...) {
        c.cleanup_failed = true;
    }
}

template<size_t N>
bool smt6a_quote_wide(const wchar_t (&name)[N], char* json, size_t capacity) noexcept
{
    size_t n = 0;
    while (n < N && name[n] != L'\0') ++n;
    if (n == N) return false;
    char utf8[N * 3 + 1] = {};
    if (n && WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, name,
        static_cast<int>(n), utf8, static_cast<int>(sizeof(utf8) - 1), nullptr, nullptr) <= 0)
        return false;
    return quote_json_utf8(utf8, json, capacity);
}

ProError smt6a_message(Smt6aContext& c, const char* name)
{
    ProFileName file = L"p1_smt_conv.txt";
    ProCharLine key = {};
    if (std::strlen(name) >= sizeof(key)) { c.feedback_failed = true; return PRO_TK_BAD_INPUTS; }
    std::memcpy(key, name, std::strlen(name) + 1);
    const ProError code = ProMessageDisplay(file, key);
    smt6a_call(c, "ProMessageDisplay", code);
    if (code != PRO_TK_NO_ERROR) c.feedback_failed = true;
    return code;
}

bool smt6a_number(double value, char (&buffer)[64]) noexcept
{
    _locale_t locale = _create_locale(LC_NUMERIC, "C");
    if (!locale) { trace_failure("smt6a_numeric_locale", ERROR_NOT_ENOUGH_MEMORY); return false; }
    const int n = _snprintf_l(buffer, sizeof(buffer), "%.17g", locale, value);
    _free_locale(locale);
    return n > 0 && static_cast<size_t>(n) < sizeof(buffer);
}

void smt6a_finish(Smt6aContext& c) noexcept
{
    char mm[64] = "null", model[64] = "null", face[32] = "null", type[32] = "null";
    char area[64] = "null", create[24] = "null", regen[24] = "null";
    char feature[24] = "null", feature_type[24] = "null";
    if (c.create_valid) std::snprintf(create, sizeof(create), "%d", static_cast<int>(c.create_status));
    if (c.regen_valid) std::snprintf(regen, sizeof(regen), "%d", static_cast<int>(c.regen_status));
    if (c.feature_id >= 0) std::snprintf(feature, sizeof(feature), "%d", c.feature_id);
    if (c.feature_type_valid) std::snprintf(feature_type, sizeof(feature_type), "%d", c.feature_type);
    if (c.thickness_valid) {
        if (!smt6a_number(c.thickness_mm, mm)) std::memcpy(mm, "null", 5);
        if (!smt6a_number(c.thickness_model, model)) std::memcpy(model, "null", 5);
    }
    if (c.face_id_valid) std::snprintf(face, sizeof(face), "%d", c.face_id);
    if (c.face_type_valid) std::snprintf(type, sizeof(type), "%d", c.face_type);
    if (c.face_valid && !smt6a_number(c.area, area)) std::memcpy(area, "null", 5);
    char facts[model_facts_capacity] = {};
    const int n = std::snprintf(facts, sizeof(facts),
        "{\"operation_id\":%llu,\"command\":\"p1_smt_drv_conv\",\"mode\":\"driving\","
        "\"result\":\"%s\",\"stage\":\"%s\",\"model_name\":%s,\"face_id\":%s,"
        "\"face_type\":%s,\"face_area_model_units_squared\":%s,\"thickness_mm\":%s,"
        "\"thickness_model_units\":%s,\"unit_from\":%s,\"unit_to\":%s,\"scale\":%s,\"offset\":%s,"
        "\"tree_ready\":%s,\"create_called\":%s,\"create_status\":%s,"
        "\"regen_called\":%s,\"regen_status\":%s,\"is_sheetmetal\":%s,"
        "\"feature_id\":%s,\"feature_type\":%s,\"feature_name\":%s,"
        "\"model_may_be_modified\":%s,\"save_called\":false,\"cleanup_failed\":%s,"
        "\"feedback_failed\":%s,\"elapsed_ms\":%llu}",
        static_cast<unsigned long long>(c.id), c.result, c.stage, c.model_json,
        face, type, area, mm, model, c.unit_from, c.unit_to, c.scale, c.offset,
        c.tree_ready ? "true" : "false", c.create_called ? "true" : "false", create,
        c.regen_called ? "true" : "false", regen, c.sheetmetal, feature, feature_type, c.feature_json,
        c.create_called ? "true" : "false", c.cleanup_failed ? "true" : "false",
        c.feedback_failed ? "true" : "false",
        static_cast<unsigned long long>(GetTickCount64() - c.started));
    smt6a_checked_event("SMT_CONV_RETURN", facts, n, sizeof(facts));
}

void smt6a_reject_command(Smt6aContext& c, const char* result, const char* key)
{
    c.result = result;
    smt6a_message(c, key);
}

struct Smt6aFaceMatch {
    Smt6aContext* context;
    int selected_id;
    int matches = 0;
    ProError failure = PRO_TK_NO_ERROR;
    Smt6aFaceMatch(Smt6aContext* c, int id) noexcept : context(c), selected_id(id) {}
};

ProError smt6a_visit_member(ProSurface surface, ProError incoming, ProAppData data)
{
    Smt6aFaceMatch& match = *static_cast<Smt6aFaceMatch*>(data);
    if (incoming != PRO_TK_NO_ERROR) { match.failure = incoming; return incoming; }
    int id = -1;
    const ProError status = ProSurfaceIdGet(surface, &id);
    if (!smt6a_call(*match.context, "ProSurfaceIdGet(member)", status)) {
        match.failure = status;
        return status;
    }
    if (id == match.selected_id) ++match.matches;
    return PRO_TK_NO_ERROR;
}

bool smt6a_face_check(Smt6aContext& c, ProMdl model, ProSolidBody& body,
    ProSelection selection)
{
    ProModelitem item = {};
    if (!smt6a_call(c, "ProSelectionModelitemGet", ProSelectionModelitemGet(selection, &item))) {
        smt6a_reject_command(c, "SELECTED_FACE_INVALID", "P1_SMT_CONV_BAD_FACE"); return false;
    }
    char item_facts[256] = {};
    const int item_n = std::snprintf(item_facts, sizeof(item_facts),
        "{\"operation_id\":%llu,\"selected_item_id\":%d,\"selected_item_type\":%d,\"owner_matches_model\":%s}",
        static_cast<unsigned long long>(c.id), item.id, static_cast<int>(item.type),
        item.owner == model ? "true" : "false");
    smt6a_checked_event("SMT_CONV_SELECTED_ITEM", item_facts, item_n, sizeof(item_facts));
    if (item.type != PRO_SURFACE || item.owner != model) {
        smt6a_reject_command(c, "SELECTED_FACE_INVALID", "P1_SMT_CONV_BAD_FACE"); return false;
    }
    c.face_id = item.id; c.face_id_valid = true;
    Smt6aFaceMatch match(&c, item.id);
    const ProError visit = ProSolidBodySurfaceVisit(&body, &smt6a_visit_member, &match);
    if (!smt6a_call(c, "ProSolidBodySurfaceVisit(membership)", visit) ||
        match.failure != PRO_TK_NO_ERROR || match.matches != 1) {
        smt6a_reject_command(c, "FACE_BODY_MISMATCH", "P1_SMT_CONV_BODY_MISMATCH"); return false;
    }
    ProSurface surface = nullptr;
    ProSrftype type = PRO_SRF_NONE;
    double area = 0.0;
    if (!smt6a_call(c, "ProSurfaceInit", ProSurfaceInit(model, item.id, &surface)) ||
        !smt6a_call(c, "ProSurfaceTypeGet", ProSurfaceTypeGet(surface, &type))) {
        smt6a_reject_command(c, "SELECTED_FACE_INVALID", "P1_SMT_CONV_BAD_FACE"); return false;
    }
    c.face_type = static_cast<int>(type); c.face_type_valid = true;
    if (type != PRO_SRF_PLANE) {
        smt6a_reject_command(c, "SELECTED_FACE_NOT_PLANE", "P1_SMT_CONV_NOT_PLANE"); return false;
    }
    if (!smt6a_call(c, "ProSurfaceAreaEval", ProSurfaceAreaEval(surface, &area)) ||
        !std::isfinite(area) || area <= 0.0) {
        smt6a_reject_command(c, "SURFACE_QUERY_FAILED", "P1_SMT_CONV_BAD_FACE"); return false;
    }
    c.face_valid = true; c.face_id = item.id; c.face_type = static_cast<int>(type); c.area = area;
    return true;
}

bool smt6a_units(Smt6aContext& c, ProMdl model, ProUnitConversion& conversion)
{
    ProUnitsystem system = {};
    ProUnititem unit = {}, mm = {};
    ProName mm_name = L"mm";
    if (!smt6a_call(c, "ProMdlPrincipalunitsystemGet", ProMdlPrincipalunitsystemGet(model, &system)) ||
        !smt6a_call(c, "ProUnitsystemUnitGet", ProUnitsystemUnitGet(&system, PRO_UNITTYPE_LENGTH, &unit)) ||
        !smt6a_call(c, "ProUnitInit(mm)", ProUnitInit(model, mm_name, &mm)) ||
        !smt6a_call(c, "ProUnitConversionCalculate(mm_to_model)",
            ProUnitConversionCalculate(&mm, &unit, &conversion))) return false;
    if (!std::isfinite(conversion.scale) || conversion.scale <= 0.0 ||
        !std::isfinite(conversion.offset) || conversion.offset != 0.0) return false;
    char unit_json[sizeof(c.unit_to)] = {}, mm_json[sizeof(c.unit_from)] = {};
    if (!unit.name[0] || !mm.name[0] ||
        !smt6a_quote_wide(unit.name, unit_json, sizeof(unit_json)) ||
        !smt6a_quote_wide(mm.name, mm_json, sizeof(mm_json))) return false;
    char scale[sizeof(c.scale)] = {}, offset[sizeof(c.offset)] = {};
    if (!smt6a_number(conversion.scale, scale) || !smt6a_number(conversion.offset, offset)) return false;
    char facts[1024] = {};
    const int n = std::snprintf(facts, sizeof(facts),
        "{\"operation_id\":%llu,\"unit_from\":%s,\"unit_to\":%s,"
        "\"direction\":\"mm_to_current_model\",\"scale\":%s,\"offset\":%s}",
        static_cast<unsigned long long>(c.id), mm_json, unit_json, scale, offset);
    if (n <= 0 || static_cast<size_t>(n) >= sizeof(facts)) {
        trace_failure("smt6a_units_format", ERROR_INSUFFICIENT_BUFFER);
        return false;
    }
    std::memcpy(c.unit_from, mm_json, sizeof(c.unit_from));
    std::memcpy(c.unit_to, unit_json, sizeof(c.unit_to));
    std::memcpy(c.scale, scale, sizeof(c.scale));
    std::memcpy(c.offset, offset, sizeof(c.offset));
    trace_event("SMT_CONV_UNITS", facts);
    return true;
}

struct Smt6aSelectedFace {
    Smt6aContext& context;
    ProSelection copy = nullptr;
    explicit Smt6aSelectedFace(Smt6aContext& c) noexcept : context(c) {}
    Smt6aSelectedFace(const Smt6aSelectedFace&) = delete;
    Smt6aSelectedFace& operator=(const Smt6aSelectedFace&) = delete;
    ~Smt6aSelectedFace() noexcept { release(); }
    void release() noexcept
    {
        if (!copy) return;
        ProSelection owned = copy;
        copy = nullptr;
        smt6a_cleanup(context, "ProSelectionFree(selected_copy)", [&] {
            return ProSelectionFree(&owned);
        });
    }
};

#include "smt_driving_tree.inl"

void smt6a_error_list(Smt6aContext& c, const ProErrorlist& errors) noexcept
{
    char facts[384] = {};
    int n = std::snprintf(facts, sizeof(facts),
        "{\"operation_id\":%llu,\"error_number\":%d,\"list_present\":%s}",
        static_cast<unsigned long long>(c.id), errors.error_number, errors.error_list ? "true" : "false");
    smt6a_checked_event("SMT_CONV_ERROR_LIST", facts, n, sizeof(facts));
    if (!errors.error_list) return;
    for (int i = 0; i < errors.error_number; ++i) {
        const ProItemerror& item = errors.error_list[i];
        n = std::snprintf(facts, sizeof(facts),
            "{\"operation_id\":%llu,\"index\":%d,\"element_id\":%d,\"item_type\":%d,\"pro_error\":%d}",
            static_cast<unsigned long long>(c.id), i, item.err_item_id,
            static_cast<int>(item.err_item_type), static_cast<int>(item.error));
        smt6a_checked_event("SMT_CONV_ELEMENT_ERROR", facts, n, sizeof(facts));
    }
}

bool smt6a_create(Smt6aContext& c, ProMdl model, ProSolidBody& body,
    ProSelection face, ProFeature& feature)
{
    Smt6aPreparedTree tree(c);
    c.stage = "wrap";
    if (!smt6a_wrap_selections(tree, model, body)) {
        smt6a_reject_command(c, "WRAP_SOLID_FAILED", "P1_SMT_CONV_WRAP_FAILED");
        return false;
    }
    c.stage = "tree";
    if (!smt6a_prepare_tree(tree, face, c.thickness_model)) {
        smt6a_reject_command(c, "TREE_CREATE_FAILED", "P1_SMT_CONV_TREE_FAILED");
        return false;
    }
    c.tree_ready = true;
    char facts[160] = {};
    const int n = std::snprintf(facts, sizeof(facts),
        "{\"operation_id\":%llu,\"root_ready\":true,\"child_count\":6,\"create_called\":false}",
        static_cast<unsigned long long>(c.id));
    smt6a_checked_event("SMT_CONV_TREE_READY", facts, n, sizeof(facts));

    c.stage = "create";
    ProErrorlist errors = {};
    c.create_status = smt6a_sdk(c, "ProFeatureWithoptionsCreate", [&] {
        c.create_called = true;
        return ProFeatureWithoptionsCreate(tree.model, tree.root, tree.options,
            PRO_REGEN_NO_FLAGS, &feature, &errors);
    });
    c.create_valid = true;
    smt6a_error_list(c, errors);
    if (c.create_status == PRO_TK_CANT_MODIFY) {
        smt6a_reject_command(c, "MODEL_READ_ONLY", "P1_SMT_CONV_READ_ONLY");
        return false;
    }
    if (c.create_status != PRO_TK_NO_ERROR) {
        smt6a_reject_command(c, "CREATE_FEATURE_FAILED", "P1_SMT_CONV_CREATE_FAILED");
        return false;
    }
    return true;
}

bool smt6a_readback(Smt6aContext& c, ProSolid solid, const ProSolidBody& original,
    ProFeature& feature, ProName& name)
{
    c.stage = "feature_identity";
    if (feature.owner != original.owner || feature.id < 0) {
        smt6a_reject_command(c, "FEATURE_READBACK_FAILED", "P1_SMT_CONV_POST_FAILED");
        return false;
    }
    c.feature_id = feature.id;
    c.stage = "regenerate";
    c.regen_status = smt6a_sdk(c, "ProSolidRegenerate", [&] {
        c.regen_called = true;
        return ProSolidRegenerate(solid, PRO_REGEN_NO_FLAGS);
    });
    c.regen_valid = true;
    if (c.regen_status != PRO_TK_NO_ERROR) {
        smt6a_reject_command(c, "REGEN_FAILED", "P1_SMT_CONV_POST_FAILED");
        return false;
    }
    c.stage = "postcheck";
    ProSolidBody body = {};
    ProBoolean sheetmetal = PRO_B_FALSE;
    if (smt6a_sdk(c, "ProSolidDefaultBodyGet(post)", [&] {
            return ProSolidDefaultBodyGet(solid, &body);
        }) != PRO_TK_NO_ERROR) {
        smt6a_reject_command(c, "STATUS_READBACK_FAILED", "P1_SMT_CONV_POST_FAILED");
        return false;
    }
    if (body.id != original.id || body.owner != original.owner) {
        smt6a_reject_command(c, "TARGET_BODY_CHANGED", "P1_SMT_CONV_POST_FAILED");
        return false;
    }
    if (smt6a_sdk(c, "ProSolidBodyIsSheetmetal(post)", [&] {
            return ProSolidBodyIsSheetmetal(&body, &sheetmetal);
        }) != PRO_TK_NO_ERROR) {
        smt6a_reject_command(c, "STATUS_READBACK_FAILED", "P1_SMT_CONV_POST_FAILED");
        return false;
    }
    c.sheetmetal = sheetmetal == PRO_B_TRUE ? "true" : "false";
    if (sheetmetal != PRO_B_TRUE) {
        smt6a_reject_command(c, "STATUS_NOT_SHEETMETAL", "P1_SMT_CONV_POST_FAILED");
        return false;
    }

    if (feature.owner != original.owner || feature.id != c.feature_id) {
        smt6a_reject_command(c, "FEATURE_READBACK_FAILED", "P1_SMT_CONV_POST_FAILED");
        return false;
    }
    ProFeattype type = {};
    if (smt6a_sdk(c, "ProFeatureTypeGet", [&] {
            return ProFeatureTypeGet(&feature, &type);
        }) != PRO_TK_NO_ERROR) {
        smt6a_reject_command(c, "FEATURE_READBACK_FAILED", "P1_SMT_CONV_POST_FAILED");
        return false;
    }
    c.feature_type = static_cast<int>(type);
    c.feature_type_valid = true;
    if (smt6a_sdk(c, "ProModelitemNameGet(feature)", [&] {
            return ProModelitemNameGet(&feature, name);
        }) != PRO_TK_NO_ERROR || !name[0] ||
        !smt6a_quote_wide(name, c.feature_json, sizeof(c.feature_json))) {
        std::memcpy(c.feature_json, "null", 5);
        smt6a_reject_command(c, "FEATURE_READBACK_FAILED", "P1_SMT_CONV_POST_FAILED");
        return false;
    }
    return true;
}

void smt6a_dump_message_buffer(const Smt6aContext& c, const char* role,
    const char* key, const char* value, ProError status, const ProLine& buffer) noexcept
{
    PreserveLastError preserve;
    const bool truncated = status == PRO_TK_MSG_TOO_LONG;
    const bool readable = status == PRO_TK_NO_ERROR || truncated;
    size_t units = 0;
    if (readable) {
        while (units < PRO_LINE_SIZE && buffer[units] != L'\0') ++units;
    }
    const bool terminated = readable && units < PRO_LINE_SIZE;
    constexpr size_t json_capacity = (PRO_LINE_SIZE - 1) * 6 + 3;
    char text_json[json_capacity] = {};
    const bool text_ok = terminated && quote_message_utf16(buffer, units, text_json, sizeof(text_json));
    bool placeholder = false;
    if (terminated) {
        for (size_t i = 0; i + 2 < units; ++i) {
            if (buffer[i] == L'%' && buffer[i + 1] == L'0' && buffer[i + 2] == L's') {
                placeholder = true;
                break;
            }
        }
    }

    // Callers supply the already-validated UTF-8 name chunks or generated ASCII details.
    char param_json[json_capacity] = {};
    const char* param_kind = "null";
    if (value) {
        if (!quote_json_utf8(value, param_json, sizeof(param_json))) {
            trace_failure("buffer_dump_format", ERROR_INSUFFICIENT_BUFFER);
            return;
        }
        param_kind = "\"ascii\"";
        for (auto p = reinterpret_cast<const unsigned char*>(value); *p; ++p) {
            if (*p > 0x7f) { param_kind = "\"zh\""; break; }
        }
    }

    char count[24] = "null";
    if (readable) std::snprintf(count, sizeof(count), "%u", static_cast<unsigned>(units));
    // Use the facts limit, leaving the existing trace envelope its capacity.
    char facts[model_facts_capacity] = {};
    const int n = std::snprintf(facts, sizeof(facts),
        "{\"operation_id\":%llu,\"stage\":\"%s\",\"probe\":\"buffer_dump_v1\","
        "\"role\":\"%s\",\"key\":\"%s\",\"param_kind\":%s,\"param_json\":%s,"
        "\"pro_error\":%d,\"buffer_observed\":%s,\"wide_units\":%s,\"terminated\":%s,"
        "\"sdk_reported_truncation\":%s,\"text_json_valid\":%s,\"text_json\":%s,"
        "\"placeholder_remaining\":%s,\"buffer_match_expected\":null}",
        static_cast<unsigned long long>(c.id), c.stage, role, key, param_kind,
        value ? param_json : "null", static_cast<int>(status), readable ? "true" : "null",
        count, readable ? (terminated ? "true" : "false") : "null",
        truncated ? "true" : "false", readable ? (text_ok ? "true" : "false") : "null",
        text_ok ? text_json : "null", terminated ? (placeholder ? "true" : "false") : "null");
    if (n <= 0 || static_cast<size_t>(n) >= sizeof(facts)) {
        trace_failure("buffer_dump_format", ERROR_INSUFFICIENT_BUFFER);
        return;
    }
    trace_event("SMT_CONV_BUFFER_DUMP", facts);
}

void smt6a_dump_static_feedback(const Smt6aContext& c, const char* role, const char* name) noexcept
{
    PreserveLastError preserve;
    ProFileName file = L"p1_smt_conv.txt";
    ProCharLine key = {};
    const size_t length = std::strlen(name);
    if (length >= sizeof(key)) return;
    std::memcpy(key, name, length + 1);
    ProLine buffer = {};
    try {
        const ProError status = ProMessageToBuffer(buffer, file, key);
        smt6a_dump_message_buffer(c, role, key, nullptr, status, buffer);
    } catch (...) {
        trace_failure("buffer_dump_static_exception", ERROR_GEN_FAILURE);
    }
}

bool smt6a_text(Smt6aContext& c, char* value, bool preview_only = false,
    const char* role = "detail")
{
    ProFileName file = L"p1_smt_conv.txt";
    ProCharLine key = "P1_SMT_CONV_TEXT";
    ProLine buffer = {};
    const ProError preview = smt6a_sdk(c, "ProMessageToBuffer(conversion_text)", [&] {
        return ProMessageToBuffer(buffer, file, key, value);
    });
    if (!preview_only) smt6a_dump_message_buffer(c, role, key, value, preview, buffer);
    if (preview != PRO_TK_NO_ERROR) return false;
    return preview_only || smt6a_sdk(c, "ProMessageDisplay(conversion_text)", [&] {
        return ProMessageDisplay(file, key, value);
    }) == PRO_TK_NO_ERROR;
}

template<size_t N>
bool smt6a_show_name(Smt6aContext& c, const char* key, const wchar_t (&name)[N], const char* role)
{
    if (smt6a_message(c, key) != PRO_TK_NO_ERROR) return false;
    smt6a_dump_static_feedback(c, role, key);
    char utf8[N * 3 + 1] = {};
    if (WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, name,
            -1, utf8, static_cast<int>(sizeof(utf8)), nullptr, nullptr) <= 0) return false;
    const size_t length = std::strlen(utf8);
    for (size_t start = 0; start < length;) {
        size_t end = start + 60 < length ? start + 60 : length;
        while (end < length && (static_cast<unsigned char>(utf8[end]) & 0xc0) == 0x80) --end;
        char line[61] = {};
        std::memcpy(line, utf8 + start, end - start);
        if (!smt6a_text(c, line, false, role)) return false;
        start = end;
    }
    return true;
}

bool smt6a_show_success(Smt6aContext& c, const ProMdlName& model_name, const ProName& feature_name)
{
    char thickness[64] = {}, detail[80] = {};
    if (!smt6a_number(c.thickness_mm, thickness)) return false;
    const int n = std::snprintf(detail, sizeof(detail), "driving; thickness=%s mm", thickness);
    if (n <= 0 || static_cast<size_t>(n) >= sizeof(detail)) return false;
    if (smt6a_message(c, "P1_SMT_CONV_SUCCESS") != PRO_TK_NO_ERROR) return false;
    smt6a_dump_static_feedback(c, "success_static", "P1_SMT_CONV_SUCCESS");
    if (!smt6a_show_name(c, "P1_SMT_CONV_MODEL_NAME", model_name, "model_name") ||
        !smt6a_text(c, detail)) return false;
    const int k = std::snprintf(detail, sizeof(detail), "feature_id=%d; IsSheetmetal=true; Save not called",
        c.feature_id);
    return k > 0 && static_cast<size_t>(k) < sizeof(detail) && smt6a_text(c, detail) &&
        smt6a_show_name(c, "P1_SMT_CONV_FEATURE_NAME", feature_name, "feature_name");
}

void smt6a_trace_selection(const Smt6aContext& c, int limit, int count, ProError status) noexcept
{
    PreserveLastError preserve;
    char returned_count[24] = "null";
    if (status == PRO_TK_NO_ERROR)
        std::snprintf(returned_count, sizeof(returned_count), "%d", count);
    char facts[256] = {};
    const int n = std::snprintf(facts, sizeof(facts),
        "{\"operation_id\":%llu,\"stage\":\"select\",\"filter\":\"surface\","
        "\"max_count\":%d,\"count\":%s,\"pro_error\":%d}",
        static_cast<unsigned long long>(c.id), limit, returned_count, static_cast<int>(status));
    smt6a_checked_event("SMT_CONV_SELECTION", facts, n, sizeof(facts));
}

void smt6a_trace_ambiguous_items(const Smt6aContext& c, ProMdl model,
    const ProSelection* borrowed, int count, int limit) noexcept
{
    if (!borrowed || count < 2) return;
    PreserveLastError preserve;
    for (int i = 0; i < count && i < limit; ++i) {
        ProModelitem item = {};
        char status[24] = "null", id[24] = "null", type[24] = "null";
        bool exception = false;
        const char* owner_matches = "null";
        if (borrowed[i]) {
            try {
                // Query while the selection is borrowed; never copy or retain it.
                const ProError code = ProSelectionModelitemGet(borrowed[i], &item);
                std::snprintf(status, sizeof(status), "%d", static_cast<int>(code));
                if (code == PRO_TK_NO_ERROR) {
                    std::snprintf(id, sizeof(id), "%d", item.id);
                    std::snprintf(type, sizeof(type), "%d", static_cast<int>(item.type));
                    owner_matches = item.owner == model ? "true" : "false";
                }
            } catch (...) {
                exception = true;
            }
        }
        char facts[320] = {};
        const int n = std::snprintf(facts, sizeof(facts),
            "{\"operation_id\":%llu,\"stage\":\"select\",\"selection_index\":%d,"
            "\"pro_error\":%s,\"item_id\":%s,\"item_type\":%s,\"owner_matches_model\":%s,\"exception\":%s}",
            static_cast<unsigned long long>(c.id), i, status, id, type, owner_matches,
            exception ? "true" : "false");
        smt6a_checked_event("SMT_CONV_AMBIGUOUS_ITEM", facts, n, sizeof(facts));
    }
}

void smt6a_run(Smt6aContext& c)
{
    c.stage = "preflight";
    ProMdl model = nullptr;
    ProError status = ProMdlCurrentGet(&model);
    if (!smt6a_call(c, "ProMdlCurrentGet", status) || !model) {
        smt6a_reject_command(c, "NO_MODEL", "P1_SMT_CONV_NO_MODEL"); return;
    }
    ProMdlType type = PRO_MDL_UNUSED;
    if (!smt6a_call(c, "ProMdlTypeGet", ProMdlTypeGet(model, &type))) {
        smt6a_reject_command(c, "MODEL_QUERY_FAILED", "P1_SMT_CONV_QUERY_FAILED"); return;
    }
    if (type != PRO_MDL_PART) {
        smt6a_reject_command(c, "NOT_PART", "P1_SMT_CONV_NOT_PART"); return;
    }
    ProMdlName model_name = {};
    if (!smt6a_call(c, "ProMdlMdlnameGet", ProMdlMdlnameGet(model, model_name)) ||
        !smt6a_quote_wide(model_name, c.model_json, sizeof(c.model_json))) {
        smt6a_reject_command(c, "MODEL_NAME_FAILED", "P1_SMT_CONV_QUERY_FAILED"); return;
    }
    const ProSolid solid = reinterpret_cast<ProSolid>(model);
    ProSolidBody body = {};
    status = ProSolidDefaultBodyGet(solid, &body);
    if (!smt6a_call(c, "ProSolidDefaultBodyGet", status)) {
        smt6a_reject_command(c, status == PRO_TK_GENERAL_ERROR ? "NO_BODY" : "WRAP_SOLID_FAILED",
            "P1_SMT_CONV_NO_BODY"); return;
    }
    ProBoolean smt = PRO_B_FALSE;
    if (!smt6a_call(c, "ProSolidBodyIsSheetmetal", ProSolidBodyIsSheetmetal(&body, &smt))) {
        smt6a_reject_command(c, "BODY_QUERY_FAILED", "P1_SMT_CONV_QUERY_FAILED"); return;
    }
    if (smt == PRO_B_TRUE) {
        smt6a_reject_command(c, "ALREADY_SHEETMETAL", "P1_SMT_CONV_ALREADY"); return;
    }
    c.stage = "select";
    if (smt6a_message(c, "P1_SMT_CONV_SELECT") != PRO_TK_NO_ERROR) { c.result = "FEEDBACK_NOT_READY"; return; }
    ProSelection* borrowed = nullptr;
    int count = 0;
    char filter[] = "surface";
    constexpr int select_max_count = 2;
    status = ProSelect(filter, select_max_count, nullptr, nullptr, nullptr, nullptr, &borrowed, &count);
    smt6a_call(c, "ProSelect(surface,2)", status);
    smt6a_trace_selection(c, select_max_count, count, status);
    if (status == PRO_TK_USER_ABORT) {
        smt6a_reject_command(c, "CANCELLED", "P1_SMT_CONV_CANCELLED"); return;
    }
    if (status != PRO_TK_NO_ERROR) {
        smt6a_reject_command(c, "SELECTION_FAILED", "P1_SMT_CONV_BAD_FACE"); return;
    }
    if (count == 0) {
        smt6a_reject_command(c, "NO_SELECTED_FACE", "P1_SMT_CONV_NO_FACE"); return;
    }
    if (count != 1 || !borrowed || !borrowed[0]) {
        smt6a_trace_ambiguous_items(c, model, borrowed, count, select_max_count);
        smt6a_reject_command(c, "SELECTION_AMBIGUOUS", "P1_SMT_CONV_ONE_FACE"); return;
    }
    Smt6aSelectedFace selected(c);
    // ProSelect output is treated as borrowed; only our independent copy is freed.
    if (!smt6a_call(c, "ProSelectionCopy(selected)", ProSelectionCopy(borrowed[0], &selected.copy))) {
        smt6a_reject_command(c, "SELECTED_FACE_INVALID", "P1_SMT_CONV_BAD_FACE"); return;
    }
    if (!selected.copy) {
        smt6a_reject_command(c, "SELECTED_FACE_INVALID", "P1_SMT_CONV_BAD_FACE"); return;
    }
    if (!smt6a_face_check(c, model, body, selected.copy)) return;
    c.stage = "input_mm";
    if (smt6a_message(c, "P1_SMT_CONV_THICKNESS") != PRO_TK_NO_ERROR) { c.result = "FEEDBACK_NOT_READY"; return; }
    double range[2] = {0.1, 20.0};
    double thickness = 0.0;
    status = ProMessageDoubleRead(range, &thickness);
    smt6a_call(c, "ProMessageDoubleRead", status);
    if (status == PRO_TK_MSG_USER_QUIT) {
        smt6a_reject_command(c, "CANCELLED", "P1_SMT_CONV_CANCELLED"); return;
    }
    if (status != PRO_TK_NO_ERROR || !std::isfinite(thickness) || thickness < range[0] || thickness > range[1]) {
        smt6a_reject_command(c, "INVALID_THICKNESS", "P1_SMT_CONV_BAD_THICKNESS"); return;
    }
    char observed[64] = {};
    if (!smt6a_number(thickness, observed)) {
        smt6a_reject_command(c, "INPUT_FORMAT_FAILED", "P1_SMT_CONV_BAD_THICKNESS"); return;
    }
    char input_facts[256] = {};
    const int input_n = std::snprintf(input_facts, sizeof(input_facts),
        "{\"operation_id\":%llu,\"input_unit\":\"mm\",\"value\":%s,\"backend_range_valid\":true}",
        static_cast<unsigned long long>(c.id), observed);
    smt6a_checked_event("SMT_CONV_THICKNESS_VALIDATED", input_facts, input_n, sizeof(input_facts));
    c.stage = "revalidate";
    ProMdl current = nullptr;
    ProSolidBody fresh_body = {};
    ProBoolean fresh_smt = PRO_B_FALSE;
    if (!smt6a_call(c, "ProMdlCurrentGet(revalidate)", ProMdlCurrentGet(&current)) || current != model ||
        !smt6a_call(c, "ProSolidDefaultBodyGet(revalidate)", ProSolidDefaultBodyGet(solid, &fresh_body)) ||
        fresh_body.id != body.id || fresh_body.owner != body.owner ||
        !smt6a_call(c, "ProSolidBodyIsSheetmetal(revalidate)", ProSolidBodyIsSheetmetal(&fresh_body, &fresh_smt)) ||
        fresh_smt == PRO_B_TRUE) {
        smt6a_reject_command(c, "STALE_CONTEXT", "P1_SMT_CONV_STALE"); return;
    }
    if (!smt6a_face_check(c, model, fresh_body, selected.copy)) return;
    c.stage = "units";
    ProUnitConversion conversion = {};
    if (!smt6a_units(c, model, conversion)) {
        smt6a_reject_command(c, "UNIT_UNSUPPORTED", "P1_SMT_CONV_UNIT_FAILED"); return;
    }
    const double converted = thickness * conversion.scale + conversion.offset;
    if (!std::isfinite(converted) || converted <= 0.0) {
        smt6a_reject_command(c, "INVALID_THICKNESS", "P1_SMT_CONV_BAD_THICKNESS"); return;
    }
    c.thickness_mm = thickness; c.thickness_model = converted; c.thickness_valid = true;
    c.stage = "feedback_preflight";
    char preview[] = "driving; thickness in mm";
    if (!smt6a_text(c, preview, true)) {
        c.feedback_failed = true;
        c.result = "FEEDBACK_NOT_READY";
        return;
    }
    ProFeature feature = {};
    const bool created = smt6a_create(c, model, fresh_body, selected.copy, feature);
    selected.release();
    if (!created) return;
    if (c.cleanup_failed) {
        smt6a_reject_command(c, "CLEANUP_FAILED", "P1_SMT_CONV_POST_FAILED"); return;
    }
    ProName feature_name = {};
    if (!smt6a_readback(c, solid, fresh_body, feature, feature_name)) return;
    c.stage = "feedback";
    if (!smt6a_show_success(c, model_name, feature_name)) {
        c.feedback_failed = true;
        c.result = "POST_FEEDBACK_FAILED";
        return;
    }
    c.result = "SUCCESS_UNSAVED";
}

int smt6a_action(uiCmdCmdId command, uiCmdValue* value, void* push_data)
{
    PreserveLastError preserve;
    (void)command; (void)value; (void)push_data;
    Smt6aContext context;
    if (InterlockedCompareExchange(&smt6a_busy, 1, 0) != 0) {
        context.result = "COMMAND_BUSY";
        try { smt6a_message(context, "P1_SMT_CONV_BUSY"); }
        catch (...) { context.feedback_failed = true; }
        smt6a_finish(context); return 0;
    }
    struct BusyReset { ~BusyReset() { InterlockedExchange(&smt6a_busy, 0); } } reset;
    char begin[128] = {};
    const int n = std::snprintf(begin, sizeof(begin), "{\"operation_id\":%llu,\"mode\":\"driving\"}",
        static_cast<unsigned long long>(context.id));
    smt6a_checked_event("SMT_CONV_ENTER", begin, n, sizeof(begin));
    try { smt6a_run(context); }
    catch (...) {
        context.result = "UNEXPECTED_EXCEPTION";
        try { smt6a_message(context, "P1_SMT_CONV_EXCEPTION"); }
        catch (...) { context.feedback_failed = true; }
    }
    flush_one_access_trace(smt6a_access_trace, "smt_conversion_return");
    smt6a_finish(context);
    return 0;
}

uiCmdAccessState smt6a_access(uiCmdAccessMode mode)
{
    // No model query, selection, messages, SDK write or file I/O in access.
    record_access_observation(smt6a_access_trace, mode, ACCESS_AVAILABLE);
    return ACCESS_AVAILABLE;
}

void register_smt6a_conversion() noexcept
{
    PreserveLastError preserve;
    Smt6aContext c;
    try {
        static char name[] = "p1_smt_drv_conv";
        static char label[] = "P1_SMT_CONV_LABEL";
        static char help[] = "P1_SMT_CONV_HELP";
        static char description[] = "P1_SMT_CONV_DESC";
        static wchar_t file[] = L"p1_smt_conv.txt";
        uiCmdCmdId id = nullptr;
        const ProError add = ProCmdActionAdd(name, &smt6a_action, uiProeImmediate,
            &smt6a_access, PRO_B_TRUE, PRO_B_TRUE, &id);
        if (!smt6a_call(c, "ProCmdActionAdd(smt_conversion)", add)) return;
        if (!id) {
            trace_event("SMT_CONV_REGISTER_NO_ID", "{\"command\":\"p1_smt_drv_conv\"}");
            return;
        }
        trace_registration_identity("p1_smt_drv_conv", id, name, label, help, description, file);
        smt6a_call(c, "ProCmdDesignate(smt_conversion)", ProCmdDesignate(id, label, help, description, file));
        flush_one_access_trace(smt6a_access_trace, "smt_conversion_initialization_end");
    } catch (...) {
        trace_event("SMT_CONV_REGISTER_EXCEPTION", "{\"existing_commands_preserved\":true}");
    }
}

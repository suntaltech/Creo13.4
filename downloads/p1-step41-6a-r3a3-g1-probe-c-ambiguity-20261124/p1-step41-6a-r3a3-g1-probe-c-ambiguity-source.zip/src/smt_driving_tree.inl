// Included after Smt6aContext and the API tracing helpers.
struct Smt6aPreparedTree {
    Smt6aContext& context;
    ProSelection model = nullptr;
    ProSelection body = nullptr;
    ProReference body_reference = nullptr;
    ProReference face_reference = nullptr;
    ProFeatureCreateOptions* options = nullptr;
    ProElement root = nullptr;

    explicit Smt6aPreparedTree(Smt6aContext& c) noexcept : context(c) {}
    Smt6aPreparedTree(const Smt6aPreparedTree&) = delete;
    Smt6aPreparedTree& operator=(const Smt6aPreparedTree&) = delete;
    ~Smt6aPreparedTree() noexcept
    {
        // The root owns attached children. Release it while references are live.
        if (root) smt6a_cleanup(context, "ProElementFree(root)", [&] { return ProElementFree(&root); });
        if (options) smt6a_cleanup(context, "ProArrayFree(options)", [&] {
            return ProArrayFree(reinterpret_cast<ProArray*>(&options));
        });
        if (face_reference) smt6a_cleanup(context, "ProReferenceFree(face)", [&] {
            return ProReferenceFree(face_reference);
        });
        if (body_reference) smt6a_cleanup(context, "ProReferenceFree(body)", [&] {
            return ProReferenceFree(body_reference);
        });
        if (body) smt6a_cleanup(context, "ProSelectionFree(body)", [&] { return ProSelectionFree(&body); });
        if (model) smt6a_cleanup(context, "ProSelectionFree(model)", [&] { return ProSelectionFree(&model); });
    }
};

struct Smt6aDetachedElement {
    Smt6aContext& context;
    ProElement value = nullptr;
    explicit Smt6aDetachedElement(Smt6aContext& c) noexcept : context(c) {}
    Smt6aDetachedElement(const Smt6aDetachedElement&) = delete;
    Smt6aDetachedElement& operator=(const Smt6aDetachedElement&) = delete;
    ~Smt6aDetachedElement() noexcept
    {
        if (value) smt6a_cleanup(context, "ProElementFree(detached)", [&] {
            return ProElementFree(&value);
        });
    }
};

template<class SetValue>
bool smt6a_add_child(Smt6aPreparedTree& tree, ProElemId id, SetValue set_value)
{
    Smt6aContext& c = tree.context;
    Smt6aDetachedElement child(c);
    const int element_id = static_cast<int>(id);
    if (smt6a_sdk(c, "ProElementAlloc(child)", [&] {
            return ProElementAlloc(id, &child.value);
        }, element_id) != PRO_TK_NO_ERROR || !child.value || !set_value(child.value, element_id)) {
        return false;
    }
    if (smt6a_sdk(c, "ProElemtreeElementAdd", [&] {
            return ProElemtreeElementAdd(tree.root, nullptr, child.value);
        }, element_id) != PRO_TK_NO_ERROR) {
        return false;
    }
    child.value = nullptr; // Ownership transferred to the root on success.
    return true;
}

bool smt6a_wrap_selections(Smt6aPreparedTree& tree, ProMdl model, ProSolidBody& body)
{
    Smt6aContext& c = tree.context;
    if (body.owner != model) return false;
    ProModelitem item = {};
    if (smt6a_sdk(c, "ProMdlToModelitem", [&] {
            return ProMdlToModelitem(model, &item);
        }) != PRO_TK_NO_ERROR ||
        smt6a_sdk(c, "ProSelectionAlloc(model)", [&] {
            return ProSelectionAlloc(nullptr, &item, &tree.model);
        }) != PRO_TK_NO_ERROR || !tree.model) {
        return false;
    }
    static_assert(std::is_same<ProSolidBody, ProModelitem>::value,
        "Verify the supplied Creo 13.4 ProObjects.h typedefs");
    return smt6a_sdk(c, "ProSelectionAlloc(body)", [&] {
        return ProSelectionAlloc(nullptr, &body, &tree.body);
    }) == PRO_TK_NO_ERROR && tree.body;
}

bool smt6a_prepare_tree(Smt6aPreparedTree& tree, ProSelection selected_face, double thickness_model)
{
    Smt6aContext& c = tree.context;
    if (smt6a_sdk(c, "ProSelectionToReference(body)", [&] {
            return ProSelectionToReference(tree.body, &tree.body_reference);
        }, PRO_E_SMT_CONV_BODY) != PRO_TK_NO_ERROR || !tree.body_reference ||
        smt6a_sdk(c, "ProSelectionToReference(face)", [&] {
            return ProSelectionToReference(selected_face, &tree.face_reference);
        }, PRO_E_SMT_DRV_SURF) != PRO_TK_NO_ERROR || !tree.face_reference ||
        smt6a_sdk(c, "ProArrayAlloc(options)", [&] {
            return ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1,
                reinterpret_cast<ProArray*>(&tree.options));
        }) != PRO_TK_NO_ERROR || !tree.options ||
        smt6a_sdk(c, "ProElementAlloc(root)", [&] {
            return ProElementAlloc(PRO_E_FEATURE_TREE, &tree.root);
        }, PRO_E_FEATURE_TREE) != PRO_TK_NO_ERROR || !tree.root) {
        return false;
    }
    tree.options[0] = PRO_FEAT_CR_NO_OPTS;

    auto integer = [&](ProElemId id, int value) {
        return smt6a_add_child(tree, id, [&](ProElement elem, int element_id) {
            return smt6a_sdk(c, "ProElementIntegerSet", [&] {
                return ProElementIntegerSet(elem, value);
            }, element_id) == PRO_TK_NO_ERROR;
        });
    };
    auto reference = [&](ProElemId id, ProReference value) {
        return smt6a_add_child(tree, id, [&](ProElement elem, int element_id) {
            return smt6a_sdk(c, "ProElementReferenceSet", [&] {
                return ProElementReferenceSet(elem, value);
            }, element_id) == PRO_TK_NO_ERROR;
        });
    };
    return integer(PRO_E_FEATURE_TYPE, PRO_FEAT_DATUM_SURF) &&
        smt6a_add_child(tree, PRO_E_STD_FEATURE_NAME, [&](ProElement elem, int id) {
            wchar_t name[] = L"SMT_CONV_DRIVING";
            return smt6a_sdk(c, "ProElementWstringSet", [&] {
                return ProElementWstringSet(elem, name);
            }, id) == PRO_TK_NO_ERROR;
        }) &&
        integer(PRO_E_DTM_SRF_TYPE, PRO_DTM_SRF_AS_WALL) &&
        reference(PRO_E_SMT_CONV_BODY, tree.body_reference) &&
        reference(PRO_E_SMT_DRV_SURF, tree.face_reference) &&
        smt6a_add_child(tree, PRO_E_STD_SMT_THICKNESS, [&](ProElement elem, int id) {
            return smt6a_sdk(c, "ProElementDecimalsSet", [&] {
                return ProElementDecimalsSet(elem, 9);
            }, id) == PRO_TK_NO_ERROR &&
                smt6a_sdk(c, "ProElementDoubleSet", [&] {
                    return ProElementDoubleSet(elem, thickness_model);
                }, id) == PRO_TK_NO_ERROR;
        });
}

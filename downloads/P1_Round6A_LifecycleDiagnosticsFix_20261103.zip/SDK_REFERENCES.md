# 本次小修补充

本轮没有新增SDK接口。诊断复用既有getptr反射；列表追踪/分类均为Java辅助方法。曲面原生体归属、自动单位读取、对话框选项工厂等缺签名事项仍未实现。下面保留6A基线的依据索引，其本机编译报告不代表本次编译通过。

# 6A 签名依据索引

下列均来自用户离线输入，不是本助手执行javap的结果。Java编译/SDK载入/真机结果均未产生。

| 本候选使用点 | 输入文件/证据 |
|---|---|
| WPart extends WSolid, Part | javap-key/WPart.txt |
| 两个内部adapter的(long)构造器 | javap-key/internal_WPart.txt、internal_WSolid.txt（package-private class、public constructor，需setAccessible） |
| 原始指针getptr() | javap-key/jxobject_i.txt；public long getptr() |
| GetDefaultBody/Model方法实现 | javap-key/internal_WPart.txt；另见输入current-source已有调用 |
| WSession.CreateElementTree(Elements) | javap-key/WSession.txt |
| Elements.create/append | javap-key/Elements.txt |
| Element_Create(int,ArgValue,int) | javap-key/wfcElementTreeStatic.txt |
| CreateInt/Double/String/SelectionArgValue | javap-key/pfcArgument.txt |
| FeatureType.FEATTYPE_DATUM_SURFACE/getValue | javap-key/FeatureType.txt |
| CreateModelItemSelection(ModelItem,ComponentPath) | javap-key/pfcSelect.txt |
| Selection.GetSelItem/GetSelModel | javap-key/Selection.txt |
| Selections.getarraysize/get | javap-key/Selections.txt |
| GetCurrentSelectionBuffer、UIReadRealMessage(double,double)、UIShowMessageDialog(String,MessageDialogOptions)、UICreateCommand | javap-key/SessionUI.txt |
| SelectionBuffer.GetContents | 02_SDK关键签名摘要.md第5节（未另附SelectionBuffer原始转储） |
| Surface.GetSurfaceType/GetIsVisible/EvalArea | javap-key/Surface.txt |
| SolidBody.IsSheetmetal/ListSurfaces | javap-key/SolidBody.txt |
| WCreateFeature(ElementTree,FeatCreateOptions,WRegenInstructions)、WRegenerate | javap-key/WSolid.txt |
| FeatCreateOptions.create/append/FEAT_CR_NO_OPTS | javap-key/FeatCreateOptions.txt、FeatCreateOption.txt |
| WRegenInstructions_Create() | javap-key/WRegenInstructionsFactory.txt |
| WFeature继承Feature/ModelItem；GetId/GetName | javap-key/WFeature.txt + 输入current-source已有调用；未新增访问器 |
| 七个wfcElemIds及数值/level | 04_驱动面元素树与验收规则.md第1节 + 输入current-source已有常量；未另附wfcElemIds转储 |
| UICommand.Designate/SetIcon/RemoveActionListener、原三个页面命令、窗口导航 | 输入current-source已有实现；未凭空新增UICommand方法 |
| WSession内部包装(long) | 仅输入current-source/createWfcSession已有反射路径；缺internal_WSession转储，仍需本机补证 |

## 本轮没有据此推断的语义

- 内部适配器在真实pfcPart$Part上的有效性和所有权/生命周期。
- MessageDialogOptions的工厂/默认枚举；本候选未发明工厂，null接受度需本机验证。
- UIReadRealMessage两个double参数的名称、取消时异常类型或非数字处理细节。
- 模型单位查询/换算方法；6A须人工确认mm模型，不把输入单位当已自动验证。
- 材料侧/切换侧/圆角的枚举值；没有加入这些节点。
- 原有UICommand重复加载/解除的真实运行时语义；只保留原路径并统一追踪新监听器。

README中的本机验收清单用于确认以上行为；没有提供编译/真机成功记录。

"use strict";
/* 装配工具：批量重命名。只处理当前激活装配体，不包含钣金或更新逻辑。 */
(function () {
  const core = window.SiswCore;
  const el = core.el;
  const ApiError = core.ApiError;
  const audit = core.audit;

  let rows = [];
  let plan = null;
  let busy = false;
  let guardBlocked = false;

  const ids = ["mode", "prefix", "startNum", "digits", "suffix", "onlyPrt"];
  core.bindStatus(el("status"));
  core.onAuditChange = () => { el("logBtn").disabled = busy || !core.events.length; };

  function syncButtons() {
    for (const id of ids) el(id).disabled = busy || guardBlocked;
    el("saveDisk").disabled = busy || guardBlocked;
    el("previewBtn").disabled = busy || guardBlocked;
    el("executeBtn").disabled = busy || guardBlocked || !plan || !rows.some(r => r.included && !r.reason);
    el("logBtn").disabled = busy || guardBlocked || !core.events.length;
    for (const check of document.querySelectorAll(".include-row")) {
      check.disabled = busy || guardBlocked || !plan || check.dataset.blocked === "true";
    }
  }

  function setBusy(value) {
    busy = value;
    core.setBusy(value);
    syncButtons();
  }

  function applyModeGuard() {
    if (new URLSearchParams(location.search).get("guard") !== "need_assembly") return false;
    guardBlocked = true;
    core.setStatus("当前不是装配体 .asm；批量重命名只在装配界面可用，请先打开装配体。", "err");
    syncButtons();
    return true;
  }

  function invalidate() {
    if (busy || guardBlocked) return;
    plan = null;
    rows = [];
    render();
    syncButtons();
    core.setStatus("命名规则已改变，请重新生成预览。");
  }

  function onModeChange() {
    const mode = el("mode").value;
    el("rowPrefix").style.display = mode === "suffix" ? "none" : "flex";
    el("rowSuffix").style.display = mode === "prefix" ? "none" : "flex";
  }

  function readOptions() {
    const options = {
      mode: el("mode").value,
      prefix: el("prefix").value,
      suffix: el("suffix").value,
      onlyPrt: el("onlyPrt").checked,
      start: Number(el("startNum").value),
      digits: Number(el("digits").value)
    };
    if (!["prefix", "suffix", "both"].includes(options.mode)) throw new Error("未知命名模式");
    if (options.mode !== "suffix") {
      if (!el("startNum").value.trim() || !Number.isSafeInteger(options.start) || options.start < 0)
        throw new Error("起始序号必须为非负整数");
      if (!el("digits").value.trim() || !Number.isInteger(options.digits) || options.digits < 1 || options.digits > 12)
        throw new Error("位数必须为 1～12 的整数");
      if (!validNamePart(options.prefix)) throw new Error("前缀含不支持的字符");
    }
    if (options.mode !== "prefix" && !validNamePart(options.suffix))
      throw new Error("后缀含不支持的字符");
    return Object.freeze(options);
  }

  // Creo 允许字母、数字、下划线、连字符和多字节字符（含中文）；拒绝空格与标点/特殊符号。
  function validNamePart(text) {
    return text.length > 0 && !new RegExp("[\\s\\[\\]{}()$&'*+,/:<=>\\\\^`|@#%?!.;]").test(text);
  }

  function newName(file, index, options) {
    const match = /^(.+)\.(prt|asm)$/i.exec(file);
    if (!match) throw new Error(`不支持的模型名称：${file}`);
    let base;
    if (options.mode === "suffix") base = match[1] + options.suffix;
    else {
      const number = options.start + index;
      if (!Number.isSafeInteger(number) || number >= 10 ** options.digits) throw new Error("序号超出指定位数");
      base = options.prefix + String(number).padStart(options.digits, "0");
      if (options.mode === "both") base += options.suffix;
    }
    if (!/^[A-Za-z0-9_一-龥-]{1,31}$/.test(base)) throw new Error("新模型主体名必须为 1～31 位，支持中文、英文、数字、下划线或连字符");
    return `${base}.${match[2]}`;
  }

  function collect(bom, options) {
    if (!bom || !bom.children || Array.isArray(bom.children)) throw new Error("BOM 未返回有效根节点");
    const root = bom.children;
    if (typeof root.file !== "string") throw new Error("BOM 根节点缺少 file");
    const seen = new Set([root.file.toLowerCase()]);
    const output = [];
    const visit = node => {
      if (!node || typeof node.file !== "string") throw new Error("BOM 节点缺少 file");
      const key = node.file.toLowerCase();
      if (/\.(prt|asm)$/i.test(node.file) && (!options.onlyPrt || /\.prt$/i.test(node.file)) && !seen.has(key)) {
        seen.add(key);
        output.push({ oldName: node.file, path: node.path || [], newName: "", included: true, reason: "", state: "待执行" });
      }
      if (node.children !== undefined && !Array.isArray(node.children)) throw new Error("BOM 子节点不是列表");
      for (const child of node.children || []) visit(child);
    };
    if (root.children !== undefined && !Array.isArray(root.children)) throw new Error("BOM 根节点 children 不是列表");
    for (const child of root.children || []) visit(child);
    return output;
  }

  function signature(bom) {
    const visit = node => ({ file: node.file, path: node.path || [], children: (node.children || []).map(visit) });
    return JSON.stringify(visit(bom.children));
  }

  async function getBom(rootFile) {
    return await core.call("bom", "get_paths", {
      file: rootFile, paths: true, skeletons: true,
      top_level: false, exclude_inactive: false
    });
  }

  async function sessionFiles() {
    const result = await core.call("file", "list");
    if (!result || !Array.isArray(result.files) || result.files.some(f => typeof f !== "string"))
      throw new Error("会话文件列表格式无效");
    return result.files;
  }

  async function preview() {
    if (busy || guardBlocked) return;
    plan = null;
    rows = [];
    core.events.length = 0;
    render();
    setBusy(true);
    try {
      const options = readOptions();
      await core.ensureSession();
      core.setStatus("读取装配树及会话冲突…");
      const active = await core.call("file", "get_active");
      if (!active || typeof active.file !== "string" || !/\.asm$/i.test(active.file))
        throw new Error("请先激活一个装配体 .asm");
      const bom = await getBom(active.file);
      if (bom.children.file.toLowerCase() !== active.file.toLowerCase()) throw new Error("激活模型与 BOM 不一致");
      const candidates = collect(bom, options);
      const names = new Set((await sessionFiles()).map(f => f.toLowerCase()));
      const reserved = new Set();
      for (let i = 0; i < candidates.length; i++) {
        const row = candidates[i];
        try {
          row.newName = newName(row.oldName, i, options);
          const target = row.newName.toLowerCase();
          if (target === row.oldName.toLowerCase()) row.reason = "名称相同，无需改名";
          else if (names.has(target) || reserved.has(target)) row.reason = "会话目标名已存在或计划重名";
          if (!row.reason) reserved.add(target);
        } catch (error) { row.reason = error.message; }
        row.included = !row.reason;
      }
      rows = candidates;
      plan = { root: active.file, signature: signature(bom), options };
      audit("preview", { root: active.file, options, rows: rows.map(r => ({ ...r })) });
      render();
      core.setStatus(`预览完成：${rows.length} 个唯一模型，可执行 ${rows.filter(r => r.included).length} 个。`, "ok");
    } catch (error) {
      plan = null;
      core.setStatus(`预览失败：${error.message}`, "err");
    } finally {
      setBusy(false);
    }
  }

  function render() {
    const div = el("tree");
    div.replaceChildren();
    if (!rows.length) return;
    const table = document.createElement("table");
    const header = document.createElement("tr");
    for (const name of ["执行", "#", "旧名", "新名", "状态 / 原因"]) {
      const th = document.createElement("th");
      th.textContent = name;
      header.appendChild(th);
    }
    table.appendChild(header);
    rows.forEach((row, index) => {
      const tr = document.createElement("tr");
      const cell = document.createElement("td");
      const check = document.createElement("input");
      check.type = "checkbox";
      check.className = "include-row";
      check.checked = row.included;
      check.dataset.blocked = String(!!row.reason);
      check.disabled = !!row.reason || busy || !plan;
      check.setAttribute("aria-label", `执行 ${row.oldName}`);
      check.addEventListener("change", () => {
        if (plan && !busy && !row.reason) {
          row.included = check.checked;
          syncButtons();
        }
      });
      cell.appendChild(check);
      tr.appendChild(cell);
      for (const text of [String(index + 1), row.oldName, row.newName, row.reason || row.state]) {
        const td = document.createElement("td");
        td.textContent = text;
        tr.appendChild(td);
      }
      table.appendChild(tr);
    });
    div.appendChild(table);
  }

  async function execute() {
    if (busy || guardBlocked) return;
    if (!plan) { core.setStatus("请先生成有效预览。", "err"); return; }
    const count = rows.filter(r => r.included && !r.reason).length;
    if (!count) { core.setStatus("没有勾选可执行项。", "err"); return; }
    if (!confirm(`确认按预览对照表重命名 ${count} 个模型？将请求 onlysession，会话改名后另行保存可能写入磁盘。请确认正在操作测试副本，并已人工排除不应改名的模型。`)) return;
    const frozenPlan = plan;
    setBusy(true);
    let aborted = "";
    try {
      const active = await core.call("file", "get_active");
      if (!active || active.file.toLowerCase() !== frozenPlan.root.toLowerCase()) throw new Error("激活装配已变化，请重新预览");
      const currentBom = await getBom(frozenPlan.root);
      if (signature(currentBom) !== frozenPlan.signature) throw new Error("组件树或模型名称已变化，请重新预览");
      audit("execute_start");
      let done = 0;
      for (const row of rows) {
        if (row.reason || !row.included) {
          row.state = "跳过";
          audit("skip", { oldName: row.oldName, newName: row.newName, reason: row.reason || "用户排除" });
          continue;
        }
        let renameDispatched = false;
        try {
          audit("rename_intent", { oldName: row.oldName, newName: row.newName });
          renameDispatched = true;
          await core.call("file", "rename", { file: row.oldName, new_name: row.newName, onlysession: true });
          row.state = "成功";
          audit("success", { oldName: row.oldName, newName: row.newName });
        } catch (error) {
          if (renameDispatched) error = new ApiError(`改名已提交，实际结果需核查：${error.message}`, true);
          row.state = error.uncertain ? "待核查" : "失败";
          audit(row.state === "待核查" ? "uncertain" : "failure", { oldName: row.oldName, newName: row.newName, error: error.message });
          if (error.uncertain) {
            aborted = `请求结果不确定，已停止后续操作：${error.message}。请在 Creo 中核查，不要直接重试。`;
            break;
          }
        }
        done++;
        if (done % 10 === 0) core.setStatus(`改名中 ${done}/${rows.length}...`);
      }
      core.setStatus(`改名完成，共 ${rows.filter(r => r.state === "成功").length} 个`);
      if (el("saveDisk").checked) {
        const saveStart = Date.now();
        const saveTimer = setInterval(() => {
          const seconds = Math.floor((Date.now() - saveStart) / 1000);
          core.setStatus(`正在批量保存到磁盘，已耗时 ${seconds} 秒；Creo 窗口短暂未响应属于正常现象，请勿关闭。`);
        }, 1000);
        try {
          const active = await core.call("file", "get_active");
          await core.call("file", "save", { file: active.file }, 600000);
          const elapsed = Math.round((Date.now() - saveStart) / 1000);
          audit("save_success", { file: active.file, elapsedSeconds: elapsed });
          core.setStatus(`保存完成，耗时 ${elapsed} 秒。`);
        } catch (error) {
          audit("save_failure", { error: error.message });
          aborted = `保存阶段失败：${error.message}`;
          throw error;
        } finally {
          clearInterval(saveTimer);
        }
      }
    } catch (error) {
      aborted = error.message;
      audit("aborted", { error: error.message });
    } finally {
      plan = null;
      for (const row of rows) if (row.state === "待执行") row.state = "未执行";
      const ok = rows.filter(r => r.state === "成功").length;
      const fail = rows.filter(r => r.state === "失败" || r.state === "待核查").length;
      const skip = rows.length - ok - fail;
      audit("summary", { success: ok, skippedOrNotRun: skip, failedOrUncertain: fail, aborted });
      render();
      setBusy(false);
      core.setStatus(`完成：成功 ${ok}，跳过/未执行 ${skip}，失败/待核查 ${fail}。${aborted} 可下载本次日志。`, fail || aborted ? "err" : "ok");
    }
  }

  function downloadLog() {
    core.downloadLog("creo_rename");
  }

  function initStoredOptions() {
    for (const id of ids) {
      const saved = core.storage.get("rename_" + id);
      if (saved !== null) el(id).value = saved;
    }
    el("saveDisk").checked = core.storage.get("rename_saveDisk") === "1";
  }

  async function connectOnStartup() {
    if (guardBlocked) {
      syncButtons();
      return;
    }
    setBusy(true);
    core.setStatus("正在自动连接 CREOSON…");
    try {
      await core.connectSession();
      audit("connected", { sessionId: core.sessionId });
      core.setStatus("已连接，请生成预览。", "ok");
    } catch (error) {
      audit("connect_failed", { error: error.message });
      core.setStatus(`未连接：${error.message}。点击生成预览时会自动重试。`, "err");
    } finally {
      setBusy(false);
    }
  }

  for (const id of ids) {
    el(id).addEventListener("input", () => {
      onModeChange();
      invalidate();
      core.storage.set("rename_" + id, el(id).value);
    });
  }
  el("saveDisk").addEventListener("change", () => {
    core.storage.set("rename_saveDisk", el("saveDisk").checked ? "1" : "0");
  });
  el("previewBtn").addEventListener("click", preview);
  el("executeBtn").addEventListener("click", execute);
  el("logBtn").addEventListener("click", downloadLog);

  initStoredOptions();
  applyModeGuard();
  connectOnStartup();
  onModeChange();
  syncButtons();
})();

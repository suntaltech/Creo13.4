"use strict";
/* 零件工具：当前激活零件钣金适用性只读分析。
   说明：Creo 13.4 同步 J-Link 的 AddBrowserMessageListener 会长期占用 CIP 原生通道，
   因此本版本不通过原生桥接执行破坏性转换；分析数据走 CREOSON HTTP，转换按钮保持禁用待安全通道验收。 */
(function () {
  const core = window.SiswCore;
  const el = core.el;
  const audit = core.audit;

  const nativeConvertReady = false; // 仅指网页写通道；6A原生命令独立验证。
  let smtAnalysis = null;
  let busy = false;
  let blocked = false;

  function syncButtons() {
    el("smtAnalyzeBtn").disabled = busy || blocked;
    el("smtConvertBtn").disabled = true;
    document.querySelectorAll("input[name='smtMode']").forEach(radio => radio.disabled = true);
    el("smtThickness").disabled = true;
    el("smtSave").disabled = true;
    el("smtSave").checked = false;
  }

  function setBusy(value) {
    busy = value;
    core.setBusy(value);
    syncButtons();
  }

  function setSmtStatus(message, kind = "info") {
    el("smtStatus").textContent = message;
    el("smtStatus").className = kind;
  }

  function applyModeBlock() {
    const params = new URLSearchParams(location.search);
    if (params.get("guard") === "need_part") {
      blocked = true;
      setSmtStatus("当前不是零件 .prt；实体转钣金分析只在普通零件界面可用，装配和工程图请使用对应功能。", "err");
      el("smtResult").textContent = "模式不匹配：本页面不会执行转换。";
    } else if (params.get("state") === "sheetmetal") {
      blocked = true;
      smtAnalysis = { sheetmetal: true, largestPlane: null };
      setSmtStatus("当前零件已是钣金，无需重复转换；本页面仅作状态提示，转换按钮保持禁用。", "ok");
      el("smtResult").textContent = "状态：已是钣金零件。";
    }
    syncButtons();
  }

  function selectedSmtMode() {
    const selected = document.querySelector("input[name='smtMode']:checked");
    return selected ? selected.value : "driving";
  }

  function currentDesiredThickness() {
    const value = Number.parseFloat(el("smtThickness").value);
    return Number.isFinite(value) && value > 0 ? value : null;
  }

  function formatLength(value) {
    return typeof value === "number" && Number.isFinite(value) && value > 0 ? `${value.toFixed(3)} mm` : "未取得";
  }

  function formatArea(value) {
    return typeof value === "number" && Number.isFinite(value) && value > 0 ? `${value.toFixed(3)} mm²` : "未识别";
  }

  function formatThickness(value) {
    return typeof value === "number" && Number.isFinite(value) && value > 0 ? `${value.toFixed(3)} mm` : "未估算";
  }

  function surfaceSpan(surface, axis) {
    const min = surface?.min_extent?.[axis];
    const max = surface?.max_extent?.[axis];
    if (typeof min !== "number" || typeof max !== "number") return NaN;
    return Math.abs(max - min);
  }

  function isPlanarSurface(surface) {
    const tolerance = 0.01;
    return ["x", "y", "z"].some(axis => {
      const span = surfaceSpan(surface, axis);
      return Number.isFinite(span) && span <= tolerance;
    });
  }

  function renderSmtAnalysis(data) {
    smtAnalysis = data;
    const plane = data.largestPlane;
    const spans = data.spans || {};
    const lines = [
      `模型：${data.model || "未知"}`,
      `当前状态：${data.sheetmetal ? "已是钣金零件" : "普通实体零件（待人工确认转换方式）"}`,
      `曲面数量：${data.surfaceCount ?? "未知"}；启发式包络候选数（非原生平面类型）：${data.planeCount ?? "未知"}`,
      `最大包络候选（仅提示，不用于原生命令选面）：${plane ? `曲面 ID ${plane.id}，面积 ${formatArea(plane.area)}` : "未找到稳定候选平面"}`,
      `包围尺寸：X ${formatLength(spans.x)}；Y ${formatLength(spans.y)}；Z ${formatLength(spans.z)}`,
      `薄向尺寸估算：${formatThickness(data.estimatedThickness)}`,
      `指定转换板厚：${formatThickness(currentDesiredThickness())}（待原生通道启用后作为正式壁厚参数）`,
      `建议人工方式：${data.suggestedMode === "shell" ? "抽壳（块状实体）" : "驱动曲面（等厚薄板）"}`
    ];
    if (!data.sheetmetal) {
      lines.push("注意：当前版本只做只读分析；自动转换按钮保持禁用，避免阻塞 Creo 13.4 同步会话。");
    }
    el("smtResult").textContent = lines.join("\n");
    if (data.sheetmetal) {
      setSmtStatus("当前零件已经是钣金，无需重复转换。", "ok");
    } else if (!plane) {
      setSmtStatus("分析完成，但未找到稳定候选平面；请人工判断是否适合自动转换。", "err");
    } else {
      setSmtStatus("只读分析完成；自动转换待安全原生通道验收，当前不会修改模型。", "ok");
    }
    syncButtons();
  }

  async function smtAnalyze() {
    if (busy || blocked) return;
    setBusy(true);
    smtAnalysis = null;
    el("smtResult").textContent = "";
    setSmtStatus("正在通过 CREOSON 读取当前零件几何…", "info");
    try {
      await core.ensureSession();
      const info = await core.call("file", "get_fileinfo", {}, 60000);
      if (!info || typeof info.file !== "string" || !/\.prt$/i.test(info.file)) {
        throw new Error("当前激活模型不是 .prt 零件；请先打开普通零件");
      }

      const [features, surfaces, box] = await Promise.all([
        core.call("feature", "list", { status: "ACTIVE", no_comp: true, paths: true }, 60000),
        core.call("geometry", "get_surfaces", {}, 60000),
        core.call("geometry", "bound_box", {}, 60000)
      ]);

      const featureList = Array.isArray(features?.featlist) ? features.featlist : [];
      const sheetmetalType = /flat|wall|bend|relief|smt|钣金|壁|折弯/i;
      const sheetmetal = featureList.some(feature => sheetmetalType.test(String(feature.type || "")));

      const surfaceList = Array.isArray(surfaces?.surflist) ? surfaces.surflist : [];
      const candidates = surfaceList.filter(isPlanarSurface)
        .sort((left, right) => (right.area || 0) - (left.area || 0));
      const largest = candidates[0] || null;

      const spans = {
        x: Number(box?.xmax) - Number(box?.xmin),
        y: Number(box?.ymax) - Number(box?.ymin),
        z: Number(box?.zmax) - Number(box?.zmin)
      };
      const minSpan = Math.min(
        Math.max(0, Number.isFinite(spans.x) ? spans.x : 0),
        Math.max(0, Number.isFinite(spans.y) ? spans.y : 0),
        Math.max(0, Number.isFinite(spans.z) ? spans.z : 0)
      );
      const estimatedThickness = Number.isFinite(minSpan) && minSpan > 0 && minSpan <= 10 ? minSpan : null;

      const data = {
        model: info.file,
        sheetmetal,
        surfaceCount: surfaceList.length,
        planeCount: candidates.length,
        estimatedThickness,
        suggestedMode: estimatedThickness ? "driving" : "shell",
        largestPlane: largest ? { id: largest.surface_id, area: largest.area } : null,
        spans
      };
      audit("smt_analyze_http", {
        model: data.model,
        sheetmetal: data.sheetmetal,
        surfaceCount: data.surfaceCount,
        planeCount: data.planeCount
      });
      renderSmtAnalysis(data);
    } catch (error) {
      audit("smt_analyze_failed", { error: error.message });
      setSmtStatus(`分析失败：${error.message}`, "err");
    } finally {
      setBusy(false);
    }
  }

  async function smtConvert() {
    if (busy || blocked) return;
    if (!smtAnalysis) return;
    setBusy(true);
    try {
      audit("smt_convert_blocked", {
        model: smtAnalysis.model,
        nativeConvertReady,
        saved: false,
        mode: selectedSmtMode(),
        desiredThickness: currentDesiredThickness(),
        reason: "safe native conversion channel pending validation; no model modification"
      });
      setSmtStatus("指定板厚转换暂未开放：安全原生通道验收前不会修改模型；当前只保留板厚参数位和只读分析。", "err");
    } finally {
      setBusy(false);
    }
  }

  function initStoredOptions() {
    const savedMode = core.storage.get("smt_mode");
    if (savedMode === "driving" || savedMode === "shell") {
      document.querySelector(`input[name='smtMode'][value='${savedMode}']`).checked = true;
    }
    const savedThickness = Number.parseFloat(core.storage.get("smt_thickness") || "1.0");
    el("smtThickness").value = Number.isFinite(savedThickness) && savedThickness > 0 ? savedThickness : 1.0;
    el("smtSave").checked = false;
    core.storage.set("smt_save", "0");
  }

  document.querySelectorAll("input[name='smtMode']").forEach(radio => {
    radio.addEventListener("change", () => {
      smtAnalysis = null;
      syncButtons();
      core.storage.set("smt_mode", radio.value);
    });
  });
  el("smtThickness").addEventListener("change", () => {
    core.storage.set("smt_thickness", String(currentDesiredThickness() || 1.0));
  });
  el("smtSave").addEventListener("change", () => {
    el("smtSave").checked = false;
    core.storage.set("smt_save", "0");
  });
  el("smtAnalyzeBtn").addEventListener("click", smtAnalyze);
  el("smtConvertBtn").addEventListener("click", smtConvert);

  initStoredOptions();
  applyModeBlock();
  syncButtons();
})();

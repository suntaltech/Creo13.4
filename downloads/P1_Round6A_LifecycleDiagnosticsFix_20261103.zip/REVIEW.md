# 6A 生命周期与运行时诊断小修（2026-11-03）

本轮只完成用户确认的两项：注册失败清理、运行阶段诊断。基线为上一份6A候选最终源码，BatchRename.java SHA256为`2827ee878b484c0cd530d40c1372b15dcd5768074cbf92a3a5c02d7189beffdf`。不是第五轮或原始生产源码；不能直接把本增量补丁用于尚未应用6A的现场文件。

**本轮未执行javac/javap、node --check、Mock/Stub、HTTP或Creo操作。** 延续第六轮输入约束，仅生成源码、做文本静态核对和补丁字节复现。上一份审核报告记载的真实SDK编译通过属于旧6A基线，不是本次修改后的编译证据。

## 交付与应用

`P1_Round6A_LifecycleDiagnosticsFix.patch`仅修改BatchRename.java；包内web文件均与6A基线逐字节相同，便于检查，无页面或协议行为改动。包内没有class、jar、rbn、dat、bat或部署脚本，不是安装/发布包。tests/static_check.py仅做文本检查。

在6A源码的隔离副本核对input-sha256.json后，先 `git apply --check P1_Round6A_LifecycleDiagnosticsFix.patch`，通过后再apply。本助手已在精确基线应用并比对最终文件字节，但这不等于Java编译或运行验证。禁止覆盖现场class/web，Ribbon仍由本机加载确认后使用Creo原生界面手动导出。

## 1. 注册失败与追踪清理

原六轮是成对追加，不能据此断言已发生列表错位；可确认的问题是部分注册成功解除后仍留在停止追踪表，导致重复解除风险。

新增纯Java辅助方法：

- `trackCommand(UICommand, DefaultUICommandActionListener)`：检查两个列表等长，按Java引用身份配对，不调用SDK equals。若listener入表发生unchecked异常，回撤本次command追加。相同pair重复跟踪不重复追加；不同pair身份冲突拒绝。
- `untrackCommand(...)`：按同一索引、相同Java引用身份成对摘除，不按可能有原生语义的equals搜索。不存在pair时不影响原三对；发现不一致不擅自移除其他项。

`registerConversionCommand()`改为UICreate → Designate → 可选图标 → 成对跟踪 → listener.enabled=true。异常先禁用新listener，再尝试原生解除；**仅解除成功时摘除追踪，只有解除失败/结果不确定时才保留禁用pair供stop重试**。SDK在抛异常前是否已解除无法由代码证明，所以异常路径可能重试，不能宣传绝对“只调用一次”。

原三个页面命令的成功入表也使用trackCommand，注册/导航/消息键等不改。原detach循环、逐项异常处理、清空引用仍保留；没有新增或猜测SDK的DeleteCommand/AddActionListener等API。

### 需本机验证的失败注入表（未执行）

| 情况 | 源码设计预期 |
|---|---|
| UICreate抛异常或返回null | 新命令不启用，原三对保留；没有可解除的新对象 |
| Designate失败，RemoveActionListener成功 | 新pair不留表，stop不重复解除该新pair |
| Designate失败，RemoveActionListener失败 | 新listener禁用，成对保留，stop再尝试解除 |
| 入表后发生异常，解除成功 | 按同一索引摘除，原三对顺序不变 |
| 入表后解除失败 | 原pair幂等保留，不重复追加；listener禁用 |
| SetIcon失败 | 只记录图标错误，不阻断正常命令注册 |
| 正常注册/stop | 新增pair与原三对一起由既有detach遍历 |

这些是控制流推导，不是已执行的故障注入结果。致命内存错误、外部并发或SDK不确定解除行为不被伪装为完全解决；真实UI/命令回调生命周期仍须本机核验。

## 2. 运行诊断字段

新增 `recordNativeObject(trace,key,object)`：只读取Java类名和已有getptr反射结果，记录Present/Class/Pointer或PointerUnavailable/PointerErrorClass。指针用十六进制字符串展示。**诊断getptr失败只记录，不改变已有转换校验/结果**；原本用于模型身份/包装的严格nativePointer检查不放宽。

新增或补强：

- `modelObject`、`solidView`、`wfcSession`的实际类和指针；solidAdapterRoute记录已是WSolid或实际命中的两级adapter类；sessionAdapterRoute记录已有、反射或缓存路径。
- `defaultBody`、`selectedFace`、`listedBodySurface`、`defaultBodyAfterInput`、`bodyAfterRegeneration`的类/指针。
- `element_tree/dispatching`在CreateElementTree之前，返回后记录elementTree对象信息；drivingNodeCount=7表示本代码提交的节点数，不是SDK树内部诊断结果。
- `feature_create/dispatching`与返回对象信息、featureReturnState；modelMayHaveChanged标记紧贴真正的创建调用之前设置，诊断日志准备失败不被当成已提交创建。
- `regenerate/dispatching`、returned与regenerationReturned；状态读取前/后的对象和sheetmetalReadback（默认体为空时为null，不冒充已读取false）；最后才记录真实GetId/GetName。
- 异常增加failedPhase、exceptionClass和completionClass，并保留原EXCEPTION堆栈与elapsedMs。没有生成本机日志或模拟特征ID。

### completionClass语义

| 字段值 | 仅在真实执行到相应条件时记录 |
|---|---|
| CREATE_NOT_DISPATCHED | 未进入创建调用 |
| INPUT_CANCELLED_CREATE_NOT_DISPATCHED | 输入null取消，未提交创建 |
| CREATE_DISPATCHED_RESULT_UNVERIFIED | 创建调用已进入，尚无已确认返回特征 |
| FEATURE_RETURNED_REGEN_UNVERIFIED | 有返回特征，重生成未确认完成 |
| REGEN_RETURNED_NOT_SHEETMETAL | 重生成返回且IsSheetmetal明确回读false |
| REGEN_RETURNED_SHEETMETAL_UNVERIFIED | 重生成返回，但钣金状态未取得（如默认体为空或读取异常） |
| SHEETMETAL_CONFIRMED_FEATURE_INFO_INCOMPLETE | 状态为钣金，特征信息回读不完整 |
| VERIFIED_CONVERSION_NOT_SAVED | 创建、重生成、状态、特征ID/名称全部满足原成功条件；仍未Save |

这些是日志分类代码，不是本轮真实执行结果。失败没有自动重试、回滚或保存，不把返回对象/端口/适配器构造本身当作成功证据。

## 3. 未扩展的原生能力

- `verifyFaceInDefaultBody`依旧是默认body曲面ID匹配，保留原GetSelModel身份及可见性/平面校验。新增matched surface指针及selectedAndListedPointerEqual只是诊断，**不是UV/ComponentPath/原生实体归属证明**。faceMembershipProof明确标注native owner API未提供。未编造GetSurfaceSolidBody。
- `unitCheck`明确未自动校验，测试仍限定人工确认mm的零件；不新增单位API或静默换算。
- `UIShowMessageDialog(message,null)`仍按基线，Options工厂/默认选项语义待补签名；输入取消的SDK异常形态也未猜测。
- 7个driving节点、FEAT_CR_NO_OPTS和默认重生成指令不变，材料侧/切换侧/失败特征诊断API均未补证，未改枚举或添加树节点。
- 页面模式守卫中的WFC包装、服务单次后台拉起、同步文件日志与之前6A相同；这不是对报告全部P1/P2问题的闭环。不增加shell、A4、Save或网页写入口。

## 4. 静态记录与验证边界

tests/static_check.py检查Java词法括号、既有红线、唯一写调用链、7节点、浏览器关闭；本次增加Designate先于跟踪、配对追加/回撤及失败清理路径、诊断字段等文本检查。evidence/static-analysis.json记录实际文本检查结果，**不证明Java类型/SDK/运行时有效**。

所有网页与6A基线哈希相同；旧的SDK签名仍为reference/javap-key转储。本轮新增的方法均为私有Java辅助方法，没有新SDK方法或常量名；原getptr已在提供的jxobject_i转储中。SDK_REFERENCES.md沿用基线索引，未决项仍未解决。

本轮编译退出码、class数量/major、Mock数量、真机特征ID/名称/状态都为未执行，不借用2026-11-03审核报告对旧基线的结果。

## 5. 本机后续命令（本助手未执行）

```powershell
& 'D:\creoson\jdk25\jdk-25.0.5+8\bin\javac.exe' --release 17 -encoding UTF-8 `
  -cp 'D:\Program Files\PTC\Creo 13.4.0.0\Common Files\text\java\otk.jar' `
  -d '<新的暂存目录>' '<本次小修源码副本>\BatchRename.java'
```

唯一同步otk.jar，不混pfcasync.jar，不编译/部署tests；目标major61是预期，不是本次实测。源码编译/静态审核完成并取得用户同意后，本机再安排失败注册清理、adapter/body/face日志、真实平面+正板厚的创建/重生成/状态回读及三页面回归。

本机记录至少包含实际adapter路径、body/face指针（或明确不可读原因）、CreateElementTree阶段、创建返回对象、重生成错误/返回、最终状态及特征信息。只收集真实日志，不填虚构示例。Ribbon可见性仍由Creo手动导出，未改二进制；运行class/Web未由本助手替换，不能宣称现场已升级或转换已验收。

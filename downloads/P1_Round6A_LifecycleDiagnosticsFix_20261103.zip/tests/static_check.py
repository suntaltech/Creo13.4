"""Text-only source checks. Does not invoke javac, javap, node, HTTP, SDK or Creo."""
from pathlib import Path
import argparse,json,re
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()

def clean(text,mask_literals=False):
    out=[];i=0
    while i<len(text):
        if text.startswith('//',i):
            end=text.find('\n',i);end=len(text) if end<0 else end
            out.append(' '*(end-i));i=end
        elif text.startswith('/*',i):
            end=text.find('*/',i+2)
            if end<0:raise ValueError('Unclosed comment')
            out.append(''.join('\n' if c=='\n' else ' ' for c in text[i:end+2]));i=end+2
        elif text[i] in ['"',"'",'`']:
            start=i;quote=text[i];i+=1
            while i<len(text):
                if text[i]=='\\':i+=2;continue
                if text[i]==quote:i+=1;break
                i+=1
            else:raise ValueError('Unclosed literal')
            literal=text[start:i];out.append(''.join('\n' if c=='\n' else ' ' for c in literal) if mask_literals else literal)
        else:out.append(text[i]);i+=1
    return ''.join(out)

def method_body(code,name):
    m=re.search(r'private static [^{;]+\b'+name+r'\([^;]*?\)\s*(?:throws [^{]+)?\{',code)
    if not m:raise ValueError('Method not found: '+name)
    start=m.end();depth=1;i=start
    while depth:
        if code[i]=='{':depth+=1
        elif code[i]=='}':depth-=1
        i+=1
    return code[start:i-1]

source=(a.root/'BatchRename.java').read_text();java=clean(source);masked=clean(source,True)
checks={}
stack=[];pairs={')':'(',']':'[','}':'{'}
for c in masked:
    if c in '([{':stack.append(c)
    elif c in ')]}':
        if not stack or stack.pop()!=pairs[c]:raise AssertionError('Unbalanced Java delimiters')
assert not stack
checks['javaLexicalDelimiters']='balanced; not compilation'
for name in ['Save','AddBrowserMessageListener']:
    assert not re.search(r'\.'+name+r'\s*\(',masked),name
for name in ['PRO_E_SMT_AUTOCALC_THICKNESS','PRO_E_SMT_NEW_BODY_LINKED','PRO_E_SMT_ADJACENT_RND_OPTS','PRO_E_SMT_KEEP_NOT_CLASS_SURFS','PRO_E_STD_MATRLSIDE','PRO_E_STD_SMT_SWAP_DRV_SIDE','PRO_E_SHELL_SRF']:
    assert name not in java,name
assert not re.search(r'\(\s*WSolid\s*\)\s*model\b',masked)
assert 'bridgeExecutor' not in java
assert not re.search(r'Thread\.sleep\s*\(|\.waitFor\s*\(',masked)
checks['forbiddenLegacyPaths']='absent in executable Java'
conversion=method_body(java,'convertPreselectedPlane')
expected=['PRO_E_FEATURE_TREE','PRO_E_FEATURE_TYPE','PRO_E_STD_FEATURE_NAME','PRO_E_DTM_SRF_TYPE','PRO_E_SMT_CONV_BODY','PRO_E_SMT_DRV_SURF','PRO_E_STD_SMT_THICKNESS']
assert re.findall(r'addElement\(elements,\s*wfcElemIds\.(\w+)',conversion)==expected
assert re.search(r'PRO_E_FEATURE_TREE,\s*null,\s*0\)',conversion)
assert conversion.count('CreateModelItemSelection(')==2
checks['drivingElements']=expected
assert java.count('.WCreateFeature(')==1 and java.count('.WRegenerate(')==1
assert conversion.index('CreateElementTree(')<conversion.index('WCreateFeature(')<conversion.index('WRegenerate(')<conversion.index('SolidBody convertedBody')<conversion.index('trace.put("featureName"')
assert re.search(r'UIReadRealMessage\(MIN_THICKNESS, MAX_THICKNESS\)',conversion)
assert 'if (entered == null) return null;' in conversion
assert 'count != 1' in conversion and 'instanceof Surface face' in conversion
assert 'SurfaceType.SURFACE_PLANE' in conversion
assert 'sameModel(model, selection.GetSelModel())' in conversion
assert len(re.findall(r'\bconvertPreselectedPlane\(',masked))==2
checks['callChain']='single private conversion call from native listener; static text inspection only'
background=method_body(java,'ensureCreosonRunningAsync')
for term in ['GetActiveModel','GetDefaultBody','WCreateFeature','WRegenerate','UIReadRealMessage','convertPreselectedPlane','wrapAsWSolid']:
    assert term not in background,term
for command in ['SISWBatchRename','SISWSheetMetal','SISWAbout','SISWSheetMetalConvert']:assert '"'+command+'"' in java
assert 'java.util.List<DefaultUICommandActionListener>' in java
assert 'registerConversionCommand();' in java
assert 'finally {\n                converting = false;' in java
assert 'commands.get(i).RemoveActionListener(listeners.get(i))' in java
bridge=method_body(java,'ensureSheetmetalBridgeAsync');assert 'wfcSession = null' not in bridge
checks['registrationAndDetach']='three page IDs retained; optional fourth tracked; bridge stub does not clear wrapper'
registration=method_body(java,'registerConversionCommand')
assert registration.index('command.Designate(')<registration.index('trackCommand(command, listener);')
assert 'commands.add(' not in registration and 'listeners.add(' not in registration
assert 'untrackCommand(command, listener)' in registration
assert 'if (listener != null) listener.enabled = false' in registration
tracking=method_body(java,'trackCommand')
assert 'commands.size() != listeners.size()' in tracking
assert 'commands.remove(index)' in tracking
assert 'commands.get(i) == command' in method_body(java,'untrackCommand')
for key in ['solidAdapterRoute','sessionAdapterRoute','defaultBody','selectedFace','elementTree','createdFeature','bodyAfterRegeneration','completionClass','failedPhase','unitCheck']:
    assert key in java,key
assert 'GETSURFACESOLIDBODY' not in masked.upper()
assert 'recordNativeObject' in conversion
checks['registrationFailureCleanup']='Designate precedes paired tracking; successful cleanup untracks; uncertain cleanup retains disabled pair'
checks['diagnosticFields']='adapter/object pointers and staged completion classification present; no native-owner API invented'
for n in ['core.js','sheetmetal.js']:
    js=clean((a.root/'web/assets/js'/n).read_text())
    assert not re.search(r'window\.external|\.ptc\s*\(',js)
smt=(a.root/'web/assets/js/sheetmetal.js').read_text();assert '.bridgeCall(' not in clean(smt)
assert 'nativeConvertReady = false' in smt
html=(a.root/'web/sheetmetal.html').read_text();assert 'SISWSheetMetalConvert' in html
checks['web']='browser writes blocked; native candidate hint only'
result={'kind':'static_source_inspection_only','checks':checks,'javaCompile':'not_run_per_task','javap':'not_run; supplied text inspected','nodeCheck':'not_run_per_task','mockTests':'not_run_per_task','creoRuntime':'not_run'}
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('Static source checks completed; NOT a compile or runtime result')

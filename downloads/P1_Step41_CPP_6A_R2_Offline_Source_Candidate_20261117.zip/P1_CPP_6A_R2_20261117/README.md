# C++ 6A R2 驱动面转换离线源码候选

日期：2026-11-17。状态：**源码候选，待本机编译、链接和受控真机验收**。与上一首段候选不同，本版已接通会修改模型的创建/重生成链路，但云端未编译、运行或部署，也不宣称实际转钣金可用。不是正式发布包。

## 改动

基线为 R10 现场证据 src/entry.cpp，46,526B，SHA256 `6b7214d99cbe8d920c749bbe7417dc14363904833f6c72a4cf2ca7d256c53c1a`。entry.cpp 只增加头文件块、匿名 namespace 内两个 .inl 的 include、原 R10 初始化步骤之后的新注册调用。删除这三块可逐字节恢复基线。body_face_count → model_info → ping 的注册顺序、原回调/access、消息键、晚期 Find 快照和入口 ABI 均未改。

新增 p1_smt_drv_conv，消息文件 p1_smt_conv.txt，Designate 键为 P1_SMT_CONV_LABEL/HELP/DESC。新增注册失败或 C++ 异常仅记录，不改变初始化返回值。其 access 使用独立 AccessTrace，只采样内存；不查询模型、不弹窗、不写文件、不调用写模型接口。该命令能否出现在 TOOLKIT 定制列表仍待现场观察。

## 同步调用链

1. action 内取得当前模型、类型、名称、默认体和钣金状态。非零件、无体、查询失败、已是钣金均在写操作前结束。
2. ProSelect("surface",1,...) 交互取得一个面，复制 selection；核对 modelitem 类型与 owner。ProSolidBodySurfaceVisit + ProSurfaceIdGet 按 ID 检查默认体成员关系，不依赖不存在的曲面反查体接口。再用 ProSurfaceInit/TypeGet/AreaEval 校验平面并记录真实面积。
3. 使用任务单新增的**备选消息行输入**：先显示提示，再 ProMessageDoubleRead，单位明确为 mm，范围 0.1–20.0；ESC 正常结束。后端再检查有限数与范围。不拼装尚未验证的 double 对话框资源，也不以默认厚度代替输入。
4. 输入后重取当前模型、默认体和钣金状态，验证身份及面归属。ProMdlPrincipalunitsystemGet → ProUnitsystemUnitGet 取得当前长度单位，再 ProUnitInit("mm") 与 ProUnitConversionCalculate(mm,current)；正有限 scale、零 offset 才继续。没有调用 ProMdlUnitsCollect 选首项；mm 名称若不被模型识别，明确拒绝。
5. 独立构造 model/body selection 与 face copy，转换两个 ProReference。根加六个子节点严格使用任务单白名单。板厚先 DecimalsSet(9) 再 DoubleSet；options 为真实 ProArray，单项 PRO_FEAT_CR_NO_OPTS。
6. ProFeatureWithoptionsCreate 仅调用一次，flags=PRO_REGEN_NO_FLAGS。立即记录返回码与错误条目；失败不再使用 feature 对象。不使用内部 UNDO 选项，不猜测回滚。
7. 创建成功后再调用一次 ProSolidRegenerate(...,PRO_REGEN_NO_FLAGS)，作为显式同步后检步骤；不对 REGEN_AGAIN 自动循环。重新取默认体与 IsSheetmetal，检查仍是目标体，再读真实特征 ID、类型和名称。任一步失败不报业务成功。
8. SUCCESS_UNSAVED 的条件为创建、显式重生成、目标体钣金状态、特征身份/名称回读全部通过。Creo 消息分行显示状态、厚度/ID、模型名和特征名；JSONL 记录完整结果。界面反馈失败与业务结果分开记录，不因消息失败重复创建。所有路径均无 Save。

## 日志与失败语义

沿用 R10 trace_event 外层 PID/TID/load_token/seq/UTC，新增 operation_id 关联单次动作。事件含 SMT_CONV_ENTER、SELECTED_ITEM、UNITS、THICKNESS_VALIDATED、TREE_READY、API_RETURN、ERROR_LIST/ELEMENT_ERROR、FEATURE_TYPE 和 RETURN。日志为执行时产生；本包不含伪造的成功日志。

API 返回只在实际调用后记录；未执行的 create_status/regen_status/feature_id/is_sheetmetal 为 null。model_may_be_modified 在进入创建调用前保守置 true，包括创建报错或抛出异常的情形。状态回读失败不等于创建没有发生。不得以模型未保存推断没有被修改。

选面/厚度/单位/树准备失败和取消可以重新手动触发，重走校验；创建/重生成失败则消息要求先检查模型与 JSONL，没有自动删除、自动重试或自动保存。C++ catch 不会接着调用写 API；不宣称能捕获 Windows SEH/宿主崩溃。

模型/特征名称严格 UTF-16→UTF-8 并 JSON 转义；JSON 数字用私有 C 数值 locale，避免小数逗号破坏 JSON，不修改宿主全局 locale。反馈使用 ProMessageToBuffer 预检动态文本消息格式，预检失败在创建前停止；很长名称的显示可能失败，JSONL 仍记录完整名称和 feedback_failed。

## 所有权与待确认项

- 根树释放已挂接子元素；未挂接子元素由局部 guard 释放；引用保留到树释放后再释放。model/body/face selection 与 options 均由本代码分配并尝试释放；每个释放返回码记录。
- ProSelect 返回数组按借用缓冲处理，只复制并释放自己的 selection，不对来源不明数组调用 ProArrayFree/SelectionarrayFree。其返回缓冲所有权仍须本机官方文档确认。
- ProErrorlist 使用栈结构并初始化为空；按照本次附带的官方样例仅遍历，不猜测 free/ProArrayFree，不混用 ProSecerrorFree。**error_list 缓冲所有权仍未证明，存在待确认的内存管理问题**；不宣称所有 SDK 缓冲均已释放。
- 根树递归释放/挂接所有权、引用是否复制及生命周期沿用给定任务说明，本机仍需对 SDK/官方样例复核。
- 本代码没有编写新的对话框面板，只采用明确允许的消息行备选。其命令线程行为、ESC、非法字符重提示需真机确认。
- 中文资源为 UTF-8 无 BOM 候选，保留 ASCII 键与原 R10 空行分隔结构，没有加入 #。中文编码与 %0s 动态文本替换仍需本机审核；动态格式的运行预检不等于中文显示已验证。
- mm 名称解析、换算方向、面过滤、最小树省略方向元素、创建后目标体 ID 稳定、重生成行为和新命令可见性均未现场验证。
- ProSelect max_count=1 限制本次交互的返回数量；本版未读预选缓冲区，不能宣称能单独识别“执行前预选两个面”的状态。默认体之外的面拒绝，复杂多体业务不属于本轮已验收范围。

## 文件与集成

src/entry.cpp 与两个 .inl 是完整候选源；patches/cpp-6a-r2.diff 同时新增两份消息资源。可选择应用 diff 到 R10 的离线副本，或审核完整源文件，不能把首段候选和 R2 重复叠加。本轮没有修改 rbn/dat/bat、构建脚本、一次锁或现场运行目录。

本机助手复用 R10 已验收的 vcvars/Include/Lib、运行库与链接命令，只替换离线源码输入。继续使用 protk_dll_NU.lib、ucore.lib、udata.lib、libcmt.lib，保留 /INCLUDE:user_initialize_plus 与 /INCLUDE:user_terminate_plus。不要用新写的通用 cl/link 命令覆盖现场已验收参数。四个入口导出与依赖仍需本机 dumpbin 审核。

下一步先执行 OFFLINE_GATES.md，真实退出码写入 acceptance.template.json。未通过代码/编译/链接审核前不做真机转换；本包没有部署步骤或现场启动命令。

## 云端实际验证结果

最终 diff 的 git apply --check 和应用到隔离 R10 副本均返回 0；应用后的 5 个文件与交付文件逐字节一致。消息资源的记录末尾空行引起 2 条 whitespace 警告，保留原受控消息记录结构，未据此去掉分隔空行。SDK 调用名称均能追溯到本次契约或 R10，但这不是参数类型、链接或运行验证。具体机读结果见 STATIC_REVIEW.json。

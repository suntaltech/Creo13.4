// Synchronous command implementation. Included after smt_driving_tree.inl.
alignas(8) volatile LONG64 smt6a_sequence = 0;
volatile LONG smt6a_busy = 0;
AccessTrace smt6a_access_trace = {"p1_smt_drv_conv", "p1_smt_drv_conv", 0, {}, {}};

struct Smt6aContext {
    ULONGLONG id = static_cast<ULONGLONG>(InterlockedIncrement64(&smt6a_sequence));
    ULONGLONG started = GetTickCount64();
    bool create_called = false, regen_called = false;
    bool create_valid = false, regen_valid = false;
    ProError create_status = PRO_TK_NO_ERROR, regen_status = PRO_TK_NO_ERROR;
    bool thickness_valid = false, face_valid = false, feature_valid = false;
    bool face_id_valid = false, face_type_valid = false;
    bool smt_valid = false, is_smt = false, feedback_failed = false;
    double thickness_mm = 0.0, thickness_model = 0.0, area = 0.0;
    int face_id = -1, face_type = -1, feature_id = -1;
    char model_json[model_name_json_capacity] = "null";
    char feature_json[512] = "null";
    const char* result = "INTERNAL_ERROR";
    const char* stage = "enter";
};

void smt6a_checked_event(const char* event, const char* facts, int n, size_t capacity) noexcept
{
    if (n > 0 && static_cast<size_t>(n) < capacity) trace_event(event, facts);
    else trace_failure("smt6a_event_format", ERROR_INSUFFICIENT_BUFFER);
}

bool smt6a_call(Smt6aContext& c, const char* api, ProError code) noexcept
{
    smt6a_api(c.id, api, code, -1, c.create_called);
    return code == PRO_TK_NO_ERROR;
}

template<size_t N>
bool smt6a_quote_wide(const wchar_t (&name)[N], char* json, size_t capacity) noexcept
{
    size_t n = 0;
    while (n < N && name[n] != L'\0') ++n;
    if (n == N) return false;
    char utf8[N * 3 + 1] = {};
    if (n && WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, name,
        static_cast<int>(n), utf8, static_cast<int>(sizeof(utf8) - 1), nullptr, nullptr) <= 0)
        return false;
    return quote_json_utf8(utf8, json, capacity);
}

ProError smt6a_message(Smt6aContext& c, const char* name)
{
    ProFileName file = L"p1_smt_conv.txt";
    ProCharLine key = {};
    if (std::strlen(name) >= sizeof(key)) { c.feedback_failed = true; return PRO_TK_BAD_INPUTS; }
    std::memcpy(key, name, std::strlen(name) + 1);
    const ProError code = ProMessageDisplay(file, key);
    smt6a_call(c, "ProMessageDisplay", code);
    if (code != PRO_TK_NO_ERROR) c.feedback_failed = true;
    return code;
}

// No printf arguments are used by ordinary messages. This one dynamic message
// is format-tested before creation; failure stops the command before writing.
bool smt6a_text(Smt6aContext& c, char* text, bool preview_only = false)
{
    ProFileName file = L"p1_smt_conv.txt";
    ProCharLine key = "P1_SMT_CONV_TEXT";
    ProLine preview = {};
    ProError code = ProMessageToBuffer(preview, file, key, text);
    if (!smt6a_call(c, "ProMessageToBuffer(summary)", code)) {
        c.feedback_failed = true;
        return false;
    }
    if (preview_only) return true;
    code = ProMessageDisplay(file, key, text);
    if (!smt6a_call(c, "ProMessageDisplay(summary)", code)) c.feedback_failed = true;
    return code == PRO_TK_NO_ERROR;
}

bool smt6a_number(double value, char (&buffer)[64]) noexcept
{
    _locale_t locale = _create_locale(LC_NUMERIC, "C");
    if (!locale) { trace_failure("smt6a_numeric_locale", ERROR_NOT_ENOUGH_MEMORY); return false; }
    const int n = _snprintf_l(buffer, sizeof(buffer), "%.17g", locale, value);
    _free_locale(locale);
    return n > 0 && static_cast<size_t>(n) < sizeof(buffer);
}

void smt6a_finish(Smt6aContext& c) noexcept
{
    char mm[64] = "null", model[64] = "null", face[32] = "null", type[32] = "null";
    char area[64] = "null", feature[32] = "null", create[32] = "null", regen[32] = "null";
    if (c.thickness_valid) {
        if (!smt6a_number(c.thickness_mm, mm)) std::memcpy(mm, "null", 5);
        if (!smt6a_number(c.thickness_model, model)) std::memcpy(model, "null", 5);
    }
    if (c.face_id_valid) std::snprintf(face, sizeof(face), "%d", c.face_id);
    if (c.face_type_valid) std::snprintf(type, sizeof(type), "%d", c.face_type);
    if (c.face_valid && !smt6a_number(c.area, area)) std::memcpy(area, "null", 5);
    if (c.feature_valid) std::snprintf(feature, sizeof(feature), "%d", c.feature_id);
    if (c.create_valid) std::snprintf(create, sizeof(create), "%d", static_cast<int>(c.create_status));
    if (c.regen_valid) std::snprintf(regen, sizeof(regen), "%d", static_cast<int>(c.regen_status));
    char facts[model_facts_capacity] = {};
    const int n = std::snprintf(facts, sizeof(facts),
        "{\"operation_id\":%llu,\"command\":\"p1_smt_drv_conv\",\"mode\":\"driving\","
        "\"result\":\"%s\",\"stage\":\"%s\",\"model_name\":%s,\"face_id\":%s,"
        "\"face_type\":%s,\"face_area_model_units_squared\":%s,\"thickness_mm\":%s,"
        "\"thickness_model_units\":%s,\"create_called\":%s,\"create_status\":%s,"
        "\"regen_called\":%s,\"regen_status\":%s,\"feature_id\":%s,\"feature_name\":%s,"
        "\"is_sheetmetal\":%s,\"model_may_be_modified\":%s,\"save_called\":false,"
        "\"feedback_failed\":%s,\"elapsed_ms\":%llu}",
        static_cast<unsigned long long>(c.id), c.result, c.stage, c.model_json,
        face, type, area, mm, model, c.create_called ? "true" : "false", create,
        c.regen_called ? "true" : "false", regen, feature, c.feature_json,
        c.smt_valid ? (c.is_smt ? "true" : "false") : "null",
        c.create_called ? "true" : "false", c.feedback_failed ? "true" : "false",
        static_cast<unsigned long long>(GetTickCount64() - c.started));
    smt6a_checked_event("SMT_CONV_RETURN", facts, n, sizeof(facts));
}

void smt6a_reject_command(Smt6aContext& c, const char* result, const char* key)
{
    c.result = result;
    smt6a_message(c, key);
}

struct Smt6aFaceMatch {
    Smt6aContext* context;
    int selected_id;
    int matches = 0;
    ProError failure = PRO_TK_NO_ERROR;
    Smt6aFaceMatch(Smt6aContext* c, int id) noexcept : context(c), selected_id(id) {}
};

ProError smt6a_visit_member(ProSurface surface, ProError incoming, ProAppData data)
{
    Smt6aFaceMatch& match = *static_cast<Smt6aFaceMatch*>(data);
    if (incoming != PRO_TK_NO_ERROR) { match.failure = incoming; return incoming; }
    int id = -1;
    const ProError status = ProSurfaceIdGet(surface, &id);
    if (!smt6a_call(*match.context, "ProSurfaceIdGet(member)", status)) {
        match.failure = status;
        return status;
    }
    if (id == match.selected_id) ++match.matches;
    return PRO_TK_NO_ERROR;
}

bool smt6a_face_check(Smt6aContext& c, ProMdl model, ProSolidBody& body,
    ProSelection selection)
{
    ProModelitem item = {};
    if (!smt6a_call(c, "ProSelectionModelitemGet", ProSelectionModelitemGet(selection, &item))) {
        smt6a_reject_command(c, "SELECTED_FACE_INVALID", "P1_SMT_CONV_BAD_FACE"); return false;
    }
    char item_facts[256] = {};
    const int item_n = std::snprintf(item_facts, sizeof(item_facts),
        "{\"operation_id\":%llu,\"selected_item_id\":%d,\"selected_item_type\":%d,\"owner_matches_model\":%s}",
        static_cast<unsigned long long>(c.id), item.id, static_cast<int>(item.type),
        item.owner == model ? "true" : "false");
    smt6a_checked_event("SMT_CONV_SELECTED_ITEM", item_facts, item_n, sizeof(item_facts));
    if (item.type != PRO_SURFACE || item.owner != model) {
        smt6a_reject_command(c, "SELECTED_FACE_INVALID", "P1_SMT_CONV_BAD_FACE"); return false;
    }
    c.face_id = item.id; c.face_id_valid = true;
    Smt6aFaceMatch match(&c, item.id);
    const ProError visit = ProSolidBodySurfaceVisit(&body, &smt6a_visit_member, &match);
    if (!smt6a_call(c, "ProSolidBodySurfaceVisit(membership)", visit) ||
        match.failure != PRO_TK_NO_ERROR || match.matches != 1) {
        smt6a_reject_command(c, "FACE_BODY_MISMATCH", "P1_SMT_CONV_BODY_MISMATCH"); return false;
    }
    ProSurface surface = nullptr;
    ProSrftype type = PRO_SRF_NONE;
    double area = 0.0;
    if (!smt6a_call(c, "ProSurfaceInit", ProSurfaceInit(model, item.id, &surface)) ||
        !smt6a_call(c, "ProSurfaceTypeGet", ProSurfaceTypeGet(surface, &type))) {
        smt6a_reject_command(c, "SELECTED_FACE_INVALID", "P1_SMT_CONV_BAD_FACE"); return false;
    }
    c.face_type = static_cast<int>(type); c.face_type_valid = true;
    if (type != PRO_SRF_PLANE) {
        smt6a_reject_command(c, "SELECTED_FACE_NOT_PLANE", "P1_SMT_CONV_NOT_PLANE"); return false;
    }
    if (!smt6a_call(c, "ProSurfaceAreaEval", ProSurfaceAreaEval(surface, &area)) ||
        !std::isfinite(area) || area <= 0.0) {
        smt6a_reject_command(c, "SURFACE_QUERY_FAILED", "P1_SMT_CONV_BAD_FACE"); return false;
    }
    c.face_valid = true; c.face_id = item.id; c.face_type = static_cast<int>(type); c.area = area;
    return true;
}

bool smt6a_units(Smt6aContext& c, ProMdl model, ProUnitConversion& conversion)
{
    ProUnitsystem system = {};
    ProUnititem unit = {}, mm = {};
    ProName mm_name = L"mm";
    if (!smt6a_call(c, "ProMdlPrincipalunitsystemGet", ProMdlPrincipalunitsystemGet(model, &system)) ||
        !smt6a_call(c, "ProUnitsystemUnitGet", ProUnitsystemUnitGet(&system, PRO_UNITTYPE_LENGTH, &unit)) ||
        !smt6a_call(c, "ProUnitInit(mm)", ProUnitInit(model, mm_name, &mm)) ||
        !smt6a_call(c, "ProUnitConversionCalculate(mm_to_model)",
            ProUnitConversionCalculate(&mm, &unit, &conversion))) return false;
    if (!std::isfinite(conversion.scale) || conversion.scale <= 0.0 ||
        !std::isfinite(conversion.offset) || conversion.offset != 0.0) return false;
    char unit_json[512] = {}, mm_json[512] = {};
    if (!smt6a_quote_wide(unit.name, unit_json, sizeof(unit_json)) ||
        !smt6a_quote_wide(mm.name, mm_json, sizeof(mm_json))) return false;
    char scale[64] = {}, offset[64] = {};
    if (!smt6a_number(conversion.scale, scale) || !smt6a_number(conversion.offset, offset)) return false;
    char facts[1400] = {};
    const int n = std::snprintf(facts, sizeof(facts),
        "{\"operation_id\":%llu,\"unit_from\":%s,\"unit_to\":%s,"
        "\"direction\":\"mm_to_current_model\",\"scale\":%s,\"offset\":%s}",
        static_cast<unsigned long long>(c.id), mm_json, unit_json, scale, offset);
    smt6a_checked_event("SMT_CONV_UNITS", facts, n, sizeof(facts));
    return true;
}

struct Smt6aSelectedFace {
    Smt6aContext& context;
    ProSelection copy = nullptr;
    explicit Smt6aSelectedFace(Smt6aContext& c) noexcept : context(c) {}
    ~Smt6aSelectedFace() noexcept {
        if (copy) smt6a_call(context, "ProSelectionFree(selected_copy)", ProSelectionFree(&copy));
    }
};

void smt6a_error_list(Smt6aContext& c, const ProErrorlist& errors) noexcept
{
    char facts[384] = {};
    int n = std::snprintf(facts, sizeof(facts),
        "{\"operation_id\":%llu,\"error_number\":%d,\"list_present\":%s,"
        "\"ownership\":\"unconfirmed_follow_supplied_sample_no_free\"}",
        static_cast<unsigned long long>(c.id), errors.error_number, errors.error_list ? "true" : "false");
    smt6a_checked_event("SMT_CONV_ERROR_LIST", facts, n, sizeof(facts));
    if (!errors.error_list || errors.error_number < 0) return;
    for (int i = 0; i < errors.error_number; ++i) {
        const ProItemerror& item = errors.error_list[i];
        n = std::snprintf(facts, sizeof(facts),
            "{\"operation_id\":%llu,\"index\":%d,\"element_id\":%d,\"item_type\":%d,\"pro_error\":%d}",
            static_cast<unsigned long long>(c.id), i, item.err_item_id,
            static_cast<int>(item.err_item_type), static_cast<int>(item.error));
        smt6a_checked_event("SMT_CONV_ELEMENT_ERROR", facts, n, sizeof(facts));
    }
    // Supplied SDK/sample policy: read only; do not guess free/ProArrayFree.
}

void smt6a_run(Smt6aContext& c)
{
    c.stage = "preflight";
    ProMdl model = nullptr;
    ProError status = ProMdlCurrentGet(&model);
    if (!smt6a_call(c, "ProMdlCurrentGet", status) || !model) {
        smt6a_reject_command(c, "NO_MODEL", "P1_SMT_CONV_NO_MODEL"); return;
    }
    ProMdlType type = PRO_MDL_UNUSED;
    if (!smt6a_call(c, "ProMdlTypeGet", ProMdlTypeGet(model, &type))) {
        smt6a_reject_command(c, "MODEL_QUERY_FAILED", "P1_SMT_CONV_QUERY_FAILED"); return;
    }
    if (type != PRO_MDL_PART) {
        smt6a_reject_command(c, "NOT_PART", "P1_SMT_CONV_NOT_PART"); return;
    }
    ProMdlName model_name = {};
    if (!smt6a_call(c, "ProMdlMdlnameGet", ProMdlMdlnameGet(model, model_name)) ||
        !smt6a_quote_wide(model_name, c.model_json, sizeof(c.model_json))) {
        smt6a_reject_command(c, "MODEL_NAME_FAILED", "P1_SMT_CONV_QUERY_FAILED"); return;
    }
    const ProSolid solid = reinterpret_cast<ProSolid>(model);
    ProSolidBody body = {};
    status = ProSolidDefaultBodyGet(solid, &body);
    if (!smt6a_call(c, "ProSolidDefaultBodyGet", status)) {
        smt6a_reject_command(c, status == PRO_TK_GENERAL_ERROR ? "NO_BODY" : "WRAP_SOLID_FAILED",
            "P1_SMT_CONV_NO_BODY"); return;
    }
    ProBoolean smt = PRO_B_FALSE;
    if (!smt6a_call(c, "ProSolidBodyIsSheetmetal", ProSolidBodyIsSheetmetal(&body, &smt))) {
        smt6a_reject_command(c, "BODY_QUERY_FAILED", "P1_SMT_CONV_QUERY_FAILED"); return;
    }
    if (smt == PRO_B_TRUE) {
        c.smt_valid = true; c.is_smt = true;
        smt6a_reject_command(c, "ALREADY_SHEETMETAL", "P1_SMT_CONV_ALREADY"); return;
    }
    c.stage = "select";
    if (smt6a_message(c, "P1_SMT_CONV_SELECT") != PRO_TK_NO_ERROR) { c.result = "FEEDBACK_NOT_READY"; return; }
    ProSelection* borrowed = nullptr;
    int count = 0;
    char filter[] = "surface";
    status = ProSelect(filter, 1, nullptr, nullptr, nullptr, nullptr, &borrowed, &count);
    smt6a_call(c, "ProSelect(surface,1)", status);
    if (status == PRO_TK_USER_ABORT) {
        smt6a_reject_command(c, "CANCELLED", "P1_SMT_CONV_CANCELLED"); return;
    }
    if (status != PRO_TK_NO_ERROR) {
        smt6a_reject_command(c, "SELECTION_FAILED", "P1_SMT_CONV_BAD_FACE"); return;
    }
    if (count == 0) {
        smt6a_reject_command(c, "NO_SELECTED_FACE", "P1_SMT_CONV_NO_FACE"); return;
    }
    if (count != 1 || !borrowed || !borrowed[0]) {
        smt6a_reject_command(c, "SELECTION_AMBIGUOUS", "P1_SMT_CONV_ONE_FACE"); return;
    }
    Smt6aSelectedFace selected(c);
    // ProSelect output is treated as borrowed; only our independent copy is freed.
    if (!smt6a_call(c, "ProSelectionCopy(selected)", ProSelectionCopy(borrowed[0], &selected.copy))) {
        smt6a_reject_command(c, "SELECTED_FACE_INVALID", "P1_SMT_CONV_BAD_FACE"); return;
    }
    if (!smt6a_face_check(c, model, body, selected.copy)) return;
    c.stage = "input_mm";
    if (smt6a_message(c, "P1_SMT_CONV_THICKNESS") != PRO_TK_NO_ERROR) { c.result = "FEEDBACK_NOT_READY"; return; }
    double range[2] = {0.1, 20.0};
    double thickness = 0.0;
    status = ProMessageDoubleRead(range, &thickness);
    smt6a_call(c, "ProMessageDoubleRead", status);
    if (status == PRO_TK_MSG_USER_QUIT) {
        smt6a_reject_command(c, "CANCELLED", "P1_SMT_CONV_CANCELLED"); return;
    }
    if (status != PRO_TK_NO_ERROR || !std::isfinite(thickness) || thickness < range[0] || thickness > range[1]) {
        smt6a_reject_command(c, "INVALID_THICKNESS", "P1_SMT_CONV_BAD_THICKNESS"); return;
    }
    char observed[64] = {};
    if (!smt6a_number(thickness, observed)) {
        smt6a_reject_command(c, "INPUT_FORMAT_FAILED", "P1_SMT_CONV_BAD_THICKNESS"); return;
    }
    char input_facts[256] = {};
    const int input_n = std::snprintf(input_facts, sizeof(input_facts),
        "{\"operation_id\":%llu,\"input_unit\":\"mm\",\"value\":%s,\"backend_range_valid\":true}",
        static_cast<unsigned long long>(c.id), observed);
    smt6a_checked_event("SMT_CONV_THICKNESS_VALIDATED", input_facts, input_n, sizeof(input_facts));
    c.stage = "revalidate";
    ProMdl current = nullptr;
    ProSolidBody fresh_body = {};
    ProBoolean fresh_smt = PRO_B_FALSE;
    if (!smt6a_call(c, "ProMdlCurrentGet(revalidate)", ProMdlCurrentGet(&current)) || current != model ||
        !smt6a_call(c, "ProSolidDefaultBodyGet(revalidate)", ProSolidDefaultBodyGet(solid, &fresh_body)) ||
        fresh_body.id != body.id || fresh_body.owner != body.owner ||
        !smt6a_call(c, "ProSolidBodyIsSheetmetal(revalidate)", ProSolidBodyIsSheetmetal(&fresh_body, &fresh_smt)) ||
        fresh_smt == PRO_B_TRUE) {
        smt6a_reject_command(c, "STALE_CONTEXT", "P1_SMT_CONV_STALE"); return;
    }
    if (!smt6a_face_check(c, model, fresh_body, selected.copy)) return;
    ProUnitConversion conversion = {};
    if (!smt6a_units(c, model, conversion)) {
        smt6a_reject_command(c, "UNIT_UNSUPPORTED", "P1_SMT_CONV_UNIT_FAILED"); return;
    }
    const double converted = thickness * conversion.scale + conversion.offset;
    if (!std::isfinite(converted) || converted <= 0.0) {
        smt6a_reject_command(c, "INVALID_THICKNESS", "P1_SMT_CONV_BAD_THICKNESS"); return;
    }
    c.thickness_mm = thickness; c.thickness_model = converted; c.thickness_valid = true;
    char format_probe[] = "driving; input=mm; no Save";
    if (!smt6a_text(c, format_probe, true)) { c.result = "FEEDBACK_NOT_READY"; return; }
    c.stage = "tree";
    Smt6aPreparedTree prepared(c.id);
    status = smt6a_prepare_tree(model, fresh_body, selected.copy, thickness, conversion, prepared);
    if (status != PRO_TK_NO_ERROR) {
        smt6a_reject_command(c, "TREE_CREATE_FAILED", "P1_SMT_CONV_TREE_FAILED"); return;
    }
    char tree_facts[192] = {};
    const int tree_n = std::snprintf(tree_facts, sizeof(tree_facts),
        "{\"operation_id\":%llu,\"root_ready\":true,\"child_count\":6,\"flags\":0,\"create_called\":false}",
        static_cast<unsigned long long>(c.id));
    smt6a_checked_event("SMT_CONV_TREE_READY", tree_facts, tree_n, sizeof(tree_facts));
    c.stage = "create";
    ProFeature feature = {};
    ProErrorlist errors = {};
    c.create_called = true; prepared.create_called = true;
    c.create_status = ProFeatureWithoptionsCreate(prepared.model_selection, prepared.root,
        prepared.options, PRO_REGEN_NO_FLAGS, &feature, &errors);
    c.create_valid = true;
    smt6a_call(c, "ProFeatureWithoptionsCreate", c.create_status);
    smt6a_error_list(c, errors);
    if (c.create_status != PRO_TK_NO_ERROR) {
        smt6a_reject_command(c, c.create_status == PRO_TK_CANT_MODIFY ? "MODEL_READ_ONLY" : "CREATE_FEATURE_FAILED",
            c.create_status == PRO_TK_CANT_MODIFY ? "P1_SMT_CONV_READ_ONLY" : "P1_SMT_CONV_CREATE_FAILED"); return;
    }
    // Use the SDK-populated structure only after successful creation.
    c.feature_id = feature.id; c.feature_valid = true;
    if (feature.owner != model || feature.id < 0) {
        smt6a_reject_command(c, "FEATURE_READBACK_FAILED", "P1_SMT_CONV_POST_FAILED"); return;
    }
    c.stage = "regenerate";
    c.regen_called = true;
    c.regen_status = ProSolidRegenerate(solid, PRO_REGEN_NO_FLAGS);
    c.regen_valid = true;
    if (!smt6a_call(c, "ProSolidRegenerate", c.regen_status)) {
        smt6a_reject_command(c, "REGEN_FAILED", "P1_SMT_CONV_POST_FAILED"); return;
    }
    c.stage = "postcheck";
    ProSolidBody result_body = {};
    ProBoolean result_smt = PRO_B_FALSE;
    if (!smt6a_call(c, "ProSolidDefaultBodyGet(post)", ProSolidDefaultBodyGet(solid, &result_body)) ||
        !smt6a_call(c, "ProSolidBodyIsSheetmetal(post)", ProSolidBodyIsSheetmetal(&result_body, &result_smt))) {
        smt6a_reject_command(c, "STATUS_READBACK_FAILED", "P1_SMT_CONV_POST_FAILED"); return;
    }
    c.smt_valid = true; c.is_smt = result_smt == PRO_B_TRUE;
    if (!c.is_smt || result_body.id != body.id || result_body.owner != body.owner) {
        smt6a_reject_command(c, "STATUS_NOT_SHEETMETAL", "P1_SMT_CONV_POST_FAILED"); return;
    }
    ProFeattype feature_type = {};
    if (!smt6a_call(c, "ProFeatureTypeGet", ProFeatureTypeGet(&feature, &feature_type))) {
        smt6a_reject_command(c, "FEATURE_READBACK_FAILED", "P1_SMT_CONV_POST_FAILED"); return;
    }
    char type_facts[192] = {};
    const int type_n = std::snprintf(type_facts, sizeof(type_facts),
        "{\"operation_id\":%llu,\"feature_id\":%d,\"feature_type\":%d}",
        static_cast<unsigned long long>(c.id), feature.id, static_cast<int>(feature_type));
    smt6a_checked_event("SMT_CONV_FEATURE_TYPE", type_facts, type_n, sizeof(type_facts));
    ProName feature_name = {};
    if (!smt6a_call(c, "ProModelitemNameGet(feature)", ProModelitemNameGet(&feature, feature_name)) ||
        feature_name[0] == L'\0' ||
        !smt6a_quote_wide(feature_name, c.feature_json, sizeof(c.feature_json))) {
        smt6a_reject_command(c, "FEATURE_READBACK_FAILED", "P1_SMT_CONV_POST_FAILED"); return;
    }
    c.result = "SUCCESS_UNSAVED";
    smt6a_message(c, "P1_SMT_CONV_SUCCESS");
    char detail[80] = {};
    int n = std::snprintf(detail, sizeof(detail), "driving; t=%.9g mm; feature=%d; SMT=true; no Save",
        thickness, feature.id);
    if (n > 0 && static_cast<size_t>(n) < sizeof(detail)) smt6a_text(c, detail);
    else c.feedback_failed = true;
    // Separate lines keep each toolkit message within its 80-character bound.
    // Names are UTF-8 encoded and sent through the same checked text message.
    const auto show_name = [&c](const wchar_t* name, size_t units) {
        char utf8[model_name_utf8_capacity] = {};
        size_t count = 0;
        while (count < units && name[count]) ++count;
        if (count == units || count == 0 || count > static_cast<size_t>(INT_MAX)) { c.feedback_failed = true; return; }
        if (WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, name, static_cast<int>(count),
            utf8, static_cast<int>(sizeof(utf8) - 1), nullptr, nullptr) <= 0) { c.feedback_failed = true; return; }
        smt6a_text(c, utf8);
    };
    smt6a_message(c, "P1_SMT_CONV_MODEL_NAME");
    show_name(model_name, sizeof(model_name) / sizeof(model_name[0]));
    smt6a_message(c, "P1_SMT_CONV_FEATURE_NAME");
    show_name(feature_name, sizeof(feature_name) / sizeof(feature_name[0]));
}

int smt6a_action(uiCmdCmdId command, uiCmdValue* value, void* push_data)
{
    PreserveLastError preserve;
    (void)command; (void)value; (void)push_data;
    Smt6aContext context;
    if (InterlockedCompareExchange(&smt6a_busy, 1, 0) != 0) {
        context.result = "COMMAND_BUSY";
        try { smt6a_message(context, "P1_SMT_CONV_BUSY"); }
        catch (...) { context.feedback_failed = true; }
        smt6a_finish(context); return 0;
    }
    struct BusyReset { ~BusyReset() { InterlockedExchange(&smt6a_busy, 0); } } reset;
    char begin[128] = {};
    const int n = std::snprintf(begin, sizeof(begin), "{\"operation_id\":%llu,\"mode\":\"driving\"}",
        static_cast<unsigned long long>(context.id));
    smt6a_checked_event("SMT_CONV_ENTER", begin, n, sizeof(begin));
    try { smt6a_run(context); }
    catch (...) {
        // No continuation into a write call from this handler.
        context.result = "UNEXPECTED_EXCEPTION";
        try { smt6a_message(context, "P1_SMT_CONV_EXCEPTION"); }
        catch (...) { context.feedback_failed = true; }
    }
    flush_one_access_trace(smt6a_access_trace, "smt_command_return");
    smt6a_finish(context);
    return 0;
}

uiCmdAccessState smt6a_access(uiCmdAccessMode mode)
{
    // No model query, selection, messages, SDK write or file I/O in access.
    record_access_observation(smt6a_access_trace, mode, ACCESS_AVAILABLE);
    return ACCESS_AVAILABLE;
}

void register_smt6a_command() noexcept
{
    PreserveLastError preserve;
    Smt6aContext c;
    try {
    static char name[] = "p1_smt_drv_conv";
    static char label[] = "P1_SMT_CONV_LABEL";
    static char help[] = "P1_SMT_CONV_HELP";
    static char description[] = "P1_SMT_CONV_DESC";
    static wchar_t file[] = L"p1_smt_conv.txt";
    uiCmdCmdId id = nullptr;
    const ProError add = ProCmdActionAdd(name, &smt6a_action, uiProeImmediate,
        &smt6a_access, PRO_B_TRUE, PRO_B_TRUE, &id);
    if (!smt6a_call(c, "ProCmdActionAdd(smt)", add) || !id) return;
    trace_registration_identity("p1_smt_drv_conv", id, name, label, help, description, file);
    smt6a_call(c, "ProCmdDesignate(smt)", ProCmdDesignate(id, label, help, description, file));
    flush_one_access_trace(smt6a_access_trace, "smt_initialization_end");
    } catch (...) {
        trace_event("SMT_CONV_REGISTER_EXCEPTION", "{\"existing_commands_preserved\":true}");
    }
}

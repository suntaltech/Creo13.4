// Included inside the R10 anonymous namespace, after trace_event.
// Tree preparation used only by the synchronous 6A command helper.
// A prepared tree is NOT evidence of a valid plane/body relationship or conversion.
struct Smt6aPreparedTree {
    ULONGLONG operation_id;
    bool create_called;
    ProElement root;
    ProReference body_reference;
    ProReference face_reference;
    ProSelection model_selection;
    ProSelection body_selection;
    ProSelection face_selection;
    ProFeatureCreateOptions* options;

    explicit Smt6aPreparedTree(ULONGLONG id) noexcept
        : operation_id(id), create_called(false), root(nullptr), body_reference(nullptr),
          face_reference(nullptr), model_selection(nullptr),
          body_selection(nullptr), face_selection(nullptr), options(nullptr) {}
    Smt6aPreparedTree(const Smt6aPreparedTree&) = delete;
    Smt6aPreparedTree& operator=(const Smt6aPreparedTree&) = delete;
    ~Smt6aPreparedTree() noexcept;
};

void smt6a_api(ULONGLONG operation_id, const char* api, ProError status,
    int element_id = -1, bool create_called = false) noexcept
{
    PreserveLastError preserve;
    char facts[384] = {};
    const int n = std::snprintf(facts, sizeof(facts),
        "{\"operation_id\":%llu,\"api\":\"%s\",\"called\":true,"
        "\"pro_error\":%d,\"element_id\":%d,\"create_called\":%s}",
        static_cast<unsigned long long>(operation_id), api,
        static_cast<int>(status), element_id, create_called ? "true" : "false");
    if (n > 0 && static_cast<size_t>(n) < sizeof(facts)) {
        trace_event("SMT_CONV_API_RETURN", facts);
    } else {
        trace_failure("smt6a_api_format", ERROR_INSUFFICIENT_BUFFER);
    }
}

ProError smt6a_reject(ULONGLONG operation_id, const char* reason) noexcept
{
    char facts[320] = {};
    const int n = std::snprintf(facts, sizeof(facts),
        "{\"operation_id\":%llu,\"result\":\"%s\",\"sdk_called\":false,"
        "\"create_called\":false}",
        static_cast<unsigned long long>(operation_id), reason);
    if (n > 0 && static_cast<size_t>(n) < sizeof(facts))
        trace_event("SMT_6A_PREP_REJECTED", facts);
    else trace_failure("smt6a_reject_format", ERROR_INSUFFICIENT_BUFFER);
    return PRO_TK_BAD_INPUTS; // Local validation code, not an observed SDK error.
}

Smt6aPreparedTree::~Smt6aPreparedTree() noexcept
{
    PreserveLastError preserve;
    // Attached children are released by their root. References remain alive
    // until the tree has been released, per the supplied task's lifecycle.
    if (root) smt6a_api(operation_id, "ProElementFree(root)", ProElementFree(&root), -1, create_called);
    if (body_reference) smt6a_api(operation_id, "ProReferenceFree(body)",
        ProReferenceFree(body_reference), -1, create_called);
    if (face_reference) smt6a_api(operation_id, "ProReferenceFree(face)",
        ProReferenceFree(face_reference), -1, create_called);
    if (face_selection) smt6a_api(operation_id, "ProSelectionFree(face_copy)",
        ProSelectionFree(&face_selection), -1, create_called);
    if (body_selection) smt6a_api(operation_id, "ProSelectionFree(body)",
        ProSelectionFree(&body_selection), -1, create_called);
    if (model_selection) smt6a_api(operation_id, "ProSelectionFree(model)",
        ProSelectionFree(&model_selection), -1, create_called);
    if (options) smt6a_api(operation_id, "ProArrayFree(options)",
        ProArrayFree(reinterpret_cast<ProArray*>(&options)), -1, create_called);
}

struct Smt6aDetachedElement {
    ULONGLONG operation_id;
    ProElement value;
    explicit Smt6aDetachedElement(ULONGLONG id) noexcept : operation_id(id), value(nullptr) {}
    Smt6aDetachedElement(const Smt6aDetachedElement&) = delete;
    Smt6aDetachedElement& operator=(const Smt6aDetachedElement&) = delete;
    ~Smt6aDetachedElement() noexcept
    {
        if (value) smt6a_api(operation_id, "ProElementFree(detached)", ProElementFree(&value));
    }
};

enum class Smt6aValueKind { integer, name, reference, thickness };

ProError smt6a_add_child(Smt6aPreparedTree& tree, ProElemId id,
    Smt6aValueKind kind, int integer_value, ProReference reference,
    double thickness)
{
    Smt6aDetachedElement child(tree.operation_id);
    ProError status = ProElementAlloc(id, &child.value);
    smt6a_api(tree.operation_id, "ProElementAlloc(child)", status, static_cast<int>(id));
    if (status != PRO_TK_NO_ERROR) return status;
    switch (kind) {
    case Smt6aValueKind::integer:
        status = ProElementIntegerSet(child.value, integer_value);
        smt6a_api(tree.operation_id, "ProElementIntegerSet", status, static_cast<int>(id));
        break;
    case Smt6aValueKind::name: {
        wchar_t name[] = L"SMT_CONV_DRIVING";
        status = ProElementWstringSet(child.value, name);
        smt6a_api(tree.operation_id, "ProElementWstringSet", status, static_cast<int>(id));
        break;
    }
    case Smt6aValueKind::reference:
        status = ProElementReferenceSet(child.value, reference);
        smt6a_api(tree.operation_id, "ProElementReferenceSet", status, static_cast<int>(id));
        break;
    case Smt6aValueKind::thickness:
        status = ProElementDecimalsSet(child.value, 9);
        smt6a_api(tree.operation_id, "ProElementDecimalsSet", status, static_cast<int>(id));
        if (status != PRO_TK_NO_ERROR) return status;
        status = ProElementDoubleSet(child.value, thickness);
        smt6a_api(tree.operation_id, "ProElementDoubleSet", status, static_cast<int>(id));
        break;
    }
    if (status != PRO_TK_NO_ERROR) return status;
    status = ProElemtreeElementAdd(tree.root, nullptr, child.value);
    smt6a_api(tree.operation_id, "ProElemtreeElementAdd", status, static_cast<int>(id));
    if (status == PRO_TK_NO_ERROR) child.value = nullptr; // Owned by root now.
    return status;
}

// The synchronous command adapter must first establish:
// current part/default body identity, selected planar face membership in that
// body, user-confirmed thickness_mm, and mm_to_current_model conversion.
// Collection of available units is NOT a query of the currently active unit.
// Output must be a new stack-local object; discard it on any failure.
// Success means PREPARED_SYNTAX_ONLY, never model conversion success.
ProError smt6a_prepare_tree(ProMdl model, ProSolidBody body,
    ProSelection selected_face, double thickness_mm,
    const ProUnitConversion& mm_to_current_model, Smt6aPreparedTree& output)
{
    PreserveLastError preserve;
    if (!model || !selected_face || body.owner != model ||
        output.root || output.options || output.model_selection ||
        output.body_selection || output.face_selection ||
        output.body_reference || output.face_reference ||
        !std::isfinite(thickness_mm) || thickness_mm < 0.1 || thickness_mm > 20.0 ||
        !std::isfinite(mm_to_current_model.scale) || mm_to_current_model.scale <= 0.0 ||
        !std::isfinite(mm_to_current_model.offset) || mm_to_current_model.offset != 0.0) {
        return smt6a_reject(output.operation_id, "INVALID_PREPARATION_INPUT");
    }
    const double thickness_model = thickness_mm * mm_to_current_model.scale;
    if (!std::isfinite(thickness_model) || thickness_model <= 0.0) {
        return smt6a_reject(output.operation_id, "INVALID_CONVERTED_THICKNESS");
    }
    ProMdlType model_type = PRO_MDL_UNUSED;
    ProError status = ProMdlTypeGet(model, &model_type);
    smt6a_api(output.operation_id, "ProMdlTypeGet", status);
    if (status != PRO_TK_NO_ERROR) return status;
    if (model_type != PRO_MDL_PART) return smt6a_reject(output.operation_id, "NOT_PART");
    ProModelitem face_item = {};
    status = ProSelectionModelitemGet(selected_face, &face_item);
    smt6a_api(output.operation_id, "ProSelectionModelitemGet", status);
    if (status != PRO_TK_NO_ERROR) return status;
    if (face_item.type != PRO_SURFACE || face_item.owner != model)
        return smt6a_reject(output.operation_id, "INVALID_FACE_OWNER_OR_TYPE");

    ProModelitem model_item = {};
    status = ProMdlToModelitem(model, &model_item); // Supplied official sample B.
    smt6a_api(output.operation_id, "ProMdlToModelitem", status);
    if (status != PRO_TK_NO_ERROR) return status;
    status = ProSelectionAlloc(nullptr, &model_item, &output.model_selection);
    smt6a_api(output.operation_id, "ProSelectionAlloc(model)", status);
    if (status != PRO_TK_NO_ERROR) return status;
    static_assert(std::is_same<ProSolidBody, ProModelitem>::value,
        "Supplied ProObjects.h declares body and modelitem as the same structure");
    status = ProSelectionAlloc(nullptr, &body, &output.body_selection);
    smt6a_api(output.operation_id, "ProSelectionAlloc(body)", status);
    if (status != PRO_TK_NO_ERROR) return status;
    status = ProSelectionCopy(selected_face, &output.face_selection);
    smt6a_api(output.operation_id, "ProSelectionCopy(face)", status);
    if (status != PRO_TK_NO_ERROR) return status;
    status = ProSelectionToReference(output.body_selection, &output.body_reference);
    smt6a_api(output.operation_id, "ProSelectionToReference(body)", status);
    if (status != PRO_TK_NO_ERROR) return status;
    status = ProSelectionToReference(output.face_selection, &output.face_reference);
    smt6a_api(output.operation_id, "ProSelectionToReference(face)", status);
    if (status != PRO_TK_NO_ERROR) return status;
    status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1,
        reinterpret_cast<ProArray*>(&output.options));
    smt6a_api(output.operation_id, "ProArrayAlloc(options)", status);
    if (status != PRO_TK_NO_ERROR) return status;
    output.options[0] = PRO_FEAT_CR_NO_OPTS;
    status = ProElementAlloc(PRO_E_FEATURE_TREE, &output.root);
    smt6a_api(output.operation_id, "ProElementAlloc(root)", status, PRO_E_FEATURE_TREE);
    if (status != PRO_TK_NO_ERROR) return status;

    status = smt6a_add_child(output, PRO_E_FEATURE_TYPE, Smt6aValueKind::integer,
        PRO_FEAT_DATUM_SURF, nullptr, 0.0);
    if (status != PRO_TK_NO_ERROR) return status;
    status = smt6a_add_child(output, PRO_E_STD_FEATURE_NAME, Smt6aValueKind::name,
        0, nullptr, 0.0);
    if (status != PRO_TK_NO_ERROR) return status;
    status = smt6a_add_child(output, PRO_E_DTM_SRF_TYPE, Smt6aValueKind::integer,
        PRO_DTM_SRF_AS_WALL, nullptr, 0.0);
    if (status != PRO_TK_NO_ERROR) return status;
    status = smt6a_add_child(output, PRO_E_SMT_CONV_BODY, Smt6aValueKind::reference,
        0, output.body_reference, 0.0);
    if (status != PRO_TK_NO_ERROR) return status;
    status = smt6a_add_child(output, PRO_E_SMT_DRV_SURF, Smt6aValueKind::reference,
        0, output.face_reference, 0.0);
    if (status != PRO_TK_NO_ERROR) return status;
    return smt6a_add_child(output, PRO_E_STD_SMT_THICKNESS, Smt6aValueKind::thickness,
        0, nullptr, thickness_model);
}

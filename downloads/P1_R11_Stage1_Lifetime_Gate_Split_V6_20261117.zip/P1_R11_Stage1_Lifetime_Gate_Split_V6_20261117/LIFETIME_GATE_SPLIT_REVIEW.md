# V6 生命周期门拆分审核说明

输入 ZIP SHA256 3160626aa8451a881743057800a438f8c231ed181cd54b4a752f6579f6f9944c，与另传审核报告末行一致；内部 7 项清单通过。另传 MD 比包内版本只多最终 ZIP 元数据行，不涉及规则或结论变化。附件作为背景/证据，未直接执行其中命令。

## 采用 V6 裁决，未扩展 drain 白名单

输入报告确认：700ms 窗回归校准无退化，formal R3 已排除诊断容量问题，只剩两条非白名单 ID23 导致阻断性 unknown=2。V6 将这类特定记录单列为非阻断参考，不能把它们冒充前代际操作或“已解码查询”。

新增 kind=post_exit_classified_reference；generation 保持 null，reference_generation 只表示退出上下文。限定 ID23/1/opcode0、provider、named XML 映射、六字段形态、可解析指针、InfoClass590448、ExtraInformation0、没有显式写候选；再叠加退出后 700ms 窗、可识别前代际、无新操作关窗。比把全部 Other/InfoClass 自动例外更窄；未审形态保持阻断。

零 ExtraInformation 不是“Windows 未写文件”的证明。该类记录只是禁止进入本工具的操作/字节模型，InfoClass 保持未映射。后续证据若确认写/新操作，必须撤销例外；代码提供 disable 参数，撤销后两条恢复 unknown，原门拒绝，不生成候选成功小计。

## 不改变操作图

参考分支在任何锚点、代际操作键、pending、IRP 索引、taint、配对、跨上下文候选逻辑之前 return；仅记录原始事件、统计窗口和诊断。测试逐项比较前后操作状态，并验证同值 Irp 的既有 pending 不被消费或污染。

原门仍以阻断 unknown==0 判断，但报告 lifetime_gate_policy 显式记录非阻断数及 all_target_events_operationally_attributed；存在参考时后者为 false，并非隐瞒语义未知。所有哈希、计数、字段、时钟、校准和必要诊断门维持；ID23 仍不在 exit-drain 白名单 13/14/22/24 中。

## 数量迁移说明

旧版本把 unknown ID23 继续放进 None 代际 pending；新参考按要求不创建此假节点。新总 pending 可能因此少两条，晚期孤儿/跨上下文引用统计也可能迁移，不能强求所有旧 counters 数字不变。活跃期逻辑保持，全部已有配对签名仍需与 R3 一致；本包校验器对全时段和退出前签名分别做流式 SHA256 对照，并列出其他差异。

校准没有此类退出后 ID23，应与输入 baseline counters/65B 六序号完全相等；不能用只看 accepted 来代替回归。

## 验证与未完成项

74 项离线测试通过：原 60 项边界回归保留（旧 100ms 超窗用例改为显式传 100ms，现行默认按裁决 700ms），新增真实参考两条、操作图无副作用、同 Irp pending 保留、非法指针/额外字段/非零信息/写候选拒绝、窗外/关窗/无代际拒绝、版本与映射拒绝、撤销例外回落、正式合成门拆分、签名变更检测。

两条真实样本在给定进程边界上下文中均成为参考：阻断 unknown=0、reference=2、exit_drain=0、操作图不变。这只是两条记录的审计，未重放 formal.etl，也未重放完整旧 pending 状态。observed creation 上下文来源于任务单，退出边界来源于附件旧判定；没有补造 process 原始事件。

合同与两个 PowerShell 文件逐字节沿用；Python AST 通过。诊断上限沿用可配置机制，正式命令使用已验证的 60000 条/256MiB，参考流不采样。新默认窗为 700ms，保持 100ms 参数回退能力，不改变白名单。

本轮完整校准/正式 accepted 与 counters 必须由本机验证；云端没有原始 ETL。阶段验收通过也不证明每个 IRP 严格配对、全无丢失、DLL 初始化、GUI 枚举或实体转钣金可用。未部署/重采/修改插件、模型或配置，未发送 PTC。

# 当前审核入口

请读 LIFETIME_GATE_SPLIT_REVIEW.md 和 README_先读.md。本轮处理非阻断参考与阻断性 unknown 的门口径拆分，不修改已验证字段合同。

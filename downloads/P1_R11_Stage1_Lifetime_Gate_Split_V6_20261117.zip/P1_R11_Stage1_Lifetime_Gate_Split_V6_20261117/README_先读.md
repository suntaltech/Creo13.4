# R11 Stage1 生命周期门拆分 V6（2026-11-17）

本轮修订 Python 配对器，把“阻断性生命周期未知”和“退出后可识别的非操作参考”分开。**ID23 不加入 exit-drain 白名单，不建立操作代际，不建立锚点、不进 pending、不生成配对或字节候选。** InfoClass590448 继续标未映射；零信息值不是 Windows 只读语义证明。

74 项离线测试通过；两条真实样本在给定进程边界上下文中归为参考且不改变操作状态。新版本全量校准/正式回放仍待本机。字段合同 /2、两份 PowerShell 文件保持原哈希；报告 schema 为 r11-stage1-pairing/6。

先读 LIFETIME_GATE_SPLIT_REVIEW.md。PAIRING_CODE_REVIEW.diff 为核心差异；本包是完整离线候选，不覆盖已验收版本。

## 精确例外，不泛化到所有 Other

仅当前已审形态 ID23/version1/opcode0、Kernel-File、经验证的 named XML 映射、InfoClass590448、六个命名字段齐全且无额外写字段、Irp/FO/FileKey 可解析、ExtraInformation=0、无显式写候选，才可能成为参考；还须在观测退出后 700ms 内、前代际可识别、窗口未被新 Create/Read/Write 关闭。非此形态或任一条件不足，仍阻断。

参考的 generation=null，reference_generation 只是上下文，不能用于操作匹配。post-exit-classified-reference.jsonl 不采样，逐条保留原始头/属性、指针、InfoClass、延迟、退出边界和无操作副作用标志。

unknown_process_lifetime 只计阻断性 unknown；原有生命周期门仍要求其为零。新计数 post_exit_classified_reference 单列，不混入 exit_drain。报告 lifetime_gate_policy 明示：即使验收门通过，也不代表所有事件具有操作归属或语义已解码。

若后续确认此 InfoClass 为写/新建/新请求，使用 --disable-post-exit-classified-reference 撤销例外，回落阻断；不要为过门扩展形态或解码未知位。

## 本机校准回归先行

```powershell
$ErrorActionPreference='Stop'
py -3 -m unittest discover -s tests -v
if ($LASTEXITCODE -ne 0) { throw '离线测试失败' }
foreach ($ReviewTool in @('tools\Check-R11ProviderSchema.ps1','tools\Extract-R11.ps1')) {
    $ReviewTokens=$null
    $ReviewParseErrors=$null
    [void][System.Management.Automation.Language.Parser]::ParseFile(
        (Join-Path (Get-Location).Path $ReviewTool),[ref]$ReviewTokens,[ref]$ReviewParseErrors)
    if ($null -ne $ReviewParseErrors -and $ReviewParseErrors.Count -gt 0) { $ReviewParseErrors; throw 'Parser 失败' }
}
.\tools\Check-R11ProviderSchema.ps1 -OutputFile '.\provider-schema-v6-r1.json'
$FormalEvidenceEtl='D:\creo-tools\build\p1-step41-r10-late-find-review-20261112\runtime-r11\formal.etl'
$CalibrationEvidenceEtl=Join-Path (Split-Path $FormalEvidenceEtl) 'calibrate.etl'
$OfflineReviewRoot='F:\P1_R11_Stage1_LifetimeGateSplit_V6_20261117_R1'
.\tools\Extract-R11.ps1 -Etl $CalibrationEvidenceEtl -Mode calibration -OutputDirectory (Join-Path $OfflineReviewRoot 'cal-extract') -ProviderSchemaReport '.\provider-schema-v6-r1.json'
py -3 .\tools\pair_r11.py --input-dir (Join-Path $OfflineReviewRoot 'cal-extract') --output-dir (Join-Path $OfflineReviewRoot 'cal-pairs') --exit-drain-max-ms 700
if ($LASTEXITCODE -ne 0) { throw '校准门失败，停止' }
```

校准须 accepted=true、全部门通过、参考数=0、阻断 unknown=0；与 feedback_v6/calibration-baseline-summary.json 的 counters 逐项相等、65B 链六序号不变。不能只看总退出码而略过回归对照。

## 校准全过后，正式新目录

正式 R2 提取已通过全量哈希/计数门且提取器未变，可复用该完整目录；首跑中断、缺 extraction.json 的 formal-extract 目录不能使用。配对器仍逐项复算四产物哈希，不依赖目录名称判通过。

```powershell
$FormalExtractR2='F:\P1_R11_Stage1_ExitDrainFix_20261116_R1\formal-extract-R2'
py -3 .\tools\pair_r11.py --input-dir $FormalExtractR2 --output-dir (Join-Path $OfflineReviewRoot 'formal-pairs') --calibration-report (Join-Path $OfflineReviewRoot 'cal-pairs\pairing-report.json') --exit-drain-max-ms 700 --diagnostic-max-records 60000 --diagnostic-max-bytes 268435456
if ($LASTEXITCODE -ne 0) { throw '正式门失败，不升级结论' }
```

若需要重提取，使用同一现存 formal.etl 和已通过模板报告，写新的 formal-extract 目录，再将上述 input-dir 指过去；不重新采集 ETL，不覆盖旧目录。

## 对照 R3 配对签名

```powershell
$PreviousFormalPairs='F:\P1_R11_Stage1_ExitDrainFix_20261116_R1\formal-pairs-R3\pairs.jsonl'
py -3 .\tools\compare_v6_reports.py --calibration-report (Join-Path $OfflineReviewRoot 'cal-pairs\pairing-report.json') --formal-report (Join-Path $OfflineReviewRoot 'formal-pairs\pairing-report.json') --reference-stream (Join-Path $OfflineReviewRoot 'formal-pairs\post-exit-classified-reference.jsonl') --previous-formal-pairs $PreviousFormalPairs --formal-pairs (Join-Path $OfflineReviewRoot 'formal-pairs\pairs.jsonl') --output (Join-Path $OfflineReviewRoot 'v6-regression-review.json')
if ($LASTEXITCODE -ne 0) { throw '回归对照失败，保留证据并停止' }
```

校验器只读本机 JSON/JSONL，确认两个报告均为 /6、策略窗为 700ms，并验证校准 counters/六序号、正式阻断 unknown=0、参考恰为两条指定 ID23、exit_drain=99，以及全时段和退出前配对签名不变。其他 counters 的 R3 差异逐项列出，不藏进“质量提升”结论。

R3 对 unknown ID23 曾继续创建 None 代际 pending 假节点；V6 按要求不创建。因此 pending 总量可能少这两条，相关 cross-context/orphan 参考桶也可能迁移。这不是消费已存在请求；新规则对既有 pending 的无副作用已有测试，实际配对签名仍须不变。

## 回传与边界

先发新校准、正式 pairing-report.json、extraction.json、v6-regression-review.json、两条 post-exit-classified-reference 记录及模板/单测结果。参考数超出 2、出现写/新操作例外、基线退化或配对签名变化均停止，不发整份 ETL/大 JSONL。

validation/id23-reference-sample-review.json 只审核收到的两条真实记录，不是全量正式回放。输入报告单独文件比包内版本只多 ZIP 路径/大小/哈希行，校验与审核结论没有冲突。

不部署、不改 Creo/UI/插件/配置/模型，不新采，不发送 PTC。BuffersLost、IOFlags、InfoClass 冲突/590448 语义、0x216、tracerpt 偏移、卷映射、.ui 持久化及 DLL/GUI 成功与否保持未决。

import json
from pathlib import Path
import tempfile
import unittest
from test_stage1 import m, event
from test_scope_fix import fixture, reseal


def life(calibration=True,created=True):
    instance=(m.CaptureLifetimes if calibration else m.Lifetimes)()
    instance.boundaries[23636]=([(1,"1")] if created else [])+[(10,"2")]
    instance.boundary_evidence[(23636,10)]={"source_sequence":10,"event_id":"2","system_time":event(10,24)["system_time"]}
    return instance


class ExitDrainTests(unittest.TestCase):
    def test_only_allowlisted_classes_are_attributed_to_retiring_generation(self):
        resolver=life()
        self.assertIsNone(resolver.generation(23636,11))
        for seq,eid in enumerate((13,14,22,24),11):
            result=resolver.resolve_event(event(seq,eid))
            self.assertEqual(result["kind"],"exit-drain")
            self.assertEqual(result["generation"],1)

    def test_new_create_read_write_rejected_and_close_window(self):
        for eid in (12,15,16):
            resolver=life()
            result=resolver.resolve_event(event(11,eid))
            self.assertIsNone(result["generation"])
            self.assertEqual(result["reason"],"new_operation_after_exit_without_create")
            later=resolver.resolve_event(event(12,13))
            self.assertEqual(later["reason"],"exit_window_closed_by_new_operation")

    def test_late_cleanup_is_not_unbounded_drain(self):
        resolver=life()
        e=event(11,13)
        e["system_time"]="2026-11-12T07:25:20.1010010Z"
        result=resolver.resolve_event(e,max_drain_ms=100)
        self.assertIsNone(result["generation"])
        self.assertEqual(result["reason"],"outside_controlled_exit_drain_window")

    def test_next_observed_create_starts_new_generation(self):
        resolver=life()
        resolver.resolve_event(event(11,15))
        resolver.boundaries[23636].append((20,"1"))
        result=resolver.resolve_event(event(21,15))
        self.assertEqual(result["generation"],20)
        self.assertEqual(result["kind"],"active_or_capture_start")

    def test_missing_boundary_clock_does_not_invent_window(self):
        resolver=life()
        resolver.boundary_evidence.clear()
        result=resolver.resolve_event(event(11,13))
        self.assertEqual(result["reason"],"exit_header_time_unavailable")

    def test_formal_requires_creation_but_calibration_can_use_capture_start_assumption(self):
        self.assertEqual(life(created=False).resolve_event(event(11,13))["generation"],0)
        self.assertIsNone(life(calibration=False,created=False).resolve_event(event(11,13))["generation"])

    def test_cleanup_unseen_object_is_recorded_without_path_invention(self):
        output=[]
        matcher=m.Matcher(23636,lambda kind,r:output.append(r) if kind=="exit-drain" else None,lifetimes=life())
        matcher.on_event(event(11,13,FileObject="999",Irp="4"))
        matcher.on_event(event(12,14,FileObject="999",Irp="5"))
        result=matcher.finish()
        self.assertEqual(result["counters"]["exit_drain"],2)
        self.assertEqual(result["counters"].get("unknown_process_lifetime",0),0)
        self.assertFalse(output[0]["open_anchor_present"])
        self.assertEqual(result["exit_drain"]["windows"][0]["file_objects_not_previously_opened_in_generation"],1)
        self.assertEqual(result["files"],[])

    def test_pre_exit_request_can_complete_in_classified_drain(self):
        pairs=[]
        matcher=m.Matcher(23636,lambda kind,r:pairs.append(r) if kind=="pairs" else None,lifetimes=life())
        for e in [event(2,12,FileObject="2",FileName="a.txt"),
            event(9,15,FileObject="2",Irp="4",IOSize="100"),
            event(11,24,Irp="4",ExtraInformation="65",Status="0")]:matcher.on_event(e)
        result=matcher.finish()
        self.assertEqual(len(pairs),1)
        self.assertEqual(result["files"][0]["successful_read_bytes_candidate"],65)
        self.assertEqual(result["counters"]["exit_drain"],1)

    def test_non_allowlisted_query_stays_unknown(self):
        result=life().resolve_event(event(11,17))
        self.assertEqual(result["reason"],"post_exit_event_not_in_drain_allowlist")

    def test_calibration_pipeline_accepts_bounded_drain_and_reports_it_separately(self):
        with tempfile.TemporaryDirectory() as d:
            folder=Path(d)
            extract,cp=fixture(folder)
            exit_record={"source_sequence":8,"event_id":2,"system_time":event(8,24)["system_time"],
                "raw_xml":"<Event><EventData><Data Name='ProcessID'>23636</Data></EventData></Event>"}
            (extract/"process-events.jsonl").write_text(json.dumps(exit_record)+"\n")
            with (extract/"target-events.jsonl").open("a") as f:
                for e in [event(9,13,FileObject="2",Irp="88"),event(10,24,Irp="88",Status="0",ExtraInformation="2"),
                          event(11,14,FileObject="2",Irp="89"),event(12,24,Irp="89",Status="0",ExtraInformation="0")]:
                    f.write(json.dumps(e)+"\n")
            reseal(extract,cp,12)
            report=m.run(extract,folder/"result",cp)
            self.assertTrue(report["accepted"])
            self.assertTrue(report["gates"]["calibration_target_not_after_unmatched_exit"])
            self.assertEqual(report["counters"]["exit_drain"],4)
            self.assertEqual(report["exit_drain"]["windows"][0]["first_sequence"],9)
            self.assertEqual(len((folder/"result/exit-drain.jsonl").read_text().splitlines()),4)

    def test_calibration_pipeline_still_rejects_new_read_after_exit(self):
        with tempfile.TemporaryDirectory() as d:
            folder=Path(d)
            extract,cp=fixture(folder)
            exit_record={"source_sequence":8,"event_id":2,"system_time":event(8,24)["system_time"],
                "raw_xml":"<Event><EventData><Data Name='ProcessID'>23636</Data></EventData></Event>"}
            (extract/"process-events.jsonl").write_text(json.dumps(exit_record)+"\n")
            with (extract/"target-events.jsonl").open("a") as f:f.write(json.dumps(event(9,15,FileObject="2",Irp="99",IOSize="100"))+"\n")
            reseal(extract,cp,9)
            report=m.run(extract,folder/"result",cp)
            self.assertFalse(report["accepted"])
            self.assertFalse(report["gates"]["calibration_target_not_after_unmatched_exit"])
            self.assertTrue(report["calibration_gate"])
            self.assertIsNone(report["files"][0]["successful_read_bytes_candidate"])


if __name__=="__main__":unittest.main()

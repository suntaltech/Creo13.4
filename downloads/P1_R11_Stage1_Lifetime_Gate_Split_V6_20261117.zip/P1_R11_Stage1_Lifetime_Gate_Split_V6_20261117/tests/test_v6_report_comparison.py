import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from test_stage1 import ROOT, m, basic, match


SPEC=importlib.util.spec_from_file_location("v6_report_comparison",ROOT/"tools/compare_v6_reports.py")
sys.path.insert(0,str(ROOT/"tools"))
helper=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(helper)


class ReportComparisonTests(unittest.TestCase):
    def test_signature_detects_new_assignment_and_filters_active_period(self):
        _,out=match(basic())
        pair=out["pairs"][0]
        with tempfile.TemporaryDirectory() as d:
            a,b=Path(d)/"old.jsonl",Path(d)/"new.jsonl"
            a.write_text(json.dumps(pair)+"\n")
            b.write_text(json.dumps(pair)+"\n")
            self.assertEqual(helper.pair_digest(a,10),helper.pair_digest(b,10))
            pair["request"]["event"]["data"]["FileObject"]="999"
            b.write_text(json.dumps(pair)+"\n")
            self.assertNotEqual(helper.pair_digest(a,10)["active_pair_digest"],helper.pair_digest(b,10)["active_pair_digest"])
            self.assertEqual(helper.pair_digest(a,2)["active_pairs"],0)


if __name__=="__main__":unittest.main()

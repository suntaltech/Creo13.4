import copy
import json
from pathlib import Path
import re
import tempfile
import unittest
from test_stage1 import m, ROOT, CONTRACT, event


SAMPLES=m.load(ROOT/"feedback_v6/id23-samples.json")


def reference(index=0):
    return copy.deepcopy(SAMPLES[index]["event"])


def life(created=True):
    result=m.Lifetimes()
    result.boundaries[23636]=([(393339,"1")] if created else [])+[(1326139,"2")]
    result.boundary_evidence[(23636,1326139)]=copy.deepcopy(SAMPLES[0]["lifetime_resolution"]["exit_boundary"])
    return result


def state(matcher):
    return copy.deepcopy({name:getattr(matcher,name) for name in
        ("pending","irp_index","object_pending","tainted_keys","anchors","generations","rows","foreign_recent","watched_keys")})


def make_formal_fixture(folder):
    cp=folder/"contract.json"
    contract=copy.deepcopy(CONTRACT)
    records=[event(2,12,FileObject="2",FileName="a.txt"),event(3,15,FileObject="2",Irp="4",IOSize="100"),
             event(4,24,Irp="4",Status="0",ExtraInformation="65")]
    for seq,index,clock in [(6,0,"2026-11-12T07:25:20.1597794Z"),(7,1,"2026-11-12T07:25:20.1953440Z")]:
        e=reference(index)
        e.update({"source_sequence":seq,"record_id":seq-1,"system_time":clock})
        e["named_xml"]=re.sub(r"TimeCreated SystemTime='[^']+'", "TimeCreated SystemTime='"+clock+"'", e["named_xml"])
        e["named_xml"]=re.sub(r"<EventRecordID>[^<]+", "<EventRecordID>"+str(seq-1),e["named_xml"])
        records.append(e)
    counts=dict(m.Counter(e["event_id"] for e in records))
    contract["formal"].update({"bytes":1,"sha256":"synthetic-formal-hash","get_winevent_total":7,
        "header_events_processed":8,"event_counts":counts})
    cp.write_text(json.dumps(contract))
    extract=folder/"extract"
    extract.mkdir()
    (extract/"target-events.jsonl").write_text("".join(json.dumps(e)+"\n" for e in records))
    (extract/"context-events.jsonl").write_text("")
    processes=[{"source_sequence":seq,"event_id":eid,"system_time":event(seq,24)["system_time"],
        "raw_xml":"<Event><EventData><Data Name='ProcessID'>23636</Data></EventData></Event>"}
        for seq,eid in [(1,1),(5,2)]]
    (extract/"process-events.jsonl").write_text("".join(json.dumps(e)+"\n" for e in processes))
    (extract/"provider-schema.json").write_text(json.dumps({"schema_checked":True,"contract_sha256":m.sha(cp),"provider_guid":contract["file_provider"]}))
    meta={"mode":"formal","target_pid":23636,"complete":True,"source_unchanged":True,
        "source_bytes":1,"source_sha256_before":"synthetic-formal-hash","source_sha256_after":"synthetic-formal-hash",
        "contract_sha256":m.sha(cp),"pass1_total_events":7,"pass2_total_events":7,"decode_errors":0,
        "target_order_matches":True,"target_order_hash_pass1":"fixture-order","target_order_hash_pass2":"fixture-order",
        "target_event_counts":counts,"files":{n:{"bytes":(extract/n).stat().st_size,"sha256":m.sha(extract/n)} for n in
            ("target-events.jsonl","context-events.jsonl","process-events.jsonl","provider-schema.json")}}
    (extract/"extraction.json").write_text(json.dumps(meta))
    cal=folder/"synthetic-calibration-report.json"
    cal.write_text(json.dumps({"mode":"calibration","accepted":True,"calibration_gate":True,"contract_sha256":m.sha(cp)}))
    return extract,cp,cal


class LifetimeGateSplitTests(unittest.TestCase):
    def test_actual_two_samples_are_reference_only_not_exit_drain(self):
        matcher=m.Matcher(23636,lifetimes=life())
        for item in SAMPLES:
            e=copy.deepcopy(item["event"])
            m.validate_layout(e,CONTRACT)
            matcher.on_event(e)
        result=matcher.finish()
        self.assertEqual(result["counters"]["post_exit_classified_reference"],2)
        self.assertEqual(result["counters"]["unknown_process_lifetime"],0)
        self.assertEqual(result["counters"]["exit_drain"],0)
        self.assertEqual(result["files"],[])
        self.assertEqual(result["pending_irp_scope_slots"],0)

    def test_reference_does_not_mutate_operational_graph(self):
        matcher=m.Matcher(23636,lifetimes=life())
        before=state(matcher)
        blocked=copy.deepcopy(matcher.life.blocked_exit_windows)
        matcher.on_event(reference())
        self.assertEqual(state(matcher),before)
        self.assertEqual(matcher.life.blocked_exit_windows,blocked)

    def test_reference_cannot_consume_or_taint_same_irp_pending_operation(self):
        pairs=[]
        matcher=m.Matcher(23636,lambda kind,r:pairs.append(r) if kind=="pairs" else None,lifetimes=life())
        e=reference()
        irp=e["data"]["Irp"]
        matcher.on_event(event(1326100,12,FileObject="2",FileName="a.txt"))
        matcher.on_event(event(1326101,15,FileObject="2",Irp=irp,IOSize="100"))
        before=state(matcher)
        matcher.on_event(e)
        self.assertEqual(state(matcher),before)
        end=event(1327724,24,Irp=irp,Status="0",ExtraInformation="65")
        end["system_time"]="2026-11-12T07:27:23.5572464Z"
        matcher.on_event(end)
        self.assertEqual(len(pairs),1)
        self.assertEqual(pairs[0]["transferred_bytes_candidate"],65)

    def test_nonzero_information_bad_pointers_and_write_evidence_are_blocking(self):
        mutations=[lambda e:e["data"].update(ExtraInformation="1"),
            lambda e:e["data"].update(Irp="0"),lambda e:e["data"].update(FileObject="bad-pointer"),
            lambda e:e["data"].update(FileKey="0"),lambda e:e.update(write_bytes_candidate=1),
            lambda e:e.update(operation="WriteFile"),lambda e:e["data"].update(IOSize="0"),
            lambda e:e["data"].update(InfoClass="589992")]
        for mutate in mutations:
            with self.subTest(mutation=mutate):
                e=reference();mutate(e)
                result=life().resolve_event(e)
                self.assertEqual(result["kind"],"unknown")

    def test_unverified_mapping_or_version_cannot_inherit_reference_profile(self):
        for field,value in [("mapping","unverified"),("version","0"),("opcode","1"),("decode_error","bad")]:
            e=reference();e[field]=value
            self.assertEqual(life().resolve_event(e)["kind"],"unknown")

    def test_outside_window_still_unknown(self):
        e=reference();e["system_time"]="2026-11-12T07:27:24.1464675Z"
        self.assertEqual(life().resolve_event(e)["reason"],"outside_controlled_exit_drain_window")

    def test_reference_after_unobserved_new_io_stays_blocked(self):
        resolver=life()
        new=reference();new["event_id"]="15";new["source_sequence"]-=1
        resolver.resolve_event(new)
        result=resolver.resolve_event(reference())
        self.assertEqual(result["reason"],"exit_window_closed_by_new_operation")

    def test_missing_exit_time_or_previous_creation_stays_blocked(self):
        resolver=life();resolver.boundary_evidence.clear()
        self.assertEqual(resolver.resolve_event(reference())["reason"],"exit_header_time_unavailable")
        self.assertEqual(life(created=False).resolve_event(reference())["reason"],"no_attributable_pre_exit_generation")

    def test_active_id23_not_reclassified_and_new_io_never_reference(self):
        resolver=life()
        e=reference();e["source_sequence"]=500000;e["system_time"]="2026-11-12T07:25:20.0000001Z"
        self.assertEqual(resolver.resolve_event(e)["kind"],"active_or_capture_start")
        for eid in (12,15,16):
            new=reference();new["event_id"]=str(eid)
            self.assertEqual(life().resolve_event(new)["reason"],"new_operation_after_exit_without_create")

    def test_profile_can_be_revoked_without_expanding_drain_whitelist(self):
        self.assertEqual(life().resolve_event(reference(),allow_post_exit_references=False)["kind"],"unknown")
        matcher=m.Matcher(23636,lifetimes=life(),allow_post_exit_references=False)
        matcher.on_event(reference())
        result=matcher.finish()
        self.assertEqual(result["counters"]["unknown_process_lifetime"],1)
        self.assertEqual(result["counters"]["post_exit_classified_reference"],0)
        self.assertNotIn("23",result["exit_drain"]["allowed_ids"])

    def test_reference_diagnostic_preserves_raw_fields_and_non_operational_generation(self):
        output=[]
        matcher=m.Matcher(23636,lambda kind,r:output.append(r) if kind=="post-exit-classified-reference" else None,lifetimes=life())
        e=reference();matcher.on_event(e)
        record=output[0]
        self.assertEqual(record["event"],e)
        self.assertIsNone(record["lifetime_resolution"]["generation"])
        self.assertEqual(record["lifetime_resolution"]["reference_generation"],393339)
        self.assertEqual(record["infoclass_mapping"],"unmapped")
        self.assertFalse(record["new_anchor"] or record["new_pending"] or record["pair_candidate"])

    def test_full_synthetic_formal_gate_split_and_uncapped_reference_stream(self):
        with tempfile.TemporaryDirectory() as d:
            folder=Path(d);extract,cp,cal=make_formal_fixture(folder)
            result=m.run(extract,folder/"result",cp,cal,diagnostic_max_records=1)
            self.assertTrue(result["accepted"])
            self.assertTrue(result["gates"]["target_lifetime_known"])
            self.assertFalse(result["lifetime_gate_policy"]["all_target_events_operationally_attributed"])
            self.assertEqual(result["counters"]["pairs"],1)
            self.assertEqual(result["counters"]["post_exit_classified_reference"],2)
            self.assertEqual(result["counters"]["unknown_process_lifetime"],0)
            self.assertEqual(result["pending_irp_scope_slots"],0)
            self.assertEqual(len((folder/"result/post-exit-classified-reference.jsonl").read_text().splitlines()),2)
            self.assertEqual(result["files"][0]["successful_read_bytes_candidate"],65)

    def test_revocation_keeps_lifetime_gate_blocking_and_withholds_aggregate(self):
        with tempfile.TemporaryDirectory() as d:
            folder=Path(d);extract,cp,cal=make_formal_fixture(folder)
            result=m.run(extract,folder/"result",cp,cal,allow_post_exit_references=False)
            self.assertFalse(result["accepted"])
            self.assertFalse(result["gates"]["target_lifetime_known"])
            self.assertEqual(result["counters"]["unknown_process_lifetime"],2)
            self.assertIsNone(result["files"][0]["successful_read_bytes_candidate"])


if __name__=="__main__":unittest.main()

import io
import json
import unittest
from pathlib import Path
import xml.etree.ElementTree as ET

from test_stage1 import m, CONTRACT, ROOT, event, basic, match


class CalibrationFixTests(unittest.TestCase):
    def test_contract_agrees_with_version_specific_manifest(self):
        source=ET.parse(ROOT/"reference/provider-manifest-win10-18990.xml").getroot()
        checked=0
        for e in source.iter():
            eid,ver=e.get("value"),e.get("version")
            if e.tag.rsplit("}",1)[-1]!="event" or eid not in CONTRACT["property_layouts"] or ver not in CONTRACT["property_layouts"][eid]:
                continue
            template=next(t for t in source.iter() if t.tag.rsplit("}",1)[-1]=="template" and t.get("tid")==e.get("template"))
            self.assertEqual([x.get("name") for x in template],CONTRACT["property_layouts"][eid][ver]["fields"])
            checked+=1
        self.assertEqual(checked,6)

    def test_real_raw_requests_use_irp_not_filekey(self):
        data=m.load(ROOT/"input_evidence/baseline-chain-sample.json")
        events={e["source_sequence"]:m.remap_raw_sample(e,CONTRACT) for e in data["events"]}
        self.assertEqual(events[180106]["data"]["Irp"],"18446646818753682312")
        self.assertEqual(events[180106]["data"]["FileObject"],"18446646818528985520")
        self.assertEqual(m.ptr(events[180106]["data"]["FileKey"]),m.ptr(events[180105]["data"]["FileKey"]))
        self.assertEqual(events[180103]["data"]["Irp"],events[180106]["data"]["Irp"])
        self.assertNotIn("FileKey",events[180103]["data"])

    def test_real_completion_samples_keep_independent_irp_and_no_fileobject(self):
        sample=m.load(ROOT/"input_evidence/id24-completion-sample.json")
        for e in sample["events"]:
            result=m.remap_raw_sample(e,CONTRACT)
            self.assertEqual(result["data"]["Irp"],e["raw_properties"][0]["value"])
            self.assertNotIn("FileObject",result["data"])

    def test_no_irp_completion_is_orphan_never_fileobject_fallback(self):
        events=basic()
        events[-1]["data"]={"FileObject":"2","Status":"0","ExtraInformation":"65"}
        report,out=match(events)
        self.assertEqual(report["counters"]["orphan_completions"],1)
        self.assertNotIn("pairs",out)

    def test_same_fileobject_parallel_distinct_irps_are_separate_operations(self):
        report,out=match([basic()[0],
            event(2,15,FileObject="2",FileKey="3",Irp="4",IOSize="100"),
            event(3,15,FileObject="2",FileKey="3",Irp="5",IOSize="100"),
            event(4,24,Irp="5",ExtraInformation="20",Status="0"),
            event(5,24,Irp="4",ExtraInformation="30",Status="0")])
        self.assertEqual(report["files"][0]["successful_read_bytes_candidate"],50)
        self.assertEqual(len(out["pairs"]),2)
        self.assertEqual(report["counters"].get("overlap_requests",0),0)

    def test_create_irp_is_consumed_before_reuse_for_read(self):
        report,out=match([
            event(1,12,Irp="4",FileObject="2",FileName="a.txt"),
            event(2,24,Irp="4",ExtraInformation="1",Status="0"),
            event(3,15,Irp="4",FileObject="2",FileKey="3",IOSize="100"),
            event(4,24,Irp="4",ExtraInformation="65",Status="0")])
        self.assertEqual(report["files"][0]["successful_read_bytes_candidate"],65)
        self.assertIsNone(out["pairs"][0]["transferred_bytes_candidate"])
        self.assertEqual(report["files"][0]["successful_open_pairs"],1)

    def test_failed_create_revokes_its_anchor(self):
        report,out=match([
            event(1,12,Irp="4",FileObject="2",FileName="a.txt"),
            event(2,24,Irp="4",ExtraInformation="0",Status="0xc0000034"),
            event(3,15,Irp="4",FileObject="2",IOSize="100"),
            event(4,24,Irp="4",ExtraInformation="65",Status="0")])
        self.assertIsNone(out["pairs"][-1]["request"]["path"])

    def test_version_and_type_are_gates_not_shape_only(self):
        e=basic()[1]
        e["version"]="0"
        with self.assertRaises(ValueError):m.validate_layout(e,CONTRACT)
        e["version"]="1"
        e["raw_properties"][1]["type"]="System.String"
        with self.assertRaises(ValueError):m.validate_layout(e,CONTRACT)

    def test_overlap_reference_size_does_not_grow_with_history(self):
        emitted=[]
        matcher=m.Matcher(23636,lambda kind,rec:emitted.append(rec) if kind=="overlaps" else None)
        matcher.on_event(basic()[0])
        for seq in range(2,1002):
            matcher.on_event(event(seq,15,Irp="4",FileObject="2",IOSize="65"))
        self.assertEqual(emitted[-1]["total_pending_requests"],999)
        self.assertLessEqual(max(len(x["request_references"]) for x in emitted),8)
        self.assertTrue(emitted[-1]["reference_list_truncated"])
        self.assertLess(sum(len(json.dumps(x)) for x in emitted),3_000_000)

    def test_diagnostic_cap_records_omissions(self):
        writer=io.StringIO()
        sink=m.DiagnosticSink({"unresolved":writer},byte_limit=1000,record_limit=2)
        for n in range(10):sink.write("unresolved",{"event":n})
        self.assertEqual(sink.stats["unresolved"]["written_records"],2)
        self.assertEqual(sink.stats["unresolved"]["omitted_records"],8)
        self.assertLessEqual(len(writer.getvalue().encode()),1000)

    def test_samples_are_not_full_calibration_acceptance(self):
        sample=m.load(ROOT/"input_evidence/baseline-chain-sample.json")
        other=m.load(ROOT/"input_evidence/id24-completion-sample.json")
        requests={m.ptr(m.remap_raw_sample(e,CONTRACT)["data"].get("Irp")) for e in sample["events"] if e["event_id"] in ("15","16")}
        completions={m.ptr(e["raw_properties"][0]["value"]) for e in other["events"]}
        self.assertFalse(requests & completions)
        self.assertFalse(any(e["event_id"]=="24" for e in sample["events"]))


if __name__=="__main__":unittest.main()

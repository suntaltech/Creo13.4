import copy
import json
from pathlib import Path
import tempfile
import unittest
import test_stage1 as base
from test_stage1 import m, ROOT, CONTRACT, event, basic, match


def fixture(folder):
    return base.PipelineTests("test_calibration_pipeline_and_exclusive_output").fixture(folder)


def reseal(extract, cp, total):
    contract=m.load(cp)
    contract["calibration"]["get_winevent_total"]=total
    cp.write_text(json.dumps(contract))
    sp=extract/"provider-schema.json"
    schema=m.load(sp)
    schema["contract_sha256"]=m.sha(cp)
    sp.write_text(json.dumps(schema))
    meta=m.load(extract/"extraction.json")
    meta.update({"contract_sha256":m.sha(cp),"pass1_total_events":total,"pass2_total_events":total})
    meta["target_event_counts"]=dict(m.Counter(e["event_id"] for e in m.lines(extract/"target-events.jsonl")))
    for name in meta["files"]:
        p=extract/name
        meta["files"][name]={"bytes":p.stat().st_size,"sha256":m.sha(p)}
    (extract/"extraction.json").write_text(json.dumps(meta))


class ScopeFixTests(unittest.TestCase):
    def test_calibration_capture_start_generation_ends_at_observed_exit(self):
        life=m.CaptureLifetimes()
        life.boundaries[23636]=[(4,"2"),(8,"1")]
        self.assertEqual(life.generation(23636,2),0)
        self.assertIsNone(life.generation(23636,6))
        self.assertEqual(life.generation(23636,9),8)

    def test_foreign_request_same_pointer_cannot_poison_target(self):
        records=[event(1,15,process=99,Irp="4",FileObject="2",IOSize="999"),
            event(2,12,FileObject="2",FileName="a.txt"),
            event(3,15,FileObject="2",Irp="4",IOSize="100"),
            event(4,24,Irp="4",ExtraInformation="65",Status="0")]
        report,out=match(records)
        self.assertEqual(report["files"][0]["successful_read_bytes_candidate"],65)
        self.assertEqual(report["counters"].get("overlap_requests",0),0)
        self.assertEqual(report["counters"].get("pending_requests",0),0)
        self.assertEqual(out["pairs"][0]["pairing_basis"]["foreign_scopes_counted_as_candidates"],0)

    def test_foreign_completion_cannot_taint_target_then_own_completion(self):
        report,out=match(basic()[:2]+[
            event(3,24,process=99,Irp="4",Status="0",ExtraInformation="1"),
            event(4,24,Irp="4",Status="0",ExtraInformation="65")])
        self.assertEqual(len(out["pairs"]),1)
        self.assertEqual(report["files"][0]["successful_read_bytes_candidate"],65)
        self.assertEqual(report["counters"]["cross_context_completions"],1)

    def test_old_process_generation_not_a_new_generation_candidate(self):
        class Life:
            def generation(self,process_id,sequence):return 1 if sequence<4 else 4
        pairs=[]
        matcher=m.Matcher(23636,lambda kind,r:pairs.append(r) if kind=="pairs" else None,lifetimes=Life())
        for e in basic()[:2]+[event(4,12,FileObject="2",FileName="new.txt"),
            event(5,15,FileObject="2",Irp="4",IOSize="100"),
            event(6,24,Irp="4",Status="0",ExtraInformation="65")]:matcher.on_event(e)
        result=matcher.finish()
        self.assertEqual(len(pairs),1)
        self.assertEqual(pairs[0]["request"]["path"],"new.txt")
        self.assertEqual(result["counters"]["pending_requests"],1)

    def test_many_sequential_reuses_are_not_overlapping(self):
        matcher=m.Matcher(23636)
        matcher.on_event(basic()[0])
        for n in range(100):
            matcher.on_event(event(2+n*2,15,FileObject="2",Irp="4",IOSize="100"))
            matcher.on_event(event(3+n*2,24,Irp="4",Status="0",ExtraInformation="65"))
        report=matcher.finish()
        self.assertEqual(report["counters"]["pairs"],100)
        self.assertEqual(report["counters"].get("pending_requests",0),0)

    def test_supplied_six_records_have_three_fragment_candidates_without_fabricated_anchors(self):
        records=m.load(ROOT/"feedback_v2/baseline-chain-sample.json")["records"]
        for e in records:m.validate_layout(e,CONTRACT)
        out=[]
        matcher=m.Matcher(27584,lambda kind,r:out.append(r) if kind=="pairs" else None)
        for e in records:matcher.on_event(e)
        matcher.finish()
        self.assertEqual([(p["request"]["event"]["source_sequence"],p["completion"]["source_sequence"]) for p in out],
            [(180106,180107),(180436,180437),(180438,180439)])
        self.assertEqual([p["completion_information_raw"] for p in out],["65","65","0"])
        self.assertTrue(all(p["request"]["path"] is None and p["transferred_bytes_candidate"] is None for p in out))

    def test_fileobject_offset_and_size_do_not_invent_completion_discriminants(self):
        report,out=match([basic()[0],
            event(2,15,FileObject="2",Irp="4",ByteOffset="0",IOSize="10"),
            event(3,15,FileObject="9",Irp="4",ByteOffset="65",IOSize="4096"),
            event(4,24,Irp="4",Status="0",ExtraInformation="65")])
        self.assertNotIn("pairs",out)
        self.assertEqual(report["counters"]["ambiguous_completions"],1)
        self.assertIn("No nearest-time",out["unresolved"][0]["reason_not_narrowed"])

    def test_baseline_chain_retained_even_when_target_diagnostics_hit_limit(self):
        with tempfile.TemporaryDirectory() as d:
            folder=Path(d)
            extract,cp=fixture(folder)
            with (extract/"target-events.jsonl").open("a") as f:
                for seq in [8,9]:f.write(json.dumps(event(seq,24,Irp="999",Status="0",ExtraInformation="1"))+"\n")
            reseal(extract,cp,9)
            report=m.run(extract,folder/"result",cp,diagnostic_max_records=1)
            self.assertFalse(report["accepted"])
            self.assertTrue(report["calibration_gate"])
            self.assertEqual(report["calibration_baseline_chain"]["omitted"],0)
            baseline=[json.loads(x) for x in (folder/"result/baseline-chain.jsonl").read_text().splitlines()]
            self.assertEqual({r["event"]["source_sequence"] for r in baseline if r["kind"]=="raw-event"},set(range(1,8)))
            self.assertTrue(any(r["kind"]=="pairs" for r in baseline))

    def test_auxiliary_foreign_sampling_does_not_hide_or_change_target_evidence(self):
        with tempfile.TemporaryDirectory() as d:
            folder=Path(d)
            extract,cp=fixture(folder)
            context=[event(8,15,process=99,Irp="4",FileObject="2",IOSize="100"),
                     event(9,24,process=99,Irp="4",Status="0",ExtraInformation="10")]
            p=extract/"context-events.jsonl"
            p.write_text("".join(json.dumps(e)+"\n" for e in context))
            reseal(extract,cp,9)
            raw_hash=m.sha(p)
            report=m.run(extract,folder/"result",cp,diagnostic_max_records=1)
            self.assertTrue(report["accepted"])
            self.assertFalse(report["diagnostic_scope"]["ancillary_context_references_complete"])
            self.assertEqual(report["diagnostic_retention"]["context-reference"]["omitted_records"],1)
            self.assertEqual(m.sha(p),raw_hash)
            self.assertEqual(report["calibration_observations"]["write_65"],1)

    def test_offset65_without_eof_does_not_pass_calibration(self):
        with tempfile.TemporaryDirectory() as d:
            folder=Path(d)
            extract,cp=fixture(folder)
            p=extract/"target-events.jsonl"
            records=list(m.lines(p))
            records[-1]=event(7,24,Irp="6",Status="0",ExtraInformation="0")
            p.write_text("".join(json.dumps(e)+"\n" for e in records))
            reseal(extract,cp,7)
            report=m.run(extract,folder/"result",cp)
            self.assertFalse(report["calibration_gate"])

    def test_eof_before_successful_read_does_not_pass_chain_order(self):
        with tempfile.TemporaryDirectory() as d:
            folder=Path(d)
            extract,cp=fixture(folder)
            p=extract/"target-events.jsonl"
            records=list(m.lines(p))[:3]+[
                event(4,15,FileObject="2",Irp="6",IOSize="4096",ByteOffset="65"),
                event(5,24,Irp="6",Status="0xc0000011",ExtraInformation="0"),
                event(6,15,FileObject="2",Irp="5",IOSize="4096",ByteOffset="0"),
                event(7,24,Irp="5",Status="0",ExtraInformation="65")]
            p.write_text("".join(json.dumps(e)+"\n" for e in records))
            reseal(extract,cp,7)
            report=m.run(extract,folder/"result",cp)
            self.assertEqual(report["calibration_observations"]["read_65"],1)
            self.assertEqual(report["calibration_observations"]["read_offset_65_seen"],1)
            self.assertFalse(report["calibration_gate"])
            self.assertIsNone(report["calibration_sequence_proof"])

    def test_invalid_completion_order_taints_instead_of_reusing_future_completion(self):
        records=basic()[:2]+[event(3,24,Irp="4",Status="0",ExtraInformation="65"),
                           event(4,24,Irp="4",Status="0",ExtraInformation="65")]
        records[2]["system_time"]="2026-11-12T07:25:19.0000001Z"
        report,out=match(records)
        self.assertNotIn("pairs",out)
        self.assertEqual(report["counters"]["invalid_pair_order"],1)


if __name__=="__main__":unittest.main()

"""Check supplied exit summary/examples against policy, not a full ETL replay."""
import argparse
import json
from pathlib import Path
from pair_r11 import ROOT, CaptureLifetimes, load, sha, time_ns


def audit(max_ms=700):
    source=ROOT/"feedback_v4/exit-drain-stats.json"
    summary=load(source)
    target_pid=summary["target_pid"]
    life=CaptureLifetimes()
    for boundary in summary["observed_boundaries"]:
        seq=boundary["sequence"]
        life.boundaries[target_pid].append((seq,str(boundary["event_id"])))
        life.boundary_evidence[(target_pid,seq)]={"source_sequence":seq,"event_id":str(boundary["event_id"]),
            "system_time":boundary["time"],"source":"uploaded summary; not independently decoded process XML"}
    examples=[]
    for sample in summary["samples"]:
        resolution=life.resolve_event(sample,max_ms,process_id=target_pid)
        assert resolution["kind"]=="exit-drain"
        assert resolution["generation"]==summary["observed_boundaries"][0]["sequence"]
        examples.append({"original_sample":sample,"pid_context_from_summary":target_pid,"resolution":resolution})
    exit_time=next(b["time"] for b in summary["observed_boundaries"] if b["sequence"]==summary["exit_boundary_sequence"])
    delay=time_ns(summary["after_exit_time_range"][-1])-time_ns(exit_time)
    assert sum(summary["after_exit_event_type_counts"].values())==summary["after_exit_event_count"]
    assert summary["after_exit_new_request_events"]==0
    assert set(summary["after_exit_event_type_counts"]).issubset({"13","14","22","24"})
    assert 0<=delay<=int(max_ms*1_000_000)
    return {"schema":"r11-exit-drain-summary-audit/1","input_sha256":sha(source),
        "policy_max_ms":max_ms,"provided_examples_classified":len(examples),"examples":examples,
        "reported_aggregate_not_independently_recomputed":{"events":summary["after_exit_event_count"],
            "event_id_counts":summary["after_exit_event_type_counts"],"last_event_delay_ns":delay,
            "aggregate_is_compatible_with_policy":True},
        "full_calibration_accepted":None,
        "limitations":["Only eight provided examples were classified. The full 371 records were not supplied.",
            "Target PID and process boundary times were read from the summary context, not synthesized into raw ETW headers.",
            "This is a policy check, not an ETL decode or proof against PID reuse/capture omissions."]}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output",type=Path,required=True)
    p.add_argument("--exit-drain-max-ms",type=float,default=700)
    a=p.parse_args()
    with a.output.open("x",encoding="utf-8") as f:
        json.dump(audit(a.exit_drain_max_ms),f,ensure_ascii=False,indent=2)
        f.write("\n")


if __name__=="__main__":main()

"""Audit the two supplied V6 ID23 records, not the full ETL or pairing state."""
import argparse
import copy
import json
from pathlib import Path
from pair_r11 import ROOT, Lifetimes, Matcher, load, sha, validate_layout


def audit():
    source=ROOT/"feedback_v6/id23-samples.json"
    records=load(source)
    contract=load(ROOT/"reference/contract.json")
    resolver=Lifetimes()
    # Creation sequence is declared in the supplied task/report; no process XML
    # or ETW header is fabricated. Exit metadata is retained in each sample.
    resolver.boundaries[23636]=[(393339,"1"),(1326139,"2")]
    resolver.boundary_evidence[(23636,1326139)]=copy.deepcopy(records[0]["lifetime_resolution"]["exit_boundary"])
    output=[]
    matcher=Matcher(23636,lambda kind,r:output.append(r) if kind=="post-exit-classified-reference" else None,lifetimes=resolver)
    protected=("pending","irp_index","object_pending","tainted_keys","anchors","generations","rows","foreign_recent","watched_keys")
    before=copy.deepcopy({k:getattr(matcher,k) for k in protected})
    for record in records:
        validate_layout(record["event"],contract)
        matcher.on_event(copy.deepcopy(record["event"]))
    after={k:getattr(matcher,k) for k in protected}
    assert before==after
    result=matcher.finish()
    assert result["counters"]["post_exit_classified_reference"]==2
    assert result["counters"]["unknown_process_lifetime"]==0
    assert result["counters"]["exit_drain"]==0
    return {"schema":"r11-v6-reference-sample-audit/1","input_sha256":sha(source),
        "contract_sha256":sha(ROOT/"reference/contract.json"),"provided_records_checked":2,
        "scope":"two provided event records with declared process-boundary context only",
        "process_context_source":"creation sequence from supplied V6 task; exit metadata from attached prior classification",
        "new_classifications":output,"operational_state_unchanged":True,
        "fragment_counters":result["counters"],"full_formal_accepted":None,
        "limitations":["No full ETL or prior pending history replayed.",
            "InfoClass590448 remains unmapped; zero information is not proof of read-only semantics.",
            "Reference generation is context only, never an operational generation."]}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output",type=Path,required=True)
    a=p.parse_args()
    with a.output.open("x",encoding="utf-8") as f:
        json.dump(audit(),f,ensure_ascii=False,indent=2)
        f.write("\n")


if __name__=="__main__":main()

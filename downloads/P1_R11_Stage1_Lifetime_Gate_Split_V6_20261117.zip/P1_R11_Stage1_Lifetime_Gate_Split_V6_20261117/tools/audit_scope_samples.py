"""Replay the six supplied records as a fragment, not a full calibration."""
import argparse
import json
from pathlib import Path
from pair_r11 import ROOT, Matcher, load, sha, validate_layout


def audit():
    source=ROOT/"feedback_v2/baseline-chain-sample.json"
    context=ROOT/"feedback_v2/cross-context-sample.json"
    contract=load(ROOT/"reference/contract.json")
    records=load(source)["records"]
    pairs=[]
    matcher=Matcher(27584,lambda kind,r:pairs.append(r) if kind=="pairs" else None)
    for e in records:
        validate_layout(e,contract)
        matcher.on_event(e)
    result=matcher.finish()
    assert [(p["request"]["event"]["source_sequence"],p["completion"]["source_sequence"]) for p in pairs]==[(180106,180107),(180436,180437),(180438,180439)]
    assert all(p["transferred_bytes_candidate"] is None for p in pairs)
    return {"schema":"r11-scope-fragment-review/1", "scope":"six provided records only; previous same-scope pending state not supplied",
        "input_sha256":{source.name:sha(source),context.name:sha(context)},
        "contract_sha256":sha(ROOT/"reference/contract.json"),
        "fragment_same_scope_pairs":pairs,"fragment_counters":result["counters"],
        "full_calibration_accepted":None,"reason":"Fragment lacks Create anchors and earlier pending history. Pair candidates in this fragment are not full-session evidence or accepted byte totals.",
        "context_summary_records_not_fabricated_into_events":sum(len(v) for v in load(context)["samples"].values()),
        "context_note":"Trimmed context summaries lack timestamps/status/raw arrays. Kept as evidence summaries; no headers or events invented."}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output",type=Path,required=True)
    a=p.parse_args()
    with a.output.open("x",encoding="utf-8") as f:
        json.dump(audit(),f,ensure_ascii=False,indent=2)
        f.write("\n")


if __name__=="__main__":main()

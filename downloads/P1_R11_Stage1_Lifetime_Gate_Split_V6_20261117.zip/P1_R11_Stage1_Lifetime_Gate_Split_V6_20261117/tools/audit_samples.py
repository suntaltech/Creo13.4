"""Audit only handoff samples; cannot certify calibration without its completions."""
import argparse
import json
from pathlib import Path
from pair_r11 import ROOT, load, remap_raw_sample, ptr, integer, sha


def audit(root, contract_path):
    contract=load(contract_path)
    baseline=root/"baseline-chain-sample.json"
    completion=root/"id24-completion-sample.json"
    events=[remap_raw_sample(e,contract) for e in load(baseline)["events"]]
    ends=[remap_raw_sample(e,contract) for e in load(completion)["events"]]
    by_seq={e["source_sequence"]:e for e in events}
    create,write,name=by_seq[180103],by_seq[180106],by_seq[180105]
    requests=[e for e in events if e["event_id"] in ("15","16")]
    baseline_irps={ptr(e["data"].get("Irp")) for e in requests}
    intersect=baseline_irps & {ptr(e["data"].get("Irp")) for e in ends}
    assertions={
        "create_v1_has_irp_no_filekey":"Irp" in create["data"] and "FileKey" not in create["data"],
        "write_irp_matches_create_irp":ptr(write["data"]["Irp"])==ptr(create["data"]["Irp"]),
        "write_fileobject_matches_create_fileobject":ptr(write["data"]["FileObject"])==ptr(create["data"]["FileObject"]),
        "write_filekey_matches_name_event":ptr(write["data"]["FileKey"])==ptr(name["data"]["FileKey"]),
        "write_requested_65_at_offset_zero":integer(write["data"]["IOSize"])==65 and integer(write["data"]["ByteOffset"])==0,
        "read_offsets_zero_and_65":[integer(e["data"]["ByteOffset"]) for e in requests if e["event_id"]=="15"]==[0,65],
        "completion_samples_have_no_baseline_irp_overlap":not intersect}
    if not all(assertions.values()):
        raise ValueError("supplied sample audit failed: "+str(assertions))
    return {"schema":"r11-sample-field-audit/1", "scope":"29 provided sample records only, not ETL extraction",
        "contract_sha256":sha(contract_path),"inputs":{baseline.name:sha(baseline),completion.name:sha(completion)},
        "assertions":assertions,"checked_records":len(events)+len(ends),
        "baseline_id24_records_supplied":sum(e["event_id"]=="24" for e in events),
        "baseline_matching_completions_in_other_sample":len(intersect),
        "calibration_accepted":None,"reason":"No matching baseline completions supplied. Do not fabricate a passing extraction.json or pairing-report.json.",
        "provider_header_note":"Provider declared by handoff context; omitted in these trimmed samples. No provider header was synthesized.",
        "baseline_remapped_records":events,"completion_remapped_records":ends}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--evidence-dir",type=Path,default=ROOT/"input_evidence")
    p.add_argument("--contract",type=Path,default=ROOT/"reference/contract.json")
    p.add_argument("--output",type=Path,required=True)
    a=p.parse_args()
    report=audit(a.evidence_dir,a.contract)
    with a.output.open("x",encoding="utf-8") as f:
        json.dump(report,f,ensure_ascii=False,indent=2)
        f.write("\n")


if __name__=="__main__":
    main()

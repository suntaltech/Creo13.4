"""Read-only native V6 regression audit over existing reports and pair JSONL.

Never opens an ETL. Expected calibration counters come from supplied evidence.
All-period and pre-exit pair signatures must remain identical to formal R3.
"""
import argparse
import hashlib
import json
from pathlib import Path
from pair_r11 import ROOT, load, integer, post_exit_reference_profile, sha, time_ns


def pair_digest(path, exit_sequence):
    all_hash,active_hash=hashlib.sha256(),hashlib.sha256()
    total,active=0,0
    with path.open(encoding="utf-8-sig") as f:
        for line in f:
            pair=json.loads(line)
            request=pair["request"];event=request["event"];end=pair["completion"]
            signature={"request_seq":event["source_sequence"],"completion_seq":end["source_sequence"],
                "request_pid":event["execution_pid"],"request_tid":event["execution_tid"],
                "completion_pid":end["execution_pid"],"completion_tid":end["execution_tid"],
                "generation":request["lifetime_generation"],"path":request["path"],
                "event_id":event["event_id"],"request_data":event["data"],"completion_data":end["data"],
                "candidate_bytes":pair["transferred_bytes_candidate"]}
            raw=(json.dumps(signature,ensure_ascii=False,sort_keys=True)+"\n").encode("utf-8")
            all_hash.update(raw);total+=1
            if event["source_sequence"]<exit_sequence and end["source_sequence"]<exit_sequence:
                active_hash.update(raw);active+=1
    return {"all_pairs":total,"all_pair_digest":all_hash.hexdigest(),
        "active_pairs":active,"active_pair_digest":active_hash.hexdigest()}


def audit(cal_path,formal_path,reference_stream,previous_pairs,current_pairs):
    cal,formal=load(cal_path),load(formal_path)
    expected_cal=load(ROOT/"feedback_v6/calibration-baseline-summary.json")
    previous_summary=load(ROOT/"feedback_v6/formal-r3-pairing-summary.json")
    with reference_stream.open(encoding="utf-8-sig") as f:refs=[json.loads(line) for line in f]
    reference_events_ok=(len(refs)==2 and {r["event"]["source_sequence"] for r in refs}=={1327723,1328038}
        and all(post_exit_reference_profile(r["event"])["qualified"] and r["operational_effect"]=="none"
            and not (r["new_anchor"] or r["new_pending"] or r["pair_candidate"])
            and r["transferred_bytes_candidate"] is None and r["lifetime_resolution"]["generation"] is None
            and r["lifetime_resolution"]["kind"]=="post_exit_classified_reference"
            and r["lifetime_resolution"]["reference_generation"]==393339
            and r["infoclass_mapping"]=="unmapped"
            and 0<=time_ns(r["event"]["system_time"])-time_ns(r["lifetime_resolution"]["exit_boundary"]["system_time"])<=700_000_000 for r in refs))
    old_digest=pair_digest(previous_pairs,1326139)
    new_digest=pair_digest(current_pairs,1326139)
    proof_keys=("write_request","write_completion","read_request","read_completion","eof_request","eof_completion")
    new_proof=cal.get("calibration_sequence_proof") or {}
    expected_proof=expected_cal["calibration_sequence_proof"]
    checks={"calibration_mode":cal.get("mode")=="calibration","formal_mode":formal.get("mode")=="formal",
        "v6_report_schemas":cal.get("schema")==formal.get("schema")=="r11-stage1-pairing/6",
        "reviewed_700ms_policy":cal.get("exit_drain",{}).get("policy_max_ms")==formal.get("exit_drain",{}).get("policy_max_ms")==700,
        "calibration_accepted":cal.get("accepted") is True and all(cal["gates"].values()),
        "formal_accepted":formal.get("accepted") is True and all(formal["gates"].values()),
        "contract_unchanged":cal.get("contract_sha256")==formal.get("contract_sha256")==sha(ROOT/"reference/contract.json"),
        "calibration_counters_equal_baseline":all(cal["counters"].get(k,0)==v for k,v in expected_cal["counters"].items()),
        "calibration_has_no_new_reference":cal["counters"].get("post_exit_classified_reference",0)==0,
        "calibration_sequence_unchanged":all(integer(new_proof.get(k))==integer(expected_proof[k]) for k in proof_keys),
        "formal_blocking_unknown_zero":formal["counters"].get("unknown_process_lifetime")==0,
        "formal_reference_exactly_two":formal["counters"].get("post_exit_classified_reference")==2 and reference_events_ok,
        "formal_exit_drain_99":formal["counters"].get("exit_drain")==99,
        "all_pair_signatures_unchanged":old_digest["all_pairs"]==new_digest["all_pairs"] and old_digest["all_pair_digest"]==new_digest["all_pair_digest"],
        "active_pair_signatures_unchanged":old_digest["active_pairs"]==new_digest["active_pairs"] and old_digest["active_pair_digest"]==new_digest["active_pair_digest"]}
    deltas={k:{"r3":v,"new":formal["counters"].get(k,0),"delta":formal["counters"].get(k,0)-v}
        for k,v in previous_summary["counters"].items()}
    return {"schema":"r11-v6-native-regression-audit/1","passed":all(checks.values()),"checks":checks,
        "previous_pair_signatures":old_digest,"current_pair_signatures":new_digest,"formal_counter_deltas":deltas,
        "inputs":{str(p):sha(p) for p in (cal_path,formal_path,reference_stream,previous_pairs,current_pairs)},
        "note":"Counters affected by removal of old unknown-scope ID23 pending nodes are reported explicitly; no pair-change assumption is substituted for signature comparison.",
        "scope":"Native artifacts only; this audit does not prove Windows operation semantics, losslessness, DLL load or GUI enumeration."}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--calibration-report",type=Path,required=True)
    p.add_argument("--formal-report",type=Path,required=True)
    p.add_argument("--reference-stream",type=Path,required=True)
    p.add_argument("--previous-formal-pairs",type=Path,required=True)
    p.add_argument("--formal-pairs",type=Path,required=True)
    p.add_argument("--output",type=Path,required=True)
    a=p.parse_args()
    result=audit(a.calibration_report,a.formal_report,a.reference_stream,a.previous_formal_pairs,a.formal_pairs)
    with a.output.open("x",encoding="utf-8") as f:
        json.dump(result,f,ensure_ascii=False,indent=2);f.write("\n")
    print(json.dumps({"passed":result["passed"],"checks":result["checks"]},ensure_ascii=False))
    raise SystemExit(0 if result["passed"] else 2)


if __name__=="__main__":main()

#requires -Version 5.1
<# Read installed provider metadata only. No ETW session or ETL is opened. #>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$OutputFile,
    [string]$Contract=(Join-Path $PSScriptRoot '..\reference\contract.json')
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
if (Test-Path -LiteralPath $OutputFile) { throw 'Output must not exist' }
$cfg=Get-Content -LiteralPath $Contract -Raw -Encoding UTF8 | ConvertFrom-Json
$provider=Get-WinEvent -ListProvider 'Microsoft-Windows-Kernel-File' -ErrorAction Stop
$templateChecks=New-Object 'System.Collections.Generic.List[object]'
$passed=($provider.Id -eq [Guid]$cfg.file_provider)
foreach ($layoutProperty in $cfg.property_layouts.PSObject.Properties) {
    foreach ($versionProperty in $layoutProperty.Value.PSObject.Properties) {
        $layout=$versionProperty.Value
        $metadata=@($provider.Events | Where-Object {
            $_.Id -eq [int]$layoutProperty.Name -and $_.Version -eq [int]$versionProperty.Name
        })
        $actual=@()
        $template=$null
        $errorText=$null
        $ok=$false
        try {
            if ($metadata.Count -ne 1) { throw 'Expected exactly one installed EventID/Version template' }
            $template=$metadata[0].Template
            [xml]$xml=$template
            $nodes=$xml.SelectNodes("//*[local-name()='template']/*[local-name()='data']")
            foreach ($node in $nodes) {
                $actual += [ordered]@{name=$node.GetAttribute('name');inType=$node.GetAttribute('inType')}
            }
            $ok=($actual.Count -eq @($layout.fields).Count)
            if ($ok) {
                for ($i=0;$i -lt $actual.Count;$i++) {
                    if ($actual[$i].name -cne $layout.fields[$i] -or $actual[$i].inType -cne $layout.manifest_types[$i]) { $ok=$false }
                }
            }
        } catch { $errorText=$_.Exception.Message; $ok=$false }
        if (-not $ok) { $passed=$false }
        $templateChecks.Add([ordered]@{event_id=$layoutProperty.Name;version=$versionProperty.Name;
            fields_match=$ok;expected_fields=$layout.fields;expected_types=$layout.manifest_types;
            actual=$actual;raw_template=$template;error=$errorText})
    }
}
$report=[ordered]@{schema='r11-installed-provider-schema/1';provider_name=$provider.Name;
    provider_guid=$provider.Id.ToString();schema_checked=$passed;
    contract_sha256=(Get-FileHash -LiteralPath $Contract -Algorithm SHA256).Hash;
    scope='Installed event metadata only; not an ETL replay/calibration acceptance';
    templates=$templateChecks.ToArray()}
$encoding=New-Object System.Text.UTF8Encoding($false)
$stream=[IO.File]::Open([IO.Path]::GetFullPath($OutputFile),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write)
$writer=New-Object IO.StreamWriter($stream,$encoding)
try { $writer.WriteLine(($report | ConvertTo-Json -Depth 32)) } finally { $writer.Dispose() }
if (-not $passed) { throw 'Installed schema differs or is unavailable. Stop and return this small report; never auto-fix pointer labels.' }
Write-Output 'Installed provider templates agree. ETL calibration still required.'

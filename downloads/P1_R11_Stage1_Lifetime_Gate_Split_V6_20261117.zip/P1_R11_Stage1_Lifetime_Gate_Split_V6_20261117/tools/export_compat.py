"""Export Stage1 target JSONL to reference review_operations.analyze event shape.

Does not create old per-path chains or trust old paired classifications.
Preserves original clock; only pads fractional precision and writes Z as +00:00.
"""
import argparse
import json
from pathlib import Path
import re
from pair_r11 import lines, time_ns


def compat_event(event):
    result = dict(event)
    text = event["system_time"]
    match = re.fullmatch(r"(.*T\d{2}:\d{2}:\d{2})(?:\.(\d{1,9}))?(Z|[+-]\d{2}:\d{2})", text)
    if not match:
        raise ValueError("unsupported clock")
    result["original_system_time"] = text
    result["system_time"] = match[1] + "." + (match[2] or "").ljust(9, "0") + ("+00:00" if match[3] == "Z" else match[3])
    if time_ns(text) != time_ns(result["system_time"]):
        raise ValueError("clock equivalence failed")
    result.setdefault("operation", {"12":"Open/Create", "13":"Cleanup", "14":"Close",
        "15":"ReadFile", "16":"WriteFile", "24":"IRP completion"}.get(str(event["event_id"]), "Other operation (raw)"))
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--input",type=Path,required=True)
    p.add_argument("--output",type=Path,required=True)
    a=p.parse_args()
    with a.output.open("x",encoding="utf-8") as f:
        for event in lines(a.input):
            f.write(json.dumps(compat_event(event),ensure_ascii=False)+"\n")


if __name__=="__main__":
    main()

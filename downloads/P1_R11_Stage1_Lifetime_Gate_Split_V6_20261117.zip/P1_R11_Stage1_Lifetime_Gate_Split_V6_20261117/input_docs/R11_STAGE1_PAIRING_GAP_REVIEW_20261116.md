# R11 阶段一：事件链重放与配对验收缺口盘点（2026-11-16，只读）

> 定位：在现有已过滤事件链片段上盘点 DAT / config.pro / `.ui` / DLL / 消息文件的请求-完成配对覆盖，为阶段一从 `formal.etl` 只读重放与配对验收定位未验收环节。
> 边界：不重采、不上传整份 ETL、不部署、不改插件/配置/模型；提取与配对脚本实现归 ChatGPT，本记录只定规则、记录缺口与验收口径。
> 输入：`runtime-r11\r11-event-chains.json`（718,804B，SHA256 `8F7E162B…74E55F6`）、`runtime-r11\formal-file-access.json`、候选产物 `recheck\op-candidates-recheck.json`（PID 23636）。

## 1. 现有片段配对总览（候选配对口径）

候选产物计数：pairs 157、unresolved 266、pending 20、files 11 路径行、events_without_irp 0。

待解完成分类：`no_pending_request_in_input` 100、`overlapping_irp_generations` 166。

| 目标类别 | pairs | 读配对 | 成功读候选字节 | pending 读请求 |
|---|---:|---:|---:|---:|
| 消息 `p1_fc.txt`（Body/FC） | 8 | 3 | 516 | 0 |
| 消息 `p1_readonly_model_info.txt` | 8 | 3 | 544 | 0 |
| 消息 `p1_readonly_ping.txt` | 未单列：读完成落入待解/歧义，未进 files 候选 | — | — | — |
| DAT `p1-step23.dat`（J-Link 对照） | 11 | 3 | 322 | 0 |
| DAT `p1_step41_r10_late_find_snapshot.dat` | 11 | 3 | 242 | 0 |
| DLL `p1_step41_r10_late_find_snapshot.dll` | 9 | 1 | 4096 | 1 |
| `config.pro`（两条路径合并归类） | 6 | 4 | 5168 | 2 |
| Roaming `creo_parametric_customization.ui` | 41 | 3 | 75910 | 1 |
| `.ui.bak` | 1 | 0 | 0 | 0 |
| 无路径锚点记录 | 50 | 50 | 0 | 16 |
| 其他（目录/未归类） | 12 | 0 | 0 | 0 |

口径说明：上表"成功读候选字节"为候选脚本按同 PID、同 IRP、Status 成功且可归到读请求的完成 ExtraInformation 统计；与旧聚合 `transferred_bytes` 口径不同，禁止直接比大小下结论。

## 2. 旧聚合对照（过滤片段聚合，含已知累加缺陷，仅作量级参考）

`formal-file-access.json` candidate_files（PID 23636），`read_bytes/write_bytes` 为 IOSize 请求缓冲量，`transferred_bytes` 为完成 ExtraInformation（旧脚本未做请求-完成配对，混入非读完成）：

| 文件 | 打开 | 读次数 | 读请求缓冲 | 写次数 | 写请求缓冲 | 完成传输 | 状态 |
|---|---:|---:|---:|---:|---:|---:|---|
| Roaming `creo_parametric_customization.ui` | 14 | 11 | 421,888 | 12 | 100,486 | 491,324 | 0x80000005, 0xC0000011, 0x0 |
| Temp `d829u7mh.ui`（临时布局） | 6 | 10 | 565,248 | 4 | 1,067,852 | 189,440 | 0x80000005, 0xC0000034, 0x0 |
| `C:\Users\DELL\config.pro` | 5 | 2 | 12,288 | 0 | 0 | 421,872 | 0xC0000034, 0x0 |
| `00_config-12\config.pro` | 1 | 4 | 16,384 | 0 | 0 | 1 | 0x0 |
| `text\config.pro` | 1 | 3 | 12,288 | 0 | 0 | 2,907 | 0x0 |
| `p1-step23.dat` | 3 | 4 | 16,384 | 0 | 0 | 435 | 0x80000005, 0xC0000011, 0x0 |
| `p1_step41_r10_late_find_snapshot.dat` | 3 | 4 | 16,384 | 0 | 0 | 57,173 | 0x80000005, 0xC0000011, 0x0 |
| `p1_fc.txt` | 2 | 4 | 16,384 | 0 | 0 | 522 | 0xC0000011, 0x0 |
| `p1_readonly_model_info.txt` | 2 | 4 | 16,384 | 0 | 0 | 550 | 0xC0000011, 0x0 |
| `p1_readonly_ping.txt` | 2 | 4 | 16,384 | 0 | 0 | 466 | 0xC0000011, 0x0 |

补充：R10 DLL 未进入 `candidate_files` 聚合；`scan_formal_dll.py` 单独扫描到 4,772,352B 候选。DLL 读取/加载结论在事件链重放前不成立。

## 3. 已定位缺口

1. **片段覆盖不全**：现有 `r11-event-chains.json` 为过滤片段；候选成功读候选字节与旧聚合完成量级差距明显，266 条完成在所给子集内找不到对应请求（100 无 pending、166 重叠 IRP 代际），20 条请求未配到完成。源头已过滤片段不能由修正脚本恢复缺失事件，须回 `formal.etl` 重抽目标 PID/时间窗。
2. **路径锚点缺失**：50 条配对、16 条 pending 无路径回填（缺 Open 锚点或跨上下文），需在完整事件集上按 PID 分层重新锚定。
3. **DLL 证据薄弱**：仅 1 条读配对、4096B 候选，1 条 pending；未进入正式文件访问聚合，不能据此判定 DLL 已被成功加载。
4. **Ping 消息文件未进候选 files**：读完成落入待解/歧义；合并片段与单文件子集两种范围不得混用。
5. **`.ui` 写完成状态未定性**：Roaming 12 条、Temp 4 条写请求；基线哈希零差异只证明最终内容一致，不证明期间无写入或写后恢复，写是否持久化待以最终哈希与写完成状态判定。
6. **跨上下文记录未隔离**：请求发起 PID 与完成执行 PID 可能不同；现有片段中跨 PID 句柄匹配须标可疑，不并入聚合。

## 4. 阶段一配对规则（沿用 R11 ETL 复核第 2/3 节，验收按此）

1. **PID 分层锚点**：先严格限定 PID，再按 IRP 为主键、FileObject/FileKey 辅助回填路径；FileObject/FileKey/IRP 指针存在跨进程、跨时段复用，禁止跨 PID 句柄匹配；保留请求与完成两侧原始 PID/TID。
2. **字段分列**：`request_bytes`（IOSize 请求量）与 `transferred_bytes`（ExtraInformation 完成量）分列；未配对完成单列，不计入某文件完成字节合计。
3. **完成配对**：ID24 仅带 IRP，在会话时间窗内按 IRP 配对；重叠 IRP 代际不猜，缺 Open 锚点保留 unresolved；非读写完成（open/cleanup/close）隔离，不计入读/写传输字节。
4. **事件链顺序**：ID12 打开 → ID15/16 请求 → ID24 完成（同 IRP）→ ID13 清理 → ID14 关闭。
5. **时钟口径**：跨基准对齐以 `formal-start/stop.json` 的 UTC Z 为准；事件级 `+07:59` 恒定偏移标注待核，不用于精确先后排序结论。
6. **状态码字典**：码值→名称→严重级→是否可视为成功由字典给出；`0x80000005=STATUS_BUFFER_OVERFLOW`（不单独判加载失败）；未解码项显式标注。

## 5. 验收口径

每个目标文件须输出：同上下文成功配对读/写字节候选、跨上下文记录、重叠 IRP 记录、缺 Open 锚点记录、未完成请求；两侧 PID/TID 留存可复核。

只有同 PID、同 IRP、Status 成功、ExtraInformation 可归到具体读/写请求的完成，才计入成功传输候选；其余单列保留原始信息。

本阶段结论仅限文件访问层事实：不证明消息被 GUI 成功解析，不据此判定文件层已排除差异，不构成 DLL 加载成功结论。

## 6. 仍待重放复核的技术项

- `BuffersLost` 独立样本（tracerpt summary/report 不输出，Header 事件 ErrorCode 15003 payload 未展开）。
- tracerpt 事件级 479 分钟（+07:59）偏移根因；本机时区与 ETL UTC 基准已核为正确。
- IOFlags 位定义；InfoClass 19/64/65 query/set 类别张力，0 未定义、589992 非法不可解码；`0x216` 无留存样本不可解码。
- `.ui` 写是否持久化；CSV/XML PID 列口径偏移风险（XML 关联以 Execution/ProcessID 为准）。
- DLL 读取/加载、R10 DAT 与 `C:\Users\DELL\config.pro` 偏大完成传输量，待事件链重放复核。

## 7. 输入证据定位

- 原始证据：`runtime-r11\formal.etl`（243,662,848B，SHA256 `AEDDC77D…D3D932BAD5`，只读，不上传整份）。
- 会话窗：start UTC `2026-11-12T07:24:09.7499775Z`，stop UTC `07:28:54.8182559Z`；目标执行 PID 23636（xtop），23 PID 进程族。
- providers：Kernel-File `{EDD08927-9CC4-4E65-B970-C2560FB5C289}`、Kernel-Process `{22FB2CD6-0E7B-422B-A0C7-2FAD1FD0E716}`。
- 机读件：`formal-file-access.json`、`formal-xml-probe.json`、`calibration-gate-result.json`、`formal-codec-review.json`、`formal-codec-scan.json`、`formal-clock-offset-review.json`、`formal-session-header.json`。
- 候选脚本：外部包 `candidate\review_operations.py`、`test_review_operations.py`（8 项单测已复跑通过，仅离线参考实现）。

# R11 阶段一 校准配对二轮整改任务单（2026-11-16）

## 1. 背景

- 一轮 v1 因字段布局错位被拒；本轮 v2 合同（schema `r11-stage1-contract/2`）字段布局已经本机安装 provider 模板、29 条原始样本与两遍只读提取交叉确认**正确**。
- 本机重跑校准 ETL 两遍提取门通过；配对门仍拒绝（`accepted=false`，退出码 2）。失败不在字段映射，而在请求-完成候选消歧唯一性。
- 分工：ChatGPT 修订配对/提取实现；助手负责规则、审核与真机验收。本轮产出为离线候选，不替换已验收版本，不部署、不重采、不改 Creo/模型/配置。

## 2. 已确认正确、不得回退的项

- 字段布局（本机模板六事件 fields_match 全 true）：
  - 12/1：Irp, FileObject, IssuingThreadId, CreateOptions, CreateAttributes, ShareAccess, FileName
  - 13、14/1：Irp, FileObject, FileKey, IssuingThreadId
  - 15、16/1：ByteOffset, Irp, FileObject, FileKey, IssuingThreadId, IOSize, IOFlags, ExtraFlags
  - 24/0：Irp, ExtraInformation, Status
- Create V1 携带 Irp、不携带 FileKey。
- 两遍只读提取、源 ETL 前后哈希比对、版本/Opcode/类型校验、未知布局不猜位、UTC Z 时钟门、输出目录不覆盖等提取口径保持不变。

## 3. 本轮配对门结果

- 20 道门 18 过 2 败：`diagnostic_details_complete=false`、`write_then_read_65_observed=false`。
- 计数：pairs 648；ambiguous_completions 331,141；overlap_requests 346,310；cross_context_completions 15,205；pending_requests 346,352；file_object_reuse_with_pending 14,291；requests_missing_anchor 41。
- 诊断省略：overlaps 省略 344,326；unresolved 省略 311,141（触 32MiB / 20,000 条上限）。
- 基线链真机字节关系吻合但未配对：写 180106(65,off0)→完成 180107(65,SUCCESS)；读 180436(off0)→完成 180437(65,SUCCESS)；读 180438(off65)→完成 180439(0,END_OF_FILE)。

## 4. 根因证据（见 evidence 目录）

1. **Irp 值在长会话内被回收复用**：同一 Irp 值在 PID 27584 内被多个不相关操作复用。基线三 Irp 目标进程内事件量：L1=3,271（ID16 写 1,362、ID24 完成 1,668）、L2=802、L3=6,004（ID16 写 2,870、ID24 完成 3,042）。仅凭 Irp 值无法唯一标识一次操作。
2. **跨 PID context 进入同一候选索引**：第二遍保留的其他 PID 同 Irp 记录写入同一 `irp_index`。三 Irp 在 context 中分别为 17,017 / 25,624 / 24,966 条；完成匹配候选集未按 scope 隔离计数，跨 PID 同值把目标同 scope 请求一并压成歧义。
3. 基线三请求落入 pending（ambiguous），对应完成未形成成功 pair。

## 5. 整改要求（离线候选）

1. **候选唯一性按 scope 隔离**：跨 PID / 跨代际的 Irp 记录只作 cross-context 引用保留，不计入目标候选集的唯一性计数；不得因其他进程同值 Irp 把目标同 scope 请求判为歧义。
2. **同 scope 内 Irp 复用的消歧**：Irp 非唯一时，结合 FileObject（同一次打开恒定）、FileKey、ByteOffset、操作方向与邻近时序收窄候选；消歧规则与依据须可复核、在记录中留痕。无法唯一确定时仍记歧义，不得猜配。
3. **诊断体量与完整性门**：复用歧义规模巨大时，现行 20,000 条 / 32MiB 上限会关闭完整性门。基线目标链相关记录须全量保留或单列小样本流；诊断省略不得掩盖基线链真实配对结论，报告须写明省略口径。
4. **校准断言**：校准基线须观测到 offset 0 的 65B 写完成、offset 0 读回 65B、offset 65 EOF 读起始；写完成序列先于读起始序列；`write_then_read_65_observed` 可通过。

## 6. 必须保持的安全边界

- 无 Irp 完成仍记孤儿，不降级 FileObject 猜配。
- 跨上下文不消耗请求、不计成功字节。
- 失败 Create 撤销对应路径锚点；Close 失效锚点。
- 门下失败时文件级成功字节小计置 null；候选字节不等于唯一内容字节。
- 不补造事件、不套用未验证版本布局；不输出 DLL 加载、GUI 命令枚举或实体转钣金成功结论。
- 不解析/复用历史卷号映射；IOFlags、InfoClass 冲突、0x216、tracerpt 偏移、BuffersLost 仍按 raw 保留为未决项。

## 7. 回传清单（离线包，不含 ETL/DLL/LIB/EXP/CSV/PDB/OBJ）

- 修订后的 `tools/Extract-R11.ps1`、`tools/pair_r11.py` 及配套测试。
- 合同如有调整，附变更说明；未调整则沿用本轮 `reference/contract.json`（哈希 `ED3FFE8A…ABB4CF4`）。
- 离线测试记录（本机复跑口径）、字段/模板核对说明。
- 明确标注：云端无原始 ETL，实际校准/正式回放结论以本机验收为准。

## 8. 验收顺序

回传后本机先跑安装模板只读核对 → 校准 ETL 两遍只读提取 → 校准配对门；校准所有门通过后，才允许提取与配对正式 `formal.etl`（PID 23636）。

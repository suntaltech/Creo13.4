# R11 阶段一 校准 ETL 回放审核记录 v2（2026-11-16）

## 1. 范围与边界

- 对象：ChatGPT 第二轮（v2 合同）回包 `P1_R11_Stage1_Calibration_Fix_20261116.zip`（合同 schema `r11-stage1-contract/2`）。
- 本机只读回放校准会话 `calibrate.etl`；未启停 ETW、未 tracerpt、未改写 ETL、未改 Creo/模型/配置。
- 结论仅限文件访问事件层的提取、字段映射与配对门；不构成 DLL 加载、GUI 命令枚举或实体转钣金可用性的判定。
- 分工：助手负责规划、规则、审核、验收；字段合同与配对实现代码的修订由 ChatGPT 完成。

## 2. 对上一轮 v1 推断的纠正（先读）

v1 审核记录 §6.1“ID24 完成首字段更接近 FileObject”的推断**作废**，不得沿用。

本轮经三类本机证据交叉确认 v2 布局：

1. 本机安装 provider 原生元数据（`Get-WinEvent -ListProvider Microsoft-Windows-Kernel-File`，不开 ETW/ETL）六个 EventID/Version 模板逐字段 name/inType 全部 `fields_match=true`；
2. 29 条原始样本按版本化布局重映射，raw 位置与字段名一一对应，旧错位命名保留在 `old_data_ignored`；
3. 两遍只读提取 `decode_errors=0`，目标流两遍顺序哈希一致。

确认布局：

| EventID / Version | 正确属性顺序 |
| --- | --- |
| 12 / 1 | Irp, FileObject, IssuingThreadId, CreateOptions, CreateAttributes, ShareAccess, FileName |
| 13、14 / 1 | Irp, FileObject, FileKey, IssuingThreadId |
| 15、16 / 1 | ByteOffset, Irp, FileObject, FileKey, IssuingThreadId, IOSize, IOFlags, ExtraFlags |
| 24 / 0 | Irp, ExtraInformation, Status |

Create V1（ID12）携带 Irp、不携带 FileKey。v1 当时把请求侧 raw[0] 误命名为 FileObject，交集证据反映的是错误命名，不能证明完成首字段是 FileObject。

## 3. 静态审核（本机离线前已通过）

| 项 | 结果 |
| --- | --- |
| 包内哈希 | sidecar MATCH；MANIFEST 27 实体 + SUMS 逐条回算全 MATCH，bad=0；无 .etl/.dll/.lib/.exp/.csv/.pdb/.obj |
| Python 单测 | 本机复跑 37 项 `Ran 37 OK`，EXIT=0（不采信云端记录） |
| PowerShell 语法门 | `Check-R11ProviderSchema.ps1`、`Extract-R11.ps1` Parser 0 错误 |
| 配对脚本口径 | scope=(pid, generation)；锚点键 (*scope, fo) 跨 PID 不复用；配对键 (*scope, irp)；无 Irp 请求不建操作；完成无候选记 orphan；跨上下文不消耗、标 tainted；歧义不消耗；失败 Create 撤销锚点、Close 失效锚点；IOSize/ExtraInformation 分列；门下失败时文件级成功字节小计置 null；诊断触限置 `diagnostic_details_complete=false`；未知布局拒绝猜位置；UTC Z 时钟门；输出目录不覆盖；源 ETL 前后哈希比对；无加载/GUI 成功断言 |
| 提取脚本口径 | `-ProviderSchemaReport` 必传且绑定合同哈希与 GUID；ETL 大小/哈希前置核对；两遍 `-Oldest` 只读；版本/Opcode/类型校验；未知 EventID 走命名 XML 且要求合同字段齐全；时间戳转 UTC Z |
| 模板门产物 | `provider-schema-r1.json`：schema_checked=true，GUID `edd08927-9cc4-4e65-b970-c2560fb5c289`，合同哈希 `ED3FFE8A…ABB4CF4`，六事件 fields_match 全 true |
| 证据前置 | calibrate.etl 129,761,280B / SHA256 `0F6D1242…0608E7C6` 提取前已核对一致；formal.etl 243,662,848B 未在本轮提取 |

## 4. 校准提取门（通过）

产物目录：`F:\P1_R11_Stage1_CalFix_20261116_R1\cal-extract\`，报告 `extraction.json`。

- mode=calibration，target_pid=27584，source_bytes=129,761,280。
- source_sha256 before/after 一致，`source_unchanged=true`。
- pass1_total_events=pass2_total_events=1,085,012；`target_order_matches=true`，两遍目标流顺序哈希一致。
- decode_errors=0；context_records=633,007；process_records=27。
- target_event_counts：12=3257、24=30908、14=2582、10=5、32=1、34=3、22=2752、18=2、16=18335、23=53、20=390、13=2583、15=121。
- 四个产物字节数与哈希在报告登记，配对门回算一致。

## 5. 校准配对门（拒绝验收，退出码 2）

产物目录：`F:\P1_R11_Stage1_CalFix_20261116_R1\cal-pairs\`，报告 `pairing-report.json`。

`accepted=false`，20 道门中 18 道通过，2 道失败：

- `diagnostic_details_complete = false`
- `write_then_read_65_observed = false`

通过的门：extractor_completed、source_unchanged、contract_hash、source_size、two_pass_counts_equal、two_pass_target_order、payload_decoding、target_pid、etl_identity、total_event_baseline、installed_provider_schema、四个产物哈希、stored_counts_equal_extractor、all_payloads_mapped、target_inside_window、get_winevent_utc_clock。

配对计数（counters）：

| 桶 | 计数 |
| --- | --- |
| pairs | 648 |
| ambiguous_completions | 331,141 |
| cross_context_completions | 15,205 |
| overlap_requests | 346,310 |
| file_object_reuse_with_pending | 14,291 |
| requests_missing_anchor | 41 |
| pending_requests | 346,352 |

诊断保留（written / omitted）：

| 流 | 写入记录 | 省略记录 |
| --- | --- | --- |
| pairs | 648 | 0 |
| cross-context | 15,205 | 0 |
| overlaps | 16,275 | 344,326 |
| unresolved | 20,000 | 311,141 |
| missing-anchor | 307 | 0 |
| pending | 346,352 | 0 |

基线文件 `calibration-baseline.txt` 行：opens_observed=6；write_requests=1（write_request_bytes=65）；read_requests=2（read_request_bytes=8,192）；write_pairs=0、read_pairs=0、pending_requests=24；成功字节小计因门下失败置 null（合规口径）。`calibration_observations={}`，未观测到 65B 写完成、65B 读完成或 offset 65 读起始。

## 6. 基线 65B 写后读链原始事件（目标 PID 27584，seq 邻近窗口）

v2 正确字段下的真机时序（Irp / FileObject / FileKey / Offset / IOSize / 完成 ExtraInformation / Status）：

| seq | ID | 方向 | Irp | FileObject | FileKey | Offset | IOSize | 完成 seq | ExtraInfo | Status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 180106 | 16 | 写 | …8753682312 | …8985520 | …8201628016 | 0 | 65 | 180107 | 65 | 0 SUCCESS |
| 180436 | 15 | 读 | …8895084424 | …9016320 | …8201628016 | 0 | 4096 | 180437 | 65 | 0 SUCCESS |
| 180438 | 15 | 读 | …8895084424 | …9016320 | …8201628016 | 65 | 4096 | 180439 | 0 | 0xC0000011 END_OF_FILE |

字节关系在邻近窗口真实吻合：offset 0 写出 65B；offset 0 读回 65B；offset 65 为 EOF 探测，不构成又读出 65B。三条请求在配对产物中落入 `pending`（ambiguous），对应完成未进入成功配对。

## 7. 根因定位（本机真机证据）

本轮布局层已被证实正确，配对失败不在字段错位，而在**候选消歧唯一性不足**，分两层：

### 7.1 Irp 指针值在长会话内被回收复用

同一 Irp 值在 PID 27584 全时段被多个不相关操作复用。基线三个 Irp 在目标进程内的事件量：

| Irp（尾号） | 目标进程内事件 | 其中写/读请求 | 其中完成 ID24 |
| --- | --- | --- | --- |
| …8753682312（L1） | 3,271 | ID16 写 1,362、ID15 读 3 | 1,668 |
| …8779011976（L2） | 802 | ID15 读 2 | 463 |
| …8895084424（L3） | 6,004 | ID16 写 2,870、ID15 读 4 | 3,042 |

配对器以 Irp 单值作唯一候选键；复用场景下同一键挂多个不同操作，pending 列表与候选集非唯一，按“歧义不消耗”全部判 ambiguous。Irp 在此 provider 为操作标识（FLT_CALLBACK_DATA 类指针），不承诺全局唯一或不复用。

### 7.2 跨 PID context 记录进入同一候选索引

第二遍保留的其他 PID context 同 Irp 记录也写入同一个 `irp_index`。三个基线 Irp 在 context 中的记录数：L1=17,017、L2=25,624、L3=24,966。完成匹配计算候选集时未按 scope 隔离计数，跨 PID 同值进一步把候选集撑成多候选，目标同 scope 请求被一并判歧义。

### 7.3 后果

- 已知成功的 65B 写后读链被判歧义，未形成合格 pair；
- ambiguous / overlap / pending 量级异常放大；
- overlaps、unresolved 两个诊断流触 32MiB / 20,000 条上限后省略，完整性门随之关闭。

### 7.4 仍为未决、不下武断结论

- 同 scope 内 Irp 复用时，FileObject（同一次打开恒定）、FileKey、ByteOffset、方向与邻近时序作为消歧维度的权重与优先级，需实现侧给出可复核规则；指针相等不是全局身份证明。
- IOFlags 位定义、InfoClass 19/64/65 query/set 张力、0x216、tracerpt +07:59 偏移根因、历史卷号映射、BuffersLost 独立样本仍未决。

## 8. 交回 ChatGPT 的二轮整改方向（离线候选，不替换验收版）

1. **候选唯一性按 scope 隔离**：跨 PID / 跨代际的 Irp 记录只作 cross-context 引用保留，不得计入目标候选集的唯一性计数；不得因其他进程同值 Irp 把目标同 scope 请求判为歧义。
2. **同 scope 内 Irp 复用的消歧**：仅凭 Irp 值非唯一时，结合 FileObject、FileKey、ByteOffset、操作方向与邻近时序收窄候选；保持“无法唯一确定即记歧义、不猜配”的底线，但消歧维度应可复核、留痕。
3. **诊断体量与完整性门**：复用歧义规模巨大时，现行 20,000 条 / 32MiB 上限会关闭完整性门；需保证诊断省略不掩盖基线目标链的真实配对结论（基线目标链相关记录应全量保留或单列小样本流），并在报告中明确省略口径。
4. 保持既有安全口径：无 Irp 完成仍记孤儿、不降级 FileObject 猜配；跨上下文不消耗、不计字节；失败 Create 撤销锚点；门下成功字节小计置 null；不补造事件；不输出 DLL 加载 / GUI 枚举 / 实体转钣金成功结论。
5. 整改包回传后，本机先重跑校准门；校准所有门通过后，才允许提取与配对正式 `formal.etl`。

## 9. 当前未执行项

- 正式 `formal.etl` 提取与正式配对验收未执行（校准门未过，按 README 不得进入正式）。
- 旧三脚本回填、C 线候选脚本替换不在本轮范围。
- v1、v2 校准诊断大产物暂留 F 盘；整改重跑使用新输出目录，不覆盖既有产物；删除前先确认报告与样本已归档。

## 10. 关键路径

- v2 回包解压：`D:\creo-tools\build\p1-step41-r11-stage1-review-20261116\fix2\extracted\P1_R11_Stage1_Calibration_Fix_20261116\`
- v2 校准提取：`F:\P1_R11_Stage1_CalFix_20261116_R1\cal-extract\`
- v2 校准配对：`F:\P1_R11_Stage1_CalFix_20261116_R1\cal-pairs\`
- 原始证据（只读）：`D:\creo-tools\build\p1-step41-r10-late-find-review-20261112\runtime-r11\formal.etl`、`calibrate.etl`

# R11 阶段一 校准配对门整改任务单（2026-11-16）

## 1. 背景与本轮已完成事项

阶段一目标：从保留的校准/正式 ETL 只读重抽事件，按 PID 分层完成请求—完成配对，补齐既有过滤片段缺口。本轮已在本机离线回放上一版候选工具（`P1_R11_Stage1_Offline_Tools_20261116`）：

- 静态审核通过：包内哈希全 MATCH；24 项 Python 离线单测本机复跑全过；PowerShell Parser 0 错误；脚本口径与既有任务单一致。
- 校准 ETL 两遍只读提取门通过：两遍总计数相等、目标流顺序哈希一致、源 ETL 前后哈希未变、解码 0 错误、时间戳全 UTC Z。
- **校准配对门拒绝验收（退出码 2，`accepted=false`）**：16 道门 15 道通过，仅 `write_then_read_65_observed` 失败。

本包不含 ETL、DLL、全量 JSONL 或大 CSV；`evidence/` 仅为从校准提取流抽取的少量样本与命中统计，供离线核准字段位置。

## 2. 失败事实（校准会话 PID 27584）

基线文件：`\Device\HarddiskVolume4\creo-tools\build\p1-step41-r10-late-find-review-20261112\runtime-r11\calibration-baseline.txt`

观测到的请求（详见 `evidence/baseline-chain-sample.json`）：

| seq | ID | 方向 | Offset | IOSize | 合同"Irp"字段值 |
| --- | --- | --- | --- | --- | --- |
| 180106 | 16 | 写 | 0 | 65 | 18446705628201628016 |
| 180436 | 15 | 读 | 0 | 4096 | 18446705628201628016 |
| 180438 | 15 | 读 | 65 | 4096 | 18446705628201628016 |

该文件 `write_pairs=0`、`read_pairs=0`，写/读请求全部落入歧义、跨上下文或挂起桶。配对计数：ambiguous 232,919、cross_context 95,342、orphan 16,206、overlap 91,377、pending 91,726。

## 3. 本机观测到的字段错位证据

### 3.1 完成事件首字段与 FileObject 同类

ID24 完成事件 `raw_properties[0]` 取值集合共 42 个唯一值，与请求侧各指针字段交集（`evidence/field-match-stats.json`）：

| 请求侧字段（合同命名） | 与 ID24 raw[0] 交集 |
| --- | --- |
| ID13/14 raw[0]（FileObject） | 42 / 42 |
| ID15/16 raw[1]（FileObject） | 29 / 42 |
| ID15/16 raw[2]（FileKey） | 0 / 42 |
| ID15/16 raw[3]（Irp） | 0 / 42 |

29/42 的缺口对应只做过 Cleanup/Close、未发起读写的 FileObject。完成首字段集合中包含基线文件三个 FileObject（…682312、…79011976、…95084424）。

### 3.2 合同标的"Irp"不具备独立 IRP 特征

- ID16 seq180106 合同 Irp 值 `18446705628201628016` = `0xffffdd08b5283170`，与同文件 ID10 事件的 FileKey `0xffffdd08b5283170` 完全相同。
- 该值在文件多次打开之间恒定，不随每个请求变化；与完成侧首字段 0 交集。
- 现状合同 `reference/contract.json` 的 `positions`：
  - ID13/14：`[FileObject, FileKey, Irp, IssuingThreadId]`
  - ID15/16：`[ByteOffset, FileObject, FileKey, Irp, IssuingThreadId, IOSize, IOFlags, ExtraFlags]`
  - ID24：`[Irp, ExtraInformation, Status]`

### 3.3 待你核准的判断（不要照单全收本机推断）

请对照 WDK/WPA 中 Microsoft-Windows-Kernel-File 各事件的权威字段定义，离线确认：

1. ID24（IRP completion）首字段究竟是 Irp 还是 FileObject；ExtraInformation、Status 的真实位置。
2. ID13（Cleanup）、ID14（Close）、ID15（ReadFile）、ID16（WriteFile）raw 属性的真实顺序，以及 FileObject / FileKey / Irp（若该事件携带）各落在哪一位置。
3. 该 ETW 完成事件是否携带独立 Irp；若不携带，配对主键不能以 Irp 为唯一键。
4. ID12 无 Irp 的既有结论是否仍成立。

样本原始属性完整保留在 `evidence/id24-completion-sample.json` 与基线链样本中，可逐条核对类型（UInt64/UInt32/String）与取值形态。

## 4. 整改要求（离线，不部署、不采集）

1. 按核准后的真实字段顺序修订 `positions`（及必要的 `named_fields`）；字段名必须与 raw 语义一致，不得把 FileObject/FileKey 标成 Irp。
2. 依据核准结果修订配对主键与回填规则：
   - 若完成事件带独立 Irp：请求侧与完成侧使用同一真实 Irp 字段回连；
   - 若不带独立 Irp：以同 PID/代际/FileObject 为主键，辅以 ByteOffset、方向（读/写）、Status、ExtraInformation 回填；FileKey 仅用于路径锚定，不得充当 Irp。
3. 保留既有安全口径：PID/generation 分层；禁止跨 PID 句柄匹配；请求字节与完成字节分列；未配对完成单列；重叠代际标 tainted 不猜；缺 Open 锚点记 unresolved；门下失败时文件级成功字节小计置 null；不补造事件；不输出 DLL 加载成功、GUI 解析成功或实体转钣金可用的结论。
4. 补离线断言：校准基线须观测到 offset 0 的 65B 写完成、offset 65 的读回，且写完成序列先于读起始序列，使 `write_then_read_65_observed` 通过。
5. 既有 24 项合成单测应继续通过；新增针对字段位置与主键回连的离线用例，覆盖：同 FileObject 多请求、Irp 复用/代际、跨 PID 不复用锚点、完成侧无独立 Irp 的情形。

## 5. 验收口径（本机回放时核对）

- 校准：提取门 + 配对门全部通过，`accepted=true`，退出码 0；基线 65B 写后读形成合格 pair。
- 校准门通过后才允许跑正式 `formal.etl` 提取与配对；正式目标 EventID 计数须逐项等于合同 PID 23636 基线。
- `accepted=true` 仅表示提取/映射/计数门通过，不代表严格全配对、无丢失、GUI 解析成功或 DLL 初始化成功。

## 6. 边界与保留项

- 本阶段不重新采集 ETL、不改 UI、不改插件、不执行真实转换、不部署发布包。
- 仍保留未决：BuffersLost 独立样本未知；IOFlags 位语义未解码；InfoClass 冲突项不推测；0x216 未解码；tracerpt +07:59 偏移根因未定位；历史卷号映射不按当前主机猜测。
- 通道 A 原始 UTC 与旧 XML 时戳各自保留，不得把旧时戳直接"加一分钟修正"。

## 7. 回传清单

- 修订后的 `contract.json`（positions/named_fields）、提取器与配对脚本、更新后的离线单测与结果。
- 校准 `extraction.json` 与 `pairing-report.json`；若仍有失败，附首条报错与对应少量原始事件（含 source_sequence/version/opcode/raw_properties/data），保留哈希。
- 不要回传整份 ETL 或 GB 级全量 JSONL。

## 8. 包内文件

- `docs/R11_STAGE1_CALIBRATION_FIX_TASK_20261116.md`：本任务单。
- `docs/R11_STAGE1_CALIBRATION_REVIEW_20261116.md`：本机审核记录（门结果、计数、路径、未执行项）。
- `reference/contract.json`：上一版现状合同，供对照修订。
- `evidence/baseline-chain-sample.json`：基线文件 17 条相关事件原始记录。
- `evidence/id24-completion-sample.json`：12 条 ID24 完成事件原始记录。
- `evidence/field-match-stats.json`：完成首字段与请求侧各字段交集统计及十六进制对照。

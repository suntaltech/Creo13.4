# R11 阶段一 校准 ETL 回放审核记录 v3（Scope Fix，2026-11-16）

## 1. 范围与边界

- 对象：ChatGPT 第三轮回包 `P1_R11_Stage1_Scope_Fix_20261116.zip`（合同 schema `r11-stage1-contract/2`，配对报告 schema `r11-stage1-pairing/3`）。
- 本机只读回放校准会话 `calibrate.etl`；未启停 ETW、未 tracerpt、未改写 ETL、未改 Creo/模型/配置、未部署、未发送 PTC。
- 结论仅限文件访问事件层的提取、字段映射与配对门；不构成 DLL 加载、GUI 命令枚举或实体转钣金可用性的判定。
- 分工：助手负责规划、规则、审核、验收；字段合同与配对实现代码的修订由 ChatGPT 完成。
- 历史作废：v1 审核记录 §6.1“ID24 完成首字段=FileObject”推断已作废，不得沿用；v2 本机模板复核已确认合同字段布局正确，本轮不回退。

## 2. 本轮相对 v2 的改动范围

经逐字节核对，合同与两个 PowerShell 脚本与 v2 完全一致，仅 Python 配对器、审计与测试/说明改动：

| 文件 | 大小 | SHA256（前 12） | 与 v2 关系 |
| --- | --- | --- | --- |
| `reference/contract.json` | 7,697B | ED3FFE8A6CE94 | 逐字节一致 |
| `tools/Extract-R11.ps1` | 12,723B | 6115F72B06E8 | 逐字节一致 |
| `tools/Check-R11ProviderSchema.ps1` | 3,152B | 3B6F4C38885F | 逐字节一致 |
| `tools/pair_r11.py` | 38,175B | 7631B3B89C5F | 本轮重写（scope 隔离） |

整改方向（对应 v2 审核记录 §8）落地情况，静态 diff 复核：

1. **候选唯一性按 scope 隔离**：非 target PID 事件提前返回，只作 context-reference 引用，不建 pending/anchor/irp_index 目标键；请求插入 existing 集合只取本 scope pending；完成唯一性只看同 (PID, generation, Irp) 候选，reference_scopes 仅引用、不参与候选计数；其他 PID 同值 Irp 不污染目标。
2. **同 scope 真重叠仍记歧义**：完成侧 ID24 仅有 Irp/ExtraInformation/Status，不拿 FileObject/FileKey/Offset/方向/“最近一条”捏造筛选；新增完成时序校验，完成 seq/时间必须晚于请求，否则 taint 记 `invalid_pair_order`。
3. **诊断体量与完整性门分离**：baseline-chain 单列不限采样；目标必要诊断省略仍置 `diagnostic_details_complete=false`；其他 PID 派生引用摘要单列 context-reference，可采样，原始 context-events 全量哈希保留；报告把辅助摘要完整性与目标诊断完整性分开登记。
4. **校准链证明强化**：`calibration_sequence_proof` 要求同 path/代际/PID/anchor/FileObject，写完成先于读起始，FileKey 一致或同 open 连续，读与 EOF 共享打开对象；EOF 必须 `0xC0000011` + ExtraInfo 0；不再用三个无关计数拼成通过。

## 3. 静态审核（本机离线，已通过）

| 项 | 结果 |
| --- | --- |
| 包内哈希 | sidecar SHA256 MATCH；zip 105,020B，本机哈希 `f16b6e5b…6c803`；解压 37 实体，无禁带扩展名；MANIFEST 39 条 + SUMS 40 条字节/哈希回算全 MATCH，bad=0 |
| Python 单测 | 本机复跑 `Ran 49 tests OK`，EXIT=0（v2 回归 37 + 新增 12；不采信云端记录） |
| PowerShell 语法门 | 两个 PS 脚本 Parser 0 错误 |
| 模板门产物 | `provider-schema-scope-r1.json`：schema_checked=true，GUID `edd08927-9cc4-4e65-b970-c2560fb5c289`，合同哈希绑定 `ED3FFE8A…ABB4CF4`，六事件（12/13/14/15/16/24）fields_match 全 true |
| 证据前置 | calibrate.etl 129,761,280B / SHA256 `0F6D1242…0608E7C6` 提取前已核对一致；formal.etl 243,662,848B 本轮未提取 |

## 4. 校准提取门（通过）

产物目录：`F:\P1_R11_Stage1_ScopeFix_20261116_R1\cal-extract\`，报告 `extraction.json`。

- mode=calibration，target_pid=27584，source_bytes=129,761,280；source_sha256 before/after 一致，`source_unchanged=true`。
- pass1_total_events=pass2_total_events=1,085,012；`target_order_matches=true`，两遍目标流顺序哈希一致。
- decode_errors=0；context_records=633,007；process_records=27；process_decode_errors=[]。
- target_event_counts 与 v2 基线逐项对齐：10=5、12=3257、13=2583、14=2582、15=121、16=18335、18=2、20=390、22=2752、23=53、24=30908、32=1、34=3。
- 四个产物（target-events 53,241,356B、context-events 551,372,059B、process-events 39,363B、provider-schema 9,682B）字节数与哈希回算全 MATCH。

## 5. 校准配对门（拒绝验收，退出码 2）

产物目录：`F:\P1_R11_Stage1_ScopeFix_20261116_R1\cal-pairs\`，报告 `pairing-report.json`。

`accepted=false`，23 道门中 22 道通过，1 道失败：

- FAIL `calibration_target_not_after_unmatched_exit = false`
- PASS `write_then_read_65_observed = true`（基线 65B 写后读链本轮已成功配对）
- PASS `diagnostic_details_complete = true`（目标必要诊断无省略）

通过的门：extractor_completed、source_unchanged、contract_hash、source_size、two_pass_counts_equal、two_pass_target_order、payload_decoding、target_pid、etl_identity、total_event_baseline、installed_provider_schema、四个产物哈希、process_payloads_decoded、stored_counts_equal_extractor、all_payloads_mapped、target_inside_window、get_winevent_utc_clock。

配对计数（counters）：

| 桶 | 计数 |
| --- | --- |
| pairs | 30,073 |
| orphan_completions | 835 |
| requests_missing_anchor | 41 |
| cross_context_completions | 26,155 |
| overlap_requests | 2 |
| unknown_process_lifetime | 371 |
| pending_requests | 6 |
| foreign_context_records | 633,007 |

诊断保留（written / omitted）：

| 流 | 写入记录 | 省略记录 |
| --- | --- | --- |
| pairs | 30,073 | 0 |
| unresolved | 835 | 0 |
| missing-anchor | 41 | 0 |
| baseline-chain | 73 | 0 |
| overlaps | 2 | 0 |
| pending | 6 | 0 |
| context-reference | 20,000 | 613,007（辅助摘要省略，原始 context-events 全量保留并哈希校验） |

基线链 `baseline-chain.jsonl`：raw_events=49、records=73、omitted=0。`diagnostic_scope.ancillary_context_references_complete=false`、`no_target_candidate_changes_due_to_reference_sampling=true`（辅助摘要省略不关闭目标门）。

### 5.1 基线 65B 写后读链（本轮已形成合格 pair）

`calibration_sequence_proof` 六序号齐全，basis=“ordered same-path write/read; FileKey or same-open continuity; read and EOF share opened object”：

| seq | ID | 方向 | 完成 seq | ExtraInfo | Status | 计入字节 |
| --- | --- | --- | --- | --- | --- | --- |
| 180106 | 16 | 写 offset 0 / IOSize 65 | 180107 | 65 | 0 SUCCESS | 65 |
| 180436 | 15 | 读 offset 0 / IOSize 4096 | 180437 | 65 | 0 SUCCESS | 65 |
| 180438 | 15 | 读 offset 65 / IOSize 4096 | 180439 | 0 | 0xC0000011 END_OF_FILE | null（EOF 不计字节） |

observations：write_65=1、read_65=1、read_offset_65_seen=1。pending 6 条（2 无完成、4 ambiguous）；unresolved 835 条全部 `no_same_scope_pending_request`；overlaps 2 条。

## 6. 唯一失败门根因定位（本机真机证据）

### 6.1 目标进程边界

`process_generation_scope.observed_target_boundaries=[[106617,"1"],[217465,"2"]]`，校准初始代际 0 为显式捕获前假设。

- seq106617 事件 1（创建）06:44:16.4414798Z，Image `…\pwsh\pwsh.exe`，ProcessID 27584。
- seq217465 事件 2（退出）06:44:21.3766997Z，Image pwsh.exe，ProcessID 27584。

### 6.2 退出边界之后的 371 条事件性质

`unknown_process_lifetime=371` 即落在退出事件 217465 之后、无后续创建边界、`generation=None` 的目标事件。逐条复核：

- seq 区间 217466–217876；时间 06:44:21.3769318Z → 06:44:21.4176832Z，紧贴退出边界 41ms 内。
- 事件类型：ID13 Cleanup 91、ID14 Close 93、ID24 Completion 186、ID22 Other 1；**新请求类（ID12 Create / ID15 Read / ID16 Write）= 0**。
- FileObject 仅 2 个在退出前未见，其余延续退出前已打开对象；Irp 延续退出前批次（含基线写链 Irp …8753682312）。

定性：这 371 条是进程退出时的句柄/IRP 清理收尾（exit drain），不是 PID 复用——PID 复用场景会出现新的打开/读写请求，而此处只有 Cleanup/Close/Completion。

### 6.3 规则缺口

`Lifetimes.generation` 规则：退出（事件 2）之后、无后续创建边界的事件返回 `None`；校准门 `calibration_target_not_after_unmatched_exit` 要求全部 target 事件 `generation is not None`。当前实现对退出前最后一代际**没有保留收尾归属窗口**，把合法的退出 drain 与“退出后未归属新操作”一并判为未归属，导致整门拒绝。

### 6.4 仍为未决、不下武断结论

- 同 scope 内 Irp 复用时 FileObject/FileKey/Offset/方向/邻近时序的消歧权重，仍以实现侧可复核规则为准；指针相等不是全局身份证明。
- IOFlags 位定义、InfoClass 19/64/65 query/set 张力、0x216 无样本不可解码、tracerpt +07:59 偏移根因、历史卷号映射、BuffersLost 独立样本、.ui 写是否持久化、DLL 读取/加载结论，仍未决。

## 7. 交回 ChatGPT 的三轮整改方向（离线候选，不替换验收版）

1. **退出 drain 归属窗口**：退出边界之后，收尾类事件（ID13 Cleanup、ID14 Close、ID24 Completion、ID22 Other）归属退出前最后一代际，单列 `exit-drain` 计数与序号范围；不得计入 `unknown_process_lifetime` 未归属拒绝。
2. **退出后新操作仍拒绝**：退出边界之后若出现新请求类（ID12 Create、ID15 Read、ID16 Write），仍判未归属并拒绝；不得为过门把新操作并入 drain。
3. **报告口径分离**：`exit-drain`、`unknown_process_lifetime`、orphan/ambiguous 分桶登记；保留 observed_target_boundaries 与 drain 序号/时间窗证据，便于复核。
4. **既有约束不得放宽**：基线链同 path/代际/PID/anchor/FileObject、FileKey 或同 open 连续、读与 EOF 共享打开对象、EOF 状态 `0xC0000011` + ExtraInfo 0、完成时序晚于请求、同 scope 真歧义不猜配、无 Irp 不降级 FO、跨上下文不消耗不计字节、门下成功字节小计置 null 等口径维持不变。
5. 整改包回传后本机先重跑校准门；校准所有门通过后，才允许提取与配对正式 `formal.etl`（PID 23636）。

## 8. 当前未执行项

- 正式 `formal.etl` 提取与正式配对验收未执行（校准门未过，按 README 不得进入正式）；formal-extract/formal-pairs 目录当前不存在。
- 旧三脚本回填、C 线候选脚本替换不在本轮范围。
- v1/v2/v3 校准诊断大产物暂留 F 盘；整改重跑使用新输出目录，不覆盖既有产物；删除前先确认报告与样本已归档。

## 9. 关键路径

- v3 回包解压：`D:\creo-tools\build\p1-step41-r11-stage1-review-20261116\fix3\extracted\P1_R11_Stage1_Scope_Fix_20261116\`
- v3 校准提取：`F:\P1_R11_Stage1_ScopeFix_20261116_R1\cal-extract\`
- v3 校准配对：`F:\P1_R11_Stage1_ScopeFix_20261116_R1\cal-pairs\`
- 原始证据（只读）：`D:\creo-tools\build\p1-step41-r10-late-find-review-20261112\runtime-r11\formal.etl`、`calibrate.etl`
- v2 审核记录：`D:\creo-tools\build\p1-step41-r11-stage1-review-20261116\R11_STAGE1_CALIBRATION_REVIEW_V2_20261116.md`

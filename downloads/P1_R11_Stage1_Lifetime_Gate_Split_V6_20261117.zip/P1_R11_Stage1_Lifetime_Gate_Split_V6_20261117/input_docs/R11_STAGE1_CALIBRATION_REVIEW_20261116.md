# R11 阶段一 校准 ETL 回放审核记录（2026-11-16）

## 1. 范围与边界

- 对象：ChatGPT 阶段一回包 `P1_R11_Stage1_Offline_Tools_20261116.zip` 的离线提取/配对工具。
- 本机只读回放校准会话 `calibrate.etl`；未启停 ETW、未 tracerpt、未改写 ETL。
- 本记录结论仅限文件访问事件层的提取/字段映射/配对门；不构成 DLL 加载成功与否、GUI 命令解析与否、实体转钣金是否可用的判定。
- 分工：助手负责规划、规则、审核、验收；字段合同与配对实现代码的修订由 ChatGPT 完成。

## 2. 静态审核（本机离线前已通过）

| 项 | 结果 |
| --- | --- |
| 包内哈希 | MANIFEST 15 实体 + SUMS 16 实体逐条回算全 MATCH，bad=0 |
| Python 单测 | 本机复跑 24 项 Ran 24 OK，EXIT=0（不采信云端记录） |
| PowerShell 语法门 | Parser ParseFile 0 错误 |
| 脚本口径 | pair_r11.py / Extract-R11.ps1 / export_compat.py 与任务单规则一致：PID/generation 分层、跨 PID 不复用锚点、请求/完成字节分列、重叠 tainted、缺锚点 unresolved、非读写隔离、UTC Z 时钟门、输出目录不覆盖、门下失败时文件级成功字节小计置 null，无加载成功断言 |
| 证据前置 | formal.etl 243,662,848B / SHA256 AEDDC77D…D3D932BAD5 与合同一致；calibrate.etl 129,761,280B 大小一致 |

## 3. 校准提取门（通过）

产物目录：`F:\P1_R11_Stage1_Offline_20261116\cal-extract\`，报告 `extraction.json`。

- mode=calibration，target_pid=27584，source_bytes=129,761,280。
- source_sha256 before/after 均为 `0F6D124272F8F0C6D4258EF1CEF44B61A585345F90CB5DFC2550DDB00608E7C6`，source_unchanged=true。
- pass1_total_events=pass2_total_events=1,085,012；target_order_matches=true，两遍目标流顺序哈希一致。
- decode_errors=0；context_records=383,517；process_records=27。
- 三个输出文件字节数与哈希已在报告登记，配对门回算一致。

## 4. 校准配对门（拒绝验收，退出码 2）

产物目录：`F:\P1_R11_Stage1_Offline_20261116\cal-pairs\`，报告 `pairing-report.json`。

`accepted=false`。16 道门中 15 道通过，唯一失败：

- `write_then_read_65_observed = false`

通过的门：extractor_completed、source_unchanged、contract_hash、source_size、two_pass_counts_equal、two_pass_target_order、payload_decoding、target_pid、三个文件哈希、stored_counts_equal_extractor、all_payloads_mapped、target_inside_window、get_winevent_utc_clock。

配对计数（counters）：

| 桶 | 计数 |
| --- | --- |
| pairs | 2,527 |
| ambiguous_completions | 232,919 |
| cross_context_completions | 95,342 |
| orphan_completions | 16,206 |
| overlap_requests | 91,377 |
| pending_requests | 91,726 |
| requests_missing_anchor | 17,023 |
| file_object_reuse_with_pending | 3,224 |

基线文件 `\Device\HarddiskVolume4\creo-tools\build\p1-step41-r10-late-find-review-20261112\runtime-r11\calibration-baseline.txt` 行：

- opens_observed=6；write_requests=1（write_request_bytes=65）；read_requests=2（read_request_bytes=8,192）。
- write_pairs=0；read_pairs=0；pending_requests=8；成功字节小计因门下失败置 null。

## 5. 基线 65B 写后读链原始事件（目标 PID 27584）

| seq | ID | 方向 | 时间(UTC Z) | FileObject | FileKey | 合同"Irp" | Offset | IOSize |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 180106 | 16 | 写 | 06:44:21.0914481 | …682312 | …8985520 | …8201628016 | 0 | 65 |
| 180436 | 15 | 读 | 06:44:21.1158467 | …95084424 | …9016320 | …8201628016 | 0 | 4096 |
| 180438 | 15 | 读 | 06:44:21.1159467 | …95084424 | …9016320 | …8201628016 | 65 | 4096 |

写请求（65B, offset 0）与两条读请求被现有配对器判为同一 Irp 的重叠代际，完成侧落入歧义/跨上下文，未形成合格 pair。

## 6. 根因定位（本机数据自证，待权威定义复核）

### 6.1 完成事件首字段与 FileObject 同类，而非合同标注的 Irp

ID24 完成事件 raw[0] 取值集合共 42 个唯一值，与请求侧各指针字段交集：

| 请求侧字段 | 与 ID24 raw[0] 交集 |
| --- | --- |
| ID13/14 raw[0]（合同名 FileObject） | 42 / 42 |
| ID15/16 raw[1]（合同名 FileObject） | 29 / 42 |
| ID15/16 raw[2]（合同名 FileKey） | 0 / 42 |
| ID15/16 raw[3]（合同名 Irp） | 0 / 42 |

29/42 的缺口对应只做过 Cleanup/Close、未发起读写的 FileObject，符合预期。

### 6.2 合同标注的"Irp"字段不与完成侧回连

- ID16 seq180106 合同 Irp 值 `18446705628201628016`，十六进制 `0xffffdd08b5283170`，与同文件 ID10 事件的 FileKey `0xffffdd08b5283170` 完全相同。
- 该值在打开 A、打开 C 之间恒定，不具备每请求独立 IRP 的特征。
- 对照：FileObject `0xffffa78c10e71b88`、FileKey `0xffffa78c038281b0`（ID12 锚点已校准）。

### 6.3 后果

现有配对主键为 `(scope, Irp)`，请求侧与完成侧都取到错位字段，假键互不回连：
- 已知成功的 65B 写后读链被判重叠/歧义；
- 歧义、跨上下文、孤儿完成、挂起请求数量异常放大；
- 诊断产物体积异常：overlaps.jsonl 6.34GB、cross-context.jsonl 1.83GB、unresolved.jsonl 1.04GB。

### 6.4 待复核假设（不下武断结论）

- `contract.json` 的 `positions` 对 ID13/14/15/16/24 的 raw 属性顺序与字段名可能存在错位；ID24 首字段按本机交集证据更接近 FileObject。
- 需确认 Kernel-File 完成事件是否携带独立 Irp；若该 ETW 事件不携带独立 Irp，配对主键不应以 Irp 为唯一键，应改为同 PID/代际/FileObject，辅以 ByteOffset、方向、Status、ExtraInformation 回填，FileKey 仅用于路径锚定。

## 7. 交回 ChatGPT 的整改要求（离线，不部署）

1. 按 WDK/WPA 中 Microsoft-Windows-Kernel-File 各事件（Open/Create、Cleanup、Close、ReadFile、WriteFile、IRP completion）的权威字段定义，逐 EventID 重新核准 raw 属性顺序与语义，重点核对：
   - ID24 首字段是 Irp 还是 FileObject；ExtraInformation、Status 的位置；
   - ID13/14、ID15/16 中 FileObject、FileKey、Irp（若存在）的真实位置；
   - ID12 无 Irp 的既有结论是否仍成立。
2. 依据核准后的字段修订配对主键与回填规则；若完成事件无独立 Irp，不得用错位指针冒充 Irp 主键。
3. 补离线断言：校准基线文件须观测到 offset 0 的 65B 写完成、以及 offset 65 的读回，写完成序列先于读起始序列，`write_then_read_65_observed` 可通过。
4. 保持既有安全口径：不补造事件、不跨 PID 匹配、未配对完成单列、门下成功字节小计置 null、不输出 DLL 加载/GUI 解析成功结论。
5. 整改包回传后，本机先重跑校准门，通过后再进入正式 ETL 提取与配对验收。

## 8. 当前未执行项

- 正式 `formal.etl` 提取与正式配对验收未执行（校准门未过，按 README 不得进入正式）。
- 旧三脚本回填、C 线候选脚本替换不在本轮范围。
- 诊断大文件暂保留在 F 盘，整改重跑前不删除；如需回收空间，先确认报告与样本已归档。

## 9. 关键路径

- 回包解压：`D:\creo-tools\build\p1-step41-r11-stage1-review-20261116\extracted\P1_R11_Stage1_Offline_Tools_20261116\`
- 校准提取：`F:\P1_R11_Stage1_Offline_20261116\cal-extract\`
- 校准配对：`F:\P1_R11_Stage1_Offline_20261116\cal-pairs\`
- 原始证据（只读）：`D:\creo-tools\build\p1-step41-r10-late-find-review-20261112\runtime-r11\formal.etl`、`calibrate.etl`

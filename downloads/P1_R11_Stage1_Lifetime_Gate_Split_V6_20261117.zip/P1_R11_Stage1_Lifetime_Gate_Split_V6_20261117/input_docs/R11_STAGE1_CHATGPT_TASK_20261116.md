# R11 阶段一：事件链重放与配对验收 —— ChatGPT 离线任务单（2026-11-16）

> 分工：本单只定目标、规则、输入、字段位置参考与验收口径；提取器/配对脚本实现归 ChatGPT。助手负责本机只读复核、规则审核与验收。
> 边界：不重采、不上传整份 ETL、不部署、不改插件/配置/模型；探针只读；不新增未知 SDK 调用。

## 1. 目标

从保留的 `formal.etl` 本地只读重抽目标会话完整 Kernel-File 事件，按 PID 分层与 IRP 配对，逐条验收 DAT / config.pro / `.ui` / DLL / 消息文件的打开→读/写请求→完成→清理→关闭链，输出可复核的配对状态表。现有 `r11-event-chains.json` 为过滤片段，不能由修正脚本补回缺失事件，必须回 ETL 重抽。

## 2. 输入证据

| 项 | 值 / 路径 |
|---|---|
| 原始 ETL | `runtime-r11\formal.etl`，243,662,848B，SHA256 `AEDDC77D8ED97FEA4606C18E67512D20507C99DAACF46FAE81C949D3D932BAD5`（只读，不上传整份） |
| 会话窗 | start UTC `2026-11-12T07:24:09.7499775Z`，stop UTC `07:28:54.8182559Z` |
| 目标执行 PID | 23636（xtop 主进程）；进程族 23 PID |
| Kernel-File provider | `{EDD08927-9CC4-4E65-B970-C2560FB5C289}` |
| Kernel-Process provider | `{22FB2CD6-0E7B-422B-A0C7-2FAD1FD0E716}` |
| 现有片段 | `runtime-r11\r11-event-chains.json`（718,804B，SHA256 `8F7E162B…74E55F6`，仅作 schema 兼容与对照，不作完整输入） |
| 聚合对照 | `formal-file-access.json`（含已知累加缺陷，仅量级参考，不作配对依据） |
| 字段映射校准 | `calibration-gate-result.json` `file_event_mapping_xml_eventid` |
| 状态码/编解码 | `formal-codec-review.json`、`formal-codec-scan.json`、`formal-clock-offset-review.json`、`formal-session-header.json` |
| 候选配对脚本 | 外部包 `candidate\review_operations.py`、`test_review_operations.py`（8 项单测已通过；离线参考实现，新提取器输出须兼容其输入 schema） |

## 3. 通道选型（两选一，先 A）

### 3.1 通道 A（推荐）：Get-WinEvent 流式只读过滤，免落地 GB 级 XML

- `Get-WinEvent -Path <etl> -Oldest` 可直接读 ETL，前向顺序；时间戳为正确本地 `+08:00`（A2 已核）。
- 实测：整份 ETL 流式遍历约 2.5–5 分钟；在遍历中按 ProviderName + PID 过滤，只落精简事件 JSON，不生成全量 XML/CSV。
- 属性为无名位置数组，须按 EventID 建位置表（见第 4 节）；ID24 字段顺序已离线回验定死。
- 输出 JSON 编码 UTF-8 无 BOM；路径保留 NT 设备路径 `\Device\HarddiskVolumeX\...`，卷号→盘符映射另列，不在事件里改写。

**通道 A 实测基线（2026-11-16，完整性自检基准）**：Get-WinEvent 流读全量 1,916,191 事件，与会话头 `events_processed` 一致，读取完整。PID 23636 Kernel-File 按 EventID 计数：

| EventID | 操作 | 计数 |
|---|---|---:|
| 10/11 | 路径重解析 | 1202 / 68 |
| 12 | Open/Create | 7,147 |
| 13 | Cleanup | 6,000 |
| 14 | Close | 4,370 |
| 15 | ReadFile | 38,009 |
| 16 | WriteFile | 427 |
| 17/18/19/22/23/31/32/34 | 属性/枚举查询 | 76 / 25 / 17 / 5,640 / 2,512 / 71 / 738 / 7 |
| 20/21 | 枚举/引用 | 1,305 / 17 |
| 24 | IRP completion | 60,450 |

新提取器在 PID 23636 范围内的各 EventID 计数应与上表对齐；偏差超出需先排查过滤/丢事件，再进入配对。

### 3.2 通道 B（备选）：tracerpt 转 XML 后 Python iterparse

- 仅当通道 A 属性映射无法稳定回验时使用。校准会话 36 秒即产出 XML 1.44GB；正式会话 XML 预计 2.7–3GB，落 `F:\`（C 余 32GB、D 余 7.3GB、F 余 46GB），验收后删除中间件。
- tracerpt 不支持按 PID/Provider 预过滤；PID 过滤只在后处理。命令用 System32 全路径，`-lr` best-effort。

## 4. 本机实测属性位置（Get-WinEvent Properties 数组，参考；最终以基线回验为准）

| EventID | 操作 | 属性位置 |
|---|---|---|
| 12 | Open/Create | `[0]`FileObject `[1]`FileKey `[2]`IssuingThreadId `[3]`CreateOptions `[4]`CreateAttributes `[5]`ShareAccess `[6]`FileName；**无 Irp 字段** |
| 13 | Cleanup | `[0]`FileObject `[1]`FileKey `[2]`Irp `[3]`IssuingThreadId |
| 14 | Close | `[0]`FileObject `[1]`FileKey `[2]`Irp `[3]`IssuingThreadId |
| 15 | ReadFile | `[0]`ByteOffset `[1]`FileObject `[2]`FileKey `[3]`Irp `[4]`IssuingThreadId `[5]`IOSize `[6]`IOFlags `[7]`ExtraFlags |
| 16 | WriteFile | 同 15 |
| 24 | IRP completion | `[0]`Irp `[1]`ExtraInformation `[2]`Status（已离线回验：`[2]` 出现 `0xC0000011/0x80000005/0xC0000034/0xC0000010/0xC000003A/0x80000006/0xC01C0004` 等 NTSTATUS，`[1]` 为传输字节/小整数；与 XML fields 顺序不同） |
| 17–23/25/31/32/34 | 属性/枚举查询 | 字段以校准门 mapping 为准，逐条保留原始值 |

ID24 字段位置已用非零 NTSTATUS 样本离线回验定死（`[1]`ExtraInformation、`[2]`Status）；其余 EventID 位置表为实测参考，脚本内仍须以校准基线（`calibration-baseline.txt` 65B 写后读）复核 IOSize/ByteOffset 与字节计数对应关系，回验结论写入输出元数据，不凭推测定值。

## 5. 配对规则（验收按此，沿用 R11 ETL 复核第 2/3 节）

1. **PID 先分层**：先严格限定 PID，再按 Irp 为主键、FileObject/FileKey 辅助回填路径；指针跨进程/跨时段复用，禁止跨 PID 句柄匹配；保留请求与完成两侧原始 PID/TID。
2. **字段分列**：`request_bytes`（IOSize 请求量）与 `transferred_bytes`（ExtraInformation 完成量）分列；未配对完成单列，不计入某文件完成字节合计。
3. **完成配对**：ID24 仅带 Irp，在会话窗内按 Irp 配对；重叠 IRP 代际不猜；缺 Open 锚点保留 unresolved；open/cleanup/close 等非读写完成隔离，不计入读/写传输字节。
4. **链顺序**：ID12 打开 → ID15/16 请求 → ID24 完成（同 Irp）→ ID13 清理 → ID14 关闭。
5. **时钟口径**：跨基准以 `formal-start/stop.json` 的 UTC Z 为准；事件级 `+07:59` 恒定偏移标注待核，不用于精确先后排序。
6. **状态码字典**：码值→名称→严重级→是否可视为成功由字典给出；`0x80000005=STATUS_BUFFER_OVERFLOW`（不单独判加载失败）；未解码项显式标"未解码"。
7. **候选口径**：IRP 配对是候选关联，不是严格一一对应；不输出"加载成功/文件层已排除差异"结论。

## 6. 输出与验收口径

每个目标文件须给出：
- 同上下文成功配对的读/写字节候选（分列请求量与完成量）；
- 跨上下文记录（两侧 PID/TID 留存）；
- 重叠 IRP 代际记录；缺 Open 锚点记录；未完成请求；
- 原始事件头留存（EventID、时间戳、PID/TID、Irp、FileObject、FileKey、Status、IOSize、ExtraInformation、路径）。

目标范围：三消息 `.txt`、`p1-step23.dat`、R10 `.dat`、R10 `.dll`、两条 `config.pro`（含 `C:\Users\DELL\config.pro` 探测行）、Roaming `.ui`、Temp `.ui`、`.ui.bak`。

仅同 PID、同 Irp、Status 成功、ExtraInformation 可归到具体读/写请求的完成，才计入成功传输候选；其余单列保留原始信息。结论仅限文件访问层事实，不证明 GUI 解析成功，不构成 DLL 加载成功判定。

## 7. 仍待重放复核的技术项（不预设结论）

- `BuffersLost` 独立样本；tracerpt 479 分钟偏移根因；IOFlags 位定义；InfoClass 19/64/65 query/set 张力、0 未定义、589992 非法；`0x216` 无样本不可解码。
- `.ui` 写是否持久化（以最终文件哈希与写完成状态判定）；CSV/XML PID 口径偏移风险（XML 关联以 Execution/ProcessID 为准）。
- DLL 读取/加载、R10 DAT 与 `C:\Users\DELL\config.pro` 偏大完成传输量，待重放复核。

## 8. 禁区

- 不重采、不删除/覆盖 `formal.etl` 原始证据；不上传整份 ETL。
- 不部署、不改插件/配置/模型；不停用 `p1s23` 做对照试错；不反编译、不抄第三方插件。
- 云端不承诺编译通过或离线重建；交付物为源码/脚本 + 静态自查说明，本机编译与真机观测由助手/用户完成。

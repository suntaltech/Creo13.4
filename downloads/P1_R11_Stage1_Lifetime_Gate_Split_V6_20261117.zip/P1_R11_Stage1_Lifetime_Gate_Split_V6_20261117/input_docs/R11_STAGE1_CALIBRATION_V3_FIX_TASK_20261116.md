# R11 阶段一 校准配对三轮整改任务单（Scope Fix 后，2026-11-16）

## 1. 背景

- 二轮 v2 字段布局已经本机模板、样本与两遍提取交叉确认**正确**；三轮 Scope Fix 已把跨 PID/跨代际 context 隔离为引用、不进目标候选，基线 65B 写后读链本轮已成功配对（`write_then_read_65_observed=true`、`diagnostic_details_complete=true`）。
- 本机重跑校准 ETL 两遍提取门通过；配对门仍拒绝（`accepted=false`，退出码 2）。23 道门 22 过，唯一失败 `calibration_target_not_after_unmatched_exit=false`，计数 `unknown_process_lifetime=371`。
- 分工：ChatGPT 修订配对实现；助手负责规则、审核与真机验收。本轮产出为离线候选，不替换已验收版本，不部署、不重采、不改 Creo/模型/配置。

## 2. 已确认正确、不得回退的项

- 字段布局（本机模板六事件 fields_match 全 true）：
  - 12/1：Irp, FileObject, IssuingThreadId, CreateOptions, CreateAttributes, ShareAccess, FileName
  - 13、14/1：Irp, FileObject, FileKey, IssuingThreadId
  - 15、16/1：ByteOffset, Irp, FileObject, FileKey, IssuingThreadId, IOSize, IOFlags, ExtraFlags
  - 24/0：Irp, ExtraInformation, Status
- 合同 `reference/contract.json`（schema `r11-stage1-contract/2`，哈希 `ED3FFE8A…ABB4CF4`）与两个 PowerShell 脚本本轮与 v2 逐字节一致；无必要不改动，若改动须附变更说明。
- 两遍只读提取、源 ETL 前后哈希比对、版本/Opcode/类型校验、未知布局不猜位、UTC Z 时钟门、输出目录不覆盖等提取口径保持不变。

## 3. 本轮配对门结果

- 23 道门 22 过 1 败：唯一 FAIL `calibration_target_not_after_unmatched_exit`；PASS `write_then_read_65_observed`、`diagnostic_details_complete`。
- 计数：pairs 30,073；orphan_completions 835；requests_missing_anchor 41；cross_context_completions 26,155；overlap_requests 2；unknown_process_lifetime 371；pending_requests 6；foreign_context_records 633,007。
- 基线链 `calibration_sequence_proof` 六序号齐全：写 180106→180107（65, SUCCESS）；读 180436→180437（65, SUCCESS）；读 180438→180439（0, END_OF_FILE，不计字节）。
- 诊断保留：pairs/unresolved/missing-anchor/baseline-chain/overlaps/pending 省略均为 0；context-reference 辅助摘要省略 613,007（原始 context-events 全量哈希保留，不关闭目标门）。

## 4. 根因证据（见 evidence 目录）

目标 PID 27584 为 pwsh.exe：创建 seq106617（06:44:16.4414798Z），退出 seq217465（06:44:21.3766997Z）。退出边界之后 371 条目标事件：

- seq 217466–217876，时间 06:44:21.3769318Z → .4176832Z，紧贴退出 41ms 内。
- 类型：ID13 Cleanup 91、ID14 Close 93、ID24 Completion 186、ID22 Other 1；新请求类（ID12 Create / ID15 Read / ID16 Write）= 0。
- FileObject 仅 2 个退出前未见，其余延续退出前已打开对象；Irp 延续退出前批次。
- 定性：进程退出时的句柄/IRP 清理收尾（exit drain），不是 PID 复用；PID 复用场景会出现新的打开/读写请求。

当前 `Lifetimes.generation` 对退出后、无后续创建边界的事件一律返回 `None`，校准门要求全部 target 事件代际非空，因此把合法 drain 与“退出后未归属新操作”一并判为未归属。

## 5. 整改要求（离线候选）

1. **退出 drain 归属窗口**：退出边界之后，收尾类事件（ID13 Cleanup、ID14 Close、ID24 Completion、ID22 Other）归属退出前最后一代际，单列 `exit-drain` 计数与序号/时间窗；不计入 `unknown_process_lifetime` 未归属拒绝。
2. **退出后新操作仍拒绝**：退出边界之后若出现新请求类（ID12 Create、ID15 Read、ID16 Write），仍判未归属并拒绝；不得为过门把新操作并入 drain。
3. **报告口径分离**：`exit-drain`、`unknown_process_lifetime`、orphan、ambiguous 分桶登记；保留 observed_target_boundaries 与 drain 序号/时间窗证据；`process_generation_scope` 记录实际边界。
4. **校准链断言维持**：同 path/代际/PID/anchor/FileObject，FileKey 一致或同 open 连续，读与 EOF 共享打开对象，EOF 必须 `0xC0000011` + ExtraInfo 0，完成时序晚于请求；不得用无关计数拼成通过。

## 6. 必须保持的安全边界

- 同 scope 真歧义不猜配；完成侧不拿 FO/FK/Offset/方向/“最近一条”捏造筛选。
- 无 Irp 完成仍记孤儿，不降级 FileObject 猜配；跨上下文不消耗请求、不计成功字节。
- 失败 Create 撤销对应路径锚点；Close 失效锚点。
- 门下失败时文件级成功字节小计置 null；候选字节不等于唯一内容字节。
- 不补造事件、不套用未验证版本布局；不输出 DLL 加载、GUI 命令枚举或实体转钣金成功结论。
- 不解析/复用历史卷号映射；IOFlags、InfoClass 19/64/65 张力、0x216、tracerpt +07:59 偏移、BuffersLost、.ui 写持久化、DLL 读取/加载结论仍按 raw 保留为未决项。

## 7. 回传清单（离线包，不含 ETL/DLL/LIB/EXP/CSV/PDB/OBJ）

- 修订后的 `tools/pair_r11.py` 及配套测试；`tools/Extract-R11.ps1`、`tools/Check-R11ProviderSchema.ps1` 无改动则沿用。
- 合同如有调整，附变更说明；未调整则沿用本轮 `reference/contract.json`。
- 离线测试记录（本机复跑口径）、代际/drain 归属规则说明。
- 明确标注：云端无原始 ETL，实际校准/正式回放结论以本机验收为准。

## 8. 验收顺序

回传后本机先跑安装模板只读核对 → 校准 ETL 两遍只读提取 → 校准配对门；校准所有门通过后，才允许提取与配对正式 `formal.etl`（PID 23636）。

# R11 阶段一 生命周期门拆分整改任务单（V6，2026-11-17）

## 1. 背景与分工

- 校准会话（PID 27584）v5 基线已全过、`accepted=true`；700ms drain 窗回归（`cal-pairs-R2`）counters 与 v5 基线逐项一致、65B 链序号不变，窗放宽对校准零退化。
- 正式会话 `formal.etl`（PID 23636）两遍只读提取门通过。按裁决将 drain 策略窗由 100ms 放宽至 700ms、ID23 维持排除后重跑 R3（`formal-pairs-R3`）：`exit_drain` 1→99，`unknown_process_lifetime` 100→2，诊断细节完整（`diagnostic_details_complete=true`），但配对门仍拒绝（`accepted=false`，退出码 2），唯一失败 `target_lifetime_known=false`。
- 口径互斥：该门口径为 `unknown_process_lifetime==0`（`pair_r11.py` 686 行）；ID23 维持排除则这 2 条必然记 unknown，门无法转 true。经裁决**拆分门口径**：把“真正不可归属”与“退出后窗内可识别、但非白名单的收尾参考”分开计数与判定。
- 分工：ChatGPT 修订配对实现（离线候选，不替换已验收版本）；助手负责规则、审核与本机验收。本轮不部署、不重采 ETL、不改 Creo/模型/配置。

## 2. 已确认正确、不得回退的项

- 字段布局（与合同一致，无必要不改）：
  - 12/1：Irp, FileObject, IssuingThreadId, CreateOptions, CreateAttributes, ShareAccess, FileName
  - 13、14/1：Irp, FileObject, FileKey, IssuingThreadId
  - 15、16/1：ByteOffset, Irp, FileObject, FileKey, IssuingThreadId, IOSize, IOFlags, ExtraFlags
  - 24/0：Irp, ExtraInformation, Status
- 合同 `reference/contract.json`（schema `r11-stage1-contract/2`，SHA256 `ED3FFE8A6CE948B611BC6E27F40C2245AE605B21FB742B8B60F362270ABB4CF4`）与两个 PowerShell 提取/校验脚本本轮沿用；若改动须附变更说明。
- 两遍只读提取、源 ETL 前后哈希、版本/Opcode/类型校验、未知布局不猜位、UTC Z 时钟门、输出目录不覆盖等提取口径不变。
- 活跃期（有观测代际）匹配逻辑、foreign PID 上下文隔离为引用（不消耗目标请求、不进候选、不计成功字节）、同 scope 真歧义不猜配、无 Irp 完成记孤儿等现行判定不变。
- 700ms drain 窗为现行策略值；白名单仍为 ID13/14/22/24。

## 3. R3 门结果与计数（见 evidence/formal-r3-pairing-summary.json）

- 唯一 FAIL：`target_lifetime_known`；其余门全 true（含 `diagnostic_details_complete`、`calibration_65_byte_actual_replay`、各哈希/计数/时钟门）。
- counters：pairs 22,296；orphan 302；ambiguous 37,851；missing-anchor 16,985；cross-context 303,757；overlap 43,958；FO-reuse-pending 5,146；pending 44,065；foreign 1,334,381；exit_drain 99；unknown_process_lifetime 2。
- 校准基线 counters（对照不得退化）：pairs 29,956；orphan 835；ambiguous 117；missing-anchor 41；cross-context 26,155；overlap 119；pending 123；foreign 633,007；exit_drain 371；unknown 0。

## 4. 根因证据（见 evidence/id23-samples.json）

目标 PID 23636：创建 seq393339（07:25:18.2888736Z），退出 seq1326139（07:27:23.3964675Z）。退出后窗内仅 2 条 ID23 未归属：

| seq | 时间 | 退出后延迟 | FO | FileKey | ExtraInfo | InfoClass | TID |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1327723 | 07:27:23.5562464Z | 159.779ms | 0xffffa78c1c6053e0 | 0xffffdd08a2d67170 | 0x0 | 590448 | 7260 |
| 1328038 | 07:27:23.5918110Z | 195.344ms | 0xffffa78c1b606e70 | 0xffffdd08be985170 | 0x0 | 590448 | 7260 |

- 两条均夹在退出后 ID22 收尾序列之间：seq1327286 ID22 → 1327723 ID23 → 1327798 ID22 → 1328038 ID23；无 ID12 Create、无 ID15 Read、无 ID16 Write。
- 指针复用迹象：FO2（0xffffa78c1b606e70）活跃期 seq768920 出现过但 FileKey 不同；两条 FileKey 在活跃期 ID10 出现过而 FO 为新。据此**不得**把它们并入前代际操作链或配对候选。
- InfoClass 590448 未在编码表映射，操作语义未确认；`mapping=named_event_xml_no_position_guess`，operation 为 “Other operation (raw)”。归类不得宣称其为查询/清理/写。

## 5. 整改要求（离线候选）

### 5.1 新增非阻断收尾参考类别

在 `exit-drain`、`unknown` 之外新增归属类别（建议名 `post_exit_classified_reference`），与阻断性 unknown 分离。

某条退出后事件同时满足以下全部条件，才归入该非阻断类别；任一不满足，回落阻断性 unknown：

1. 在观测到的退出边界之后、`exit_drain_max_ms`（现行 700ms）窗内；
2. 非新操作：event_id ∉ {12, 15, 16}；
3. 该退出窗未被新操作关窗（不在 `blocked_exit_windows`）；
4. 存在可归属的前代际（formal 需观测到创建；校准可用初始代际 0）；
5. 非白名单（当前仅 ID23 落此），指针可解析，ExtraInformation=0，无写候选字节；
6. **不建立新的 open 锚点；IRP 不进入 pending；不生成 pair / cross-context / ambiguous 候选**；仅落诊断流留证。

### 5.2 计数与门判定拆分

- `unknown_process_lifetime` 只统计阻断性子原因：`no_observed_active_generation`、`new_operation_after_exit_without_create`、`exit_window_closed_by_new_operation`、`post_exit_event_not_in_drain_allowlist`（不满足 5.1 条件者）、`no_attributable_pre_exit_generation`、`exit_header_time_unavailable`、`invalid_exit_window_clock_or_limit`、`outside_controlled_exit_drain_window`。
- 新增 `post_exit_classified_reference` 计数，逐条在诊断流留证：reason、event_id、InfoClass、FO/FileKey/Irp、elapsed、前代际、退出边界。
- 门口径：formal `target_lifetime_known` 与校准 `calibration_target_not_after_unmatched_exit` 均只要求**阻断性 unknown==0**；非阻断参考不计入阻断性拒绝，但仍在报告与诊断流可见、可复核。

### 5.3 保守回落

- InfoClass 590448 维持“未映射”标注；归类依据仅是退出后位置 + 非新操作 + 无写候选，不声明语义。
- 若后续证据表明该 InfoClass 为写/新建/新请求，规则必须回落阻断性 unknown；不得为过门放宽 5.1 条件。
- 非阻断参考不得改变既有配对结果：不消费请求、不解除 pending、不改写锚点与作用域。

## 6. 必须保持的安全边界

- 同 scope 真歧义不猜配；完成侧不拿 FO/FK/Offset/方向/“最近一条”捏造筛选。
- 无 Irp 完成仍记孤儿，不降级 FileObject 猜配；跨上下文不消耗请求、不计成功字节。
- 失败 Create 撤销对应路径锚点；Close 失效锚点；FO 复用且前代际有 pending 的既有判定不变。
- 门下失败时文件级成功字节小计置 null；候选字节不等于唯一内容字节。
- 不补造事件、不套用未验证版本布局；不输出 DLL 加载、GUI 命令枚举或实体转钣金成功结论。
- 未决项按 raw 保留：IOFlags 位定义、InfoClass 19/64/65 张力、0/589992/590448 映射、0x216、tracerpt +07:59 偏移、BuffersLost、.ui 写持久化、DLL 读取/加载结论。

## 7. 回传清单（离线包，不含 ETL/DLL/LIB/EXP/CSV/PDB/OBJ）

- 修订后的 `tools/pair_r11.py` 及配套测试；两个 PowerShell 脚本无改动则沿用。
- 合同如有调整附变更说明；未调整沿用本轮 `reference/contract.json`。
- 离线测试记录（本机复跑口径）、类别拆分规则与计数/门判定说明。
- 明确标注：云端无原始 ETL，实际校准/正式回放结论以本机验收为准。

## 8. 验收顺序（本机）

1. 回包先做安装模板只读核对与静态检查。
2. 校准 ETL 两遍提取 → 校准配对门：阻断 unknown=0、exit_drain=371、pairs=29,956、orphan=835、ambiguous=117、cross-context=26,155、overlap=119、pending=123、missing-anchor=41、foreign=633,007；65B 链序号 180106/180107/180436/180437/180438/180439 不变；`accepted=true`。
3. 校准全过后跑 formal 新目录：阻断 unknown=0；`post_exit_classified_reference=2`（仅两条 ID23）；exit_drain=99；其余桶与 R3 对照，不得产生新的活跃期误配；非阻断参考不进 pairs/pending；诊断细节完整。
4. 任一步退化或出现新写/新操作被归为参考，即驳回并回退现行已验收版本。

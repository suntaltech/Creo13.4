# 校准配对失败根因与修正（2026-11-16）

上一版工具的位置合同有错，合成样本又按同一错误合同构造，24 项测试通过不能证明字段语义正确。本轮修正该实现缺陷，并增加独立定义、实际原始样本及本机模板检查。

**ID24 首字段仍为 Irp。错误在请求侧，包含此前错误认定“没有 Irp”的 ID12。保留同 PID/代际/真实 Irp 配对，不改用 FileObject 猜配。**

| EventID / Version | 正确属性顺序 |
|---|---|
|12 / 1|Irp, FileObject, IssuingThreadId, CreateOptions, CreateAttributes, ShareAccess, FileName|
|13、14 / 1|Irp, FileObject, FileKey, IssuingThreadId|
|15、16 / 1|ByteOffset, Irp, FileObject, FileKey, IssuingThreadId, IOSize, IOFlags, ExtraFlags|
|24 / 0|Irp, ExtraInformation, Status|

Create V1 有 Irp、没有 FileKey。旧合同把 Create raw[0] 与 Cleanup/Read/Write 的真实 Irp 误命名为 FileObject，所以“完成首字段与 FileObject 集合相交”反映的是错误命名，不能证明完成首字段是 FileObject。旧 Read/Write raw[3] 实为 FileKey；其跨多次打开稳定不构成 Irp 不存在的证明。

## 核对依据及边界

微软维护的 [Kernel-File 桥接解析器](https://github.com/microsoft/perfview/blob/9c3b7e88e86a6e6199b21f8747c426353e8f98c8/src/TraceEvent/Parsers/Microsoft-Windows-Kernel-File.cs) 使用相同 provider GUID，将 Create ID12 转交 FileIOCreateTraceData。

微软维护的 [KernelTraceEventParser](https://github.com/microsoft/perfview/blob/9c3b7e88e86a6e6199b21f8747c426353e8f98c8/src/TraceEvent/Parsers/KernelTraceEventParser.cs) 区分 IrpPtr、FileObject、FileKey；Create 对 manifest 使用 Version+2 的 LayoutVersion，不能直接套 classic 版本号。FileIOReadWrite 的 IrpPtr 在 offset 8，OperationEnd 的 IrpPtr 在 offset 0，后接 ExtraInfo、NtStatus。上述源码已按固定提交重取并核对内容哈希。

[公开导出的 provider manifest](https://github.com/repnz/etw-providers-docs/blob/master/Manifests-Win10-18990/Microsoft-Windows-Kernel-File.xml) 给出这六个版本模板的精确属性顺序。它是次级公开导出，不是当前 Windows 的原生 WDK/WPA 输出。样本 Version/类型与之交叉核对，本机还必须用新脚本导出安装的模板，不能把公开快照冒称为本机定义。来源、下载哈希和模板摘录见 reference/source-contract-review.json。

微软对 Create 的 IrpPtr 注释为 FLT_CALLBACK_DATA 指针；此处 Irp 是 provider 定义的操作标识，不承诺物理 nt!_IRP 对象，更不承诺全局唯一或永不复用。

## 本轮实际样本

seq180103 Create raw[0] 与 seq180106 Write raw[1] 同为 18446646818753682312，角色是 Irp；Create raw[1] 与 Write raw[2] 同为 18446646818528985520，角色是 FileObject。Write raw[3] 的 18446705628201628016 等价于 ID10 的 0xffffdd08b5283170，角色是 FileKey。

Write offset=0/IOSize=65，两条 Read offset=0、65 / IOSize=4096 保留。validation/sample-field-review.json 保存 29 条重映射结果、原始属性及被忽略的旧 data，没有补附件省略的 provider 头。

基线 17 条记录没有 ID24，另一组 12 条完成与基线读写 Irp 没有交集。样本足够揭示错位，不足以证明 65B 写后读已完成配对。当前无法给出真实回放 extraction.json / pairing-report.json，不按任务回传清单伪造它们。

## 实现修正

- 按 EventID/Version/Opcode/类型选择字段，未知版本不凭相同属性数套用；实际安装模板报告与合同哈希绑定。
- Create 的真实 Irp 进入操作表，完成消费后允许顺序复用；失败 Create 撤销对应路径锚点。FileObject 只在同 PID/代际回填路径，FileKey 从后续同对象操作学习。
- 同 FileObject 不同 Irp 的并发请求分别配对；同 Irp 重叠保持 tainted。无 Irp 完成记孤立，不降级为 FileObject 猜配。跨上下文只保留引用，不跨 PID 锚定路径或计字节。
- 非读写信息隔离，IOSize/ExtraInformation 分列。失败验收门下文件级小计为 null；成功候选也不等于唯一内容字节或 GUI/DLL 成功。
- 上版错误键堆积大量挂起请求，又在每条诊断中复制整个历史列表，导致重复内容放大。改为键级 taint、最多 8 个请求引用、保留总数，不为打标遍历所有旧请求。
- 四个重复诊断流默认每流 32MiB/20,000 条上限，省略计数写报告并关闭完整性门。原始输入与核心 pairs/pending 保留；不删旧大日志。

## 本机验收

顺序是新脚本 Parser → 安装的 provider 模板 → 现存校准 ETL 只读重提取/配对 → 校准所有门通过后才读正式 ETL。旧第二遍过滤键错误，不能只修改旧 JSON 标签或合同哈希来升级为本轮回放。

37 项 Python 测试通过，包括原有安全边界回归、实际样本和模板、同对象多请求、Irp 复用、跨 PID、失败 Create、无 Irp 完成、版本/类型拒绝、引用有界、诊断触限后拒绝验收。云端没有原始 ETL 或 Windows PowerShell，未声称本轮实际校准通过。

仍保留 BuffersLost 未知、IOFlags 未解码、InfoClass 冲突、0x216 未解码、tracerpt +07:59 根因和历史卷号映射未决。不部署、不重采、不修改 Creo/模型/配置，不发送 PTC，不把文件层候选升级为 DLL 加载、GUI 枚举或实体转钣金结论。

# 历史审核

上一轮作用域修复说明见 reference/SCOPE_FIX_REVIEW_PREVIOUS.md。本轮入口为 EXIT_DRAIN_REVIEW.md 和 README_先读.md。

# 历史审核

上一轮退出归属说明存于 reference/EXIT_DRAIN_REVIEW_PREVIOUS.md。本轮入口为 LIFETIME_GATE_SPLIT_REVIEW.md；现行策略窗为经本机回归的 700ms。

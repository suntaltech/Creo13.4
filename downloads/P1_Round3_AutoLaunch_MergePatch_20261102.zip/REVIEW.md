# P1 第三轮：插件后台拉起服务 + 只读分析 + 关闭转换

按用户明确回复“必须由插件自动拉起”选择启动方案。本轮只改原四个目标文件；保留三个命令、SiswCore、页面布局及现有 ID；新增单位提示 span 的 ID。不部署 class，不启用转换，不执行写模型。

## 两份补丁如何选择

- `P1_Round3_from_Round2.patch`：用于已应用第二轮源码的副本。
- `P1_Round3_from_Production.patch`：用于尚未应用第二轮的原生产源码副本，即用户此前交接的四文件基线。

**二选一，不连续应用两份。** 先与对应 `input-sha256-*.json` 核对；不要覆盖已有未合并修改。在副本目录执行 `git apply --check <所选补丁>`，通过后再 `git apply`。两份补丁均已在各自精确基线上应用并核对四份输出字节一致。

包内根目录四个源码为最终结果，不是现场部署许可。测试源在 tests，检查结果在 evidence。没有 class/jar 产物，生成的 SDK 替身不允许用于生产构建。

## 启动责任与顺序（用户已选择插件自动拉起）

1. Windows 上安装并配置真实 CREOSON2.8.2，保留其 `creoson_run.bat`。默认目录仍为 `D:\creoson\CreosonServerWithSetup-2.8.2-win64`。可在启动 Creo 前设置 `CREO_BR_SERVER_DIR`，或使用 JVM property `creo.batchrename.serverDir`（优先）；目录不会由插件创建。
2. Creo 加载插件后，`start()` 只提交 daemon 后台启动任务，并继续注册三个命令；不在 UI/命令线程等待服务、端口或子进程。
3. 后台先单次连接 `127.0.0.1:9056`，超时500ms；已有监听则跳过启动，防止重复进程。**端口监听不是 CREOSON 就绪证明**，前端仍须验证 connection/connect。错误占用端口时需现场排查，不再启动第二份争抢端口。
4. 未监听时，后台确认脚本存在，再通过 `cmd /d /c start "" /b cmd /d /c creoson_run.bat` 请求 detached 启动。工作目录固定为配置的服务目录，启动输出追加到该目录的 `p1_launch_stdout.log` / `p1_launch_stderr.log`。不 waitFor、不循环探测、不 Thread.sleep。日志“launch requested”仅说明请求已提交，不能证明脚本成功、服务或 Creo 会话就绪。
5. 正在提交启动时的重复调用不再启动第二个后台任务。任务独立于插件停止；stop 不等待启动线程，也不杀 CREOSON。下次加载会重新单次检查端口。
6. 用户点页面分析，沿用 SiswCore 建立连接。对通信不确定错误最多尝试4次，每次 connection/connect 超时3秒，间隔1秒；正常定时器下约15秒预算。业务错误不盲目重试；耗尽后中文提示服务未就绪，用户可以再次分析。没有自动轮询读取模型，也没有重试钣金写操作。

本云环境是 Linux；实际 Windows `cmd start`、bat脚本运行、文件权限、端口占用与真实 CREOSON 连接**未执行**，必须现场确认。Linux 分支明确不启动任何进程；测试仅验证后台任务调度及模拟连接状态。

## 对审核意见的最小整改

### P1-A：启动方案

恢复插件的服务拉起责任，但放到纯后台任务；没有恢复第二轮删除的20秒同步等待。后台不获取 session/model/body，不调用任何 Creo API。前端连接状态绑定到现有 smtStatus，保留原 core.call uncertain 一次重连逻辑。connectSession 可选 timeout 参数保持默认值兼容既有调用。

### P2-C：旧桥接

core.bridgeCall 对 `bridgeKey==="sisw-smt"` 的全部 action（含 analyze、health、未知/空action）统一返回 CHANNEL_BLOCKED，且在访问 window.external 前结束。其他 bridgeKey 的通用行为保留。sheetmetal.js 不调用旧桥接。

### P2-D：无调用方契约

原 convertActivePart 重命名为 `validateClosedConversionContractForTests`，注释标明仅离线反射测试、无 UI/桥接动作入口，禁止未来直接添加创建。没有生产调用方；保留0.1–20mm、save拒绝、确认参数及错误码的独立校验测试，不伪装成可执行转换能力。

### P2-E：单位

HTML 去掉板厚参数旁静态 `mm`，初始显示“单位待确认”。真实单位读取成功后动态显示“输入契约按 mm；模型长度单位：cm/inch/...（未换算，参数禁用）”；失败或重新分析时恢复待确认。**板厚数值契约仍为0.1–20mm**；没有随标签改成模型单位，也没有静默数值换算。几何尺寸/面积继续显示模型真实单位或“单位未确认”；不把几何跨度当正式壁厚。

### P2-F：日志

保留第二轮非阻塞队列关闭：stop 不等待任何磁盘排空，UI线程等待预算为0ms；后台继续尽力处理已有日志，并记录 dropped=N。未采用建议中的500–1000ms同步等待，避免给 UI/卸载回调增加停顿。daemon线程/JVM退出时尾部可能丢失，仍是明确的诊断日志局限，不是完整持久审计。需要可靠收集时，应由现场外部日志收集/退出流程处理，不能声称卸载已保证日志落盘。

### P1-B / P2-G：保持未完成

真机三命令/五种模式、现场CREOSON响应、现有重命名/关于页面、真实多实体诊断、面选择来源、材料侧、原生动作通道等仍未验证。真实创建、重生成、保存和 AddBrowserMessageListener 均未恢复。nativeConvertReady=false，saved=false；控件继续禁用。

## 编译与检查

在源码副本应用所选补丁后，Windows 暂存编译（不得输出到现场 jlink/classes）：

```powershell
& 'D:\creoson\jdk25\jdk-25.0.5+8\bin\javac.exe' --release 17 -encoding UTF-8 `
  -cp 'D:\Program Files\PTC\Creo 13.4.0.0\Common Files\text\java\otk.jar' `
  -d '<新的暂存目录>' '.\BatchRename.java'
node --check .\web\assets\js\core.js
node --check .\web\assets\js\sheetmetal.js
```

预期退出0；第三轮真实 otk.jar 编译**本云端未执行，没有退出码**。用户审核报告确认的是第二轮源码在其现场真实 SDK 编译退出0，不能当成本轮编译证据。classpath 唯一 otk.jar，不混入 pfcasync.jar。

离线复跑：

```sh
node tests/test_round3.cjs /新日志目录/frontend.jsonl
python3 tests/run_java.py --jdk /JDK目录 --output /新建且不存在的输出目录
```

本轮实际结果：两份补丁应用核对通过；两项 node --check 退出0；25项前端模拟检查通过；完整本轮 Java 源码对生成的 SDK 替身编译退出0、major61，53项模拟行为检查通过。包括全部P1桥接阻断、其他桥接兼容、动态单位提示/失败清理、有限启动重试、启动任务不在owner线程运行、重复启动去重、启动未完成时stop及时返回。未运行真实 Windows 脚本，不将模拟调度结果称为真实UI无阻塞验收。

## 修改文件与未修改范围

1. BatchRename.java：后台进程启动任务、关闭测试契约命名。
2. core.js：全部P1桥接阻断、有限连接重试与状态。
3. sheetmetal.js：绑定现有状态、动态单位提示和失败重置。
4. sheetmetal.html：增加单位提示 span，保留布局、CSS、原 ID及脚本引用。

未改 .dat、RBN、rename/about 页面或base.css；未部署class、未修改真实模型。未实现WFC创建/选择句柄/shell移除面/材料方向/自动转换/保存/备份回滚/A4批量转换。上线前必须重新做本轮真实SDK编译与现场只读回归。

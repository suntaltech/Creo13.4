struct R3Definition {
    const char* name;
    const char* begin;
    const char* finish;
    unsigned ordinal;
};
constexpr R3Definition r3_definitions[] = {
    {"message", "PROBE_MSG_BEGIN", "PROBE_MSG_RETURN", 1},
    {"units", "PROBE_UNITS_BEGIN", "PROBE_UNITS_RETURN", 2},
    {"bodies", "PROBE_BODIES_BEGIN", "PROBE_BODIES_RETURN", 3},
};
alignas(8) volatile LONG64 r3_sequence = 0;
volatile LONG r3_busy = 0;

struct R3Run {
    const R3Definition& definition;
    ULONGLONG id = static_cast<ULONGLONG>(InterlockedIncrement64(&r3_sequence));
    const char* result = "INCOMPLETE";
    bool cleanup_failed = false;
    std::string terminal{};
};

const char* r3_bool(bool value) noexcept { return value ? "true" : "false"; }

void r3_trace(const R3Run& run, const char* event, const char* details) noexcept
{
    char facts[model_facts_capacity] = {};
    const int count = std::snprintf(facts, sizeof(facts),
        "{\"probe\":\"%s\",\"probe_ordinal\":%u,\"operation_id\":%llu%s}",
        run.definition.name, run.definition.ordinal, static_cast<unsigned long long>(run.id), details);
    if (count > 0 && static_cast<size_t>(count) < sizeof(facts)) trace_event(event, facts);
    else trace_failure("r3_probe_facts", ERROR_INSUFFICIENT_BUFFER);
}

struct R3Status {
    bool returned = false;
    ProError code = PRO_TK_NO_ERROR;
    bool ok() const noexcept { return returned && code == PRO_TK_NO_ERROR; }
    std::string json() const { return returned ? std::to_string(static_cast<int>(code)) : "null"; }
};

void r3_api(const R3Run& run, const char* event, const char* name,
    const char* role, const R3Status& status, bool threw = false) noexcept
{
    char value[24] = "null", facts[300] = {};
    if (status.returned) std::snprintf(value, sizeof(value), "%d", static_cast<int>(status.code));
    const int count = std::snprintf(facts, sizeof(facts),
        ",\"api\":\"%s\",\"role\":\"%s\",\"pro_error\":%s,\"exception\":%s",
        name, role, value, r3_bool(threw));
    if (count > 0 && static_cast<size_t>(count) < sizeof(facts)) r3_trace(run, event, facts);
    else trace_failure("r3_probe_api_facts", ERROR_INSUFFICIENT_BUFFER);
}

template<class Function>
bool r3_call(const R3Run& run, const char* name, const char* role, R3Status& status, Function fn)
{
    r3_api(run, "R3_PROBE_API_START", name, role, R3Status{});
    try {
        status.code = fn();
        status.returned = true;
        r3_api(run, "R3_PROBE_API_DONE", name, role, status);
    } catch (...) {
        r3_api(run, "R3_PROBE_API_DONE", name, role, R3Status{}, true);
        throw;
    }
    return status.ok();
}

template<size_t N>
std::string r3_utf8_name(const wchar_t (&name)[N])
{
    size_t units = 0;
    while (units < N && name[units]) ++units;
    if (!units || units == N) return "null";
    char utf8[N * 3 + 1] = {}, quoted[N * 6 + 3] = {};
    if (WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, name, static_cast<int>(units),
            utf8, static_cast<int>(sizeof(utf8) - 1), nullptr, nullptr) <= 0 ||
        !quote_json_utf8(utf8, quoted, sizeof(quoted))) return "null";
    return quoted;
}

std::string r3_number(double number)
{
    if (!std::isfinite(number)) return "null";
    const _locale_t locale = _create_locale(LC_NUMERIC, "C");
    if (!locale) return "null";
    char buffer[64] = {};
    const int written = _snprintf_l(buffer, sizeof(buffer), "%.17g", locale, number);
    _free_locale(locale);
    return written > 0 && static_cast<size_t>(written) < sizeof(buffer) ? buffer : "null";
}

struct R3Model {
    ProMdl handle = nullptr;
    ProMdlType type = PRO_MDL_UNUSED;
    ProMdlName name = {};
    R3Status current, type_status, name_status;
    std::string name_json = "null";

    bool read(R3Run& run)
    {
        if (!r3_call(run, "ProMdlCurrentGet", "model", current, [&] { return ProMdlCurrentGet(&handle); })
            || !handle) { run.result = "MODEL_UNAVAILABLE"; return false; }
        if (!r3_call(run, "ProMdlTypeGet", "model", type_status, [&] { return ProMdlTypeGet(handle, &type); })) {
            run.result = "MODEL_TYPE_UNAVAILABLE"; return false;
        }
        if (type != PRO_MDL_PART) { run.result = "NOT_PART"; return false; }
        if (!r3_call(run, "ProMdlMdlnameGet", "model", name_status, [&] { return ProMdlMdlnameGet(handle, name); })) {
            run.result = "MODEL_NAME_UNAVAILABLE"; return false;
        }
        name_json = r3_utf8_name(name);
        if (name_json == "null") { run.result = "MODEL_NAME_INVALID"; return false; }
        return true;
    }

    std::string facts() const
    {
        return ",\"model_name\":" + name_json +
            ",\"model_type\":" + (type_status.ok() ? std::to_string(static_cast<int>(type)) : "null") +
            ",\"current_pro_error\":" + current.json() + ",\"type_pro_error\":" + type_status.json() +
            ",\"name_pro_error\":" + name_status.json();
    }
};

bool r3_message_file(ProFileName& file, const wchar_t* value) noexcept
{
    const size_t count = std::wcslen(value);
    if (count >= sizeof(file) / sizeof(file[0])) return false;
    std::wmemcpy(file, value, count + 1);
    return true;
}

bool r3_message_key(ProCharLine& key, const char* value) noexcept
{
    const size_t count = std::strlen(value);
    if (count >= sizeof(key)) return false;
    std::memcpy(key, value, count + 1);
    return true;
}

struct R3MessageVariant {
    const wchar_t* file;
    const char* filename;
    const char* name;
    const char* encoding;
    const char* marker_key;
    const char* static_key;
    const char* dynamic_key;
    const wchar_t* zh_token;
    const wchar_t* ascii_token;
};
constexpr R3MessageVariant r3_variants[] = {
    {L"p1_r3a2_ctl.txt", "p1_r3a2_ctl.txt", "control", "usascii",
        "P1_R3A2_CTL_MARK", "P1_R3A2_CTL_STATIC", nullptr, L"A2_CTL_ZH", L"A2_CTL_EN"},
    {L"p1_r3a2_u8.txt", "p1_r3a2_u8.txt", "current", "utf8_no_bom",
        "P1_R3A2_U8_MARK", "P1_R3A2_U8_STATIC", "P1_R3A2_U8_TEXT", L"A2_U8_ZH", L"A2_U8_EN"},
    {L"p1_r3a2_bom.txt", "p1_r3a2_bom.txt", "bom", "utf8_bom",
        "P1_R3A2_BOM_MARK", "P1_R3A2_BOM_STATIC", "P1_R3A2_BOM_TEXT", L"A2_BOM_ZH", L"A2_BOM_EN"},
    {L"p1_r3a2_gbk.txt", "p1_r3a2_gbk.txt", "cp936", "cp936_no_bom",
        "P1_R3A2_GBK_MARK", "P1_R3A2_GBK_STATIC", "P1_R3A2_GBK_TEXT", L"A2_GBK_ZH", L"A2_GBK_EN"},
};

struct R3Marker {
    const R3MessageVariant* variant = nullptr;
    const wchar_t* token = nullptr;
    const char* language_dir = nullptr;

    bool found() const noexcept { return variant != nullptr; }
    bool same_resource(const R3Marker& other) const noexcept
    {
        return found() && variant == other.variant && token == other.token;
    }
    std::string path_json() const
    {
        return found() ? std::string("\"text/") + language_dir + "/" + variant->filename + "\"" : "null";
    }
};

std::string r3_message_utf16(const wchar_t* value)
{
    if (!value) return "null";
    const size_t units = std::wcslen(value);
    if (units >= PRO_LINE_SIZE) return "null";
    if (units == 0) return "\"\"";
    char utf8[PRO_LINE_SIZE * 3 + 1] = {}, quoted[483] = {};
    if (WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, value, static_cast<int>(units),
            utf8, sizeof(utf8) - 1, nullptr, nullptr) <= 0 ||
        !quote_json_utf8(utf8, quoted, sizeof(quoted))) return "null";
    return quoted;
}

struct R3MessageBuffer {
    ProLine text = {};
    R3Status status;

    bool readable() const noexcept
    {
        return status.ok() || (status.returned && status.code == PRO_TK_MSG_TOO_LONG);
    }
    size_t units() const noexcept
    {
        size_t size = 0;
        if (readable()) while (size < PRO_LINE_SIZE && text[size]) ++size;
        return size;
    }
    bool terminated() const noexcept { return readable() && units() < PRO_LINE_SIZE; }
    std::string json() const { return terminated() ? r3_message_utf16(text) : "null"; }
};

R3Marker r3_find_marker(const R3MessageBuffer& response, bool prefix) noexcept
{
    if (!response.status.ok() || !response.terminated()) return {};
    for (const auto& variant : r3_variants) {
        const wchar_t* tokens[] = {variant.zh_token, variant.ascii_token};
        for (unsigned i = 0; i < 2; ++i) {
            const size_t count = std::wcslen(tokens[i]);
            if (response.units() < count || std::wmemcmp(response.text, tokens[i], count) != 0) continue;
            if (response.text[count] == (prefix ? L'|' : L'\0')) {
                return R3Marker{&variant, tokens[i], i == 0 ? "chinese_cn" : "usascii"};
            }
        }
    }
    return {};
}

bool r3_lookup_message(R3Run& run, ProFileName& file, const char* key_name,
    const char* role, R3MessageBuffer& response, char* parameter = nullptr)
{
    ProCharLine key = {};
    if (!r3_message_key(key, key_name)) return false;
    r3_call(run, "ProMessageToBuffer", role, response.status, [&] {
        return parameter ? ProMessageToBuffer(response.text, file, key, parameter) :
            ProMessageToBuffer(response.text, file, key);
    });
    return true;
}

bool r3_display_message(R3Run& run, ProFileName& file, const char* key_name,
    const char* role, R3Status& status, char* parameter)
{
    ProCharLine key = {};
    if (!r3_message_key(key, key_name)) return false;
    r3_call(run, "ProMessageDisplay", role, status, [&] {
        return parameter ? ProMessageDisplay(file, key, parameter) : ProMessageDisplay(file, key);
    });
    return true;
}

// Show one sample per trigger. Re-read the source marker before every later sample.
unsigned r3_message_sample = 0;
bool r3_static_ok = false, r3_ascii_ok = false;

void r3_probe_message(R3Run& run)
{
    const unsigned sample = r3_message_sample;
    r3_message_sample = (sample + 1) % 14;
    const bool control = sample < 2;
    const unsigned step = control ? sample : (sample - 2) % 4;
    const auto& variant = r3_variants[control ? 0 : 1 + (sample - 2) / 4];
    const char* role = step == 0 ? "marker" : step == 1 ? "static" : "dynamic";
    const char* kind = step < 2 ? "none" : step == 2 ? "ascii" : "zh";
    const char* key = step == 0 ? variant.marker_key : step == 1 ? variant.static_key : variant.dynamic_key;
    if (step == 0) { r3_static_ok = false; r3_ascii_ok = false; }

    ProFileName file = {};
    R3MessageBuffer marker_buffer, response;
    R3Status display;
    if (!r3_message_file(file, variant.file) ||
        !r3_lookup_message(run, file, variant.marker_key, "marker", marker_buffer)) {
        run.result = "RESOURCE_IDENTIFIER_INVALID"; return;
    }
    const R3Marker marker = r3_find_marker(marker_buffer, false);
    const bool has_target = marker.variant == &variant && (control || marker.token == variant.zh_token);
    const bool eligible = step == 0 || (has_target &&
        (step == 1 || (r3_static_ok && (step == 2 || r3_ascii_ok))));
    const wchar_t* parameter = step < 2 ? nullptr : step == 2 ? L"R3_ASCII" : L"\u4e2d\u6587";
    const wchar_t* static_text = control ? L"Select one planar surface belonging to the default body." :
        L"\u8bf7\u9009\u62e9\u9ed8\u8ba4\u4f53\u4e0a\u7684\u4e00\u4e2a\u5e73\u9762\u66f2\u9762\u4f5c\u4e3a\u9a71\u52a8\u9762\u3002";
    std::wstring expected;
    if (has_target) {
        expected = marker.token;
        if (step != 0) {
            expected += L'|';
            expected += parameter ? parameter : static_text;
        }
    }

    char value[64] = {};
    if (eligible && parameter && WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, parameter, -1,
            value, sizeof(value), nullptr, nullptr) <= 0) {
        run.result = "PARAMETER_ENCODING_FAILED"; return;
    }
    char* argument = parameter ? value : nullptr;
    if (eligible && step != 0 && !r3_lookup_message(run, file, key, role, response, argument)) {
        run.result = "RESOURCE_IDENTIFIER_INVALID"; return;
    }
    const auto& measured = step == 0 ? marker_buffer : response;
    // Keep marker failures visible as API results. A skipped text sample leaves the previous display alone.
    if (eligible && measured.status.ok() && !r3_display_message(run, file, key, role, display, argument)) {
        run.result = "RESOURCE_IDENTIFIER_INVALID"; return;
    }
    const R3Marker text_marker = step == 0 ? marker : r3_find_marker(response, true);
    const bool same_source = marker.same_resource(text_marker);
    const bool match = has_target && same_source && measured.status.ok() && measured.terminated() &&
        measured.units() == expected.size() &&
        std::wmemcmp(measured.text, expected.c_str(), expected.size()) == 0;
    if (step == 1) r3_static_ok = match;
    if (step == 2) r3_ascii_ok = match;
    run.result = !eligible ? "PREREQUISITE_UNVERIFIED" : !measured.status.ok() ? "BUFFER_API_FAILED" :
        !match ? "BUFFER_MISMATCH" : !display.ok() ? "DISPLAY_API_FAILED" : "BUFFER_MATCH";
    const char* matched = measured.readable() ? r3_bool(match) : "null";
    const char* decode_layer = !eligible || step == 0 ? "untested" : !same_source ? "source_unconfirmed" :
        match ? "buffer_matches" : step == 1 ? "decode_mismatch_with_source" : "parameter_or_substitution";
    const char* lookup = !marker_buffer.status.ok() ? "marker_api_failed" :
        !marker.found() ? "marker_unrecognized" : has_target ? "target_marker_match" :
        marker.variant == &variant ? "same_filename_usascii_marker" : "different_variant_marker";
    run.terminal =
        ",\"sample\":" + std::to_string(sample + 1) + ",\"role\":\"" + role + "\""+
        ",\"key\":\"" + key + "\",\"variant\":\"" + variant.name + "\"" +
        ",\"encoding_tag\":\"" + variant.encoding + "\",\"requested_file\":\"" + variant.filename + "\"" +
        ",\"marker_key\":\"" + variant.marker_key + "\",\"marker_pro_error\":" + marker_buffer.status.json() +
        ",\"marker_buffer_json\":" + marker_buffer.json() +
        ",\"marker_expected_zh\":" + r3_message_utf16(variant.zh_token) +
        ",\"marker_expected_usascii\":" + r3_message_utf16(variant.ascii_token) +
        ",\"marker_token_json\":" + r3_message_utf16(marker.token) +
        ",\"marker_matched_resource\":" + marker.path_json() +
        ",\"target_source_confirmed\":" + r3_bool(has_target) + ",\"lookup_layer\":\"" + lookup + "\"" +
        ",\"text_matched_resource\":" + text_marker.path_json() +
        ",\"text_source_matches_marker\":" + (measured.status.ok() ? r3_bool(same_source) : "null") +
        ",\"pro_error\":" + measured.status.json() + ",\"display_pro_error\":" + display.json() +
        ",\"wide_units\":" + (measured.readable() ? std::to_string(measured.units()) : "null") +
        ",\"terminated\":" + (measured.readable() ? r3_bool(measured.terminated()) : "null") +
        ",\"text_json\":" + measured.json() +
        ",\"expected_units_json\":" + r3_message_utf16(has_target ? expected.c_str() : nullptr) +
        ",\"unit_match\":" + matched + ",\"buffer_match\":" + matched + ",\"buffer_ok\":" + matched +
        ",\"decode_layer\":\"" + decode_layer + "\",\"display_layer\":\"" +
            (display.ok() ? "requires_screenshot" : display.returned ? "display_api_failed" : "not_attempted") +
        "\",\"display_observed\":null,\"display_ok\":null,\"param_kind\":\"" + kind +
        "\",\"param_json\":" + r3_message_utf16(parameter) +
        ",\"param_roundtrip_ok\":" + (parameter ? matched : "null") +
        ",\"control_file_sha256\":" + (control ?
            "\"921ebd62f52ebf07759021f4e68b42ca6f0916c9f2e6e273af12468bc800aa4f\"" : "null") +
        ",\"control_match\":" + (control ? matched : "null");
}

void r3_probe_units(R3Run& run)
{
    R3Model model;
    ProUnitsystem system = {};
    ProUnititem target = {}, mm = {};
    ProName mm_name = L"mm";
    ProUnitConversion conversion = {};
    R3Status system_status, target_status, mm_status, conversion_status;
    const bool context = model.read(run);
    if (context) {
        if (r3_call(run, "ProMdlPrincipalunitsystemGet", "units", system_status, [&] {
                return ProMdlPrincipalunitsystemGet(model.handle, &system);
            }) && r3_call(run, "ProUnitsystemUnitGet", "units", target_status, [&] {
                return ProUnitsystemUnitGet(&system, PRO_UNITTYPE_LENGTH, &target);
            }) && r3_call(run, "ProUnitInit", "mm", mm_status, [&] {
                return ProUnitInit(model.handle, mm_name, &mm);
            })) {
            r3_call(run, "ProUnitConversionCalculate", "mm_to_current_model", conversion_status, [&] {
                return ProUnitConversionCalculate(&mm, &target, &conversion);
            });
        }
    }
    const std::string from = mm_status.ok() ? r3_utf8_name(mm.name) : "null";
    const std::string to = target_status.ok() ? r3_utf8_name(target.name) : "null";
    const bool names_ok = from != "null" && to != "null";
    const bool valid_conversion = conversion_status.ok();
    const bool finite_scale = valid_conversion && std::isfinite(conversion.scale);
    const bool zero_offset = valid_conversion && std::isfinite(conversion.offset) && conversion.offset == 0.0;
    const double sample = 1.0 * conversion.scale + conversion.offset;
    const bool sample_ok = finite_scale && conversion.scale > 0.0 && zero_offset &&
        std::isfinite(sample) && sample > 0.0;
    if (context) {
        run.result = (target_status.ok() && to == "null") || (mm_status.ok() && from == "null") ?
            "UNIT_NAME_INVALID" : !valid_conversion ? "UNIT_QUERY_FAILED" :
            names_ok && sample_ok ? "UNITS_OBSERVED" : "UNIT_CONVERSION_INVALID";
    }
    run.terminal = model.facts() + ",\"system_pro_error\":" + system_status.json() +
        ",\"unit_pro_error\":" + target_status.json() + ",\"mm_init_pro_error\":" + mm_status.json() +
        ",\"convert_pro_error\":" + conversion_status.json() +
        ",\"unit_from_name_json\":" + from + ",\"unit_to_name_json\":" + to +
        ",\"direction\":\"mm_to_current_model\",\"scale\":" +
            (valid_conversion ? r3_number(conversion.scale) : "null") +
        ",\"offset\":" + (valid_conversion ? r3_number(conversion.offset) : "null") +
        ",\"scale_finite\":" + (valid_conversion ? r3_bool(finite_scale) : "null") +
        ",\"offset_zero\":" + (valid_conversion ? r3_bool(zero_offset) : "null") +
        ",\"sample_mm\":1.0,\"sample_model_units\":" + (sample_ok ? r3_number(sample) : "null");
}

struct R3BodyArray {
    R3Run& context;
    R3Status& free_status;
    ProSolidBody* data = nullptr;

    R3BodyArray(R3Run& run, R3Status& status) noexcept : context(run), free_status(status) {}
    R3BodyArray(const R3BodyArray&) = delete;
    R3BodyArray& operator=(const R3BodyArray&) = delete;
    ~R3BodyArray() noexcept
    {
        if (!data) return;
        ProArray owned = data;
        try {
            if (!r3_call(context, "ProArrayFree", "body_array", free_status, [&] {
                    return ProArrayFree(&owned);
                })) context.cleanup_failed = true;
        } catch (...) {
            context.cleanup_failed = true;
        }
    }
};

struct R3BodyFaces {
    R3Run& run;
    int index;
    int body_id;
    ProMdl owner;
    bool is_default;
    bool callback_failed = false, callback_exception = false;
    R3Status surface_id_error, visit;
    std::vector<int> ids;

    R3BodyFaces(R3Run& r, int i, const ProSolidBody& body, const ProSolidBody& default_body) :
        run(r), index(i), body_id(body.id), owner(body.owner),
        is_default(body.id == default_body.id && body.owner == default_body.owner) {}
};

ProError r3_visit_surface(ProSurface surface, ProError incoming, ProAppData data) noexcept
{
    auto& body = *static_cast<R3BodyFaces*>(data);
    if (incoming != PRO_TK_NO_ERROR) {
        body.callback_failed = true;
        return incoming;
    }
    try {
        int id = -1;
        R3Status status;
        if (!r3_call(body.run, "ProSurfaceIdGet", "surface_visit", status, [&] {
                return ProSurfaceIdGet(surface, &id);
            })) {
            body.callback_failed = true;
            body.surface_id_error = status;
            return status.code;
        }
        body.ids.push_back(id);
        return PRO_TK_NO_ERROR;
    } catch (...) {
        body.callback_failed = true;
        body.callback_exception = true;
        return PRO_TK_GENERAL_ERROR;
    }
}

void r3_log_body(const R3BodyFaces& body, ProMdl model)
{
    char owner[32] = {};
    std::snprintf(owner, sizeof(owner), "0x%" PRIxPTR, reinterpret_cast<uintptr_t>(body.owner));
    const bool complete = body.visit.ok() && !body.callback_failed;
    const std::string prefix = ",\"body_index\":" + std::to_string(body.index) +
        ",\"body_id\":" + std::to_string(body.body_id);
    const std::string summary = prefix + ",\"owner\":\"" + owner + "\",\"owner_matches_model\":" +
        r3_bool(body.owner == model) + ",\"is_default\":" + r3_bool(body.is_default) +
        ",\"surface_count\":" + (complete ? std::to_string(body.ids.size()) : "null") +
        ",\"observed_surface_count\":" + std::to_string(body.ids.size()) +
        ",\"visit_pro_error\":" + body.visit.json() +
        ",\"surface_id_error\":" + body.surface_id_error.json() +
        ",\"callback_exception\":" + r3_bool(body.callback_exception) +
        ",\"surface_ids_complete\":" + r3_bool(complete);
    r3_trace(body.run, "R3_PROBE_BODY_VISIT", summary.c_str());
    // A large model may exceed the JSONL line capacity. Keep all IDs in bounded chunks.
    const size_t per_line = 32;
    for (size_t begin = 0; begin < body.ids.size();) {
        size_t end = begin;
        std::string ids = "[";
        for (; end < body.ids.size() && end - begin < per_line; ++end) {
            if (end != begin) ids += ',';
            ids += std::to_string(body.ids[end]);
        }
        const std::string chunk = prefix + ",\"first_surface_index\":" + std::to_string(begin) +
            ",\"surface_ids_json\":" + ids + "]";
        r3_trace(body.run, "R3_PROBE_BODY_SURFACE_IDS", chunk.c_str());
        begin = end;
    }
}

bool r3_pick_face(R3Run& run, ProMdl model, bool expected_default, int& face_id)
{
    const char* role = expected_default ? "default_body" : "other_body";
    ProFileName file = L"p1_r3_readonly.txt";
    ProCharLine prompt = {};
    r3_message_key(prompt, expected_default ? "P1_R3_BODIES_PICK_DEFAULT" : "P1_R3_BODIES_PICK_OTHER");
    R3Status display, selection, item_status, surface_status, surface_type;
    if (!r3_call(run, "ProMessageDisplay", role, display, [&] { return ProMessageDisplay(file, prompt); })) {
        run.result = "PROMPT_FAILED"; return false;
    }
    char filter[] = "surface";
    ProSelection* borrowed = nullptr;
    int count = 0;
    if (!r3_call(run, "ProSelect", role, selection, [&] {
            return ProSelect(filter, 1, nullptr, nullptr, nullptr, nullptr, &borrowed, &count);
        })) {
        run.result = selection.code == PRO_TK_USER_ABORT ? "CANCELLED" : "SELECTION_FAILED";
        return false;
    }
    ProModelitem selected = {};
    // The SDK's selection array is borrowed. Read the item before issuing another SDK query.
    if (count != 1 || !borrowed || !borrowed[0] ||
        !r3_call(run, "ProSelectionModelitemGet", role, item_status, [&] {
            return ProSelectionModelitemGet(borrowed[0], &selected);
        }) || selected.type != PRO_SURFACE || selected.owner != model) {
        run.result = "SELECTED_FACE_INVALID"; return false;
    }
    ProSurface surface = nullptr;
    ProSrftype type = PRO_SRF_NONE;
    if (!r3_call(run, "ProSurfaceInit", role, surface_status, [&] {
            return ProSurfaceInit(model, selected.id, &surface);
        }) || !surface || !r3_call(run, "ProSurfaceTypeGet", role, surface_type, [&] {
            return ProSurfaceTypeGet(surface, &type);
        })) {
        run.result = "SURFACE_QUERY_FAILED"; return false;
    }
    if (type != PRO_SRF_PLANE) { run.result = "SELECTED_FACE_NOT_PLANE"; return false; }
    face_id = selected.id;
    const std::string facts = std::string(",\"role\":\"") + role +
        "\",\"selected_face_id\":" + std::to_string(face_id) +
        ",\"surface_type\":" + std::to_string(static_cast<int>(type));
    r3_trace(run, "R3_PROBE_FACE_SELECTED", facts.c_str());
    return true;
}

bool r3_compare_face(R3Run& run, const std::vector<R3BodyFaces>& bodies, int face_id, bool expected_default)
{
    size_t matches = 0;
    int matched_body = -1;
    bool on_default = false;
    for (const auto& body : bodies) {
        for (int id : body.ids) {
            if (id != face_id) continue;
            ++matches;
            matched_body = body.index;
            on_default = body.is_default;
        }
    }
    const bool expected = matches == 1 && on_default == expected_default;
    const std::string facts =
        ",\"expected_default\":" + std::string(r3_bool(expected_default)) +
        ",\"selected_face_id\":" + std::to_string(face_id) +
        ",\"matched_body_index\":" + (matches == 1 ? std::to_string(matched_body) : "null") +
        ",\"match_count\":" + std::to_string(matches) +
        ",\"belongs_to_default\":" + (matches == 1 ? r3_bool(on_default) : "null") +
        ",\"result\":\"" + (expected ? "FACE_MEMBERSHIP_CONFIRMED" : "FACE_BODY_MISMATCH") + "\"";
    r3_trace(run, "R3_PROBE_BODY_MATCH", facts.c_str());
    return expected;
}

void r3_probe_bodies(R3Run& run)
{
    R3Model model;
    R3Status default_status, collect, size, release, current_again, default_again;
    ProSolidBody default_body = {};
    int body_count = -1, defaults_matched = 0, first = -1, second = -1;
    bool visits_ok = true, picked_first = false, picked_second = false, paired = false;
    std::vector<R3BodyFaces> bodies;
    auto observe = [&] {
        if (!model.read(run)) return;
        const ProSolid solid = reinterpret_cast<ProSolid>(model.handle);
        if (!r3_call(run, "ProSolidDefaultBodyGet", "default_body", default_status, [&] {
                return ProSolidDefaultBodyGet(solid, &default_body);
            }) || default_body.owner != model.handle) {
            run.result = "DEFAULT_BODY_UNAVAILABLE"; return;
        }
        {
            R3BodyArray array(run, release);
            if (!r3_call(run, "ProSolidBodiesCollect", "body_array", collect, [&] {
                    return ProSolidBodiesCollect(solid, &array.data);
                }) || !array.data || !r3_call(run, "ProArraySizeGet", "body_array", size, [&] {
                    return ProArraySizeGet(array.data, &body_count);
                }) || body_count < 0) {
                run.result = "BODY_ARRAY_UNAVAILABLE"; return;
            }
            for (int i = 0; i < body_count; ++i) {
                bodies.emplace_back(run, i, array.data[i], default_body);
                auto& body = bodies.back();
                if (body.is_default) ++defaults_matched;
                r3_call(run, "ProSolidBodySurfaceVisit", "body_visit", body.visit, [&] {
                    return ProSolidBodySurfaceVisit(&array.data[i], &r3_visit_surface, &body);
                });
                visits_ok = visits_ok && body.visit.ok() && !body.callback_failed &&
                    body.owner == model.handle;
                r3_log_body(body, model.handle);
            }
        }
        if (run.cleanup_failed) { run.result = "CLEANUP_FAILED"; return; }
        if (body_count < 2) { run.result = "MULTIBODY_FIXTURE_REQUIRED"; return; }
        if (!visits_ok || defaults_matched != 1) { run.result = "FACE_BODY_MISMATCH"; return; }
        picked_first = r3_pick_face(run, model.handle, true, first);
        if (!picked_first) return;
        picked_second = r3_pick_face(run, model.handle, false, second);
        if (!picked_second) return;

        ProMdl current = nullptr;
        ProSolidBody body = {};
        if (!r3_call(run, "ProMdlCurrentGet", "revalidate", current_again, [&] {
                return ProMdlCurrentGet(&current);
            }) || current != model.handle ||
            !r3_call(run, "ProSolidDefaultBodyGet", "revalidate", default_again, [&] {
                return ProSolidDefaultBodyGet(solid, &body);
            }) || body.owner != default_body.owner || body.id != default_body.id) {
            run.result = "STALE_CONTEXT"; return;
        }
        const bool first_matches = r3_compare_face(run, bodies, first, true);
        const bool second_matches = r3_compare_face(run, bodies, second, false);
        paired = first_matches && second_matches;
        run.result = paired ? "FACE_MEMBERSHIP_CONFIRMED" : "FACE_BODY_MISMATCH";
    };
    observe();
    char default_owner[32] = {};
    std::snprintf(default_owner, sizeof(default_owner), "\"0x%" PRIxPTR "\"",
        reinterpret_cast<uintptr_t>(default_body.owner));
    run.terminal = model.facts() + ",\"default_body_id\":" +
        (default_status.ok() ? std::to_string(default_body.id) : "null") +
        ",\"default_body_owner\":" + (default_status.ok() ? default_owner : "null") +
        ",\"default_body_owner_matches_model\":" +
        (default_status.ok() ? r3_bool(default_body.owner == model.handle) : "null") +
        ",\"body_get_pro_error\":" + default_status.json() +
        ",\"body_count\":" + (size.ok() && body_count >= 0 ? std::to_string(body_count) : "null") +
        ",\"collect_pro_error\":" + collect.json() + ",\"size_pro_error\":" + size.json() +
        ",\"array_free_pro_error\":" + release.json() + ",\"free_pro_error\":" + release.json() +
        ",\"default_face_id\":" + (picked_first ? std::to_string(first) : "null") +
        ",\"other_face_id\":" + (picked_second ? std::to_string(second) : "null") +
        ",\"revalidated_current_pro_error\":" + current_again.json() +
        ",\"revalidated_body_pro_error\":" + default_again.json() +
        ",\"membership_pair_confirmed\":" + r3_bool(paired);
}

AccessTrace r3_accesses[] = {
    {"p1_r3_probe_msg", "p1_r3_probe_msg", 0, {}, {}},
    {"p1_r3_probe_units", "p1_r3_probe_units", 0, {}, {}},
    {"p1_r3_probe_bodies", "p1_r3_probe_bodies", 0, {}, {}}
};

template<size_t Index>
uiCmdAccessState r3_access(uiCmdAccessMode mode)
{
    record_access_observation(r3_accesses[Index], mode, ACCESS_AVAILABLE);
    return ACCESS_AVAILABLE;
}

template<size_t Index, void (*Probe)(R3Run&)>
int r3_action(uiCmdCmdId, uiCmdValue*, void*) noexcept
{
    PreserveLastError preserve;
    R3Run run{r3_definitions[Index]};
    r3_trace(run, run.definition.begin, "");
    if (InterlockedCompareExchange(&r3_busy, 1, 0) != 0) {
        run.result = "COMMAND_BUSY";
    } else {
        struct BusyReset { ~BusyReset() { InterlockedExchange(&r3_busy, 0); } } reset;
        try {
            Probe(run);
        } catch (...) {
            run.result = "UNEXPECTED_EXCEPTION";
        }
        flush_one_access_trace(r3_accesses[Index], "r3_probe_return");
    }
    char details[model_facts_capacity] = {};
    const int n = std::snprintf(details, sizeof(details),
        ",\"result\":\"%s\",\"model_may_be_modified\":false,\"save_called\":false,\"cleanup_failed\":%s%s",
        run.result, r3_bool(run.cleanup_failed), run.terminal.c_str());
    if (n > 0 && static_cast<size_t>(n) < sizeof(details)) {
        r3_trace(run, run.definition.finish, details);
    } else {
        r3_trace(run, run.definition.finish,
            ",\"result\":\"TRACE_FACTS_TOO_LONG\",\"model_may_be_modified\":false,\"save_called\":false");
    }
    return 0;
}

template<size_t Index, void (*Probe)(R3Run&)>
void r3_register(char* name, char* label, char* help, char* description) noexcept
{
    PreserveLastError preserve;
    R3Run run{r3_definitions[Index]};
    try {
        ProFileName file = L"p1_r3_readonly.txt";
        uiCmdCmdId id = nullptr;
        R3Status add, designate;
        if (!r3_call(run, "ProCmdActionAdd", "registration", add, [&] {
                return ProCmdActionAdd(name, &r3_action<Index, Probe>, uiProeImmediate,
                    &r3_access<Index>, PRO_B_TRUE, PRO_B_TRUE, &id);
            }) || !id) {
            r3_trace(run, "R3_PROBE_REGISTRATION_FAILED", ",\"phase\":\"add_or_identity\"");
            return;
        }
        trace_registration_identity(name, id, name, label, help, description, file);
        if (!r3_call(run, "ProCmdDesignate", "registration", designate, [&] {
                return ProCmdDesignate(id, label, help, description, file);
            })) {
            r3_trace(run, "R3_PROBE_REGISTRATION_FAILED", ",\"phase\":\"designate\"");
        }
    } catch (...) {
        r3_trace(run, "R3_PROBE_REGISTRATION_FAILED", ",\"phase\":\"exception\"");
    }
}

void register_r3_readonly_probes() noexcept
{
    static char message[] = "p1_r3_probe_msg";
    static char message_label[] = "P1_R3_MSG_LABEL", message_help[] = "P1_R3_MSG_HELP";
    static char message_desc[] = "P1_R3_MSG_DESC";
    static char units[] = "p1_r3_probe_units";
    static char units_label[] = "P1_R3_UNITS_LABEL", units_help[] = "P1_R3_UNITS_HELP";
    static char units_desc[] = "P1_R3_UNITS_DESC";
    static char bodies[] = "p1_r3_probe_bodies";
    static char bodies_label[] = "P1_R3_BODIES_LABEL", bodies_help[] = "P1_R3_BODIES_HELP";
    static char bodies_desc[] = "P1_R3_BODIES_DESC";
    r3_register<0, r3_probe_message>(message, message_label, message_help, message_desc);
    r3_register<1, r3_probe_units>(units, units_label, units_help, units_desc);
    r3_register<2, r3_probe_bodies>(bodies, bodies_label, bodies_help, bodies_desc);
}

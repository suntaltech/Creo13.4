import com.ptc.pfc.pfcArgument.ArgValue;
import com.ptc.pfc.pfcArgument.pfcArgument;
import com.ptc.pfc.pfcCommand.DefaultUICommandActionListener;
import com.ptc.pfc.pfcCommand.UICommand;
import com.ptc.pfc.pfcFeature.FeatureType;
import com.ptc.pfc.pfcGeometry.Surface;
import com.ptc.pfc.pfcGeometry.SurfaceType;
import com.ptc.pfc.pfcGeometry.Surfaces;
import com.ptc.pfc.pfcModel.Model;
import com.ptc.pfc.pfcModel.ModelType;
import com.ptc.pfc.pfcSelect.Selection;
import com.ptc.pfc.pfcSelect.pfcSelect;
import com.ptc.pfc.pfcSession.CreoCompatibility;
import com.ptc.pfc.pfcSession.Session;
import com.ptc.pfc.pfcSession.pfcSession;
import com.ptc.pfc.pfcSolid.SolidBody;
import com.ptc.pfc.pfcWindow.Window;
import com.ptc.pfc.pfcWindow.Windows;
import com.ptc.wfc.wfcElemIds.wfcElemIds;
import com.ptc.wfc.wfcElementTree.Element;
import com.ptc.wfc.wfcElementTree.ElementTree;
import com.ptc.wfc.wfcElementTree.Elements;
import com.ptc.wfc.wfcFeature.WFeature;
import com.ptc.wfc.wfcFeatureInstructions.FeatCreateOption;
import com.ptc.wfc.wfcFeatureInstructions.FeatCreateOptions;
import com.ptc.wfc.wfcSession.WSession;
import com.ptc.wfc.wfcSolid.WSolid;
import com.ptc.wfc.wfcSolidInstructions.WRegenInstructions;
import com.ptc.wfc.wfcSolidInstructions.wfcSolidInstructions;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Creo 13 同步 J-Link 入口：注册原生命令、打开内嵌页面，并以独立原生命令执行6A驱动面转换；网页继续只读。
 * 不创建 AsyncConnection，不请求 CREOSON，不在命令回调中等待网络或启动子进程。
 * 必须使用本机 Creo 13 的同步 SDK archive 编译，不混入 pfcasync.jar。
 */
public final class BatchRename {
    private static final String MESSAGES = "batchrename.txt";
    private static final String RENAME_COMMAND = "SISWBatchRename";
    private static final String RENAME_PAGE = "http://localhost:9056/rename.html";
    private static final String RENAME_ICON = "batchrename.png";
    private static final String SMT_COMMAND = "SISWSheetMetal";
    private static final String SMT_CONVERT_COMMAND = "SISWSheetMetalConvert";
    private static final double MIN_THICKNESS = 0.1;
    private static final double MAX_THICKNESS = 20.0;
    private static final String SMT_PAGE = "http://localhost:9056/sheetmetal.html";
    private static final String SMT_ICON = "sheetmetal.png";
    private static final String ABOUT_COMMAND = "SISWAbout";
    private static final String ABOUT_PAGE = "http://localhost:9056/about.html";
    private static final String ABOUT_ICON = "about.png";
    // WFC AddBrowserMessageListener 在当前 Creo 13.4 同步会话中会长期占用 CIP 原生通道；
    // 先关闭原生浏览器监听，钣金页面通过 CREOSON HTTP 与后续可用的原生路径处理，避免阻塞 Ribbon 命令回调。
    private static final boolean SHEETMETAL_BRIDGE_ENABLED = false;

    private static Session session;
    private static WSession wfcSession;
    private static final java.util.List<UICommand> commands = new java.util.ArrayList<>();
    private static final java.util.List<DefaultUICommandActionListener> listeners = new java.util.ArrayList<>();
    private static boolean active;
    private static boolean opening;
    private static boolean converting;
    private static Thread creosonStarter;

    private BatchRename() { }

    /** 同步注册入口必须是 public static void 且无参数。 */
    public static void start() throws Exception {
        if (active) {
            log("start ignored: already active", null);
            return;
        }
        if (!listeners.isEmpty()) {
            throw new IllegalStateException("Previous listener detach failed; restart Creo before reloading");
        }
        log("start entered; java=" + System.getProperty("java.version"), null);
        try {
            // 显式设置兼容性，避免先用 GetProESession() 进入旧的 C3 兼容模式。
            session = pfcSession.GetCurrentSessionWithCompatibility(CreoCompatibility.C4Compatible);
            if (session == null) {
                throw new IllegalStateException("No synchronous Creo session");
            }
            log("synchronous session acquired", null);
            ensureCreosonRunningAsync();

            registerPageCommand(RENAME_COMMAND, new OpenPageListener(RENAME_COMMAND, RENAME_PAGE),
                    "SISW_BR_LABEL", "SISW_BR_HELP", "SISW_BR_DESC", RENAME_ICON);
            registerPageCommand(SMT_COMMAND, new OpenPageListener(SMT_COMMAND, SMT_PAGE),
                    "SISW_SMT_LABEL", "SISW_SMT_HELP", "SISW_SMT_DESC", SMT_ICON);
            registerPageCommand(ABOUT_COMMAND, new OpenPageListener(ABOUT_COMMAND, ABOUT_PAGE),
                    "SISW_ABOUT_LABEL", "SISW_ABOUT_HELP", "SISW_ABOUT_DESC", ABOUT_ICON);
            log("three native page commands registered", null);

            registerConversionCommand();
            ensureSheetmetalBridgeAsync();

            active = true;
            log("command designated", null);
            log("start returned", null);
            // 功能区位置由首次自定义导出的 .rbn 或用户现有 Ribbon 配置负责。
        } catch (Exception ex) {
            log("start failed", ex);
            detach();
            throw ex; // 让辅助应用程序显示真正的加载错误，而不是伪报启动成功。
        } catch (LinkageError ex) {
            log("JAR/class version or linkage error", ex);
            detach();
            throw ex;
        }
    }

    /** 停止时只解除回调，不退出 Creo，不关闭浏览器，不修改模型。 */
    public static void stop() {
        log("stop entered", null);
        active = false;
        detach();
        log("stop returned", null);
    }

    /** 仅将既有服务探测/拉起放到后台；不在后台执行任何Creo API。 */
    private static synchronized void ensureCreosonRunningAsync() {
        if (creosonStarter != null && creosonStarter.isAlive()) return;
        creosonStarter = new Thread(() -> {
            try {
                try (java.net.Socket socket = new java.net.Socket()) {
                    socket.connect(new java.net.InetSocketAddress("localhost", 9056), 500);
                    log("port 9056 listening; service identity must be checked by frontend", null);
                    return;
                } catch (Exception notListening) { /* 单次探测，不等待端口。 */ }
                String configured = System.getenv("CREO_BR_SERVER_DIR");
                // 保留输入基线的服务默认目录；转换逻辑本身没有安装目录/模型路径依赖。
                if (configured == null || configured.isBlank()) configured = "D:\\creoson\\CreosonServerWithSetup-2.8.2-win64";
                ProcessBuilder process = new ProcessBuilder("cmd.exe", "/c", "creoson_run.bat");
                process.directory(new java.io.File(configured));
                process.inheritIO(); // 保留输入基线的stdin继承行为；Windows启动仍待本机验证。
                process.redirectOutput(ProcessBuilder.Redirect.DISCARD);
                process.redirectError(ProcessBuilder.Redirect.DISCARD);
                process.start();
                log("CREOSON launch requested asynchronously; readiness not confirmed", null);
            } catch (Throwable error) {
                log("EXCEPTION: CREOSON_LAUNCH_FAILED", error);
            }
        }, "creoson-service-start");
        creosonStarter.setDaemon(true);
        creosonStarter.start();
    }

    /** 内部 WFC 会话适配器为包私有；反射复用同一原生指针构造公开 WSession 接口对象。 */
    private static WSession createWfcSession(Session plainSession) throws Exception {
        Class<?> adapterClass = Class.forName("com.ptc.wfc.Implementation.wfcSession$WSession");
        java.lang.reflect.Constructor<?> constructor = adapterClass.getDeclaredConstructor(long.class);
        constructor.setAccessible(true);
        Object adapter = constructor.newInstance(plainSession.getptr());
        return (WSession) adapter;
    }

    /** 本轮永不注册浏览器监听，也不清除供原生命令使用的WFC会话包装。 */
    private static void ensureSheetmetalBridgeAsync() {
        log("sheetmetal browser bridge disabled; 6A uses only SISWSheetMetalConvert native command", null);
    }

    private static UICommand registerPageCommand(String commandId, OpenPageListener pageListener,
                                                  String labelKey, String helpKey, String descriptionKey,
                                                  String iconName) throws Exception {
        UICommand pageCommand = session.UICreateCommand(commandId, pageListener);
        pageCommand.Designate(MESSAGES, labelKey, helpKey, descriptionKey);
        try {
            pageCommand.SetIcon(iconName);
            log("icon registered: " + commandId + " -> " + iconName, null);
        } catch (Exception | LinkageError iconError) {
            log("icon registration failed for " + commandId + "; command remains available with default icon", iconError);
        }
        commands.add(pageCommand);
        listeners.add(pageListener);
        return pageCommand;
    }

    private static void detach() {
        active = false;
        for (int i = 0; i < commands.size(); i++) {
            try {
                commands.get(i).RemoveActionListener(listeners.get(i));
            } catch (Throwable ex) {
                log("EXCEPTION: LISTENER_DETACH_FAILED; command index=" + i + "; restart Creo before reloading", ex);
            }
        }
        commands.clear();
        listeners.clear();
        session = null;
        wfcSession = null;
    }

    /** 原生回调只发出本模块浏览器导航，随后立即把控制权交回 Creo。 */
    private static final class OpenPageListener extends DefaultUICommandActionListener {
        private final String commandId;
        private final String pageUrl;

        private OpenPageListener(String commandId, String pageUrl) {
            this.commandId = commandId;
            this.pageUrl = pageUrl;
        }

        @Override
        public void OnCommand() {
            if (!active) {
                log("OnCommand ignored: plugin inactive; target=" + pageUrl, null);
                return;
            }
            if (opening) {
                log("OnCommand ignored: previous navigation still running; target=" + pageUrl, null);
                return;
            }
            if (session == null) {
                log("OnCommand ignored: J-Link session null; target=" + pageUrl, null);
                return;
            }
            opening = true;
            String targetUrl = guardedPageUrl(commandId, pageUrl);
            log("OnCommand entered; command=" + commandId + "; target=" + targetUrl, null);
            try {
                Window window = null;
                try {
                    window = session.GetCurrentWindow();
                } catch (Throwable currentWindowError) {
                    log("GetCurrentWindow failed; trying window list", currentWindowError);
                }
                if (window == null) {
                    try {
                        Windows windows = session.ListWindows();
                        if (windows != null && windows.getarraysize() > 0) {
                            window = windows.get(0);
                            log("using first listed Creo window after current window was null", null);
                        }
                    } catch (Throwable listWindowsError) {
                        log("ListWindows fallback failed", listWindowsError);
                    }
                }
                if (window == null) {
                    log("No available Creo window; cannot open " + pageUrl, null);
                    return;
                }
                String currentUrl = null;
                try {
                    currentUrl = window.GetURL();
                } catch (Exception urlError) {
                    log("current window URL unavailable", urlError);
                }
                if (currentUrl == null || !currentUrl.equals(targetUrl)) {
                    window.SetURL(targetUrl);
                    log("browser navigation issued; target=" + targetUrl, null);
                } else {
                    log("browser tab already open; reusing existing tab", null);
                }
                window.SetBrowserSize(80.0);
                window.Activate();
                window.Refresh();
                log("browser activated; currentUrl=" + currentUrl + "; OnCommand returned", null);
            } catch (Exception ex) {
                log("open embedded browser failed", ex);
            } finally {
                opening = false;
            }
        }
    }

    private static String detectActiveModelMode() {
        if (session == null) {
            return "no_session";
        }
        Model model;
        try {
            model = session.GetActiveModel();
        } catch (Throwable detectionError) {
            log("active model detection failed", detectionError);
            return "unknown";
        }
        if (model == null) {
            return "no_model";
        }
        ModelType type;
        try {
            type = model.GetType();
        } catch (Throwable typeError) {
            log("active model type detection failed", typeError);
            return "unknown";
        }
        if (type == ModelType.MDL_ASSEMBLY) {
            return "assembly";
        }
        if (type == ModelType.MDL_DRAWING) {
            return "drawing";
        }
        if (type == ModelType.MDL_PART) {
            try {
                WSolid solid = wrapAsWSolid(model);
                SolidBody body = solid.GetDefaultBody();
                if (body == null) return "unknown";
                if (body.IsSheetmetal()) {
                    return "sheetmetal";
                }
            } catch (Throwable sheetmetalCheckIgnored) {
                log("EXCEPTION: MODE_DETECTION_FAILED; returning unknown", sheetmetalCheckIgnored);
                return "unknown";
            }
            return "solid_part";
        }
        return "other";
    }

    private static String guardedPageUrl(String commandId, String baseUrl) {
        if (ABOUT_COMMAND.equals(commandId)) return baseUrl; // S1不需要读取模型或包装WFC对象。
        String mode = detectActiveModelMode();
        if (RENAME_COMMAND.equals(commandId) && !"assembly".equals(mode)) {
            return appendPageQuery(baseUrl, "guard", "need_assembly", "modelMode", mode);
        }
        if (SMT_COMMAND.equals(commandId)) {
            if ("sheetmetal".equals(mode)) {
                return appendPageQuery(baseUrl, "state", "sheetmetal", "modelMode", mode);
            }
            if (!"solid_part".equals(mode)) {
                return appendPageQuery(baseUrl, "guard", "need_part", "modelMode", mode);
            }
            return appendPageQuery(baseUrl, "modelMode", mode);
        }
        return baseUrl;
    }

    private static String appendPageQuery(String baseUrl, String... pairs) {
        try {
            URL source = new URL(baseUrl);
            StringBuilder query = new StringBuilder(source.getQuery() == null ? "" : source.getQuery());
            for (int i = 0; i + 1 < pairs.length; i += 2) {
                if (query.length() > 0) {
                    query.append('&');
                }
                query.append(URLEncoder.encode(pairs[i], StandardCharsets.UTF_8));
                query.append('=');
                query.append(URLEncoder.encode(pairs[i + 1], StandardCharsets.UTF_8));
            }
            String result = source.getProtocol() + "://" + source.getHost()
                    + (source.getPort() == -1 ? "" : ":" + source.getPort()) + source.getPath();
            if (query.length() > 0) {
                result += "?" + query;
            }
            return result;
        } catch (Exception queryError) {
            log("guard query assembly failed; using base page url", queryError);
            return baseUrl;
        }
    }

    private static final class ConversionFailure extends Exception {
        final String code;
        ConversionFailure(String code, String message) { super(message); this.code = code; }
        ConversionFailure(String code, String message, Throwable cause) { super(message, cause); this.code = code; }
    }

    /** Only installed as a native UICommand listener; never submitted to a background executor. */
    private static final class SmtConvertListener extends DefaultUICommandActionListener {
        private boolean enabled;

        @Override
        public void OnCommand() {
            if (session == null) {
                log("EXCEPTION: NO_SESSION; plugin session unavailable; no native API called", null);
                showConversionMessage("NO_SESSION：插件会话未初始化，请重启 Creo。");
                return;
            }
            if (!enabled || !active) {
                log("6A command ignored: inactive or registration incomplete", null);
                return;
            }
            if (converting || opening) {
                showConversionMessage("BUSY：已有命令正在处理，请稍后重试。");
                return;
            }
            converting = true;
            long started = System.nanoTime();
            Map<String,Object> trace = new LinkedHashMap<>();
            trace.put("requestId", java.util.UUID.randomUUID().toString());
            trace.put("mode", "driving");
            trace.put("saved", false);
            trace.put("thread", Thread.currentThread().getName());
            nativeAudit(trace, "command", "started");
            try {
                Map<String,Object> result = convertPreselectedPlane(trace);
                trace.put("elapsedMs", (System.nanoTime() - started) / 1_000_000L);
                if (result == null) {
                    nativeAudit(trace, "command", "cancelled");
                    showConversionMessage("已取消板厚输入，未创建特征，未执行 Save。");
                    return;
                }
                nativeAudit(trace, "command", "succeeded");
                showConversionMessage("6A driving 完成：" + result.get("model")
                        + "\n板厚：" + result.get("thickness") + "（模型长度单位；6A前提为mm模型）"
                        + "\n特征 ID：" + result.get("featureId") + "；名称：" + result.get("featureName")
                        + "\nIsSheetmetal=true；未执行 Save。");
            } catch (Throwable error) {
                String code = error instanceof ConversionFailure ? ((ConversionFailure) error).code : "UNEXPECTED_ERROR";
                String message = error instanceof ConversionFailure ? error.getMessage() : "原生命令发生异常，请查看 jlink.log";
                trace.put("errorCode", code);
                trace.put("elapsedMs", (System.nanoTime() - started) / 1_000_000L);
                nativeAudit(trace, "command", "failed");
                log("EXCEPTION: " + code + "; requestId=" + trace.get("requestId"), error);
                String inspection = Boolean.TRUE.equals(trace.get("modelMayHaveChanged"))
                        ? "\n创建请求已提交，模型可能已有未保存变化，请检查特征树；不会自动重试或回滚。" : "";
                showConversionMessage(code + "：" + message + inspection + "\n未执行 Save。");
            } finally {
                converting = false;
            }
        }
    }

    /** Optional command: a registration/designation failure never aborts the three existing commands. */
    private static void registerConversionCommand() {
        SmtConvertListener listener = null;
        UICommand command = null;
        try {
            listener = new SmtConvertListener();
            command = session.UICreateCommand(SMT_CONVERT_COMMAND, listener);
            commands.add(command);
            listeners.add(listener);
            // Reuse existing message keys; no assumptions about batchrename.txt encoding or new keys.
            command.Designate(MESSAGES, "SISW_SMT_LABEL", "SISW_SMT_HELP", "SISW_SMT_DESC");
            try { command.SetIcon(SMT_ICON); }
            catch (Throwable iconError) { log("6A icon unavailable; native command remains registered", iconError); }
            listener.enabled = true;
            log("native conversion command registered: " + SMT_CONVERT_COMMAND + "; browser bridge remains disabled", null);
        } catch (Throwable registrationError) {
            if (listener != null) listener.enabled = false;
            log("EXCEPTION: CONVERT_COMMAND_REGISTER_FAILED; three existing page commands remain available", registrationError);
            // Keep any created object tracked for detach(); disabled listener cannot modify a model.
            if (command != null && listener != null) {
                try { command.RemoveActionListener(listener); }
                catch (Throwable detachError) { log("6A partial registration detach failed; disabled listener retained until stop", detachError); }
            }
        }
    }

    private static long nativePointer(Object object) throws Throwable {
        if (object == null) throw new IllegalArgumentException("Null native object");
        Object value = object.getClass().getMethod("getptr").invoke(object);
        if (!(value instanceof Number) || ((Number) value).longValue() == 0L) {
            throw new IllegalStateException("Native object pointer unavailable");
        }
        return ((Number) value).longValue();
    }

    /** Type guard first; otherwise use only the two adapter constructors supplied in javap-key. */
    private static WSolid wrapAsWSolid(Model model) throws ConversionFailure {
        if (model instanceof WSolid existing) return existing;
        String className = model == null ? "null" : model.getClass().getName();
        String modelType = "unknown";
        try { if (model != null) modelType = String.valueOf(model.GetType()); }
        catch (Throwable typeError) { log("EXCEPTION: WRAP_MODEL_TYPE_READ_FAILED; class=" + className, typeError); }
        IllegalStateException chain = new IllegalStateException("WFC adaptation failed; class=" + className + "; type=" + modelType);
        final long pointer;
        try { pointer = nativePointer(model); }
        catch (Throwable pointerError) {
            log("EXCEPTION: WRAP_POINTER_FAILED; source=" + className + "; type=" + modelType, pointerError);
            throw new ConversionFailure("WRAP_SOLID_FAILED", "无法取得当前零件的原生对象指针", pointerError);
        }
        for (String adapterName : new String[] {
                "com.ptc.wfc.Implementation.wfcPart$WPart",
                "com.ptc.wfc.Implementation.wfcSolid$WSolid" }) {
            try {
                java.lang.reflect.Constructor<?> constructor = Class.forName(adapterName).getDeclaredConstructor(long.class);
                constructor.setAccessible(true);
                Object wrapper = constructor.newInstance(pointer);
                if (!(wrapper instanceof WSolid solid)) throw new IllegalStateException("Adapter does not implement WSolid");
                log("WFC solid view acquired; source=" + className + "; type=" + modelType + "; adapter=" + adapterName, null);
                return solid;
            } catch (Throwable adapterError) {
                chain.addSuppressed(adapterError);
                log("EXCEPTION: WFC_ADAPTER_ATTEMPT_FAILED; source=" + className + "; type=" + modelType + "; adapter=" + adapterName, adapterError);
            }
        }
        throw new ConversionFailure("WRAP_SOLID_FAILED", "无法将当前零件适配为WFC实体，详见日志中的适配器异常链", chain);
    }

    /** Reuse the baseline WSession adapter; never register a browser listener. */
    private static void ensureWfcSession() throws ConversionFailure {
        if (wfcSession != null) return;
        if (session == null) throw new ConversionFailure("NO_SESSION", "插件会话未初始化，请重启 Creo");
        try {
            if (session instanceof WSession existing) wfcSession = existing;
            else wfcSession = createWfcSession(session);
            if (wfcSession == null) throw new IllegalStateException("Null WSession wrapper");
        } catch (Throwable sessionError) {
            wfcSession = null;
            throw new ConversionFailure("WRAP_SESSION_FAILED", "WFC会话包装失败，未创建特征", sessionError);
        }
    }

    private static boolean sameModel(Model left, Model right) throws Throwable {
        return left != null && right != null && (left == right || nativePointer(left) == nativePointer(right));
    }

    private static void verifyFaceInDefaultBody(SolidBody body, Surface face) throws Throwable {
        if (!face.GetIsVisible()) throw new ConversionFailure("SELECTED_FACE_INVALID", "预选曲面当前不可见，请重新选择");
        Surfaces surfaces = body.ListSurfaces();
        if (surfaces != null) {
            for (int i = 0; i < surfaces.getarraysize(); i++) {
                if (surfaces.get(i).GetId() == face.GetId()) return;
            }
        }
        throw new ConversionFailure("SELECTED_FACE_OTHER_BODY", "预选面不属于当前默认实体体，6A不处理其他实体体");
    }

    /** Sole feature-writing call chain, reached synchronously only from SmtConvertListener.OnCommand. */
    private static Map<String,Object> convertPreselectedPlane(Map<String,Object> trace) throws Throwable {
        String phase = "READ_MODEL_FAILED";
        Session owner = session;
        try {
            if (owner == null) throw new ConversionFailure("NO_SESSION", "插件会话未初始化，请重启 Creo");
            Model model = owner.GetActiveModel();
            if (model == null) throw new ConversionFailure("NO_MODEL", "请先打开普通零件");
            if (model.GetType() != ModelType.MDL_PART) {
                throw new ConversionFailure("NOT_PART", "当前只支持普通零件 .prt；装配、工程图及其他类型不能执行6A");
            }
            String modelName = model.GetFileName();
            if (modelName == null || !modelName.toLowerCase(java.util.Locale.ROOT).endsWith(".prt")) {
                throw new ConversionFailure("NOT_PART", "当前模型文件不是 .prt 普通零件");
            }
            trace.put("model", modelName);
            phase = "WRAP_SOLID_FAILED";
            WSolid solid = wrapAsWSolid(model);
            phase = "READ_BODY_FAILED";
            SolidBody body = solid.GetDefaultBody();
            if (body == null) throw new ConversionFailure("NO_BODY", "未找到默认实体体");
            if (body.IsSheetmetal()) throw new ConversionFailure("ALREADY_SHEETMETAL", "当前已是钣金，无需重复转换");

            phase = "SELECTED_FACE_INVALID";
            com.ptc.pfc.pfcSelect.SelectionBuffer buffer = owner.GetCurrentSelectionBuffer();
            com.ptc.pfc.pfcSelect.Selections selected = buffer == null ? null : buffer.GetContents();
            int count = selected == null ? 0 : selected.getarraysize();
            if (count == 0) throw new ConversionFailure("NO_SELECTED_FACE", "请先在图形区选择1个平面作为驱动面");
            if (count != 1) throw new ConversionFailure("TOO_MANY_FACES", "请只选择1个驱动平面，不要混选其他对象");
            Selection selection = selected.get(0);
            if (selection == null) throw new ConversionFailure("SELECTED_FACE_INVALID", "预选对象为空，请重新选择");
            if (!(selection.GetSelItem() instanceof Surface face)) {
                throw new ConversionFailure("SELECTED_FACE_INVALID", "请选择曲面，不要选择基准面、边、点或坐标系");
            }
            if (face.GetSurfaceType() != SurfaceType.SURFACE_PLANE) {
                throw new ConversionFailure("SELECTED_NOT_PLANE", "6A暂只支持预选平面，请重新选择平面");
            }
            if (!sameModel(model, selection.GetSelModel())) {
                throw new ConversionFailure("SELECTED_FACE_OTHER_MODEL", "预选面不属于当前激活零件，请重新选择");
            }
            verifyFaceInDefaultBody(body, face);
            double area = face.EvalArea();
            if (!Double.isFinite(area) || area <= 0.0) throw new ConversionFailure("SELECTED_FACE_INVALID", "预选平面面积无效");
            trace.put("selectedFaceId", face.GetId());
            trace.put("selectedFaceType", String.valueOf(face.GetSurfaceType()));
            trace.put("selectedFaceArea", area);
            nativeAudit(trace, "selection", "validated");

            phase = "THICKNESS_INPUT_FAILED";
            if (!showConversionMessage("6A真机验证：仅对已人工确认长度单位为mm的普通零件执行。"
                    + "\n接下来请输入0.1–20的板厚，使用预选平面；本命令不保存模型。")) {
                throw new ConversionFailure("UI_PROMPT_FAILED", "无法显示输入提示，未创建特征");
            }
            // javap只有参数类型；此处按任务范围传下/上限，输入界面语义待本机确认。
            Double entered = owner.UIReadRealMessage(MIN_THICKNESS, MAX_THICKNESS);
            if (entered == null) return null;
            if (!Double.isFinite(entered) || entered < MIN_THICKNESS || entered > MAX_THICKNESS) {
                throw new ConversionFailure("INVALID_THICKNESS", "板厚必须为0.1–20的有限正数，不能使用包围尺寸兜底");
            }
            double thickness = entered;
            trace.put("thickness", thickness);
            trace.put("thicknessUnit", "model_length_unit; 6A prerequisite: mm");
            phase = "MODEL_RECHECK_FAILED";
            if (!active || owner != session || !sameModel(model, owner.GetActiveModel())) {
                throw new ConversionFailure("MODEL_CHANGED", "输入期间激活模型或插件状态已变化，未创建特征");
            }
            phase = "READ_BODY_FAILED";
            body = solid.GetDefaultBody();
            if (body == null) throw new ConversionFailure("NO_BODY", "输入后未找到默认实体体");
            if (body.IsSheetmetal()) throw new ConversionFailure("ALREADY_SHEETMETAL", "当前已是钣金，停止重复转换");
            phase = "SELECTED_FACE_INVALID";
            verifyFaceInDefaultBody(body, face);

            phase = "TREE_CREATE_FAILED";
            Selection bodySelection = pfcSelect.CreateModelItemSelection(body, null);
            Selection faceSelection = pfcSelect.CreateModelItemSelection(face, null);
            if (bodySelection == null || faceSelection == null) throw new ConversionFailure("TREE_CREATE_FAILED", "无法建立真实体/面的选择对象");
            Elements elements = Elements.create();
            if (elements == null) throw new ConversionFailure("TREE_CREATE_FAILED", "元素集合工厂返回空对象");
            addElement(elements, wfcElemIds.PRO_E_FEATURE_TREE, null, 0);
            addElement(elements, wfcElemIds.PRO_E_FEATURE_TYPE,
                    pfcArgument.CreateIntArgValue(FeatureType.FEATTYPE_DATUM_SURFACE.getValue()), 1);
            addElement(elements, wfcElemIds.PRO_E_STD_FEATURE_NAME, pfcArgument.CreateStringArgValue("SMT_CONV_DRIVING"), 1);
            addElement(elements, wfcElemIds.PRO_E_DTM_SRF_TYPE, pfcArgument.CreateIntArgValue(15), 1);
            addElement(elements, wfcElemIds.PRO_E_SMT_CONV_BODY, pfcArgument.CreateSelectionArgValue(bodySelection), 1);
            addElement(elements, wfcElemIds.PRO_E_SMT_DRV_SURF, pfcArgument.CreateSelectionArgValue(faceSelection), 1);
            addElement(elements, wfcElemIds.PRO_E_STD_SMT_THICKNESS, pfcArgument.CreateDoubleArgValue(thickness), 1);
            ensureWfcSession();
            ElementTree tree = wfcSession.CreateElementTree(elements);
            if (tree == null) throw new ConversionFailure("TREE_CREATE_FAILED", "元素树创建返回空对象");
            nativeAudit(trace, "element_tree", "created");
            FeatCreateOptions options = FeatCreateOptions.create();
            if (options == null) throw new ConversionFailure("TREE_CREATE_FAILED", "创建选项工厂返回空对象");
            options.append(FeatCreateOption.FEAT_CR_NO_OPTS);
            WRegenInstructions regen = wfcSolidInstructions.WRegenInstructions_Create();
            if (regen == null) throw new ConversionFailure("TREE_CREATE_FAILED", "重生成指令工厂返回空对象");
            phase = "CREATE_FEATURE_FAILED";
            trace.put("modelMayHaveChanged", true);
            nativeAudit(trace, "feature_create", "dispatching");
            WFeature feature = solid.WCreateFeature(tree, options, regen);
            if (feature == null) throw new ConversionFailure("CREATE_FEATURE_FAILED", "创建接口未返回特征，请检查模型状态");
            trace.put("featureCreated", true);
            nativeAudit(trace, "feature_create", "returned");
            phase = "REGEN_FAILED";
            solid.WRegenerate(regen);
            nativeAudit(trace, "regenerate", "returned");
            phase = "STATUS_READ_FAILED";
            SolidBody convertedBody = solid.GetDefaultBody();
            if (convertedBody == null || !convertedBody.IsSheetmetal()) {
                throw new ConversionFailure("STATUS_NOT_SHEETMETAL", "创建/重生成已返回，但未回读到钣金状态，请检查特征树");
            }
            trace.put("sheetmetal", true);
            phase = "FEATURE_RESULT_READ_FAILED";
            trace.put("featureId", feature.GetId());
            String featureName = feature.GetName();
            if (featureName == null || featureName.isBlank()) throw new ConversionFailure("FEATURE_RESULT_READ_FAILED", "钣金状态为真，但特征名称未取得");
            trace.put("featureName", featureName);
            return new LinkedHashMap<>(trace);
        } catch (ConversionFailure failure) {
            throw failure;
        } catch (Throwable error) {
            throw new ConversionFailure(phase, "原生步骤未完成，请查看jlink.log中的错误阶段与异常链", error);
        }
    }

    private static void addElement(Elements elements, int id, ArgValue value, int level) throws Exception {
        Element element = com.ptc.wfc.wfcElementTree.wfcElementTree.Element_Create(id, value, level);
        elements.append(element);
    }

    private static void nativeAudit(Map<String,Object> trace, String stage, String outcome) {
        Map<String,Object> event = new LinkedHashMap<>(trace);
        event.put("timestamp", Instant.now().toString());
        event.put("stage", stage);
        event.put("outcome", outcome);
        event.put("saved", false);
        log("6A_AUDIT " + toJson(event), null);
    }

    /** UI dialog options factory was not supplied; null-options acceptance remains a local runtime check. */
    private static boolean showConversionMessage(String message) {
        if (session == null) {
            log("6A user message (session unavailable): " + message, null);
            return false;
        }
        try {
            session.UIShowMessageDialog(message, null);
            return true;
        } catch (Throwable feedbackError) {
            log("EXCEPTION: UI_FEEDBACK_FAILED; summary=" + message, feedbackError);
            return false;
        }
    }

    private static String toJson(Object value) {
        StringBuilder out = new StringBuilder();
        appendJson(out, value);
        return out.toString();
    }

    private static void appendJson(StringBuilder out, Object value) {
        if (value == null) {
            out.append("null");
        } else if (value instanceof String) {
            appendJsonString(out, (String) value);
        } else if (value instanceof Boolean) {
            out.append(value.toString());
        } else if (value instanceof Number) {
            out.append(value.toString());
        } else if (value instanceof Map) {
            out.append('{');
            boolean first = true;
            for (Map.Entry<?, ?> entry : ((Map<?, ?>) value).entrySet()) {
                if (!first) out.append(',');
                first = false;
                appendJsonString(out, String.valueOf(entry.getKey()));
                out.append(':');
                appendJson(out, entry.getValue());
            }
            out.append('}');
        } else if (value instanceof Iterable) {
            out.append('[');
            boolean first = true;
            for (Object item : (Iterable<?>) value) {
                if (!first) out.append(',');
                first = false;
                appendJson(out, item);
            }
            out.append(']');
        } else {
            appendJsonString(out, String.valueOf(value));
        }
    }

    private static void appendJsonString(StringBuilder out, String text) {
        out.append('"');
        for (char c : text.toCharArray()) {
            switch (c) {
                case '"' -> out.append("\\\"");
                case '\\' -> out.append("\\\\");
                case '\n' -> out.append("\\n");
                case '\r' -> out.append("\\r");
                case '\t' -> out.append("\\t");
                default -> {
                    if (c < 0x20) {
                        out.append(String.format("\\u%04x", (int) c));
                    } else {
                        out.append(c);
                    }
                }
            }
        }
        out.append('"');
    }

    /** 不调用任何 Creo API 的诊断日志；日志失败不影响退出回调。 */
    private static void log(String message, Throwable error) {
        String text = Instant.now() + " " + message + System.lineSeparator();
        if (error != null) {
            StringWriter buffer = new StringWriter();
            error.printStackTrace(new PrintWriter(buffer));
            text += buffer.toString();
        }
        System.err.print("[BatchRename] " + text);
        try {
            Path folder = Paths.get(System.getProperty("user.home"), "CreoBatchRename");
            Files.createDirectories(folder);
            Files.write(folder.resolve("jlink.log"), text.getBytes(StandardCharsets.UTF_8),
                        StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception ignored) {
            // System.err 仍可供 Creo/JVM 日志收集，不递归记录日志错误。
        }
    }
}

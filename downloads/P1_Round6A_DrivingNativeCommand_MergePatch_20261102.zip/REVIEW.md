# P1 第六轮6A：原生预选平面驱动转换候选补丁

## 状态与输入

本轮交付是**基于给定源码/SDK签名的代码候选**。按照离线输入包要求，未执行javac、javap、node --check、SDK替身行为测试、浏览器自动化、HTTP请求或Creo真机操作；不存在本轮编译退出码、class数量、特征ID、真机日志或成功结果。只执行文件哈希、补丁字节复现和源码文本静态检查。这些检查不是编译或运行结果。

基线是本次输入包的current-source/BatchRename.java（SHA256 `2138d56bbf355c53a632b59ea91351936ac55ae05ebf84c377f49d552b8545bd`）和current-web，**不是第五轮输出**。不得把本补丁直接叠加到第二至第五轮最终源码；此前未部署加固不能据此自动认为已合并。37项MANIFEST哈希/大小已核对。input-sha256.json包含补丁适用基线。

交付包含根目录最终源码、`P1_Round6A_from_CurrentSource.patch`、签名引用、静态记录和本机验收清单。不包含部署class、真实otk.jar、SDK替身或部署脚本。没有修改rbn/dat/bat/config.pro/消息资源文件，没有回写现场目录。输入未含update.js、base.css或消息文件，沿用原工程，本包不是完整安装器。

## 新增/修改方法

| 方法/类型 | 职责 |
|---|---|
| SmtConvertListener.OnCommand | 原生UICommand同步回调唯一调用转换链；防重入；捕获Throwable，finally恢复converting |
| registerConversionCommand | 原三页面命令后注册SISWSheetMetalConvert；新增命令构造/指定失败不让start失败；未完成注册的listener不启用 |
| wrapAsWSolid(Model) | 已是WSolid则返回；否则通过getptr依次反射WPart/WSolid构造器；失败保存异常链，不对普通Model直接强转 |
| nativePointer / sameModel | 反射读取给定getptr，核对预选面及输入后激活模型身份 |
| ensureWfcSession / createWfcSession | 优先已有WSession，否则复用输入基线会话适配器；仅转换时初始化，不注册监听 |
| verifyFaceInDefaultBody | 验证真实预选Surface可见，且ID存在于默认body的曲面集合；不是自动选面 |
| convertPreselectedPlane | 模型/实体/预选面/输入校验→7节点最小树→创建→重生成→重新读body钣金状态及特征信息 |
| addElement | 保留公开Element_Create工厂和level参数，不手写XML |
| nativeAudit / showConversionMessage | 记录实际运行阶段、错误码、耗时；原生中文提示；不将堆栈送网页 |
| ensureCreosonRunningAsync | 将输入基线的启动阶段20秒UI轮询改为单次后台服务探测/拉起，不在后台调用Creo |

`listeners`泛型改为DefaultUICommandActionListener以统一跟踪四个命令；detach统一逐个移除，单个异常不阻止其余项尝试解除。

## 主调用链及行为

1. 原三页面命令注册后追加SISWSheetMetalConvert，复用SISW_SMT_LABEL/HELP/DESC和图标，未改batchrename.txt或假设新键编码。复用标签会使两个命令文字相近，本机须按命令ID识别；若需专用标签，另在原编码资源中增加键。不得手写RBN，本轮不将新命令自动加入Ribbon。
2. 新命令回调依次验证session/active、MDL_PART及.prt、WFC包装、默认体和非钣金状态。
3. 读取选择缓冲区，必须恰好1项；GetSelItem必须是Surface，必须SURFACE_PLANE，且属于当前模型和默认body、当前可见。记录选中面ID/类型/面积；不以最大面积或HTTP候选代替用户选择。
4. 原生提示后调用UIReadRealMessage(0.1,20.0)。null作为取消正常结束；有限数且0.1≤value≤20才继续。若SDK取消行为是抛异常，本候选会报告THICKNESS_INPUT_FAILED而不创建特征；具体取消异常类型未提供，未凭空匹配异常名。
5. 输入后重新验证当前模型、session、默认体和所选面；再用真实body/face和null ComponentPath创建两个Selection。
6. 根386/level0/null，其余level1：387=FEATTYPE_DATUM_SURFACE、1964=SMT_CONV_DRIVING、1131=15、6612=body selection、5111=face selection、3332=输入double。没有可选方向/圆角/shell元素。
7. CreateElementTree → FeatCreateOptions.create/FEAT_CR_NO_OPTS → WRegenInstructions_Create → WCreateFeature → WRegenerate → 重新GetDefaultBody/IsSheetmetal → GetId/GetName。创建返回null、重生成异常、状态非钣金或结果读取失败均不报告成功。
8. 成功消息只在上述步骤完成后使用真实返回值生成；记录saved=false。创建请求一经提交即标记modelMayHaveChanged；失败时提醒检查特征树，既不自动重试，也不虚构回滚。本轮无Save。

**线程范围：** native写链仅由SmtConvertListener.OnCommand直接调用；没有队列、Timer、HTTP写服务、bridgeExecutor或后台原生轮询。UIReadRealMessage本身是同步用户输入，WCreateFeature/WRegenerate也可能耗时；不能据源码设计声称真机UI永不短暂占用或三命令运行时已无阻塞。异常结束后guard会释放，仍需本机验证。

## 删除/废弃旧路径

移除SmtBridgeListener、parseBridgeParams、reply/replyOk/replyError、bridgeExecutor/注册任务，以及旧readActivePart/analyzeActivePart/estimateThickness/convertActivePart驱动+抽壳分支和其无用imports。不存在旧save=true、自动最大平面、自动壁厚、shell移除面或硬编码材料侧/切换侧路径。

ensureSheetmetalBridgeAsync现在仅记录关闭状态，**不清空wfcSession**；detach时正常清空缓存。createWfcSession沿用输入基线反射，不引入未给出的新会话工厂。

原三个页面命令的ID、消息键、图标、URL、窗口回退/导航逻辑保留；普通零件模式检测改为使用同一包装辅助方法，失败返回unknown，普通零件URL附modelMode。S1直接返回原页面URL，不额外读取模型或包装WFC对象。三个原有命令的注册/注销及新命令失败隔离均待本机核验，未声称运行通过。

服务自动拉起只作与线程要求直接相关的最小调整：原20秒同步sleep轮询删除；500ms单次探测和原批处理启动请求移到daemon后台，支持CREO_BR_SERVER_DIR并保留原基线默认服务目录。没有新增转换模型路径依赖。**这不是此前第五轮完整启动加固的合并**：原基线输出重定向、同步诊断日志方法、服务目录校验能力仍是原有/精简行为；本轮不改BAT，也未验证Windows进程或服务身份。端口监听只是一条未核验监听信息。

## 网页侧修改（不触发写模型）

- core.js保留bridgeCall接口名，但删除浏览器原生调用分支；全部返回CHANNEL_BLOCKED。审计增加敏感键/当前session值脱敏，connected不记录会话号；其余公共连接/重命名/版本接口保留输入基线实现，未宣称合并此前全部公共层加固。
- sheetmetal.js保留HTTP只读分析；方式/板厚/转换/保存保持禁用，历史smt_save被清false；nativeConvertReady=false仅指网页写通道。浏览器参数不传给6A命令。
- sheetmetal.html增加候选验证提示：先在零件窗口预选平面，再从原生命令输入板厚；明确待本机编译/真机验证，不写“转换已开放”。包络候选文案标明不是原生平面类型。
- about.html仅修正功能状态说明，保留DOM和版本逻辑。
- rename.html/rename.js无修改；未改rbn/dat/bat或消息文件。

网页保留的是本次输入基线，不等于第五轮完整只读/单位分析实现。本轮没有声称HTTP候选可授权转换，也没有把网页估算或localStorage板厚带入原生特征树。

## SDK依据与未决假设

逐条引用见SDK_REFERENCES.md，来源为包内javap-key与当前源码，不是本助手执行javap。以下必须本机核验：

1. WPart/WSolid内部构造器在真实pfcPart$Part对象上是否有效；构造成功不证明后续原生调用有效。fallback限于适配构造失败，不重试已经发出的原生创建/重生成。
2. WSession内部适配器来自基线createWfcSession，包内未附internal_WSession构造器转储；本候选复用已有代码，并明确需补本机证据。两种实体适配失败必须失败，不能恢复旧强转。
3. UIShowMessageDialog(String, MessageDialogOptions)签名已给，但MessageDialogOptions工厂未给。本候选传null，不臆造工厂；null接受度待验证。若输入提示对话框不能显示，命令以UI_PROMPT_FAILED结束，不创建。session为空时只记录日志，不调用UI原生API。成功后消息展示失败仅记录UI_FEEDBACK_FAILED，不抹去真实模型结果。
4. UIReadRealMessage仅有两个double的类型转储，没有参数名。本候选按任务输入范围传MIN/MAX；实际参数语义、非数字输入和取消行为必须本机确认，不声称已试过。
5. SDK输入未提供模型长度单位换算/查询接口。6A必须以**已人工确认mm单位的测试零件**为前提；double按模型长度单位直接传递，没有自动换算或自动确认mm。日志/提示明确这一点，不伪装已读出单位。若要自动校验/换算cm/inch，需要补SDK签名后另改。
6. GetSelModel指针相等、所选面ID在默认体集合内、输入提示期间预选项是否仍有效，均待真机；校验失败即拒绝，不使用其他面兜底。多实体自动选择不做。
7. 省略材料侧后最小树是否被Creo接受、选择UV是否需额外参数、feature名是否返回非空，均待真机；失败先回传本机日志，不猜枚举。
8. 原基线日志方法为同步文件IO，保留方法/路径；这不能证明慢磁盘时UI耗时无影响。当前未执行任何性能测试。原三命令/stop-reload的真实SDK注册生命周期也未验证。

## 12项静态检查结论（不是编译/运行证据）

| 项 | 文本核对结果 |
|---|---|
| 1 直接普通Model→WSolid强转 | 已删除；instanceof类型守卫或反射包装 |
| 2 两级适配fallback | 已实现，记录原始类/类型及异常链 |
| 3 新命令注册/注销 | 已追加且统一跟踪，失败不向start传播；待本机验证 |
| 4 原生同步线程调用 | 写入口仅OnCommand私有调用链；后台仅服务启动 |
| 5 单个预选平面 | 严格count=1、Surface、SURFACE_PLANE及模型/默认体归属 |
| 6 板厚读取/取消 | 用给定UIReadRealMessage，null取消；输入异常不创建 |
| 7 元素树 | 恰好7个规定节点，root/level符合要求 |
| 8 Save | 无调用 |
| 9 浏览器监听 | 无注册，仅历史说明注释 |
| 10 原三命令 | ID、导航/回退和注销结构保留，未做真实响应测试 |
| 11 异常分支 | 分阶段ConversionFailure、EXCEPTION日志、中文摘要、finally释放guard |
| 12 待验证行为 | 见上节，均未当成真机通过 |

## 本机建议编译与检查命令（未执行）

在隔离源码副本应用补丁，输出只到新暂存目录；不要覆盖现场classes/web：

```powershell
& 'D:\creoson\jdk25\jdk-25.0.5+8\bin\javac.exe' --release 17 -encoding UTF-8 `
  -cp 'D:\Program Files\PTC\Creo 13.4.0.0\Common Files\text\java\otk.jar' `
  -d '<新的暂存目录>' '<第六轮源码副本>\BatchRename.java'
node --check '<第六轮源码副本>\web\assets\js\core.js'
node --check '<第六轮源码副本>\web\assets\js\sheetmetal.js'
```

本助手未执行这些命令，不输出退出码/产物数。目标major61是--release17的预期，不是本轮实测结果；classpath不得混入pfcasync.jar。

## 本机受控真机验收矩阵（全部未执行）

无模型/装配/工程图→NO_MODEL/NOT_PART；钣金→ALREADY_SHEETMETAL；无默认体→NO_BODY；未选面→NO_SELECTED_FACE；多选→TOO_MANY_FACES；基准面/边/点→SELECTED_FACE_INVALID；非平面→SELECTED_NOT_PLANE；跨模型/其他body→SELECTED_FACE_OTHER_MODEL/OTHER_BODY；取消null→正常退出；非法板厚→INVALID_THICKNESS；模型切换→MODEL_CHANGED。

普通mm薄板+真实平面+正板厚→本机确认WCreateFeature/WRegenerate/IsSheetmetal和特征信息后，才可记录成功。几何拒绝→CREATE_FEATURE_FAILED；重生成失败→REGEN_FAILED；状态非钣金→STATUS_NOT_SHEETMETAL；包装失败→WRAP_SOLID_FAILED/WRAP_SESSION_FAILED。另有READ_MODEL_FAILED、READ_BODY_FAILED、THICKNESS_INPUT_FAILED、MODEL_RECHECK_FAILED、TREE_CREATE_FAILED、STATUS_READ_FAILED、FEATURE_RESULT_READ_FAILED等技术阶段码；错误后不自动重试，三页面命令应能继续使用。

必须同时检查新增命令注册失败不影响原三命令，stop能逐个detach，输入/失败后guard恢复；前后依次点击原三命令，记录本机实际耗时/异常。本轮不执行部署、不产生本机日志，不开展shell/Save/A4；真实操作由本机助手在代码审核及用户同意后进行。

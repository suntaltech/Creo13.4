import com.ptc.pfc.pfcCommand.DefaultUICommandActionListener;
import com.ptc.pfc.pfcCommand.UICommand;
import com.ptc.pfc.pfcSession.CreoCompatibility;
import com.ptc.pfc.pfcSession.Session;
import com.ptc.pfc.pfcSession.pfcSession;
import com.ptc.pfc.pfcWindow.Window;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.Instant;

/**
 * Creo 13 同步 J-Link 入口：只注册原生命令并打开已有页面。
 * 不创建 AsyncConnection，不请求 CREOSON，不在回调中等待网络或启动子进程。
 * 必须使用本机 Creo 13 的同步 SDK archive 编译，不混入 pfcasync.jar。
 */
public final class BatchRename {
    private static final String COMMAND = "SISWBatchRename";
    private static final String MESSAGES = "batchrename.txt";
    private static final String ICON = "batchrename_r5.png";
    private static final String BUILD = "2026-10-28-icon-r5-png-diagnostic";
    private static final String PAGE = "http://localhost:9056/rename.html";
    private static Session session;
    private static UICommand command;
    // 保持强引用，避免回调对象在插件生命周期内被回收。
    private static OpenPageListener listener;
    private static boolean active;
    private static boolean opening;
    private static final Object STARTER_LOCK = new Object();
    private static volatile Thread starterThread;
    // 日志使用有界队列；慢磁盘/网络主目录不会阻塞 Creo 回调。JVM 退出时不保证排空。
    private static final java.util.concurrent.atomic.AtomicLong droppedLogs =
        new java.util.concurrent.atomic.AtomicLong();
    private static final java.util.concurrent.ThreadPoolExecutor logs =
        new java.util.concurrent.ThreadPoolExecutor(1, 1, 30L, java.util.concurrent.TimeUnit.SECONDS,
            new java.util.concurrent.ArrayBlockingQueue<Runnable>(128), runnable -> {
                Thread thread = new Thread(runnable, "BatchRename-log");
                thread.setDaemon(true);
                return thread;
            }, (task, executor) -> droppedLogs.incrementAndGet());

    private BatchRename() { }

    /** 同步注册入口必须是 public static void 且无参数。 */
    public static void start() throws Exception {
        if (active) {
            log("start ignored: already active", null);
            return;
        }
        if (listener != null) {
            throw new IllegalStateException("Previous listener detach failed; restart Creo before reloading");
        }
        log("start entered; build=" + BUILD + "; icon=" + ICON + "; java=" + System.getProperty("java.version"), null);
        try {
            // 显式设置兼容性，避免先用 GetProESession() 进入旧的 C3 兼容模式。
            session = pfcSession.GetCurrentSessionWithCompatibility(CreoCompatibility.C4Compatible);
            if (session == null) {
                throw new IllegalStateException("No synchronous Creo session");
            }
            log("synchronous session acquired", null);
            listener = new OpenPageListener();
            if (session.IsCommandAdded(COMMAND)) {
                command = session.UIGetCommand(COMMAND);
                if (command == null) throw new IllegalStateException("Existing command lookup returned null");
                command.AddActionListener(listener);
            } else {
                command = session.UICreateCommand(COMMAND, listener);
            }
            log("native command registered", null);
            try {
                // 文件位于注册 text_dir 下的 resource 目录；不用硬编码绝对图标路径。
                command.SetIcon(ICON);
                log("icon registered: " + ICON + "; visual result requires Creo verification", null);
            } catch (Exception | LinkageError iconError) {
                log("icon registration failed; command remains available with default icon", iconError);
            }
            command.Designate(MESSAGES, "SISW_BR_LABEL", "SISW_BR_HELP", "SISW_BR_DESC");
            active = true;
            log("command designated", null);
            startCreosonInBackground();
            log("start returned; service readiness is checked separately in background", null);
            // 不调用已弃用的 UIAddButton/UIAddMenu，也不在此打开浏览器。
            // 功能区位置由首次自定义导出的 .rbn 或用户现有 Ribbon 配置负责。
        } catch (Exception ex) {
            log("start failed", ex);
            detach();
            throw ex; // 让辅助应用程序显示真正的加载错误，而不是伪报启动成功。
        } catch (LinkageError ex) {
            log("JAR/class version or linkage error", ex);
            detach();
            throw ex;
        }
    }

    /** 停止时只解除回调，不退出 Creo，不关闭浏览器，不修改模型。 */
    public static void stop() {
        log("stop entered", null);
        active = false;
        detach();
        Thread starter = starterThread;
        if (starter != null) starter.interrupt(); // 不等待，不终止既有/已启动的服务。
        log("stop returned; background wait cancelled, server process left running", null);
    }

    private static String setting(String property, String environment, String fallback) {
        String value = System.getProperty(property);
        if (value == null || value.trim().isEmpty()) value = System.getenv(environment);
        return value == null || value.trim().isEmpty() ? fallback : value;
    }

    /** 后台线程不得调用任何 Creo/J-Link API；stop 只取消探测，不杀服务器。 */
    private static void startCreosonInBackground() {
        if (!Boolean.parseBoolean(setting("creo.batchrename.autostart", "CREO_BR_AUTOSTART", "true"))) {
            log("CREOSON autostart disabled; use start_creoson.ps1 for API/session validation", null);
            return;
        }
        synchronized (STARTER_LOCK) {
            if (starterThread != null && starterThread.isAlive()) {
                log("CREOSON background check already in progress", null);
                return;
            }
            starterThread = new Thread(() -> {
                try { ensureCreosonRunning(); }
                finally {
                    synchronized (STARTER_LOCK) {
                        if (starterThread == Thread.currentThread()) starterThread = null;
                    }
                }
            }, "BatchRename-service");
            starterThread.setDaemon(true);
            try { starterThread.start(); }
            catch (RuntimeException error) {
                starterThread = null;
                log("Background thread could not start; command remains available", error);
            }
        }
    }

    private static boolean hasListener() throws InterruptedException {
        if (Thread.currentThread().isInterrupted()) throw new InterruptedException();
        try (java.net.Socket socket = new java.net.Socket()) {
            socket.connect(new java.net.InetSocketAddress("localhost", 9056), 500);
            return true;
        } catch (java.io.IOException unavailable) { return false; }
    }

    /** 仅判断预期页面，不能由此推断 CREOSON API/Creo 会话正常。限制响应大小与等待时间。 */
    private static boolean isPageReady(String address) throws java.io.IOException {
        java.net.HttpURLConnection connection = (java.net.HttpURLConnection)
            new java.net.URL(address).openConnection(java.net.Proxy.NO_PROXY);
        connection.setConnectTimeout(500);
        connection.setReadTimeout(1000);
        connection.setInstanceFollowRedirects(false);
        try {
            if (connection.getResponseCode() != 200) return false;
            try (java.io.InputStream input = connection.getInputStream()) {
                byte[] bytes = input.readNBytes(65536);
                String html = new String(bytes, StandardCharsets.UTF_8);
                return html.contains("id=\"executeBtn\"") && html.contains("onlysession");
            }
        } finally { connection.disconnect(); }
    }

    private static void ensureCreosonRunning() {
        try {
            if (!hasListener()) {
                Path directory = Paths.get(setting("creo.batchrename.creosonDir", "CREO_BR_SERVER_DIR",
                    "D:\\creoson\\CreosonServerWithSetup-2.8.2-win64"));
                if (!Files.isRegularFile(directory.resolve("creoson_run.bat"))) {
                    log("CREOSON launch script missing: " + directory + "; plugin command remains available", null);
                    return;
                }
                if (Thread.currentThread().isInterrupted()) throw new InterruptedException();
                ProcessBuilder builder = new ProcessBuilder("cmd.exe", "/d", "/c", "creoson_run.bat");
                builder.directory(directory.toFile());
                builder.redirectOutput(ProcessBuilder.Redirect.appendTo(directory.resolve("batchrename_server_stdout.log").toFile()));
                builder.redirectError(ProcessBuilder.Redirect.appendTo(directory.resolve("batchrename_server_stderr.log").toFile()));
                Process process = builder.start();
                process.getOutputStream().close();
                log("CREOSON launch requested; pid=" + process.pid() + "; readiness NOT established", null);
            } else {
                log("Port 9056 is listening; preserving existing process; identity/readiness NOT established", null);
            }
            for (int attempt = 0; attempt < 20; attempt++) {
                if (Thread.currentThread().isInterrupted()) throw new InterruptedException();
                try {
                    if (isPageReady(PAGE)) {
                        log("Rename HTTP page ready; CREOSON API and Creo session NOT verified; run start_creoson.ps1", null);
                        return;
                    }
                } catch (java.io.IOException notReady) { /* HTTP 就绪可重试；不重复启动进程。 */ }
                Thread.sleep(1000);
            }
            log("Rename HTTP page not ready after 20 background attempts; inspect server logs; no automatic relaunch", null);
        } catch (InterruptedException cancelled) {
            Thread.currentThread().interrupt();
            log("CREOSON background check cancelled; no server process terminated", null);
        } catch (Exception error) {
            log("CREOSON background startup/check failed; plugin command remains available", error);
        }
    }

    private static void detach() {
        active = false;
        if (command != null && listener != null) {
            try {
                command.RemoveActionListener(listener);
                listener = null;
            } catch (Exception ex) {
                log("listener detach failed; restart Creo before reloading", ex);
                // 保留引用以便诊断；该回调受 active=false 保护。
            }
        }
        session = null;
    }

    /** 只做原生浏览器调用；SetURL/SetBrowserSize 的实机耗时仍须测量。 */
    private static final class OpenPageListener extends DefaultUICommandActionListener {
        @Override
        public void OnCommand() {
            if (!active || opening || session == null) {
                return;
            }
            opening = true;
            log("OnCommand entered", null);
            try {
                Window window = session.GetCurrentWindow();
                if (window == null) {
                    log("No current window; open a model window first", null);
                    return;
                }
                window.SetURL(PAGE);
                window.SetBrowserSize(80.0);
                log("browser navigation issued; OnCommand returned", null);
            } catch (Exception ex) {
                log("open embedded browser failed", ex);
            } finally {
                opening = false;
            }
        }
    }

    /** UI 线程只入有界队列；真正的终端/文件 IO 在后台执行。 */
    private static void log(String message, Throwable error) {
        final String timestamp = Instant.now().toString();
        logs.execute(() -> writeLog(timestamp, message, error));
    }

    private static void writeLog(String timestamp, String message, Throwable error) {
        String text = timestamp + " " + message + System.lineSeparator();
        long dropped = droppedLogs.getAndSet(0);
        if (dropped > 0) text = timestamp + " log queue full; dropped=" + dropped + System.lineSeparator() + text;
        if (error != null) {
            StringWriter buffer = new StringWriter();
            error.printStackTrace(new PrintWriter(buffer));
            text += buffer.toString();
        }
        try { System.err.print("[BatchRename] " + text); }
        catch (RuntimeException ignored) { /* 仍尝试文件日志。 */ }
        try {
            Path folder = Paths.get(setting("creo.batchrename.logDir", "CREO_BR_LOG_DIR",
                Paths.get(System.getProperty("user.home"), "CreoBatchRename").toString()));
            Files.createDirectories(folder);
            Files.write(folder.resolve("jlink.log"), text.getBytes(StandardCharsets.UTF_8),
                        StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception ignored) { /* 不递归记录日志错误。 */ }
    }
}

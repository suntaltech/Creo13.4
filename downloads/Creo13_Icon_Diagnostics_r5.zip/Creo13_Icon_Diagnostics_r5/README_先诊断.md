# 图标问题：先定位实际加载链路（r5诊断候选版）

**当前没有足够证据确定你的实机根因。** “SetIcon抛XToolkitBadInputs，所以Creo一定要求16色BMP”的推断此前没有真实SDK依据；r4只证明文件是16色BMP，未证明SetIcon接受这个输入。现在用户反馈仍失败，不能继续将问题当成调色板错误。

本包是小范围诊断和PNG候选修订，不是已验证生产修复，也不是完整环境安装器。没有真实Creo日志、SDK或Windows机器，不能保证它解决问题。当前r4完整业务包和配置不自动改动。

## 已查到的证据与不足

1. 现有代码确实向SetIcon传入 `batchrename.bmp`，并且在Designate之后设置；mock只模拟接口，没有验证SDK真正接受的图像格式。
2. 公开的现代Creo TOOLKIT Ribbon参考使用 `command.png`（16px）和 `command_large.png`（32px），注册顺序为创建命令、设置PNG图标、指定文字资源。参考为C TOOLKIT，**不能单独证明Creo13 J-Link的全部要求**：
   https://github.com/zewei2580-tech/creo-plugin-skills/blob/HEAD/skills/creo-toolkit-ribbon-tab-plugin/SKILL.md
   https://github.com/zewei2580-tech/creo-plugin-skills/blob/HEAD/skills/creo-toolkit-ribbon-tab-plugin/references/layout-and-registration.md
3. 已检查的两个公开J-Link示例没有SetIcon调用，不能作为验证。
4. 官方UICommand文档仍被本环境代理在CONNECT阶段以403拒绝，不是已证明PTC文档不存在。已在云环境网络配置草稿中加入 support.ptc.com；需要在环境设置中审核保存并发布，才能再试正式文档。
5. SetIcon失败、调用成功但Ribbon仍旧图标、运行的class未更新、注册的text_dir不同，是不同情况。需要最新日志和实际路径区分。

## 先运行只读检查，保留现状

在Windows解压本包，执行（路径按实际修改）：

```powershell
powershell -NoProfile -File .\CheckIcon.ps1 -PluginDir 'D:\creoson\jlink' -RegistrationFile 'D:\creoson\jlink\batchrename.dat'
```

脚本只读检查候选.dat、磁盘class、图标文件头/哈希和相关日志，另写JSON报告，不加载插件，不改配置或Ribbon，不启动服务。若实际加载的是manual.dat或其他目录，请明确传那个文件；脚本不会把候选路径冒充实际已加载路径。类路径包含多个目录时需人工检查。Windows PowerShell5.1解析/执行未在当前Linux环境验证，请先审阅脚本。

请保留输出的报告路径，将其中以下内容回传：`installed_class_on_disk`、`assets`、`relevant_log_tail`。也可以直接回传最新jlink.log中SetIcon前后和堆栈，以及替换BMP的完整路径。报告含本机路径，分享前可自行隐去用户名等信息。

判读：
- 磁盘class仍引用BMP：换PNG本身无效，需要重新编译并复制新class。
- 图标文件不存在/哈希不对应：先修正实际注册的text_dir和部署。
- 新日志没有r5 build标记：尚不能证明运行的是新class；磁盘上有新class也不代表已加载。
- 新日志仍有SetIcon异常：保留完整类型/堆栈，不能只看“按钮仍能用”。
- 新日志显示SetIcon成功但视觉不变：再检查Ribbon绑定的命令与应用名、缓存和按钮布局；不要直接删除用户Ribbon配置。
- r4用户没安装r5时，缺少r5标记是正常现象，不能据此认定其r4部署错误。

## PNG候选验证（需要重新编译，不能只换图片）

在检查和备份之后，才做这一分支：

1. 本包代码将SetIcon输入改为 `batchrename_r5.png`，并移到Designate之前。资源为16px RGBA PNG，配套32px文件为 `batchrename_r5_large.png`。新文件名便于排除旧资源缓存；大型图标自动选取行为待实机确认。
2. `build.cmd` 使用本机真实同步otk.jar/pfc.jar，--release17编译；设置实际CREO_BR_COMMON/CREO_BR_JDK。编译失败则停止并回传完整build.log，不使用mock类替代SDK。
3. 关闭Creo，备份已部署classes及text/resource，再复制**整个新classes目录**和本包两个PNG到已注册的text_dir/resource。保留原有中文消息、.dat、Ribbon及其他插件文件；不需要新增.dat图标字段。无完整备份不要覆盖。
4. 完整重启Creo。日志应出现 `build=2026-10-28-icon-r5-png-diagnostic; icon=batchrename_r5.png`，然后查看图标步骤结果。没有这个标记就先查加载路径，而不是继续改图片。
5. 按钮保留图标失败回退。此包不删除用户Ribbon，不自动把原应用名/命令名改成新名字。

## 本轮验证

21项Java mock/辅助检查通过；这只验证生命周期、日志、回退与本机HTTP辅助方法，**不验证真实SetIcon格式约束**。两个PNG的签名、IHDR尺寸/位深/颜色类型及每个chunk CRC检查通过（16/32px、8位RGBA、非隔行）。Windows脚本、真实SDK编译及Creo显示未执行。代码补丁和日志在本包，未附生产class。

"""Offline Stage1 pairing of existing Extract-R11.ps1 JSONL; no ETL/Creo access.

Source order is primary. PID/generation scopes path anchors. Cross-context IRP
references are retained as observations, never as successful byte evidence.
"""
import argparse
from bisect import bisect_right
from collections import Counter, defaultdict, deque
import calendar
from datetime import datetime, timedelta, timezone
import hashlib
import heapq
import json
import math
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def integer(value):
    if value is None or isinstance(value, bool):
        return None
    try:
        text = str(value)
        return int(text, 16 if text.lower().startswith("0x") else 10)
    except ValueError:
        return None


def ptr(value):
    n = integer(value)
    if n is not None and -(1 << 63) <= n < 0:
        n += 1 << 64
    return n if n is not None and 0 < n < (1 << 64) else None


def status_code(value):
    n = integer(value)
    if n is not None and -(1 << 31) <= n < 0:
        n += 1 << 32
    return n if n is not None and 0 <= n < (1 << 32) else None


def pid(event):
    return integer(event.get("execution_pid"))


def time_ns(text):
    m = re.fullmatch(r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.(\d{1,9}))?(Z|[+-]\d{2}:\d{2})", text)
    if not m:
        raise ValueError("timestamp without explicit reviewed offset/precision: " + text)
    offset = m[3]
    minutes = 0 if offset == "Z" else (int(offset[1:3]) * 60 + int(offset[4:6])) * (1 if offset[0] == "+" else -1)
    dt = datetime.strptime(m[1], "%Y-%m-%dT%H:%M:%S") - timedelta(minutes=minutes)
    return calendar.timegm(dt.timetuple()) * 10**9 + int((m[2] or "").ljust(9, "0"))


def lines(path):
    previous = 0
    with Path(path).open(encoding="utf-8-sig") as f:
        for line in f:
            event = json.loads(line)
            sequence = integer(event.get("source_sequence"))
            if sequence is None or sequence <= previous:
                raise ValueError("missing/non-increasing source sequence: " + str(path))
            previous = sequence
            yield event


def merge_events(target, context):
    previous = 0
    for e in heapq.merge(lines(target), lines(context), key=lambda e: e["source_sequence"]):
        if e["source_sequence"] <= previous:
            raise ValueError("duplicate/overlapping source sequence across passes")
        previous = e["source_sequence"]
        yield e


def validate_layout(event, contract):
    """Recheck the extractor's array mapping, not just its self-reported gate."""
    fields = contract["positions"].get(str(event["event_id"]))
    if event.get("mapping") == "unresolved":
        return
    if fields is None:
        if event.get("mapping") != "named_event_xml_no_position_guess":
            raise ValueError("unknown layout requires named fields, never guessed positions")
        required = contract["named_fields"].get(str(event["event_id"]))
        if required is None or not set(required).issubset(event["data"]):
            raise ValueError("named payload lacks calibration contract fields")
        return
    layout = contract["property_layouts"][str(event["event_id"])].get(str(event.get("version")))
    if layout is None or str(event.get("opcode")) != layout["opcode"]:
        raise ValueError("unsupported EventID/Version/Opcode; no shape-only fallback")
    fields = layout["fields"]
    raw = event.get("raw_properties", [])
    if len(raw) != len(fields) or set(event["data"]) != set(fields):
        raise ValueError("property count/names differ from contract")
    for field, expected_type, item in zip(fields, layout["types"], raw):
        if item["type"] != expected_type:
            raise ValueError("raw property type differs from versioned manifest: " + field)
        if event["data"][field] != item["value"]:
            raise ValueError("mapped field differs from raw property: " + field)


def remap_raw_sample(event, contract):
    """Audit ONLY supplied raw samples. Never call this a new ETL extraction."""
    result = dict(event)
    eid, version = str(event["event_id"]), str(event.get("version"))
    layout = contract["property_layouts"].get(eid, {}).get(version)
    if layout is not None:
        raw = event["raw_properties"]
        if len(raw) != len(layout["fields"]):
            raise ValueError("raw sample length mismatch")
        result["old_data_ignored"] = event.get("data")
        result["data"] = {field: item["value"] for field, item in zip(layout["fields"], raw)}
        result["mapping"] = "versioned_manifest_positions_sample_only"
    validate_layout(result, contract)
    return result


class DiagnosticSink:
    """Bound duplicated diagnostic payloads; raw input JSONL is retained unchanged."""
    LIMITED = {"unresolved", "overlaps", "cross-context", "missing-anchor", "context-reference"}

    def __init__(self, writers, byte_limit=32*1024*1024, record_limit=20000):
        self.writers = writers
        self.byte_limit = byte_limit
        self.record_limit = record_limit
        self.stats = defaultdict(lambda: {"written_records": 0, "written_bytes": 0, "omitted_records": 0})

    def write(self, kind, record):
        text = json.dumps(record, ensure_ascii=False) + "\n"
        size = len(text.encode("utf-8"))
        s = self.stats[kind]
        if kind in self.LIMITED and (s["written_records"] >= self.record_limit or s["written_bytes"]+size > self.byte_limit):
            s["omitted_records"] += 1
            return
        self.writers[kind].write(text)
        s["written_records"] += 1
        s["written_bytes"] += size


class Lifetimes:
    """Use named ProcessID in retained process payload; never header execution PID."""
    def __init__(self, path=None):
        self.boundaries = defaultdict(list)
        self.boundary_evidence = {}
        self.blocked_exit_windows = set()
        self.errors = []
        if path is None:
            return
        for e in lines(path):
            if str(e.get("event_id")) not in ("1", "2"):
                continue
            try:
                tree = ET.fromstring(e["raw_xml"])
                data = {n.get("Name"): n.text for n in tree.iter()
                        if n.tag.rsplit("}", 1)[-1] == "Data"}
                process_id = integer(data.get("ProcessID"))
                if process_id is None:
                    raise ValueError("no named ProcessID")
                self.boundaries[process_id].append((e["source_sequence"], str(e["event_id"])))
                self.boundary_evidence[(process_id,e["source_sequence"])]= {
                    "source_sequence":e["source_sequence"],"event_id":str(e["event_id"]),
                    "system_time":e.get("system_time"),"source":"retained process event header"}
            except (ValueError, KeyError, ET.ParseError) as error:
                self.errors.append({"sequence": e["source_sequence"], "error": str(error)})

    def generation(self, process_id, sequence):
        rows = self.boundaries.get(process_id, [])
        index = bisect_right(rows, (sequence, "z")) - 1
        if index < 0 or rows[index][1] != "1":
            return None
        return rows[index][0]

    def resolve_event(self, event, max_drain_ms=100, process_id=None):
        """Event-aware exit attribution. Generic generation() remains strict.

        100ms is an explicit review policy, not a Windows lifetime guarantee.
        No new Create/Read/Write may enter a retired generation, even in-window.
        """
        process_id=pid(event) if process_id is None else process_id
        sequence=event["source_sequence"]
        generation=self.generation(process_id,sequence)
        if generation is not None:
            return {"kind":"active_or_capture_start","generation":generation}
        unknown={"kind":"unknown","generation":None}
        rows=self.boundaries.get(process_id,[])
        index=bisect_right(rows,(sequence,"z"))-1
        if index<0 or rows[index][1]!="2":
            return {**unknown,"reason":"no_observed_active_generation"}
        exit_seq=rows[index][0]
        window_key=(process_id,exit_seq)
        boundary=self.boundary_evidence.get(window_key,{"source_sequence":exit_seq,"system_time":None})
        evidence={"exit_boundary":boundary,"max_drain_ms":max_drain_ms}
        if str(event["event_id"]) in ("12","15","16"):
            self.blocked_exit_windows.add(window_key)
            return {**unknown,**evidence,"reason":"new_operation_after_exit_without_create"}
        if window_key in self.blocked_exit_windows:
            return {**unknown,**evidence,"reason":"exit_window_closed_by_new_operation"}
        if str(event["event_id"]) not in ("13","14","22","24"):
            return {**unknown,**evidence,"reason":"post_exit_event_not_in_drain_allowlist"}
        if index>0 and rows[index-1][1]=="1":
            previous_generation=rows[index-1][0]
        elif index==0 and isinstance(self,CaptureLifetimes):
            previous_generation=0
        else:
            return {**unknown,**evidence,"reason":"no_attributable_pre_exit_generation"}
        if not boundary.get("system_time"):
            return {**unknown,**evidence,"reason":"exit_header_time_unavailable"}
        try:
            elapsed=time_ns(event["system_time"])-time_ns(boundary["system_time"])
            limit=int(max_drain_ms*1_000_000)
        except (ValueError,TypeError,OverflowError):
            return {**unknown,**evidence,"reason":"invalid_exit_window_clock_or_limit"}
        if sequence<=exit_seq or elapsed<0 or elapsed>limit:
            return {**unknown,**evidence,"elapsed_ns":elapsed,"reason":"outside_controlled_exit_drain_window"}
        return {"kind":"exit-drain","generation":previous_generation,**evidence,
            "elapsed_ns":elapsed,"rule":"allowed cleanup/close/completion/query after observed exit; before next create; no post-exit new I/O"}


class CaptureLifetimes(Lifetimes):
    """Calibration may start after its process. Split at every observed boundary.

    Initial generation 0 is an explicit capture-start assumption, not a proven
    pre-capture lifetime. Never extend it past an observed exit or creation.
    """
    def generation(self, process_id, sequence):
        rows=self.boundaries.get(process_id,[])
        index=bisect_right(rows,(sequence,"z"))-1
        return 0 if index<0 else super().generation(process_id,sequence)


def calibration_sequence_proof(groups):
    """One ordered write/read/EOF chain, not three unrelated observations."""
    for write in groups["write_65"]:
        w=write["request"]
        for read in groups["read_65"]:
            r=read["request"]
            if (w["path"]!=r["path"] or w["lifetime_generation"]!=r["lifetime_generation"] or
                pid(w["event"])!=pid(r["event"]) or write["completion"]["source_sequence"]>=r["event"]["source_sequence"]):
                continue
            wkey,rkey=ptr(w["event"]["data"].get("FileKey")),ptr(r["event"]["data"].get("FileKey"))
            same_open=(ptr(w["event"]["data"].get("FileObject"))==ptr(r["event"]["data"].get("FileObject")) and w["anchor"]==r["anchor"])
            if (wkey and rkey and wkey!=rkey) or (not (wkey and rkey) and not same_open):
                continue
            for eof in groups["eof_65"]:
                e=eof["request"]
                if (r["path"]==e["path"] and r["lifetime_generation"]==e["lifetime_generation"] and
                    pid(r["event"])==pid(e["event"]) and r["anchor"]==e["anchor"] and
                    ptr(r["event"]["data"].get("FileObject"))==ptr(e["event"]["data"].get("FileObject")) and
                    read["completion"]["source_sequence"]<e["event"]["source_sequence"]):
                    return {"write_request":w["event"]["source_sequence"],"write_completion":write["completion"]["source_sequence"],
                        "read_request":r["event"]["source_sequence"],"read_completion":read["completion"]["source_sequence"],
                        "eof_request":e["event"]["source_sequence"],"eof_completion":eof["completion"]["source_sequence"],
                        "basis":"ordered same-path write/read; FileKey or same-open continuity; read and EOF share opened object"}
    return None


class Matcher:
    def __init__(self, target_pid, emit=lambda *_: None, lifetimes=None,
                 enabled=True, status_names=None, window=None, watch_suffix=None,exit_drain_max_ms=100):
        self.target_pid = target_pid
        self.emit = emit
        self.life = lifetimes
        self.enabled = enabled
        self.status_names = status_names or {0: "STATUS_SUCCESS", 0xC0000011: "STATUS_END_OF_FILE"}
        self.window = window
        self.pending = defaultdict(list)
        self.irp_index = defaultdict(set)
        self.object_pending = defaultdict(set)
        self.tainted_keys = set()
        self.anchors = {}
        self.generations = Counter()
        self.rows = {}
        self.counts = Counter({"exit_drain":0,"unknown_process_lifetime":0,
            "orphan_completions":0,"ambiguous_completions":0})
        self.target_ids = Counter()
        self.offsets = Counter()
        self.watch_suffix = watch_suffix.lower() if watch_suffix else None
        self.watched_keys = set()
        self.foreign_recent = defaultdict(lambda: deque(maxlen=4))
        if not math.isfinite(exit_drain_max_ms) or exit_drain_max_ms<=0:
            raise ValueError("exit drain limit must be positive and finite")
        self.exit_drain_max_ms=exit_drain_max_ms
        self.exit_drain_windows={}
        self.exit_drain_unseen_objects=defaultdict(set)

    def watched_path(self, path):
        return bool(self.watch_suffix and path and path.lower().endswith(self.watch_suffix))

    def watch_event(self, event, path=None, keys=()):
        if self.watched_path(path) or any(key in self.watched_keys for key in keys):
            self.emit("baseline-chain", {"kind":"raw-event", "event":event,
                "association":"observed baseline anchor or same-IRP reference to a pending baseline operation; not a match proof"})

    def references(self, keys, limit=8):
        """Bound references per record, not repeatedly serialize an entire history."""
        total = sum(len(self.pending[k]) for k in keys)
        references = []
        for key in sorted(keys, key=str):
            requests = self.pending[key]
            selected = requests if len(requests) <= limit else requests[:limit//2] + requests[-limit//2:]
            for req in selected:
                if len(references) >= limit:
                    break
                e = req["event"]
                references.append({"source_sequence":e["source_sequence"], "pid":e["execution_pid"], "tid":e["execution_tid"]})
            if len(references) >= limit:
                break
        return {"request_references":references,"total_pending_requests":total,
                "reference_list_truncated":total > len(references)}

    def row(self, path):
        if path not in self.rows:
            self.rows[path] = {"path": path, "opens_observed": 0,
                "open_pairs":0,"successful_open_pairs":0,
                "read_requests": 0, "write_requests": 0,
                "read_request_bytes": 0, "write_request_bytes": 0,
                "successful_read_bytes_candidate": 0, "successful_write_bytes_candidate": 0,
                "read_pairs": 0, "write_pairs": 0, "eof_read_pairs": 0,
                "non_read_write_pairs": 0, "pending_requests": 0}
        return self.rows[path]

    def on_event(self, event):
        data = event.get("data", {})
        event_id = str(event["event_id"])
        process_id = pid(event)
        sequence = event["source_sequence"]
        clock = time_ns(event["system_time"])
        self.offsets["Z" if event["system_time"].endswith("Z") else event["system_time"][-6:]] += 1
        in_window = self.window is None or self.window[0] <= clock <= self.window[1]
        if process_id == self.target_pid:
            self.target_ids[event_id] += 1
            if not in_window:
                self.counts["target_outside_window"] += 1
        if event.get("mapping") == "unresolved":
            self.counts["unmapped_events"] += 1
            self.emit("unresolved", {"reason": "unmapped_event_payload", "event": event})
            return
        if process_id != self.target_pid:
            # Context is evidence, NEVER an operation candidate or a path anchor.
            # Recycled pointers in unrelated processes must not poison target state.
            irp = ptr(data.get("Irp"))
            self.counts["foreign_context_records"] += 1
            reference={"source_sequence":sequence,"event_id":event_id,
                "pid":event["execution_pid"],"tid":event["execution_tid"],
                "irp_raw":data.get("Irp"),"system_time":event["system_time"],
                "reference_only":True,"effect_on_target_candidates":"none"}
            if irp:
                self.foreign_recent[irp].append(reference)
            keys=set(self.irp_index.get(irp,())) if irp else set()
            self.watch_event(event,keys=keys)
            if event_id=="24" and keys:
                self.counts["cross_context_completions"] += 1
                self.emit("cross-context", {"reason":"foreign_execution_context_reference_only",
                    "completion":event, "reference_only":True,
                    "effect_on_target_candidates":"none; request neither consumed nor tainted",
                    **self.references(keys)})
            else:
                self.emit("context-reference", reference)
            return
        if self.life and hasattr(self.life,"resolve_event"):
            resolution=self.life.resolve_event(event,self.exit_drain_max_ms)
        else:
            resolution={"kind":"active_or_capture_start","generation":self.life.generation(process_id,sequence) if self.life else 0}
        generation=resolution["generation"]
        if generation is None:
            self.counts["unknown_process_lifetime"] += 1
            self.emit("unresolved",{"reason":"unknown_process_lifetime","event":event,"lifetime_resolution":resolution})
        scope = (process_id, generation)
        fo, fk, irp = ptr(data.get("FileObject")), ptr(data.get("FileKey")), ptr(data.get("Irp"))
        anchor_key = (*scope, fo)
        if resolution["kind"]=="exit-drain":
            self.counts["exit_drain"] += 1
            key=(process_id,generation,resolution["exit_boundary"]["source_sequence"])
            if key not in self.exit_drain_windows:
                self.exit_drain_windows[key]={"pid":process_id,"generation":generation,
                    "exit_boundary":resolution["exit_boundary"],"first_sequence":sequence,"last_sequence":sequence,
                    "first_time":event["system_time"],"last_time":event["system_time"],"event_count":0,"event_id_counts":{},
                    "max_elapsed_ns":0,"file_objects_not_previously_opened_in_generation":0,"events_with_unseen_file_object":0}
            bucket=self.exit_drain_windows[key]
            bucket["last_sequence"]=sequence
            bucket["last_time"]=event["system_time"]
            bucket["event_count"]+=1
            bucket["event_id_counts"][event_id]=bucket["event_id_counts"].get(event_id,0)+1
            bucket["max_elapsed_ns"]=max(bucket["max_elapsed_ns"],resolution["elapsed_ns"])
            if fo and anchor_key not in self.generations:
                self.exit_drain_unseen_objects[key].add(fo)
                bucket["file_objects_not_previously_opened_in_generation"]=len(self.exit_drain_unseen_objects[key])
                bucket["events_with_unseen_file_object"]+=1
            self.emit("exit-drain",{"event":event,"lifetime_resolution":resolution,
                "open_anchor_present":anchor_key in self.anchors if fo else None,
                "file_object_previously_opened_in_generation":anchor_key in self.generations if fo else None})
        # Verified Create V1 includes Irp and FileObject, but no FileKey.
        # Establish an observed path anchor, then handle its IRP as an operation.
        if event_id == "12" and fo and data.get("FileName"):
            # Reusing a FileObject while an earlier generation still has pending
            # operations is not a proven continuation of the old path lifetime.
            self.tainted_keys.update(self.object_pending.get(anchor_key, ()))
            if self.object_pending.get(anchor_key):
                self.emit("overlaps", {"reason": "file_object_reopened_with_pending_operations", "event": event})
                self.counts["file_object_reuse_with_pending"] += 1
            self.generations[anchor_key] += 1
            self.anchors[anchor_key] = {"path": data["FileName"], "file_key": fk,
                "generation": self.generations[anchor_key], "open_sequence": sequence}
            if process_id == self.target_pid:
                self.row(data["FileName"])["opens_observed"] += 1
        anchor = self.anchors.get(anchor_key) if fo else None
        self.watch_event(event,path=(anchor or {}).get("path") or data.get("FileName"),
            keys=((*scope,irp),) if irp else ())
        if anchor and fk and anchor["file_key"] is None:
            # Create V1 has no FileKey. Learn it only from a later named/typed
            # operation on this same PID/generation/FileObject, not from an IRP.
            anchor = {**anchor,"file_key":fk}
            self.anchors[anchor_key] = anchor
        if anchor and fk and anchor["file_key"] and fk != anchor["file_key"]:
            self.emit("missing-anchor", {"reason": "file_key_conflicts_with_open", "event": event, "anchor": anchor})
            anchor = None
        path = anchor["path"] if anchor else None
        if event_id in ("15", "16") and process_id == self.target_pid:
            if path:
                r = self.row(path)
                direction = "read" if event_id == "15" else "write"
                r[direction + "_requests"] += 1
                size = integer(data.get("IOSize"))
                if size is not None and size >= 0:
                    r[direction + "_request_bytes"] += size
            else:
                self.counts["requests_missing_anchor"] += 1
                self.emit("missing-anchor", {"reason": "no_explicit_same_pid_open_anchor", "event": event})
        if event_id == "14":
            self.anchors.pop(anchor_key, None)
        if event_id == "24":
            self.complete(event, scope, irp, in_window)
            return
        if not irp:
            # Name/reparse events are retained in raw stream; never fabricate an IRP.
            return
        key = (*scope, irp)
        existing = {key} if self.pending.get(key) else set()
        req = {"event": event, "path": path, "anchor": anchor,
               "lifetime_generation": generation, "in_window": in_window,
               "tainted": bool(existing)}
        if existing:
            self.tainted_keys.update(existing)
            self.tainted_keys.add(key)
            self.counts["overlap_requests"] += 1
            self.emit("overlaps", {"reason": "overlapping_irp_generations_or_contexts",
                 **self.references(existing), "new_request": req})
        self.pending[key].append(req)
        self.irp_index[irp].add(key)
        if self.watched_path(path):
            self.watched_keys.add(key)
        if fo:
            self.object_pending[anchor_key].add(key)

    def complete(self, completion, scope, irp, in_window):
        reference_scopes = set(self.irp_index.get(irp, ())) if irp else set()
        key = (*scope, irp)
        same = self.pending.get(key, [])
        if not same and not reference_scopes:
            self.counts["orphan_completions"] += 1
            self.emit("unresolved", {"reason": "no_same_scope_pending_request", "completion": completion,
                "foreign_pointer_history_not_candidates":list(self.foreign_recent.get(irp,()))})
            return
        if not same:
            self.counts["cross_context_completions"] += 1
            self.emit("cross-context", {"reason": "IRP_reference_only_not_matched",
                "completion": completion, **self.references(reference_scopes),
                "effect_on_other_generations":"none; references excluded from candidate uniqueness"})
            return
        if len(same) != 1 or key in self.tainted_keys or same[0]["tainted"]:
            self.counts["ambiguous_completions"] += 1
            self.emit("unresolved", {"reason": "overlapping_or_tainted_irp",
                "completion": completion, **self.references({key}),
                "scope":list(scope),"completion_discriminants":["Irp","ExtraInformation","Status"],
                "reason_not_narrowed":"Completion lacks FileObject/FileKey/offset/direction. No nearest-time or size-fit guess."})
            return
        req = same[0]
        if (completion["source_sequence"] <= req["event"]["source_sequence"] or
            time_ns(completion["system_time"]) < time_ns(req["event"]["system_time"])):
            self.tainted_keys.add(key)
            self.counts["invalid_pair_order"] += 1
            self.emit("unresolved",{"reason":"completion_not_after_request","completion":completion,
                **self.references({key})})
            return
        self.pending.pop(key)
        self.watched_keys.discard(key)
        request_fo = ptr(req["event"]["data"].get("FileObject"))
        if request_fo:
            object_key = (*scope, request_fo)
            self.object_pending[object_key].discard(key)
            if not self.object_pending[object_key]:
                self.object_pending.pop(object_key)
        self.irp_index[irp].discard(key)
        if not self.irp_index[irp]:
            self.irp_index.pop(irp)
        event = req["event"]
        data, cd = event["data"], completion["data"]
        operation = str(event["event_id"])
        st, size, extra = status_code(cd.get("Status")), integer(data.get("IOSize")), integer(cd.get("ExtraInformation"))
        exact_success = st == 0
        if operation == "12" and not exact_success:
            object_key = (*scope,ptr(data.get("FileObject")))
            current = self.anchors.get(object_key)
            if current and current["open_sequence"] == event["source_sequence"]:
                self.anchors.pop(object_key,None)
        conditions = {"integrity_or_calibration_gate_not_passed": self.enabled,
            "not_target_execution_pid": pid(event) == self.target_pid,
            "non_read_write_operation": operation in ("15", "16"),
            "no_open_path_anchor": req["path"] is not None,
            "unknown_lifetime": req["lifetime_generation"] is not None,
            "outside_window": req["in_window"] and in_window,
            "not_exact_status_success": exact_success,
            "invalid_request_or_completion_size": size is not None and extra is not None and 0 <= extra <= size}
        exclusions = [reason for reason, passed in conditions.items() if not passed]
        eligible = not exclusions
        raw_pair = {"request": req, "completion": completion,
            "pairing_basis":{"rule":"one_untainted_active_request_in_same_pid_generation_irp",
                "same_scope_candidates":1,"scope":list(scope),
                "request_sequence":event["source_sequence"],"completion_sequence":completion["source_sequence"],
                "latency_ns":time_ns(completion["system_time"])-time_ns(event["system_time"]),
                "file_object_raw":data.get("FileObject"),"file_key_raw":data.get("FileKey"),
                "byte_offset_raw":data.get("ByteOffset"),"operation_id":operation,
                "foreign_scopes_counted_as_candidates":0,
                "foreign_pointer_history_reference_only":list(self.foreign_recent.get(irp,()))},
            "request_bytes": size if operation in ("15", "16") else None,
            "completion_information_raw": cd.get("ExtraInformation"),
            "transferred_bytes_candidate": extra if eligible else None,
            "byte_candidate_exclusions": exclusions,
            "status": {"raw": cd.get("Status"), "name": self.status_names.get(st, "unresolved"),
                "severity": ("success", "informational", "warning", "error")[(st >> 30) & 3]
                    if st is not None and 0 <= st < 2**32 else "unknown",
                "exact_zero": exact_success}, "scope": "same-context operation candidate, not strict proof"}
        self.emit("pairs", raw_pair)
        self.counts["pairs"] += 1
        if req["path"] and pid(event) == self.target_pid:
            r = self.row(req["path"])
            if operation in ("15", "16"):
                direction = "read" if operation == "15" else "write"
                r[direction + "_pairs"] += 1
                if eligible:
                    r["successful_" + direction + "_bytes_candidate"] += extra
                if operation == "15" and st == 0xC0000011:
                    r["eof_read_pairs"] += 1
            else:
                r["non_read_write_pairs"] += 1
                if operation == "12":
                    r["open_pairs"] += 1
                    if exact_success:
                        r["successful_open_pairs"] += 1

    def finish(self):
        for key, requests in self.pending.items():
            for req in requests:
                self.counts["pending_requests"] += 1
                if req["path"] and pid(req["event"]) == self.target_pid:
                    self.row(req["path"])["pending_requests"] += 1
                tainted = req["tainted"] or key in self.tainted_keys
                self.emit("pending", {**req, "tainted":tainted,
                    "reason": "ambiguous" if tainted else "no_completion_in_input"})
        return {"counters": dict(self.counts), "target_event_counts": dict(self.target_ids),
                "observed_offsets": dict(self.offsets), "files": list(self.rows.values()),
                "exit_drain":{"policy_max_ms":self.exit_drain_max_ms,"allowed_ids":["13","14","22","24"],
                    "rejected_new_operation_ids":["12","15","16"],"windows":list(self.exit_drain_windows.values()),
                    "note":"Controlled attribution policy, not proof against PID reuse or capture omissions; raw records in exit-drain.jsonl"},
                "pending_irp_scope_slots": len(self.pending)}


def run(directory, output, contract_path, calibration_path=None,
        diagnostic_max_bytes=32*1024*1024, diagnostic_max_records=20000,exit_drain_max_ms=100):
    if not math.isfinite(exit_drain_max_ms) or exit_drain_max_ms<=0:
        raise ValueError("exit drain limit must be positive and finite")
    contract = load(contract_path)
    extraction = load(directory / "extraction.json")
    provider_schema = load(directory / "provider-schema.json")
    mode = extraction["mode"]
    expected = contract[mode]
    if output.exists():
        raise ValueError("output directory already exists; refusing overwrite")
    gates = {"extractor_completed": extraction["complete"] is True,
             "source_unchanged": extraction["source_unchanged"] is True and
                extraction["source_sha256_before"] == extraction["source_sha256_after"],
             "contract_hash": extraction["contract_sha256"].lower() == sha(contract_path),
             "source_size": extraction["source_bytes"] == expected["bytes"],
             "two_pass_counts_equal": extraction["pass1_total_events"] == extraction["pass2_total_events"],
             "two_pass_target_order": extraction.get("target_order_matches") is True and
                extraction.get("target_order_hash_pass1") == extraction.get("target_order_hash_pass2"),
             "payload_decoding": extraction["decode_errors"] == 0,
             "target_pid": extraction["target_pid"] == expected["pid"],
             "etl_identity":extraction["source_sha256_before"].lower()==expected["sha256"].lower(),
             "total_event_baseline":extraction["pass1_total_events"]==expected["get_winevent_total"]}
    gates["installed_provider_schema"] = (provider_schema.get("schema_checked") is True and
        provider_schema.get("contract_sha256", "").lower()==sha(contract_path) and
        provider_schema.get("provider_guid", "").strip("{}").lower()==contract["file_provider"])
    for name in ("target-events.jsonl", "context-events.jsonl", "process-events.jsonl", "provider-schema.json"):
        spec = extraction["files"][name]
        gates["hash_" + name] = (directory / name).stat().st_size == spec["bytes"] and sha(directory / name) == spec["sha256"].lower()
    life = (Lifetimes if mode=="formal" else CaptureLifetimes)(directory / "process-events.jsonl")
    gates["process_payloads_decoded"] = not life.errors
    if mode == "formal":
        gates["formal_etl_hash"] = extraction["source_sha256_before"].lower() == expected["sha256"].lower()
        gates["get_winevent_total"] = extraction["pass1_total_events"] == expected["get_winevent_total"]
        gates["pid_counts_declared"] = extraction["target_event_counts"] == expected["event_counts"]
        calibration = load(calibration_path) if calibration_path else {}
        gates["calibration_65_byte_actual_replay"] = (calibration.get("calibration_gate") is True
            and calibration.get("accepted") is True and calibration.get("contract_sha256") == sha(contract_path)
            and calibration.get("mode") == "calibration")
        gates["target_creation_present"] = any(k == "1" for _, k in life.boundaries.get(expected["pid"], []))
    output.mkdir(parents=True)
    names = ("pairs", "unresolved", "pending", "overlaps", "cross-context", "missing-anchor", "context-reference", "baseline-chain","exit-drain")
    writers = {n: (output / (n + ".jsonl")).open("x", encoding="utf-8") for n in names}
    sink = DiagnosticSink(writers, diagnostic_max_bytes, diagnostic_max_records)
    calibration_stats = Counter()
    calibration_sequences = {"write_65": [], "read_65": [],"eof_65":[]}
    watched_sequences=set()
    codec = load(ROOT / "reference/formal-codec-review.json")
    status_names = {status_code(x["code"]): x["name"] for x in codec["status_code_table"]}
    def emit(kind, record):
        if kind=="baseline-chain":
            watched_sequences.add(record["event"]["source_sequence"])
            sink.write(kind,record)
            return
        # Foreign execution contexts are raw evidence plus sampled references,
        # not target operations. Their raw input remains hash-verified in full.
        destination="context-reference" if kind=="cross-context" and record.get("reference_only") else kind
        sink.write(destination, record)
        sequences=[(record.get(key) or {}).get("source_sequence") for key in ("event","completion")]
        request=record.get("request") or record.get("new_request") or {}
        sequences.append((request.get("event") or {}).get("source_sequence"))
        if mode=="calibration" and (any(s in watched_sequences for s in sequences) or
            (record.get("path") or request.get("path") or "").lower().endswith(expected["baseline_suffix"].lower())):
            sink.write("baseline-chain",{"kind":kind,"record":record})
        if mode == "calibration" and kind == "pairs":
            req = record["request"]
            if (req["path"] or "").lower().endswith(expected["baseline_suffix"].lower()):
                value = record["transferred_bytes_candidate"]
                if value == expected["baseline_bytes"]:
                    kind65 = "write_65" if str(req["event"]["event_id"]) == "16" else "read_65"
                    rd = req["event"]["data"]
                    if integer(rd.get("ByteOffset")) == 0 and (kind65 != "write_65" or integer(rd.get("IOSize")) == 65):
                        calibration_stats[kind65] += 1
                        calibration_sequences[kind65].append(record)
                if (str(req["event"]["event_id"]) == "15" and
                    integer(req["event"]["data"].get("ByteOffset")) == 65 and
                    status_code(record["completion"]["data"].get("Status"))==0xC0000011 and
                    integer(record["completion"]["data"].get("ExtraInformation"))==0):
                    calibration_stats["read_offset_65_seen"] += 1
                    calibration_sequences["eof_65"].append(record)
    matcher = Matcher(expected["pid"], emit, life,
        enabled=all(gates.values()), status_names=status_names,
        window=(time_ns(expected["start_utc"]), time_ns(expected["stop_utc"])),
        watch_suffix=expected["baseline_suffix"] if mode=="calibration" else None,exit_drain_max_ms=exit_drain_max_ms)
    try:
        for e in merge_events(directory / "target-events.jsonl", directory / "context-events.jsonl"):
            if e.get("provider_guid", "").strip("{}").lower() != contract["file_provider"]:
                raise ValueError("unexpected provider in file event stream")
            validate_layout(e, contract)
            matcher.on_event(e)
        result = matcher.finish()
    finally:
        for writer in writers.values():
            writer.close()
    gates["stored_counts_equal_extractor"] = result["target_event_counts"] == extraction["target_event_counts"]
    gates["all_payloads_mapped"] = result["counters"].get("unmapped_events", 0) == 0
    gates["target_inside_window"] = result["counters"].get("target_outside_window", 0) == 0
    gates["get_winevent_utc_clock"] = set(result["observed_offsets"]) == {"Z"}
    gates["diagnostic_details_complete"] = not any(s["omitted_records"] for name,s in sink.stats.items() if name!="context-reference")
    if mode == "formal":
        gates["stored_counts_equal_baseline"] = result["target_event_counts"] == expected["event_counts"]
        gates["target_lifetime_known"] = result["counters"].get("unknown_process_lifetime",0)==0
    else:
        gates["calibration_target_not_after_unmatched_exit"] = result["counters"].get("unknown_process_lifetime",0)==0
    sequence_proof=calibration_sequence_proof(calibration_sequences) if mode=="calibration" else None
    calibration_gate = sequence_proof is not None
    if mode == "calibration":
        gates["write_then_read_65_observed"] = calibration_gate
    accepted = all(gates.values())
    # Never expose successful-byte aggregates as accepted when a later integrity
    # gate fails. Detail records remain diagnostic operation candidates only.
    if not accepted:
        for row in result["files"]:
            for field in ("successful_read_bytes_candidate", "successful_write_bytes_candidate"):
                row[field] = None
    for row in result["files"]:
        row["target_file"] = row["path"].split("\\")[-1].lower() in contract["target_names"]
    target_coverage = {name: [r["path"] for r in result["files"]
        if r["path"].split("\\")[-1].lower() == name] for name in contract["target_names"]}
    report = {"schema": "r11-stage1-pairing/4", "contract_schema": contract["schema"], "mode": mode, "accepted": accepted,
        "acceptance_scope": "extractor/field-map/count gates only; candidate matching may remain unresolved",
        "calibration_gate": calibration_gate if mode == "calibration" else gates["calibration_65_byte_actual_replay"],
        "calibration_observations": dict(calibration_stats), "contract_sha256": sha(contract_path),
        "calibration_sequence_proof":sequence_proof,
        "input_extraction_sha256": sha(directory / "extraction.json"),
        "input_source_etl_sha256": extraction["source_sha256_before"], "gates": gates,
        "process_decode_errors": life.errors, **result,
        "process_generation_scope":{"observed_target_boundaries":life.boundaries.get(expected["pid"],[]),
            "calibration_initial_generation_assumption":0 if mode=="calibration" else None,
            "note":"Calibration capture-start generation is explicit. Exit closes new I/O; only bounded classified drain may refer to the retiring generation. Formal mode requires observed creation."},
        "diagnostic_retention":dict(sink.stats),
        "diagnostic_scope":{"required":"target-PID operation diagnostics; baseline-chain is uncapped",
            "foreign_context":"reference-only summaries may be sampled; full context-events.jsonl is retained and hashed",
            "ancillary_context_references_complete":sink.stats["context-reference"]["omitted_records"]==0,
            "no_target_candidate_changes_due_to_reference_sampling":True},
        "calibration_baseline_chain":{"file":"baseline-chain.jsonl","raw_events":len(watched_sequences),
            "records":sink.stats["baseline-chain"]["written_records"],"omitted":sink.stats["baseline-chain"]["omitted_records"],
            "scope":"all observed baseline-associated raw records and decisions within supplied input; no events fabricated"} if mode=="calibration" else None,
        "diagnostic_limits":{"bytes_per_limited_stream":diagnostic_max_bytes,"records_per_limited_stream":diagnostic_max_records,
            "limited_streams":sorted(DiagnosticSink.LIMITED),"raw_input":"retained; omissions are not raw ETL loss"},
        "target_coverage": target_coverage,
        "coverage_note": "Empty lists mean no explicit open path observed in this replay, not proof of no access.",
        "formal_header_events_lost_reported": load(ROOT / "reference/formal-session-header.json")["session"]["events_lost"] if mode == "formal" else None,
        "formal_header_reference_sha256": sha(ROOT / "reference/formal-session-header.json") if mode == "formal" else None,
        "formal_buffers_lost": None,
        "total_count_comparison": {"read": extraction["pass1_total_events"],
            "get_winevent_baseline": expected.get("get_winevent_total"),
            "tracerpt_header_reported": expected.get("header_events_processed"),
            "header_delta": extraction["pass1_total_events"] - expected["header_events_processed"],
            "note": "One-event channel difference is documented, not silently reconciled."},
        "limitations": ["No GUI parsing, DLL initialization or file-layer exclusion conclusion.",
            "Candidate bytes are not unique file bytes and not a full losslessness proof.",
            "BuffersLost unknown; no inference from calibration zero loss.",
            "Historical volume mapping not guessed. IOFlags and conflicting InfoClass semantics remain raw.",
            "Create V1 has Irp; FileKey is absent there. Pointer equality is not global identity proof.",
            "accepted is not a signature or proof against modified input artifacts."]}
    report["outputs"] = {p.name: {"bytes": p.stat().st_size, "sha256": sha(p)} for p in output.glob("*.jsonl")}
    (output / "pairing-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return report


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--input-dir", type=Path, required=True)
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument("--contract", type=Path, default=ROOT / "reference/contract.json")
    p.add_argument("--calibration-report", type=Path)
    p.add_argument("--diagnostic-max-bytes",type=int,default=32*1024*1024)
    p.add_argument("--diagnostic-max-records",type=int,default=20000)
    p.add_argument("--exit-drain-max-ms",type=float,default=100)
    args = p.parse_args()
    if args.diagnostic_max_bytes <= 0 or args.diagnostic_max_records <= 0 or not math.isfinite(args.exit_drain_max_ms) or args.exit_drain_max_ms<=0:
        p.error("diagnostic limits must be positive; exit drain limit must be positive and finite")
    report = run(args.input_dir, args.output_dir, args.contract, args.calibration_report,
        args.diagnostic_max_bytes,args.diagnostic_max_records,args.exit_drain_max_ms)
    print(json.dumps({"accepted": report["accepted"], "gates": report["gates"]}, ensure_ascii=False))
    raise SystemExit(0 if report["accepted"] else 2)


if __name__ == "__main__":
    main()

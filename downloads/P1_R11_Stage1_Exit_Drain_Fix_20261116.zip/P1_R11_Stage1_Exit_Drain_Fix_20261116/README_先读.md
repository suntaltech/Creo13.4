# R11 Stage1 退出收尾归属修正候选（2026-11-16）

V3 本机报告已确认：字段模板、双遍提取、基线 65B 写后读链和目标诊断门均通过；仅因退出后 371 条收尾事件被判代际未知而拒绝校准。本包修正该归属逻辑，**不代表本轮完整校准已经在云端通过**。

先读 EXIT_DRAIN_REVIEW.md。合同仍为 /2，SHA256 ED3FFE8A6CE948B611BC6E27F40C2245AE605B21FB742B8B60F362270ABB4CF4；两个 PowerShell 文件保持不变。本轮报告 schema 为 r11-stage1-pairing/4，60 项测试通过。

## 规则

- 默认退出后 100ms 内，且尚无下一次进程创建边界时，只允许 ID13 Cleanup、ID14 Close、ID22 Query/Other、ID24 Completion 归到刚退出的代际。
- 100ms 是本轮显式审核策略，不是 Windows/SDK 的通用保证。输入报告最晚事件距退出 40.9835ms，符合默认窗口；超窗仍未知，不自动延长。
- 退出后出现 ID12 Create、ID15 Read、ID16 Write 仍未知并拒绝；同时关闭该退出窗口，后续收尾也不得继续假借旧代际。观察到新的进程创建后，正常进入新代际。
- 没有退出时钟、没有可归属的前代际、非允许事件类，均不猜归属。收尾中的未见 FileObject 不据此创建路径或证明文件打开成功。
- exit-drain 仅是生命周期归属；配对仍要求同作用域唯一候选。orphan、ambiguous 独立保留，不能与 drain 数相加当唯一事件总数。

exit-drain.jsonl 不采样，保留每条归属依据；报告 exit_drain.windows 给出退出边界、代际、类型计数、首尾序号/时间、最晚延迟和窗口参数。未知生命周期仍计 unknown_process_lifetime，并输出具体拒绝原因。原验收门仍检查是否存在未知事件，没有删除或硬设为通过。

## 本机验收顺序

在解压根目录，按原顺序做单测、Parser、模板、校准两遍提取和配对。使用新的输出目录，不覆盖旧结果：

```powershell
$ErrorActionPreference='Stop'
py -3 -m unittest discover -s tests -v
if ($LASTEXITCODE -ne 0) { throw '测试失败，停止' }
foreach ($ReviewTool in @('tools\Check-R11ProviderSchema.ps1','tools\Extract-R11.ps1')) {
    $ReviewTokens=$null
    $ReviewParseErrors=$null
    [void][System.Management.Automation.Language.Parser]::ParseFile(
        (Join-Path (Get-Location).Path $ReviewTool),[ref]$ReviewTokens,[ref]$ReviewParseErrors)
    if ($null -ne $ReviewParseErrors -and $ReviewParseErrors.Count -gt 0) { $ReviewParseErrors; throw 'Parser 失败' }
}
.\tools\Check-R11ProviderSchema.ps1 -OutputFile '.\provider-schema-drain-r1.json'
$FormalEvidenceEtl='D:\creo-tools\build\p1-step41-r10-late-find-review-20261112\runtime-r11\formal.etl'
$CalibrationEvidenceEtl=Join-Path (Split-Path $FormalEvidenceEtl) 'calibrate.etl'
$OfflineReviewRoot='F:\P1_R11_Stage1_ExitDrainFix_20261116_R1'
.\tools\Extract-R11.ps1 -Etl $CalibrationEvidenceEtl -Mode calibration -OutputDirectory (Join-Path $OfflineReviewRoot 'cal-extract') -ProviderSchemaReport '.\provider-schema-drain-r1.json'
py -3 .\tools\pair_r11.py --input-dir (Join-Path $OfflineReviewRoot 'cal-extract') --output-dir (Join-Path $OfflineReviewRoot 'cal-pairs')
if ($LASTEXITCODE -ne 0) { throw '校准门未过，停止；保留报告' }
```

可先对已通过哈希门的 V3 JSONL 作算法对照诊断，另写新目录；完整本机验收仍按上述顺序，不替代校准门。合同/提取器未改，不能使用早期 v1 错字段过滤的提取件。

本轮重点检查：observed_target_boundaries 保留；exit_drain 类型/数量/时间范围可回算；unknown_process_lifetime 不混入合格 drain；退出后没有新 I/O 被接受；baseline-chain 和 calibration_sequence_proof 六序号仍完整；所有 gates 通过、accepted=true、退出码 0。不能提前承诺新计数恰为 371，因为云端未收到全量事件。

## 校准全部通过后才读正式 ETL

```powershell
.\tools\Extract-R11.ps1 -Etl $FormalEvidenceEtl -Mode formal -OutputDirectory (Join-Path $OfflineReviewRoot 'formal-extract') -ProviderSchemaReport '.\provider-schema-drain-r1.json'
py -3 .\tools\pair_r11.py --input-dir (Join-Path $OfflineReviewRoot 'formal-extract') --output-dir (Join-Path $OfflineReviewRoot 'formal-pairs') --calibration-report (Join-Path $OfflineReviewRoot 'cal-pairs\pairing-report.json')
if ($LASTEXITCODE -ne 0) { throw '正式验收失败，不升级结论' }
```

上述步骤只读现存 ETL，不启停 ETW，不改 Creo、插件、UI、配置或模型。未知源码版本不猜位，源 ETL 前后校验，输出不覆盖；旧大日志保留，不为本轮释放空间而自动删除。

## 输出与回传

先回传校准 extraction.json、pairing-report.json、模板/Parser 结果、exit-drain.jsonl 和 baseline-chain.jsonl。若流较大，先发报告及首个拒绝点附近少量原始记录，完整文件留本机。未知或新 I/O 若仍出现，应回传其退出/下一创建边界和事件头，不放宽窗口来过门。

诊断策略沿用上一轮：目标必要诊断省略仍关闭门、小计置 null；辅助 context-reference 可采样，原始 context-events 全量校验保留；baseline-chain 和 exit-drain 不采样。候选字节不是唯一文件内容量，也不证明 DLL 加载、GUI 枚举或实体转钣金成功。

validation/exit-drain-sample-review.json 只核对已提供的 8 条收尾示例与汇总一致性，不是重放全部 371 条。本机报告的 EventsLost/丢缓冲、IOFlags、InfoClass、0x216、tracerpt 偏移及历史卷号映射等未决项不因此清零。

"""Text inspection only. Does not compile or execute Java, SDK, JS or Creo."""
from pathlib import Path
import hashlib,json,re,sys
out=Path(__file__).resolve().parents[1]
base=Path(sys.argv[1]) if len(sys.argv)>1 else out.parent/'baseline/BatchRename.java'
s=(out/'BatchRename.java').read_text(); b=base.read_text()
checks={}
def check(name,value):
 checks[name]=bool(value)
def erase_literals_comments(text):
 pattern=r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|//[^\n]*|/\*[\s\S]*?\*/'
 return re.sub(pattern,lambda m: ''.join('\n' if c=='\n' else ' ' for c in m.group()),text)
code=erase_literals_comments(s)
def block(text,marker):
 clean=erase_literals_comments(text); start=text.index(marker); op=clean.index('{',start); depth=1; i=op+1
 while depth:
  depth+=(clean[i]=='{')-(clean[i]=='}'); i+=1
 return text[start:i]
check('baseline_sha256',hashlib.sha256(base.read_bytes()).hexdigest()=='dde67be4f671a5d69abd5ef9a5dae0109424183feb966ef13c21f5b7a2df9abc')
stack=[]; pairs={')':'(',']':'[','}':'{'}; balanced=True
for c in code:
 if c in '([{': stack.append(c)
 elif c in ')]}':
  if not stack or stack.pop()!=pairs[c]: balanced=False; break
check('text_delimiters_balanced_only',balanced and not stack)
for method in ['registerPageCommand','registerConversionCommand','trackCommand','untrackCommand','detach','guardedPageUrl','detectActiveModelMode','appendPageQuery','ensureCreosonRunningAsync']:
 # Locate declarations, not invocation sites.
 marker=re.search(r'private static [^\n]+ '+method+r'\(',s).group()
 check('unchanged_'+method,block(s,marker)==block(b,marker))
oldpage=block(b,'private static final class OpenPageListener')
newpage=block(s,'private static final class OpenPageListener')
oldcallback=block(oldpage,'public void OnCommand()')
body=oldcallback[oldcallback.index('{')+1:-1]
check('page_callback_original_body_preserved',re.sub(r'\s+','',body) in re.sub(r'\s+','',newpage))
check('page_callback_request_id_context',all(x in newpage for x in ['UUID.randomUUID()','pageRequestId.set','pageRequestId.remove()','finally']))
check('no_forbidden_calls',not re.search(r'\.(?:Save|AddBrowserMessageListener)\s*\(|window\.external|PRO_E_SHELL_SRF|pfcasync|\(\s*WSolid\s*\)\s*model',code))
check('no_modal_dialog_call','UIShowMessageDialog(' not in code)
check('status_line_call_present','session.UIDisplayMessage(CONVERSION_MESSAGES, key, null)' in code)
convert=block(s,'private static Map<String,Object> convertPreselectedPlane')
check('unit_gate_before_elements',convert.index('requireConfirmedMillimetres')<convert.index('Elements.create()') and convert.index('"UNIT_GATE_CONFIRMED_MM"')<convert.index('Elements.create()'))
check('unit_states_present',all(v in s for v in ['UNIT_GATE_UNKNOWN_REQUIRED','UNIT_GATE_CONFIRMED_MM','UNIT_GATE_NON_MM_BLOCKED']))
check('input_real_outcomes_present',all(v in s for v in ['CANCEL_NULL_RETURNED','THROWN_EXCEPTION','INVALID_RANGE_REJECTED','VALID_FINITE_POSITIVE','UNCLASSIFIED']))
check('native_block_not_automatically_asserted','trace.put("thicknessInputOutcome", "NATIVE_DIALOG_BLOCKED")' not in s)
check('single_create_regenerate_calls',code.count('.WCreateFeature(')==1 and code.count('.WRegenerate(')==1)
check('same_seven_tree_nodes',len(re.findall(r'\baddElement\(elements,',convert))==7)
check('tree_node_count_actual','trace.put("drivingNodeCount", elements.getarraysize())' in convert)
check('material_side_risk_explicit','trace.put("materialSideRisk", "UNVERIFIED")' in convert)
check('ownership_internal_reflection_only','getMethod("GetSurfaceSolidBody", Surface.class)' in s and '.GetSurfaceSolidBody(' not in code)
check('public_failure_children_readback','.ListChildOfFailedFeatures()' in code and 'not_failed_parent_list' in s)
check('feature_four_fields',all(x in s for x in ['featureId','featureName','featureFeatType','featureStatus','GetId','GetName','GetFeatType','GetStatus']))
check('success_requires_complete_metadata','if (!readFeatureMetadata(feature, trace))' in convert)
check('regeneration_flag_after_call',convert.index('solid.WRegenerate(regen)')<convert.index('trace.put("regenerationReturned", true)'))
check('sheetmetal_readback_before_success',convert.index('if (!Boolean.TRUE.equals(sheetmetal))')<convert.index('"VERIFIED_CONVERSION_NOT_SAVED"'))
listener=block(s,'private static final class SmtConvertListener')
check('conversion_id_before_guards',listener.index('UUID.randomUUID()')<listener.index('if (session == null)'))
check('guard_not_reset_other_invocation','if (acquired) converting = false' in listener)
check('final_trace_elapsed','nativeAudit(trace, "command", "finished")' in listener and 'elapsedMs' in listener)
keys=re.findall(r'showConversionMessage\(trace, "([A-Z0-9_]+)"',s)+['P1_6A_INSPECT','P1_6A_FAILED']
resources=(out/'text/p1_6a_r2.txt').read_text()
check('feedback_resource_keys',all(k+'\n' in resources for k in keys))
check('no_runtime_artifacts',not any(p.suffix.lower() in {'.class','.rbn','.dat','.bat','.jar'} for p in out.rglob('*') if p.is_file()))
report={'scope':'text-only static assertions; not Java syntax, SDK compile or runtime validation','baselineSha256':hashlib.sha256(base.read_bytes()).hexdigest(),'sourceSha256':hashlib.sha256((out/'BatchRename.java').read_bytes()).hexdigest(),'checks':checks,'allPassed':all(checks.values()),'notExecuted':['javac','javap','node --check','Mock/Stub','HTTP','Creo','browser','deployment']}
(out/'evidence/static-claims.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'passed':sum(checks.values()),'total':len(checks),'failed':[k for k,v in checks.items() if not v]},ensure_ascii=False))
raise SystemExit(0 if all(checks.values()) else 1)

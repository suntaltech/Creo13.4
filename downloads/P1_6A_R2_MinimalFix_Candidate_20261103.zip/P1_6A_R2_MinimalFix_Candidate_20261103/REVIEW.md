# P1 6A R2 最小整改源码候选（2026-11-03）

本包仅用于本机离线编译、审核和受控测试准备，不代表可部署、可发布或转换已成功。本次未加载 Creo、未创建真实特征、未改现场目录。没有输出 class/rbn/dat/bat/jar。

## 输入与变更

输入：上一版生命周期诊断修复的 `BatchRename.java`，SHA256：
`dde67be4f671a5d69abd5ef9a5dae0109424183feb966ef13c21f5b7a2df9abc`。
输出哈希见 `evidence/static-claims.json` 和 `SHA256SUMS`。

| 目标 | 源码处理与证据边界 |
|---|---|
| P0 / 3.1 必需对象、适配器 | 保留公开 WSolid 优先，随后 WPart(long)、WSolid(long) 顺序。对象 present/class 与可选 pointer 分开；指针诊断失败收集到 diagnosticPointerFailedKeys，不改变结果。构造适配器和同模型身份校验必需的指针读取仍可阻断操作，不能把安全身份校验也降为可忽略。 |
| P0 / 3.2 用户反馈 | 删除 UIShowMessageDialog 调用；使用 UIDisplayMessage 和独立零替换参数资源 `text/p1_6a_r2.txt`。不猜测 MessageDialogOptions 或 stringseq 工厂。完整中文原因及身份字段写入本地日志，状态行提供简明英文操作指引。 |
| P0 / 3.3 输入分类 | thicknessInputOutcome 区分 UNCLASSIFIED、CANCEL_NULL_RETURNED、THROWN_EXCEPTION、INVALID_RANGE_REJECTED、VALID_FINITE_POSITIVE；异常保留真实类和消息，failedPhase=THICKNESS_INPUT_FAILED。非有限数用字符串记录，避免非法 JSON 数字。 |
| P0 / 3.4 单位门禁 | 每次调用先显示单位指引，再通过已给出签名的 UIReadStringMessage(Boolean.FALSE) 获取用户声明。仅输入 MM（忽略大小写和首尾空白）可进入 CONFIRMED_MM；NON_MM 明确 BLOCKED；null、其他输入、异常、提示失败均 UNKNOWN 并中断。此为人工声明，不能检测误报单位。树构造前再次检查确认状态。 |
| P1 / 3.5 面归属 | 在内部实现对象上可选反射 GetSurfaceSolidBody(Surface)，记录 nativeFaceOwner；回读owner与默认体身份明确不一致时阻断。方法不可用、空返回或可选比较指针不可读时保留风险并走 ListSurfaces ID匹配。所有路径仍要求ID匹配、同模型、可见平面和有效面积。原生回调返回值提供额外线索，内部契约未升级为公开强归属保证。 |
| P1 / 3.6 材料侧 | 不新增节点，继续省略材料侧和方向切换；materialSidePolicy=OMITTED_PENDING_RUNTIME_EVIDENCE，materialSideRisk=UNVERIFIED。drivingNodeCount 从实际 Elements.getarraysize() 获取；源码仍为7个节点。 |
| P0 / 3.7 创建与回读 | 保留 FEAT_CR_NO_OPTS，以维持基线行为；没有可靠依据可声称切换 UNDO_IF_FAIL 更安全。选项语义继续待证。创建返回或异常分别记录；特征4字段分别尝试回读并记录缺失原因。重生成后再次读取，4字段完整、重生成返回和钣金状态真才可生成 VERIFIED_CONVERSION_NOT_SAVED。 |
| P0 / 3.7 失败诊断 | 提交创建后若创建异常、空返回、重生成失败、钣金状态非真或身份回读不完整，尝试公开 ListChildOfFailedFeatures()。记录范围明确为“失败特征的子特征”，不是失败父特征全集。子特征逐项记录ID、名称、类型、状态，单字段失败不掩盖其他字段；诊断异常不替代原始错误。空列表不能证明没有失败特征。不自动删除、重试或保存。 |
| P0 / 3.8 兼容性 | 三旧命令注册、track/untrack、转换注册失败清理、detach、URL守卫、页面导航实际业务逻辑和服务启动保持基线。旧页面回调仅增加请求ID日志上下文，finally 恢复上下文。转换 busy/inactive/no-session 也有唯一ID，未取得 converting 标志的调用不会清除另一个调用的标志。 |
| P0 / 3.9 日志归组 | 每次原生转换及旧页面 OnCommand 生成新UUID。转换 nativeAudit、诊断异常和最终完成记录携带该ID；页面日志及其调用的守卫日志继承对应页面ID。启动/停止注册事件不属于某次命令调用，不伪造请求ID。最终trace包含mode、模型名/类型（读取前明确UNREAD）、路由、失败阶段、完成分类和elapsedMs。 |

## 无法由当前 SDK 返回接口自动实现的一项

`UIReadRealMessage` 只有返回值和抛异常接口。原生输入框可能拒绝某个值后继续等待，Java 此时没有收到任何返回，也没有原生“被拦截”事件签名。因此本包**不会自动写出 NATIVE_DIALOG_BLOCKED**，更不会伪造 Java INVALID_THICKNESS 事件。

该值保留为外部审核观察分类，使用 `evidence/native-input-observation-template.json` 记录真实对话框证据、同一requestId、会话标识和证据文件哈希。模板 executed=false，是未填写记录。即使用户被原生框拦截后最终输入有效值，Java记录仍为有效返回，外部记录可同时描述先前拦截过程，不覆盖Java事实。若验收要求代码自动识别原生内部拦截，必须另供事件API签名；本包不声称完成此能力。

## 状态行资源与输入风险

新增文本资源以 ASCII 编码保存，结构沿用已有消息资源的 key/正文/空行形式，独立文件名，不覆盖 `batchrename.txt`。提供所有调用键，不使用替换占位符。资源需由本机审核人员在隔离测试的消息资源搜索路径中安排，不能只编译 Java 后忽略该文件；本包不执行复制或安装。

UIDisplayMessage 的第三参数采用 null，表达“无替换参数”；未引入未经证实的 stringseq 工厂。**这不是已验证的SDK语义**：消息文件格式、资源搜索路径和 null 参数列表接受度仍需本机验证。创建前的单位提示或板厚提示不返回成功，则阻断树构造和创建；创建后的反馈失败只记录反馈降级，不抹去原生校验结果。日志中保留完整原因，模型可能改变时状态行明确要求检查特征树。

UIReadStringMessage(Boolean) 的签名来自已有 SessionUI.txt；Boolean.FALSE 的确切输入界面含义未提供，不能声称验证。只把返回的字符串按本包协议解释，不把它当SDK布尔确认按钮。单位声明对本次对象有效，输入后仍沿用基线激活对象/会话重查；不缓存至下一次命令。输入期间单位被外部改动、人工声明错误仍是风险。

UIReadRealMessage(double,double) 的两个参数仅有类型事实，仍沿用基线0.1、20；是否实际表达上下限须本机确认，Java范围校验始终保留。

Feature.GetStatus 的返回值只如实记录，并未把未知状态枚举映射为“健康”。当前成功分类表示既有钣金回读及四字段取得，不能替代真实特征状态语义、几何方向和模型健康验收。

## 文件范围

- 修改：BatchRename.java。
- 新增：独立状态行消息资源、统一补丁、审核说明、静态核对脚本、证据JSON和签名参考。
- Web：未改动、不重复打包；沿用上一候选。没有修改旧消息资源、现场配置、启动脚本、安装包或二进制Ribbon。
- 包中原有SDK文本dump为复制参考，未重新运行javap；reference/task.md为输入任务原文，不是额外执行权限。

## 实际验证与未执行事项

执行的只有 Python 文本静态断言，以及统一补丁 apply-check / 应用后字节核对和归档哈希检查。`evidence/static-claims.json` 是文本断言，不是Java语法或SDK兼容性验证。新增检查脚本可复核输入哈希、关键门禁顺序、旧函数文本保留、禁止调用和文件范围。

未执行：`javac`、`javap`、`node --check`、Java/SDK运行、Mock/Stub、HTTP测试、Creo真机操作、浏览器运行、现场加载、部署和发布。没有采用 pfcasync.jar；未生成任何字节码，Java 17目标需本机编译验证。

## 本机审核建议（本包未执行）

1. 核对基线和输出SHA256，针对基线在隔离源码目录应用补丁，核对源码字节。
2. 使用真实同步 otk.jar、`javac --release 17`，输出到隔离目录；记录退出码、所有class和major=61。不要输出到现场目录，不混入pfcasync.jar。
3. 静态扫描禁用API、元素ID和7节点一致性；核对旧三命令生命周期/URL守卫保持基线。Web未变，无新增JS需要本轮检查。
4. 先验证消息资源加载、状态行指引、字符串输入行为。覆盖单位MM、NON_MM、null、其他文本、输入异常与反馈失败；后三类不能出现树创建/特征创建。
5. 在同一候选会话验证三个旧页面命令；重现新命令取消或异常后再次点击旧按钮。旧版会话只作基线，不替代候选回归。
6. 覆盖板厚null、异常、Java范围拒绝、NaN/Infinity（若本机界面可产生）和正常值；原生拦截只能按实际证据补记。不可复现项标注未覆盖。
7. 单个临时mm实体的正向链路需同时有创建返回、重生成返回、IsSheetmetal=true、特征4字段、完成分类、同一请求ID日志和转换前后截图；不保存模型。检查featureStatus实际语义、材料侧/方向及几何结果。
8. 失败路径核对modelMayHaveChanged、公开失败子特征回读与原始异常共存；诊断失败不能覆盖原始失败码。不得将空子特征列表理解为模型无失败。实际创建失败的故障用例需单独受控安排。
9. 既有内部适配器、面owner反射、创建选项、材料侧省略、单位人工误确认、重启/卸载、Ribbon可见性均继续列入真机证据，不因静态断言通过而解除。

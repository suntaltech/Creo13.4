# SDK 依据与来源分级

本次未运行 javap。优先复用第六轮离线SDK输入包的现有文本dump（附于 javap-key/）；新任务单第2节提供的补充事实另列，不能冒称有本次重新生成的dump。

| 使用项 | 来源 | 说明 |
|---|---|---|
| UIDisplayMessage(String,String,stringseq)、UIReadStringMessage(Boolean)、UIReadRealMessage(double,double) | javap-key/SessionUI.txt | 编译签名事实；null参数列表、资源位置、Boolean参数和数值参数语义未知。 |
| ListChildOfFailedFeatures(): Features | javap-key/WSolid.txt | 公开API，记录子特征范围；Features数组式get/getarraysize需本机编译核对，未提供独立Features dump。 |
| Feature.GetFeatType / GetStatus，ModelItem.GetId / GetName | task.md第2节 | 新任务给出的签名事实；通过公开Feature接口反射逐字段调用，方法缺失/读取异常记录UnavailableReason。未伪造返回类型。 |
| WFeature继承Feature | javap-key/WFeature.txt | 可传给Feature元数据读取器。 |
| 内部GetSurfaceSolidBody(Surface): SolidBody | javap-key/internal_WSolid.txt | 实现类可选反射，方法访问权限和运行有效性待验证；非公开WSolid编译调用。 |
| WPart(long)、WSolid(long) | javap-key/internal_WPart.txt、internal_WSolid.txt | 保留基线适配器次序；反射内部构造仍有运行风险。 |
| WSession(long) | 基线代码及此前SDK引用 | 本次没有独立WSession构造dump；没有强化为新证据。 |
| Elements.getarraysize、create、append | javap-key/Elements.txt | 实际节点数来源，仍为基线7节点。 |
| FEAT_CR_NO_OPTS、FEAT_CR_UNDO_IF_FAIL等 | javap-key/FeatCreateOption.txt、task.md第2节 | 枚举存在不等于失败恢复语义已验证，维持NO_OPTS并标记未决。 |
| getptr | javap-key/jxobject_i.txt | 可选诊断与适配器/身份所需读取分开。 |
| 7个driving节点 | 前一候选与初始第六轮输入的驱动面树 | 本轮不新增节点；材料侧和方向节点省略仍未被官方语义证实。 |

没有可靠自动单位API来源；仅提供人工确认门禁。没有原生对话框拦截事件来源；NATIVE_DIALOG_BLOCKED需外部证据。未构造MessageDialogOptions或假定存在stringseq.create。

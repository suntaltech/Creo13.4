# P1 6A 第二轮最小整改任务单：给 ChatGPT 的补丁要求

日期：2026-11-03
基线：`P1_Round6A_LifecycleDiagnosticsFix_20261103` 输出源码
基线 `BatchRename.java` SHA256：`dde67be4f671a5d69abd5ef9a5dae0109424183feb966ef13c21f5b7a2df9abc`
前置基线（首个 6A）SHA256：`2827ee878b484c0cd530d40c1372b15dcd5768074cbf92a3a5c02d7189beffdf`

## 1. 本轮定位

本轮只要求 ChatGPT 生成**下一轮源码补丁候选**，用于本机离线编译、静态审核和后续受控真机准备。本轮不要求 ChatGPT 声称完成编译、真机运行、特征创建或发布。

目标是在上一版 6A 生命周期诊断补丁基础上，补齐失败分类、必需对象与可选诊断分级、单位门禁、面归属证据、元素树材料侧风险说明、失败特征回读和旧命令兼容性保护。

本轮不是：

1. 不实现装配批量转钣金 A4。
2. 不实现 6B 抽壳转换。
3. 不实现自动保存策略。
4. 不修改二进制 Ribbon 文件。
5. 不恢复浏览器消息监听或旧桥接写模型通道。
6. 不输出 class、rbn、dat、bat、jar 等运行产物。

## 2. 本机已核验的签名事实

以下签名来自本机 `otk.jar` 或解压 class 的 `javap`；编译层存在不等于运行时可用。

| 主题 | 已核验签名或事实 | 本轮要求 |
|---|---|---|
| 板厚输入 | `Session.UIReadRealMessage(double, double)` 返回 `java.lang.Double` 并声明 `jxthrowable` | 必须区分取消返回空值、抛出异常、Java 范围拒绝和原生输入框拦截，不能预设唯一完成码 |
| 模态消息框 | `Session.UIShowMessageDialog(String, MessageDialogOptions)`；`MessageDialogOptions` 接口未显示公开工厂方法 | 避免依赖空选项接受度；优先使用稳定非阻塞反馈或可构造选项，并说明选择依据 |
| 状态行消息 | `Session.UIDisplayMessage(String, String, stringseq)` | 可作为模态对话框不可用时的降级反馈；不要伪造不存在的 stringseq 工厂 |
| 创建选项枚举 | 存在 `FEAT_CR_NO_OPTS`、`FEAT_CR_UNDO_IF_FAIL`、`FEAT_CR_FIX_MODEL_ON_FAIL`、`FEAT_CR_DEFINE_MISS_ELEMS` 等枚举 | 必须说明最终选项选择依据；不能在无运行证据时假定 `FEAT_CR_NO_OPTS` 语义充分 |
| 失败特征 | 公开 `WSolid.ListChildOfFailedFeatures()`；内部实现类另有 `ListFailedFeatures()` 可见性线索 | 主链路优先使用公开 API；内部 API 只能作为可选反射诊断并记录路由 |
| 特征身份 | `ModelItem.GetId()`、`ModelItem.GetName()`；`Feature.GetFeatType()`、`Feature.GetStatus()` | 成功或失败回读都应记录可获得的身份和状态字段 |
| 面归属 | 公开 `WSolid` 接口未声明 `GetSurfaceSolidBody(Surface)`；内部 `wfcSolid$WSolid` 实现类可见该方法线索 | 不得在公开类型上直接编译调用；只能作为可选反射增强，ID 列表匹配继续作为降级方案 |
| 长度单位 | 本机 `pfcModel.Model` 接口未发现直接长度单位 getter | 不得编造单位 API；要么给出 javap 可验证依据，要么保留显式人工确认门禁并阻断未确认输入 |
| 元素树 | `wfcElementTree.Element_Create(int, ArgValue, int)` 可编译构造；`WSession.CreateElementTree(Elements)` 为主链路 | 新增节点必须有官方 ID 和参数类型依据，禁止臆造 `ArgValue` |

## 3. 必须完成的最小整改项

### 3.1 适配器包装与必需对象分级

要求：

1. 保留“公开 `WSolid` 可直接使用则优先”的顺序。
2. 反射包装按 `wfcPart$WPart(long)`、`wfcSolid$WSolid(long)` 顺序尝试，记录 `solidAdapterRoute`、`sessionAdapterRoute`。
3. 必需对象为空时才判失败，包括 WFC 视图为空、默认体为空、选中面为空、元素树为空、创建特征为空。
4. `PointerUnavailable` 只表示可选指针诊断失败；对象 `Present=true` 且 `Class` 可读取时，不得仅因指针不可读判转换失败。
5. 禁止恢复 `pfcPart$Part` 到 `wfcSolid.WSolid` 的直接强转。

建议日志字段：

- `solidAdapterRoute`
- `sessionAdapterRoute`
- `solidViewPresent`、`solidViewClass`
- `defaultBodyPresent`、`defaultBodyClass`
- `selectedFacePresent`、`selectedFaceClass`
- `elementTreePresent`、`elementTreeClass`
- `createdFeaturePresent`、`createdFeatureClass`
- `diagnosticPointerFailedKeys`

### 3.2 用户反馈通道不依赖未证实的 null 选项

要求：

1. 评估是否可改用 `UIDisplayMessage` 状态行反馈，减少对 `UIShowMessageDialog(message, null)` 的依赖。
2. 如果继续使用 `UIShowMessageDialog`，必须使用可由 SDK 支持构造的 `MessageDialogOptions`，并在补丁说明中给出构造来源；不能只写“预计 null 可用”。
3. 反馈通道失败只影响提示质量时，不得改变原生校验结论；若提示失败发生在创建前，应保持不提交创建。
4. 不要为了对话框反馈新增后台线程、浏览器监听或阻塞式重试。

### 3.3 板厚输入的 SDK 真实行为分类

要求：

1. 单独记录 `thicknessInputOutcome`，取值至少覆盖：`CANCEL_NULL_RETURNED`、`THROWN_EXCEPTION`、`INVALID_RANGE_REJECTED`、`NATIVE_DIALOG_BLOCKED`、`VALID_FINITE_POSITIVE`、`UNCLASSIFIED`。
2. `entered == null` 时记录取消，不提交创建；外层完成码必须与真实原始结果一致，不得把取消固定写成未经验证的另一类错误。
3. `UIReadRealMessage` 抛出异常时，记录 `exceptionClass`、异常消息和 `failedPhase=THICKNESS_INPUT_FAILED`，不得吞掉后假装成功。
4. 非法值若被原生输入框在 Java 校验前拦截，记录为 `NATIVE_DIALOG_BLOCKED`；不要补写伪造的 Java `INVALID_THICKNESS` 执行事实。
5. 合法值仍必须满足有限正数、大于等于 0.1、小于等于 20.0；不得用包围盒尺寸估算板厚。

### 3.4 单位门禁

要求：

1. 不要编造 `Model` 单位 getter。若 ChatGPT 能从 SDK 签名或官方文档找到可靠单位读取方法，必须附签名来源。
2. 在未取得可靠自动单位读取能力前，增加显式单位门禁状态：`UNIT_GATE_CONFIRMED_MM`、`UNIT_GATE_UNKNOWN_REQUIRED`、`UNIT_GATE_NON_MM_BLOCKED`。
3. `UNIT_GATE_UNKNOWN_REQUIRED` 或 `UNIT_GATE_NON_MM_BLOCKED` 时，不得构造元素树，不得调用 `WCreateFeature`。
4. 原提示文字只能作为告知，不能代替门禁状态；最终成功日志不得写“系统已自动确认 mm”。
5. 若实现为人工确认确认框，必须说明使用的 SDK 方法、返回值含义和失败分支。

### 3.5 面归属证据增强

要求：

1. 保留默认体 `ListSurfaces()` 的 ID 匹配降级路径。
2. 可选尝试内部实现类上的 `GetSurfaceSolidBody(Surface)` 反射调用；因为公开 `WSolid` 接口不声明该方法，不得通过公开编译类型直接调用。
3. 记录 `faceOwnershipRoute`：`NATIVE_SOLID_BODY_CALLBACK`、`SURFACE_ID_FALLBACK`、`OWNERSHIP_DIAGNOSTIC_UNAVAILABLE`。
4. ID 匹配只能作为辅助证据；若原生 owner 调用不可用，应在 `faceOwnershipRisk` 中保留未证实标注，不能反向证明强归属。
5. 可见性、平面类型、同模型、有效面积仍保持硬校验。

### 3.6 材料侧元素树策略必须显式说明

要求：

1. 6A 继续只走 driving 驱动面树，禁止加入抽壳节点 `PRO_E_SHELL_SRF`。
2. 对 `PRO_E_STD_MATRLSIDE` 和 `PRO_E_STD_SMT_SWAP_DRV_SIDE` 给出明确策略：
   - 若官方资料确认省略可接受，记录 `materialSidePolicy=OMITTED_ACCEPTED_BY_DOC` 并附来源说明。
   - 若无法确认，保留省略，但记录 `materialSideRisk=UNVERIFIED`；真机拒绝时不得记成功。
3. 若新增材料侧节点，必须提供元素 ID、参数类型、建议取值和官方依据；禁止无依据调用 `CreateBoolArgValue`、`CreateIntArgValue` 或其他 `ArgValue`。
4. 树节点数量必须与实际代码一致；成功日志不得继续写固定 7 节点，而代码已经变化。

### 3.7 创建选项、失败特征回读和成功回读

要求：

1. 说明最终创建选项选择 `FEAT_CR_NO_OPTS` 还是 `FEAT_CR_UNDO_IF_FAIL` 的依据；两者枚举均存在，但语义需真机或官方文档补证。
2. 调用 `WCreateFeature` 后记录 `featureReturnState`、`createdFeaturePresent`、`createdFeatureClass`。
3. 成功路径必须读取并记录：`featureId`、`featureName`、`featureFeatType`、`featureStatus`；字段不可得时记录缺失原因，不得伪造 ID。
4. 异常、空返回或 `IsSheetmetal()` 非真时，尝试通过公开 `ListChildOfFailedFeatures()` 记录失败特征 ID、名称和状态；内部 `ListFailedFeatures()` 只能作为可选反射诊断。
5. 若已经提交创建但后续重生成或状态回读失败，必须设置 `modelMayHaveChanged=true` 并明确提示用户检查特征树；不得自动保存、不得自动删除、不得静默重试覆盖。
6. `WRegenerate` 调用后必须确认返回；缺失 `regenerationReturned` 不得记成功。

### 3.8 旧三命令兼容性

要求：

1. 候选会话内必须保持 `SISWBatchRename`、`SISWSheetMetal`、`SISWAbout` 可触发原有页面导航或守卫提示。
2. 新增候选命令不得改变三个旧命令的注册生命周期、URL 守卫和前端职责。
3. `trackCommand` 与 `untrackCommand` 继续按引用身份成对维护；注册失败时记录禁用原因、清理动作和是否仍需停止阶段重试。
4. 禁止让候选命令异常影响旧命令按钮响应；异常应被捕获并记录阶段。
5. 代码不要要求旧版独立会话日志代替候选会话内的兼容性验证。

### 3.9 requestId 全链路归组

要求：

1. 每次 `OnCommand` 生成唯一 `requestId`。
2. 所有 `nativeAudit`、异常日志和最终 `completionClass` 必须携带同一 `requestId`。
3. 日志字段按同一 `requestId` 归档；不同命令、不同会话、不同运行次的字段不得互相拼接。
4. 最终 trace 中同时记录 `mode=driving`、模型名、模型类型、适配器路由、阶段码、完成码和 `elapsedMs`。

## 4. 禁止项

1. 禁止调用 `Save()` 或任何自动保存 API。
2. 禁止实现抽壳 `PRO_E_SHELL_SRF` 分支。
3. 禁止恢复 `AddBrowserMessageListener`。
4. 禁止使用 `window.external`、`sisw-smt` bridge action 或 CREOSON 写模型接口。
5. 禁止直接修改或手写二进制 `toolkitribbonui.rbn`。
6. 禁止输出 `.class`、`.rbn`、`.dat`、`.bat`、`.jar` 产物。
7. 禁止把本机隔离编译结果写成 ChatGPT 已完成编译；实际编译由本机审核执行。
8. 禁止声称 `WCreateFeature`、`WRegenerate` 或 `IsSheetmetal()` 真机成功，除非提交真实日志和特征 ID。
9. 禁止使用 `pfcasync.jar` 编译。
10. 禁止使用高于 Java 17 的字节码目标；本机审核统一使用 `--release 17`。
11. 禁止改动现场 `D:\creo-tools\jlink\classes`、现场 Web 目录、`config.pro`、启动脚本和安装包输出。
12. 禁止在没有官方依据时新增材料侧、方向切换、自动圆角或自动选面节点。

## 5. 期望补丁包结构

ChatGPT 输出建议采用离线补丁包形式：

```text
P1_6A_R2_MinimalFix_Candidate_YYYYMMDD/
  BatchRename.java
  P1_6A_R2_MinimalFix.patch
  REVIEW.md
  evidence/
    static-claims.json
    unresolved-risks.json
  reference/
    sdk-signatures.md
```

允许且鼓励包含 `web/` 只读文案修正，但必须逐项说明；若无必要，本轮保持 Web 文件不变。

`REVIEW.md` 必须包含：

1. 输入基线文件 SHA256。
2. 修改清单和每个修改对应的 P0/P1 目标。
3. 未运行命令清单：`javac`、`javap`、`node --check`、Creo 真机操作、浏览器运行均未执行。
4. 未决运行时风险清单。
5. 本机审核应执行的编译、静态扫描和真机用例建议。
6. 明确声明：补丁仅为代码候选，不代表可部署、可发布或转换已成功。

## 6. 本机审核标准

助手收到候选后执行以下离线检查，不代替真机验收：

| 检查项 | 通过要求 |
|---|---|
| 真实 SDK 编译 | 使用本机 `otk.jar` 和 `--release 17`，退出 0，class major=61 |
| 禁止 API 扫描 | 不出现 `Save()` 写保存、`AddBrowserMessageListener`、`window.external`、抽壳节点、现场目录覆盖逻辑 |
| 编译范围 | 不混入 `pfcasync.jar`，不输出 class 到现场 |
| 静态结构 | `requestId`、适配器路由、输入分类、单位门禁、失败特征回读字段齐备 |
| 兼容性 | 旧三命令注册和页面命令逻辑未被破坏 |
| 风险标注 | 材料侧、创建选项、null 对话框、内部适配器、面归属均保留未决标注 |
| 部署结论 | 离线通过不等于真机通过；不得发布 |

## 7. 复制即用的 ChatGPT 提示词

```text
你是 Creo J-Link 6A 驱动面转钣金的代码生成候选，不运行编译、不运行 Creo、不声称真机成功。
输入基线为 BatchRename.java，SHA256=dde67be4f671a5d69abd5ef9a5dae0109424183feb966ef13c21f5b7a2df9abc。
本轮只做最小整改：适配器对象分级、板厚输入 SDK 行为分类、显式单位门禁、面归属路由、材料侧风险说明、失败特征回读、requestId 全链路日志和旧三命令兼容性保护。
继续禁止 Save、抽壳分支、AddBrowserMessageListener、window.external、现场目录修改、rbn 修改、输出 class/rbn/dat/bat/jar。
UIReadRealMessage(double,double) 返回 Double；取消可能为空，也可能抛异常，必须分类记录。
不要依赖未证实的 UIShowMessageDialog(null) 选项；优先评估 UIDisplayMessage 或合法 MessageDialogOptions 构造。
公开 WSolid 接口没有 GetSurfaceSolidBody；内部实现类线索只能做可选反射诊断，不能直接公开调用。
材料侧节点若新增，必须给出官方 ID、参数类型和依据；无法确认时保留省略并标注 materialSideRisk=UNVERIFIED。
成功日志必须包含 featureId、featureName、featureFeatType、featureStatus；缺失不得伪造。
输出统一源码、统一 patch、REVIEW.md、static-claims.json 和 unresolved-risks.json；明确列出未执行的 javac、javap、node、Creo 真机检查。
```

## 8. 本轮完成后仍未解除的真机前提

1. 内部 `WPart`、`WSolid`、`WSession` 包装对象运行时行为仍需真机验证。
2. `FEAT_CR_NO_OPTS` 或 `FEAT_CR_UNDO_IF_FAIL` 的最终语义仍需真机证据。
3. 材料侧省略是否被 Creo 接受仍需真机证据。
4. 面归属强证明 API 仍未闭环。
5. 单位自动读取若未取得可靠 SDK 依据，仍需显式人工确认门禁。
6. 发布级 Ribbon 命令可见性仍需 Creo 原生导出和回归。
7. 候选会话内旧三命令兼容性仍需真机截图和日志。

本任务单只规定下一轮补丁目标、证据要求和禁止边界；不构成对任何真机转换结果的批准。

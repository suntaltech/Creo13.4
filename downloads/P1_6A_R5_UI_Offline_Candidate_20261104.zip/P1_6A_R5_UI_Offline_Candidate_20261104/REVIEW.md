# P1 6A R5 UI Offline 离线审核材料候选

日期：2026-11-04。R5是候选轮次，不是正式发布版本，未升级产品版本号。

固定边界：未编译、未加载、未部署、未证明UI可见、未证明OTK可行、未证明真实转钣金可用。

## 文件改动白名单

允许变更：checks/*.py、evidence-template/*.json、docs/*.md、evidence/*.json、REVIEW.md、SHA256SUMS。

本轮不使用探针源码修改例外。BatchRename.java、三个探针、六份资源、三份注册模板共13个文件全部冻结为R4原字节。R4历史源码补丁P1_6A_R4_UI_Offline.patch也保留原字节以满足全包基线白名单核对；它是历史材料，不是R5更新补丁，本轮没有源码补丁或运行行为变更。

evidence/r4-baseline-files.json从实际R4 ZIP生成全部文件哈希；检查器固定其内容SHA256作为基线契约。对现有/新增/删除文件统一比较，不在上述白名单内的变化使outsideWhitelistChangedFiles检查失败。该契约只含候选文本文件哈希，没有class或运行证据哈希。

## 基线

R4 ZIP SHA256：`90a899170f80a90dd8c152ea6bdd0e1f99ce28428b7ccefb7fe508369cbbc893`。
冻结业务源码SHA256：`9dbd71f36e403c3ed1a027d810a70befb57d3973c67aedca821f7b31df802400`，与R3/R4一致。

输入整改单记载R4在本机有118/118静态、9/9反例及真实SDK/Java17隔离编译结果。R5不推翻这些已提供事实，但没有读取本机审核文件或重演其编译/运行。

## 两类事实严格分开

| 类别 | 本包口径 |
|---|---|
| candidateSelfCheck | 本轮实际执行的Python文本、JSON/schema、资源、模板、白名单、反例、字节和SHA清单检查。不是Java编译或UI结果。 |
| auditorLocalCompile | 由本机审核者使用真实同步otk.jar、--release 17独立执行，不属于候选自述。R5不含class，也不将R4 class哈希复制成R5编译证据。 |

编译期望见evidence/compile-expectations.json：release17、major61、业务4类、探针5类仅是基于冻结源码的审核期望；candidateCompiledItself=false、compilerExecutionOwner=LOCAL_AUDITOR_ONLY。它不是编译结果。

## 本轮改动与检查

- 保留R4全部118项断言及受保护块、模板、禁止调用与资源覆盖；R4扁平OTK前提的“未填”断言改为检查七个结构化条目，其余覆盖不降低。
- 新增整文件businessSourceByteFrozen、全包允许差异白名单、13文件冻结、探针递归只读边界扫描。
- token-fill-worksheet.json精确列出三份模板全部8个token及usedBy，不解析真实路径或值；模板字段、顺序、身份和双classpath占位符保持原样。
- 生成resource-manifest.json，列出两套6个文件的字节/SHA256/键数量；每项selectedLayout=false、runtimeLookupStatus=UNVERIFIED，resourceLookupVerified=false。
- 路线B前提改为七项结构化清单，默认UNVERIFIED且evidenceRefs为空；来源标记OFFICIAL_DOCUMENT_LOCATOR_FROM_AUDIT_NOT_CHATGPT_RESEARCH，不编造本机文档行号、许可、解锁或签名结果。
- runtime-evidence-schema.json增加机器上下文和来源/层级绑定：L1需SDK_OUTCOME和CLASS/LOG，L2需MACRO_CALLBACK和LOG，L3需MANUAL_UI和SCREENSHOT/LOG，L4需MANUAL_UI、SCREENSHOT及MANUAL_OPERATION_RECORD。聚合VERIFIED字段也必须有对应层观察条目，不能绕过来源约束。
- L5和featureCreated始终仅UNVERIFIED/NOT_APPLICABLE。runtimeEvidenceAuthenticated固定false，evidenceAuthenticity固定UNVERIFIED。schemaValidatedEvidence只描述形状状态；schema自检报告中shape验证true不等于runtime认证false。
- 新增未填runtime-evidence-skeleton.json及12项negative-case-plan.json。计划分类与Java实际码分开，不输出真实requestId、截图、日志路径或运行哈希。
- 增加只读check_package.py验证SHA256SUMS覆盖、内容及卫生，不改写文件。检查器报告无时间戳和临时路径，设计为可原样复跑的确定性输出。

## 冻结范围及路线边界

14个受保护块哈希继续与R4对照，整个业务文件字节相同。WCreateFeature/WRegenerate/IsSheetmetal等候选旧路径未执行，未改单位、板厚、面选择、归属、元素树、失败诊断、保存、抽壳、桥接或CREOSON启动行为。

UiExposureProbe.java原字节不变，所以不新增R5审计字段或声称已补充运行拒绝日志。R4三个策略、精确basename、显式neighbor和Info父菜单保持；只读探针不读取模型、调用特征、服务或浏览器。旧菜单返回仍NOT_MODERN_TOOLKIT_LIST_EVIDENCE，按ID区分按钮返回，不推断现代列表或固定按钮。

B仅只读注册探针，业务保持startup java。C4前提不足只记录BLOCKED_PREREQUISITES，不以A旧菜单替代。没有JAR构建、解锁、签名、许可命令或结论。

两套资源不合并，不选择优胜layout。UIDisplayMessage第三参数仍null，未添加stringseq.create()分支。资源静态一致性不证明text_dir运行解析。历史特定消息单次成功不外推全部上下文。

## Schema与反例的实际含义

checks/check_schema.py使用已有jsonschema校验器验证形状和分层条件；若环境没有该依赖，应记录无法执行而非宣称通过。本包不含安装命令。

条件单元用例仅使用kind标签检查来源/引用规则，不构造完整运行证据，不虚构文件路径、截图、日志或哈希。输出schema-check.json是候选自检报告，不是认证结果。完整UNVERIFIED骨架可以不附refs，VERIFIED/FAILED必须有refs；匹配种类与来源也不能认证内容真实性、许可或因果关系。

checks/check_checker.py的临时错误文件仅用于Python文本检查，不编译/执行Java，不把错误路径或禁止调用写入正式源码。原9个反例与新增7个反例均保留，覆盖字节哈希、白名单、清单误填、离线UI成功误填、绝对路径、重复键和探针特征调用。

## 生产保护

- `config.proUnchanged=true (design promise; ChatGPT cannot verify machine state)`
- `productionFilesUntouched=true (design promise)`

这两条是设计承诺，不是对本机状态的核验。历史R2受控配置恢复由本机操作者在另行授权后独立处理；本包不含config.pro片段、恢复/安装/卸载脚本、生产路径、写入说明或自动UI命令。

## 未执行事项

未执行javac、javap、jar、Creo、宏、进程查看、运行日志查看、许可查询、deployment、feature creation、HTTP/浏览器/SDK Mock或Stub。没有class/jar/dat/bat/rbn/html/js/log/截图、解锁文件、签名文件或许可满足声明。

候选自检通过只支持离线完整性。本机审核仍需独立编译与分层判定，L1/L2、L3/L4、OTK、L5和发布层不能由本轮结果升级。

## 本轮candidateSelfCheck结果

140/140主断言、16/16临时文本反例、25/25 schema形状断言通过；业务整文件与13个源码/资源/注册模板保持R4字节。白名单外变化为空。审核期望清单没有class哈希，路线B与运行证据骨架保持未填状态。这些结果不属于auditorLocalCompile，也不证明任何UI或转换行为。

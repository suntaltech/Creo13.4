# 负向用例计划（仅文档，不新增运行分支）

evidence-template/negative-case-plan.json的12项均为UNVERIFIED，不含requestId、截图、日志路径或哈希。expectedClassification是计划层标签，不是对当前Java错误码、failedPhase或completionClass的实测断言。未来须由操作者记录实际值，不把计划标签补写进原生日志。

| caseId | 计划停止点 | 计划分类 |
|---|---|---|
| NO_MODEL | 当前模型读取/无模型门禁 | READ_MODEL_FAILED |
| NOT_PART | 模型类型门禁 | MODEL_TYPE_BLOCKED |
| ALREADY_SHEETMETAL | 默认体已是钣金 | ALREADY_SHEETMETAL |
| NO_SELECTED_FACE | 选择数量为0 | NO_SELECTED_FACE |
| TOO_MANY_FACES | 多个选择 | TOO_MANY_FACES |
| SELECTED_FACE_INVALID | 对象/可见性/面积无效 | SELECTED_FACE_INVALID |
| SELECTED_NOT_PLANE | 非平面 | SELECTED_NOT_PLANE |
| SELECTED_FACE_OTHER_BODY | 默认体归属不符 | SELECTED_FACE_OTHER_BODY |
| UNIT_BLOCK | 单位人工门禁未通过 | UNIT_GATE_BLOCKED |
| THICKNESS_CANCEL | 板厚取消的返回或抛异常路径 | THICKNESS_CANCELLED |
| INVALID_THICKNESS | 原生拦截或Java有限数/范围校验 | INVALID_THICKNESS |
| CREOSON_UNAVAILABLE | 独立辅助页面服务观察 | AUXILIARY_SERVICE_UNAVAILABLE |

注意：现有源码中NOT_PART等是实际错误码，可能与计划标签不同；UNIT_BLOCK包含人工NON_MM、未知输入与异常等多个分支。板厚取消可能null返回或抛异常，必须按SDK事实分别记录；原生框内部拦截需外部观察，不能伪造Java范围拒绝。服务不可用是辅助页面的独立观察，不是原生转换函数现有的创建前门禁，不能凭服务不可用自动填写原生失败码。

这些用例不是可随意执行的自动测试。特别是业务类在全部门禁通过后存在冻结写模型路径；未来负向采集须保证目标输入在预定门禁停止，不能把“计划只读”当作对任意模型执行回调都只读的保证。所有计划禁止WCreateFeature、WRegenerate、Save；R5不执行，不提供宏或启动命令。

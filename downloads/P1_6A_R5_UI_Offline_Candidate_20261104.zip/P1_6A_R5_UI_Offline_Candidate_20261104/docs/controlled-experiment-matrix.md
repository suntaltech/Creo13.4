# R5只读受控实验矩阵（计划，未执行）

L1对象、L2触发、L3候选列表、L4固定按钮、L5创建分开。默认objectRegistered、macroDispatchable、uiListed、ribbonVisible、featureCreated均UNVERIFIED。对象API返回、编译通过、菜单API返回或宏进入回调都不能升级为L3/L4。

| 用例 | 入口身份/计划条件 | selectedLayout | textDirAbsoluteValue | messageFileSha256 | startupLine | resourceLookupStatus | restartedAfterLayoutChange |
|---|---|---|---|---|---|---|---|
| C1 | BatchRename / java / root | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED |
| C2 | 同一业务源码 / java / 仅换usascii资源 | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED |
| C3 | JLinkUiProbe / java / 一种旧菜单策略 | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED |
| C4 | OtkUiProbe / otk_java / 前提核对后 | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED |

一次会话只选择一种layout、startup与API路线。消息文件会话内只加载一次，资源/布局变化后必须重启。根目录和usascii子目录不合并，资源清单selectedLayout=false，不选择优胜目录。C1/C2比较时只变layout，使用同一冻结业务源码；C3/C4为不同身份/API实验，不能合并为单一因果链。

## 路线A三个策略（源码保持R4字节）

| policyId | menu | neighbor | parentMenu / menuNeighbor | UIAddMenu | 示例basename |
|---|---|---|---|---|---|
| FILE_EXPLICIT_NULL_NEIGHBOR | File | 显式null | 不适用 | 不调用 | RunDisplayExamples.java |
| APPLICATIONS_EXPLICIT_NEIGHBOR | Applications | Applications.psh_util_pproc | 不适用 | 不调用 | ParamEditor.java |
| CUSTOM_TOP_LEVEL_INFO_MENU | P1_UI_CUSTOM_MENU | 显式null | Info / 显式null | 先调用 | pfcExamplesMenu.java |

保留R4显式策略ID、菜单、neighbor及来源basename配置校验；未知配置拒绝，不接受绝对路径、后缀匹配、任意parent/neighbor或子菜单。拒绝后不继续添加菜单或按钮。

R5未改探针，因此不新增审计字段或声称已补齐新运行观测。原有policyId/menu/neighbor/parentMenu/menuNeighbor/uiAddMenuCalled/uiAddButtonReturned/sourceExampleBasename记录仅描述调用；uiAddButtonReturned按ID区分，不由前一按钮推断下一按钮。固定标签LEGACY_MENU_CALL_RETURNED; NOT_MODERN_TOOLKIT_LIST_EVIDENCE; ACTUAL_LOCATION_UNVERIFIED继续保留。来源basename不是对本机示例原文的验证。

## 来源约束

- L1 VERIFIED需要SDK_OUTCOME与CLASS或LOG类型引用。
- L2 VERIFIED需要MACRO_CALLBACK与LOG引用；此枚举表示触发回调来源类别，不证明按钮可见。
- L3 VERIFIED需要MANUAL_UI与SCREENSHOT或LOG引用，Designate RETURNED不能单独满足。
- L4 VERIFIED需要MANUAL_UI，refs同时包含SCREENSHOT及MANUAL_OPERATION_RECORD。
- L5只允许UNVERIFIED/NOT_APPLICABLE。Schema和文件哈希只校验形状/完整性，不认证内容来源或许可。

C4缺前提只能BLOCKED_PREREQUISITES，不以C3替代。业务NO_MODEL等观察须另按负向计划采集；只读探针不调用模型或业务转换。配置恢复由本机操作者在另行授权后安排，本包不处理历史受控配置状态。

# 模板与token工作表

三份注册模板与R4逐字节相同，仅保留占位符，不生成真实dat。业务/A分别为BatchRename/JLinkUiProbe及startup java；B为OtkUiProbe及startup otk_java、toolkit object、creo_type parametric。不得混用身份。

`evidence-template/token-fill-worksheet.json`逐token列出usedBy、用途、操作者归属、runtimeStatus=UNVERIFIED、mustBeFilledBeforeRuntime与允许值类别。模板中的token与工作表必须精确双向对应，工作表无已解析路径或值字段。

| token类别 | 填写责任与约束 |
|---|---|
| DAT_NAME | 独立受控应用名，由操作者提供 |
| 隔离业务/探针class目录 | 仅受控目录，不能从候选推断已编译或已存在 |
| 应用JAR、官方otk.jar | 两个独立条目，B前提未满足前不填写成功状态 |
| ALLOW_STOP_TRUE | 操作者只在另行受控dat中填写true；模板本身保持占位 |
| DELAY_START_FALSE | 操作者只在受控dat中填写false；其他启动实验需单独记录 |
| 资源text目录 | 指定一种layout的受控目录；搜索语义仍待运行证据 |

不得填写生产路径、固定SDK安装路径或pfcasync.jar。模板不接受注释形式的本机路径。本文不是填写后的注册配置，不包含安装、切换、卸载或恢复命令。

包内SHA256SUMS覆盖除自身外全部文件。checks/check_package.py为只读校验，不重写清单。离线静态脚本的报告设计为确定性输出；原样复跑不应改变字节，若修改候选内容则原清单失效，须由候选作者重新交付，不能把旧哈希视为新证据。

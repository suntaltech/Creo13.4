"""Text-only source/resource consistency. Does not execute Java, SDK or runtime commands."""
from pathlib import Path
import hashlib,json,re,sys,fnmatch
out=Path(__file__).resolve().parents[1]; baseline=Path(sys.argv[1]); s=(out/'BatchRename.java').read_text(); b=baseline.read_text()
checks={}; unresolved=[]
def check(name,value):checks[name]=bool(value)
def strip(text):
 return re.sub(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|//[^\n]*|/\*[\s\S]*?\*/',lambda m:''.join('\n' if c=='\n' else ' ' for c in m.group()),text)
def block(text,marker):
 clean=strip(text); start=text.index(marker); pos=clean.index('{',start); depth=1;i=pos+1
 while depth:
  depth+=(clean[i]=='{')-(clean[i]=='}');i+=1
 return text[start:i]
def split_args(text):
 parts=[];start=0;depth=0;quote=None;escape=False
 for i,c in enumerate(text):
  if quote:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c==quote:quote=None
  elif c in '\"\'':quote=c
  elif c in '([{':depth+=1
  elif c in ')]}':depth-=1
  elif c==',' and depth==0:parts.append(text[start:i].strip());start=i+1
 parts.append(text[start:].strip());return parts
def calls(text,name):
 clean=strip(text)
 for m in re.finditer(r'\b'+name+r'\s*\(',text):
  # String/comment matches are masked, declarations have '{' after their argument list.
  if not clean[m.start():m.start()+len(name)].strip():continue
  op=text.index('(',m.start());depth=1;i=op+1
  while depth:
   depth+=(clean[i]=='(')-(clean[i]==')');i+=1
  tail=text[i:].lstrip()
  if tail.startswith('throws ') or tail.startswith('{'):continue
  yield split_args(text[op+1:i-1])
def resolve(expr,env):
 expr=expr.strip()
 if re.fullmatch(r'"(?:\\.|[^"\\])*"',expr):return json.loads(expr)
 if expr in env:return env[expr]
 raise ValueError('unresolved expression: '+expr)
constants={m.group(1):json.loads(m.group(2)) for m in re.finditer(r'private static final String (\w+)\s*=\s*("(?:\\.|[^"\\])*")\s*;',s)}
check('baseline_sha256',hashlib.sha256(baseline.read_bytes()).hexdigest()=='9dbd71f36e403c3ed1a027d810a70befb57d3973c67aedca821f7b31df802400')
markers=['private static final class SmtConvertListener','private static final class ConversionFailure','private static Map<String,Object> convertPreselectedPlane','private static void verifyFaceInDefaultBody','private static boolean showConversionMessage','private static void requireConfirmedMillimetres','private static boolean readFeatureMetadata','private static void readFailedFeatureChildren','private static void ensureWfcSession','private static void recordNativeObject','private static long nativePointer','private static boolean sameModel','private static void addElement','private static void nativeAudit','private static void trackCommand','private static void untrackCommand','private static void detach','private static final class OpenPageListener','private static String guardedPageUrl','private static String detectActiveModelMode','private static String appendPageQuery','private static synchronized void ensureCreosonRunningAsync','private static WSession createWfcSession','public static void start()','public static void stop()']
for marker in markers:check('unchanged_'+marker.split('(')[0].split()[-1],block(s,marker)==block(b,marker))
a='    private static WSolid wrapAsWSolid(Model model)';z='    /** Reuse the baseline WSession'
check('solid_wrappers_unchanged',s[s.index(a):s.index(z)]==b[b.index(a):b.index(z)])
check('no_registry_placeholder_in_code','attach_selected_dat_and_classpath_manifest_from_test_operator' not in s)
check('parameterized_designate', 'command.Designate(messageFile, labelKey, helpKey, descriptionKey)' in s)
check('parameterized_audit',all('event.put("'+key+'", '+key+')' in s for key in ['messageFile','labelKey','helpKey','descriptionKey']))
check('audit_outcomes_are_separate',all(v in s for v in ['"ATTEMPT"','"RETURNED_NON_NULL"','"RETURNED"','"THROWN"']))
check('runtime_null_acceptance_unverified','RUNTIME_STRINGSEQ_ACCEPTANCE_UNVERIFIED' in s)
check('no_registration_evidence_promoted',all('event.put("'+key+'", "UNVERIFIED")' in s for key in ['objectRegistered','macroDispatchable','uiListed','ribbonVisible','featureCreated']))
# Expand the page-registration wrapper with the values from its actual call sites.
page=block(s,'private static UICommand registerPageCommand'); entries=[]
for args in calls(s,'registerPageCommand'):
 try:
  env=dict(constants)
  for name,index in [('commandId',0),('labelKey',2),('helpKey',3),('descriptionKey',4)]:env[name]=resolve(args[index],env)
  nested=list(calls(page,'designateUiCommand'))
  if len(nested)!=1:raise ValueError('page helper must designate once')
  vals=nested[0]
  values=[resolve(vals[i],env) for i in [0,1,3,4,5]]
  entries.append(dict(zip(['commandId','messageFile','labelKey','helpKey','descriptionKey'],values),usage='Designate'))
 except (ValueError,IndexError) as e:unresolved.append(str(e))
# Direct literal/constant calls outside the known page helper must resolve too.
without_page=s.replace(page,'')
for args in calls(without_page,'designateUiCommand'):
 try:
  values=[resolve(args[i],constants) for i in [0,1,3,4,5]]
  entries.append(dict(zip(['commandId','messageFile','labelKey','helpKey','descriptionKey'],values),usage='Designate'))
 except (ValueError,IndexError) as e:unresolved.append(str(e))
check('four_business_designate_sites_resolved',len(entries)==4 and not unresolved)
# Check all raw business Designate calls are routed through the parameterized helper.
check('single_raw_business_designate_call',len(list(calls(s,'Designate')))==1)
statefile=constants['CONVERSION_MESSAGES']; uifile=constants['MESSAGES']
# Six state literals are passed directly or selected by the feedback ternary, not inferred from resource keys.
statekeys=set(re.findall(r'"(P1_6A_[A-Z0-9_]+)"',s))
check('state_resource_separate',statefile!=uifile)
probe=(out/'probes/UiExposureProbe.java').read_text();pc=strip(probe)
check('explicit_neighbor_required','requiredPolicyValue("SISW_UI_PROBE_NEIGHBOR")' in probe)
check('route_a_allowlist',all(v in probe for v in ['requireEqual(menu, "File",','requireEqual(menu, "Applications",','requireEqual(menu, "P1_UI_CUSTOM_MENU",','ROUTE_A_MENU_POLICY_REJECTED','Applications.psh_util_pproc']))
check('custom_menu_creation_before_buttons',probe.index('session.UIAddMenu(')<probe.index('register(suffix)') and 'menuPolicy.createMenu' in probe)
check('custom_policy_parameters_explicit',all('requiredPolicyValue("'+v+'")' in probe for v in ['SISW_UI_PROBE_PARENT_MENU','SISW_UI_PROBE_MENU_NEIGHBOR','SISW_UI_PROBE_SOURCE_EXAMPLE']))
check('no_default_null_button_neighbor','session.UIAddButton(command, menuPolicy.menu, menuPolicy.neighbor,' in probe and 'UIAddButton(command, menu, null' not in probe)
check('legacy_not_modern','LEGACY_MENU_CALL_RETURNED; NOT_MODERN_TOOLKIT_LIST_EVIDENCE' in probe)
check('probe_readonly',not re.search(r'\.(?:GetActiveModel|GetCurrentModel|WCreateFeature|WRegenerate|Save|OpenFile|Navigate|CreateModelItemSelection)\s*\(',pc) and 'BatchRename.' not in pc)
check('probe_b_no_button_fallback','if ("B".equals(route))' in probe and 'NOT_REQUESTED_ROUTE_B' in probe)
check('probe_observation_defaults',all(k+'=UNVERIFIED' in probe for k in ['objectRegistered','macroDispatchable','uiListed','ribbonVisible','featureCreated']))
check('probe_example_sources',all(n in probe for n in ['RunDisplayExamples.java','ParamEditor.java','pfcExamplesMenu.java']))
# The finite route/suffix generator is validated before expanding its actual key expressions.
check('supported_probe_key_generator','String key = "P1_UI_" + route + "_" + suffix.toUpperCase(java.util.Locale.ROOT);' in probe)
m=re.search(r'for \(String suffix : new String\[\] \{([^}]+)\}',probe)
suffixes=re.findall(r'"([A-Za-z]+)"',m.group(1)) if m else []
check('four_probe_suffixes',len(suffixes)==4 and len(set(suffixes))==4)
probe_entries=[]
for mode in ['A','B']:
 for suffix in suffixes:
  base='P1_UI_'+mode+'_'+suffix.upper()
  item={'commandId':'SISWUIProbe'+mode+suffix,'messageFile':'p1_6a_ui_probe.txt','labelKey':base+'_LABEL','helpKey':base+'_HELP','usage':'UIAddButton' if mode=='A' else 'Designate'}
  if mode=='B':item['descriptionKey']=base+'_DESC'
  probe_entries.append(item)
references={uifile:{},statefile:{},'p1_6a_ui_probe.txt':{}}
for item in entries+probe_entries:
 for role in ['labelKey','helpKey','descriptionKey']:
  if role in item:references[item['messageFile']].setdefault(item[role],[]).append({'commandId':item['commandId'],'role':role,'usage':item['usage']})
for key in statekeys:references[statefile][key]=[{'commandId':'SISWSheetMetalConvert','role':'status','usage':'UIDisplayMessage'}]
for key,usage in [('P1_UI_PROBE_CALLBACK','UIDisplayMessage'),('P1_UI_CUSTOM_MENU','UIAddMenu')]:
 check('probe_literal_reference_'+key,'"'+key+'"' in probe)
 references['p1_6a_ui_probe.txt'][key]=[{'commandId':'READONLY_PROBE','role':'callbackStatus' if usage=='UIDisplayMessage' else 'customMenuLabel','usage':usage}]
coverage={'scope':'text source/reference coverage; not runtime message lookup','businessCommands':entries,'probeCommands':probe_entries,'unresolvedSourceExpressions':unresolved,'layouts':[]}
for layout,folder in [('root-layout',out/'resources/root-layout/text'),('usascii-layout',out/'resources/usascii-layout/text/usascii')]:
 item={'layout':layout,'files':[],'missingKeys':[],'unreferencedKeys':[],'missingFiles':[]};allkeys=[]
 paths={p.name:p for p in folder.glob('*.txt')}
 for name in references:
  if name not in paths:item['missingFiles'].append(name)
 for name,p in sorted(paths.items()):
  lines=p.read_text(encoding='ascii').splitlines();keys=lines[::4];lookup={key:i*4+1 for i,key in enumerate(keys)}
  check('filename_'+layout+'_'+name,bool(re.fullmatch(r'[a-z0-9_]+\.[a-z]{3}',name)) and len(name)<=30)
  check('four_lines_'+layout+'_'+name,len(lines)%4==0 and all(re.fullmatch(r'[A-Z0-9_]+',k) for k in keys) and all(lines[i+1].strip() and lines[i+3]=='' for i in range(0,len(lines)-3,4)))
  allkeys+=keys
  expected=references.get(name,{})
  rows=[{'key':key,'file':name,'layout':layout,'line':lookup.get(key),'missing':key not in lookup,'sourceReferences':uses} for key,uses in sorted(expected.items())]
  item['missingKeys'] +=[{'file':name,'key':key} for key in expected if key not in lookup]
  item['unreferencedKeys'] +=[{'file':name,'key':key} for key in keys if key not in expected]
  item['files'].append({'file':name,'role':'UI_DESIGNATE' if name==uifile else 'CONVERSION_STATUS' if name==statefile else 'READONLY_UI_PROBE','lines':len(lines),'keys':len(keys),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'coverage':rows})
 check('keys_unique_'+layout,len(allkeys)==len(set(allkeys)))
 check('coverage_no_missing_'+layout,not item['missingKeys'] and not item['missingFiles'])
 check('coverage_no_unreferenced_'+layout,not item['unreferencedKeys'])
 check('ui_status_disjoint_'+layout,not(set(references[uifile])&set(references[statefile])))
 coverage['layouts'].append(item)
for name in references:
 check('layout_identical_'+name,(out/'resources/root-layout/text'/name).read_bytes()==(out/'resources/usascii-layout/text/usascii'/name).read_bytes())
for p in [out/'BatchRename.java',*sorted((out/'probes').glob('*.java'))]:
 code=strip(p.read_text());stack=[];pairs={')':'(',']':'[','}':'{'};ok=True
 for c in code:
  if c in '([{':stack.append(c)
  elif c in ')]}':
   if not stack or stack.pop()!=pairs[c]:ok=False;break
 check('balanced_delimiters_only_'+p.name,ok and not stack)
 check('forbidden_api_'+p.name,not re.search(r'\.(?:Save|AddBrowserMessageListener)\s*\(|window\.external|PRO_E_SHELL_SRF',code))
business_template=(out/'registration/business-java.dat.template').read_text();bt=(out/'registration/route-b-otk-java.dat.template').read_text()
check('business_remains_java','startup java\n' in business_template and 'otk_java' not in business_template)
check('b_separate_classpath_parts','@ABSOLUTE_APPLICATION_JAR_PATH@;@ABSOLUTE_OFFICIAL_OTK_JAR_PATH@' in bt and 'startup otk_java' in bt and 'java_app_class OtkUiProbe' in bt)
check('no_runtime_artifacts',not any(p.suffix.lower() in {'.class','.jar','.dat','.bat','.rbn','.html','.js'} for p in out.rglob('*') if p.is_file()))

# R4 additions: preserve earlier coverage while freezing the entire business source.
check('business_file_fully_frozen',s==b)
protected=[]
def protected_record(name,old,new):
 normal=lambda text:text.replace('\r\n','\n').replace('\r','\n')
 record={'name':name,'unchanged':old==new,'normalization':'line-endings-only; whitespace inside source preserved','baselineNormalizedSha256':hashlib.sha256(normal(old).encode()).hexdigest(),'candidateNormalizedSha256':hashlib.sha256(normal(new).encode()).hexdigest()}
 protected.append(record);check('protected_'+name,record['unchanged'])
for name,marker in [('SmtConvertListener.OnCommand','private static final class SmtConvertListener'),('convertPreselectedPlane','private static Map<String,Object> convertPreselectedPlane'),('verifyFaceInDefaultBody','private static void verifyFaceInDefaultBody'),('requireConfirmedMillimetres','private static void requireConfirmedMillimetres'),('addElement','private static void addElement'),('readFailedFeatureChildren','private static void readFailedFeatureChildren'),('showConversionMessage','private static boolean showConversionMessage'),('ensureCreosonRunningAsync','private static synchronized void ensureCreosonRunningAsync'),('detectActiveModelMode','private static String detectActiveModelMode'),('guardedPageUrl','private static String guardedPageUrl'),('appendPageQuery','private static String appendPageQuery')]:
 old=block(b,marker);new=block(s,marker)
 if name=='SmtConvertListener.OnCommand':old=block(old,'public void OnCommand()');new=block(new,'public void OnCommand()')
 protected_record(name,old,new)
def between(text,start,end):
 op=text.index(start);close=text.index(end,op);return text[op:close]
for name,start,end in [
 ('thicknessReadAndValidation','            phase = "THICKNESS_INPUT_FAILED";','            phase = "MODEL_RECHECK_FAILED";'),
 ('drivingElementTree','            phase = "TREE_CREATE_FAILED";','            phase = "CREATE_OPTIONS_FAILED";'),
 ('createRegenerateReadback','            phase = "CREATE_FEATURE_FAILED";','            trace.put("completionClass", "VERIFIED_CONVERSION_NOT_SAVED");')]:
 old=block(b,'private static Map<String,Object> convertPreselectedPlane');new=block(s,'private static Map<String,Object> convertPreselectedPlane');protected_record(name,between(old,start,end),between(new,start,end))
(out/'evidence/protected-blocks.json').write_text(json.dumps({'scope':'text freeze against supplied R3 source; not SDK execution','blocks':protected,'allFrozen':all(x['unchanged'] for x in protected)},indent=2)+'\n')
# Validate exact template order, mandatory values, unresolved placeholders and forbidden configuration.
configs={
 'business-java.dat.template': [('name','@DAT_NAME@'),('startup','java'),('java_app_class','BatchRename'),('java_app_classpath','@ABSOLUTE_ISOLATED_BUSINESS_CLASSES_DIRECTORY@'),('java_app_start','start'),('java_app_stop','stop'),('allow_stop','@ALLOW_STOP_TRUE@'),('delay_start','@DELAY_START_FALSE@'),('text_dir','@ABSOLUTE_SELECTED_RESOURCE_LAYOUT_TEXT_DIRECTORY@'),('end','')],
 'route-a-java.dat.template': [('name','@DAT_NAME@'),('startup','java'),('java_app_class','JLinkUiProbe'),('java_app_classpath','@ABSOLUTE_ISOLATED_PROBE_CLASSES_DIRECTORY@'),('java_app_start','start'),('java_app_stop','stop'),('allow_stop','@ALLOW_STOP_TRUE@'),('delay_start','@DELAY_START_FALSE@'),('text_dir','@ABSOLUTE_SELECTED_RESOURCE_LAYOUT_TEXT_DIRECTORY@'),('end','')],
 'route-b-otk-java.dat.template': [('name','@DAT_NAME@'),('startup','otk_java'),('toolkit','object'),('creo_type','parametric'),('java_app_class','OtkUiProbe'),('java_app_classpath','@ABSOLUTE_APPLICATION_JAR_PATH@;@ABSOLUTE_OFFICIAL_OTK_JAR_PATH@'),('java_app_start','start'),('java_app_stop','stop'),('allow_stop','@ALLOW_STOP_TRUE@'),('delay_start','@DELAY_START_FALSE@'),('text_dir','@ABSOLUTE_SELECTED_RESOURCE_LAYOUT_TEXT_DIRECTORY@'),('end','')]
}
production_pattern=r'(?i)[a-z]:[\\/]creo-tools[\\/]jlink(?:[\\/\s]|$)'
sdk_absolute_pattern=r'(?i)[a-z]:[\\/]Program Files[\\/]PTC[\\/]Creo 13\.4\.0\.0[\\/]Common Files[\\/]text[\\/]java[\\/]otk\.jar'
template_rows=[]
for filename,expected in configs.items():
 text=(out/'registration'/filename).read_text();lines=[line.strip() for line in text.splitlines() if line.strip()]
 actual=[tuple(line.split(None,1)) if len(line.split(None,1))==2 else (line,'') for line in lines]
 field_checks={field:{'expected':value,'present':sum(1 for key,_ in actual if key==field)==1,'valueMatches':(field,value) in actual} for field,value in expected}
 forbidden={'async_sdk':bool(re.search(r'(?i)pfcasync\.jar',text)),'absolute_windows_path':bool(re.search(r'(?i)[a-z]:[\\/]',text)),'production_root':bool(re.search(production_pattern,text)),'fixed_sdk_path':bool(re.search(sdk_absolute_pattern,text))}
 if filename!='route-b-otk-java.dat.template':forbidden.update({'otk_startup':('startup','otk_java') in actual,'toolkit_object':('toolkit','object') in actual})
 else:forbidden.update({'java_startup':('startup','java') in actual,'generic_classpath_placeholder':'@ABSOLUTE_ISOLATED_APPLICATION_JAR_AND_OFFICIAL_SDK_CLASSPATH@' in text})
 passed=actual==expected and not any(forbidden.values())
 row={'file':filename,'requiredFields':field_checks,'fieldOrderMatches':actual==expected,'forbiddenPatternsMatched':forbidden,'pass':passed};template_rows.append(row)
 check('template_exact_fields_'+filename,actual==expected)
 check('template_forbidden_patterns_'+filename,not any(forbidden.values()))
template_pass=all(row['pass'] for row in template_rows)
(out/'evidence/template-audit.json').write_text(json.dumps({'scope':'unresolved template text only; no dat loaded','templates':template_rows,'pass':template_pass},indent=2)+'\n')
# Calls are counted in executable Java tokens after comments/literals are masked.
patterns={'Save':r'\bSave\s*\(','AddBrowserMessageListener':r'\bAddBrowserMessageListener\s*\(','window.external':r'\bwindow\s*\.\s*external\b','PRO_E_SHELL_SRF':r'\bPRO_E_SHELL_SRF\b'}
forbidden_counts={key:0 for key in patterns};per_source=[];allowed_runtime_counts={'WCreateFeature':0,'WRegenerate':0,'IsSheetmetal':0}
for path in sorted(out.rglob('*.java')):
 clean=strip(path.read_text());counts={key:len(re.findall(pattern,clean)) for key,pattern in patterns.items()}
 for key,count in counts.items():forbidden_counts[key]+=count
 allowed={key:len(re.findall(r'\b'+key+r'\s*\(',clean)) for key in allowed_runtime_counts}
 for key,count in allowed.items():allowed_runtime_counts[key]+=count
 per_source.append({'file':path.relative_to(out).as_posix(),'forbiddenCallCounts':counts,'retainedCandidateCalls':allowed,'notExecuted':True})
check('recursive_forbidden_counts_zero',not any(forbidden_counts.values()))
(out/'evidence/forbidden-call-audit.json').write_text(json.dumps({'scope':'Java source text after masking literals/comments','forbiddenCallCounts':forbidden_counts,'sources':per_source,'retainedRuntimeCalls':allowed_runtime_counts,'notExecuted':True},indent=2)+'\n')
# Production paths are disallowed in candidate executable configuration/source; paths in diagnostics are not used as config.
unsafe_paths=[]
for path in sorted(out.rglob('*')):
 if path.is_file() and (path.suffix=='.java' or path.name.endswith('.dat.template')):
  text=path.read_text().replace('\\\\','\\')
  if re.search(production_pattern,text) or re.search(sdk_absolute_pattern,text):unsafe_paths.append(path.relative_to(out).as_posix())
check('no_production_paths_in_executable_config',not unsafe_paths)
check('no_config_pro_payload',not any(path.name.lower()=='config.pro' for path in out.rglob('*')))
check('route_a_three_exact_policy_ids',all(x in probe for x in ['FILE_EXPLICIT_NULL_NEIGHBOR','APPLICATIONS_EXPLICIT_NEIGHBOR','CUSTOM_TOP_LEVEL_INFO_MENU']) and 'CUSTOM_EXPLICIT_EXAMPLE_DECLARATION' not in probe)
check('route_a_no_source_path_suffix_matching','source.endsWith(' not in probe and '.replace(' not in block(probe,'private static MenuPolicy resolveMenuPolicy'))
check('route_a_fixed_info_parent','requireEqual(requiredPolicyValue("SISW_UI_PROBE_PARENT_MENU"), "Info", "parentMenu")' in probe and 'return new MenuPolicy("P1_UI_CUSTOM_MENU", null, true, "Info", null, source, id)' in probe)
check('route_a_fixed_basename_allowlist','pfcAsyncFullExample.java' not in probe and 'requireEqual(source, "pfcExamplesMenu.java", "sourceExampleBasename")' in probe)
check('route_a_required_diagnostics',all('"; '+field+'="' in probe for field in ['policyId','menu','neighbor','parentMenu','menuNeighbor','uiAddMenuCalled','uiAddButtonReturned','sourceExampleBasename']))

# Evidence templates are unfilled; schema constrains shape rather than asserting runtime facts.
schema=json.loads((out/'evidence-template/runtime-evidence-schema.json').read_text())
observation_properties=schema['properties']['observations']['items']['properties']
check('schema_observation_fields',all(key in observation_properties for key in ['commandId','messageFile','labelKey','helpKey','descriptionKey','designateReturned','menuApiName','menuPolicyId','feedbackApiArgument','evidenceRefs']))
check('schema_null_argument_field','NULL_STRINGSEQ' in observation_properties['feedbackApiArgument']['enum'])
check('schema_feature_outside_scope',set(schema['properties']['evidence']['properties']['featureCreated']['enum'])=={'UNVERIFIED','NOT_APPLICABLE'})
prereqs=json.loads((out/'evidence-template/route-b-prerequisite-checklist.json').read_text())
check('route_b_template_unfilled',prereqs.get('state')=='UNVERIFIED' and bool(prereqs.get('prerequisites')) and all(item.get('status')=='UNVERIFIED' and item.get('evidenceRefs')==[] for item in prereqs['prerequisites']))
check('no_screenshots_or_log_exports',not any(path.suffix.lower() in {'.png','.jpg','.jpeg','.bmp','.log'} for path in out.rglob('*') if path.is_file()))


# R5: immutable R4 baseline contract and exact change allowlist.
contract_path=out/'evidence/r4-baseline-files.json';contract_bytes=contract_path.read_bytes();contract=json.loads(contract_bytes)
check('baselineContractTrusted',hashlib.sha256(contract_bytes).hexdigest()=='7ba0af23a246705c9e0d555dde442a364f6b139cce0f92ae6e1431a8b8f5d39e')
allowed_diff=['checks/*.py','evidence-template/*.json','docs/*.md','evidence/*.json','REVIEW.md','SHA256SUMS']
current={path.relative_to(out).as_posix():hashlib.sha256(path.read_bytes()).hexdigest() for path in out.rglob('*') if path.is_file()}
changed_files=sorted(name for name in set(current)|set(contract['files']) if current.get(name)!=contract['files'].get(name))
outside_whitelist=[name for name in changed_files if not any(fnmatch.fnmatchcase(name,pattern) for pattern in allowed_diff)]
check('businessSourceByteFrozen',hashlib.sha256((out/'BatchRename.java').read_bytes()).hexdigest()=='9dbd71f36e403c3ed1a027d810a70befb57d3973c67aedca821f7b31df802400')
check('outsideWhitelistChangedFiles',not outside_whitelist)
frozen_names=['BatchRename.java','probes/JLinkUiProbe.java','probes/OtkUiProbe.java','probes/UiExposureProbe.java']+[path.relative_to(out).as_posix() for path in sorted((out/'resources').rglob('*.txt'))]+[path.relative_to(out).as_posix() for path in sorted((out/'registration').glob('*.dat.template'))]
frozen_files={name:current.get(name)==contract['files'].get(name) for name in frozen_names}
check('allSourceResourceTemplatesFrozen',all(frozen_files.values()) and len(frozen_files)==13)
# Recursive probe boundary, after comments/strings are masked; source freeze is a separate stronger guard.
probe_forbidden_pattern=r'(?i)\b(?:WCreateFeature|WRegenerate|IsSheetmetal|Save|Feature|Model|Shell|pfcasync|CREOSON|http|HttpClient|URLConnection|URL|ProcessBuilder)\b|java\s*\.\s*net'
probe_boundary={path.relative_to(out).as_posix():re.findall(probe_forbidden_pattern,strip(path.read_text())) for path in sorted((out/'probes').rglob('*.java'))}
check('probeReadOnlyBoundary',not any(probe_boundary.values()))
# All declared template tokens must have exactly one unfilled worksheet entry and exact usedBy mapping.
worksheet=json.loads((out/'evidence-template/token-fill-worksheet.json').read_text());token_usage={}
for path in sorted((out/'registration').glob('*.dat.template')):
 for token in re.findall(r'@[A-Z0-9_]+@',path.read_text()):token_usage.setdefault(token,set()).add(path.name)
worksheet_entries=worksheet.get('entries',[]);worksheet_by_token={entry.get('token'):entry for entry in worksheet_entries}
worksheet_valid=(worksheet.get('state')=='UNVERIFIED' and len(worksheet_entries)==len(worksheet_by_token) and set(token_usage)==set(worksheet_by_token))
for token,used_by in token_usage.items():
 entry=worksheet_by_token.get(token,{})
 worksheet_valid=worksheet_valid and set(entry.get('usedBy',[]))==used_by and entry.get('runtimeStatus')=='UNVERIFIED' and entry.get('owner')=='OPERATOR_CONTROLLED_SESSION' and entry.get('mustBeFilledBeforeRuntime') is True and bool(entry.get('allowedLiteralClass'))
check('templateTokenWorksheetComplete',worksheet_valid)
worksheet_text=json.dumps(worksheet)
check('tokenWorksheetNoResolvedPaths',not re.search(r'(?i)[a-z]:[\\/]|/(?:workspace|tmp|home|opt|usr)/',worksheet_text) and 'resolvedValue' not in worksheet_text)
template_absolute_files=[path.name for path in (out/'registration').glob('*.dat.template') if re.search(r'(?i)[a-z]:[\\/]|/(?:workspace|tmp|home|opt|usr)/',path.read_text())]
check('templateNoResolvedAbsolutePath',not template_absolute_files)
# Resource manifest describes byte integrity only and explicitly selects no winning layout.
resource_manifest=[];resource_unique=True
for layout,folder in [('root-layout',out/'resources/root-layout/text'),('usascii-layout',out/'resources/usascii-layout/text/usascii')]:
 for path in sorted(folder.glob('*.txt')):
  lines=path.read_text().splitlines();keys=lines[::4];resource_unique=resource_unique and len(keys)==len(set(keys))
  resource_manifest.append({'file':path.name,'path':path.relative_to(out).as_posix(),'layout':layout,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'keyCount':len(keys),'selectedLayout':False,'runtimeLookupStatus':'UNVERIFIED'})
check('resourceKeysUnique',resource_unique)
(out/'evidence/resource-manifest.json').write_text(json.dumps({'recordType':'OFFLINE_RESOURCE_BYTE_MANIFEST','resourceLookupVerified':False,'files':resource_manifest},indent=2)+'\n')
# Prevent runtime success and fabricated references in unfilled offline JSON skeletons (schema is a definition).
def walk_values(value):
 if isinstance(value,dict):
  for key,item in value.items():yield key,item;yield from walk_values(item)
 elif isinstance(value,list):
  for item in value:yield from walk_values(item)
context=json.loads((out/'evidence-template/registration-context.json').read_text())
skeleton=json.loads((out/'evidence-template/runtime-evidence-skeleton.json').read_text())
check('registrationEvidenceDefaults',all(context.get('evidence',{}).get(key)=='UNVERIFIED' for key in ['objectRegistered','macroDispatchable','uiListed','ribbonVisible','featureCreated']) and context.get('evidenceRefs')==[])
check('offlineSkeletonNoRuntimeSuccess',all(value.get('evidence',{}).get(key)=='UNVERIFIED' for value in [context,skeleton] for key in ['objectRegistered','macroDispatchable','uiListed','ribbonVisible','featureCreated']) and all(value.get('evidenceRefs')==[] for value in [context,skeleton]) and all(obs.get('status') not in {'VERIFIED','FAILED'} for obs in skeleton.get('observations',[])))
expected_prereqs={'APPLICATION_JAR','OFFICIAL_OTK_JAR_ON_CLASSPATH','UNLOCK_STATUS','SIGNATURE_STATUS','LICENSE_STATUS','REGISTRY_FIELDS','RESOURCE_LOOKUP'}
invalid_prereq_states={'PASS','BLOCKED_OK','LICENSE_OK','UNLOCKED','SIGNED','VERIFIED'}
prereq_items=prereqs.get('prerequisites',[])
route_b_unverified=(prereqs.get('state')=='UNVERIFIED' and prereqs.get('gateWhenMissing')=='BLOCKED_PREREQUISITES' and prereqs.get('noFallbackToRouteA') is True and {item.get('id') for item in prereq_items}==expected_prereqs and len(prereq_items)==7 and all(item.get('status')=='UNVERIFIED' and item.get('evidenceRefs')==[] and item.get('requiredEvidenceKinds') and item.get('officialDocLocator') for item in prereq_items))
route_b_unverified=route_b_unverified and not any(isinstance(value,str) and value in invalid_prereq_states for _,value in walk_values(prereqs))
check('routeBPrerequisitesRemainUnverified',route_b_unverified)
check('officialLocatorProvenance',prereqs.get('locatorOrigin')=='OFFICIAL_DOCUMENT_LOCATOR_FROM_AUDIT_NOT_CHATGPT_RESEARCH')
check('offlineSkeletonNoFabricatedEvidence',not any((key in {'requestId','sessionId','registrationId','sourceSha256','controlledDatSha256','candidateSourceSha256','sha256','path'} and isinstance(value,str) and value!='UNVERIFIED') or (key in {'refs','evidenceRefs','requestIds','classpathEntries'} and value!=[]) for item in [context,skeleton,prereqs] for key,value in walk_values(item)))
check('schemaAuthenticationNotPromoted',schema['properties']['runtimeEvidenceAuthenticated'].get('const') is False and schema['properties']['evidenceAuthenticity'].get('const')=='UNVERIFIED' and skeleton.get('runtimeEvidenceAuthenticated') is False and context.get('runtimeEvidenceAuthenticated') is False)
check('schemaMachineContextFields',all(key in schema['properties'] for key in ['creoVersion','javaCommand','controlledDatSha256','sourceSha256','classpathEntries','selectedLayout','textDir','runtimeEvidenceAuthenticated','evidenceAuthenticity']))
compiled_expectation=json.loads((out/'evidence/compile-expectations.json').read_text())
check('compileExpectationsOnly',compiled_expectation=={'recordType':'COMPILE_EXPECTATION_FOR_LOCAL_AUDITOR','candidateCompiledItself':False,'javaRelease':17,'expectedClassMajor':61,'businessSourceFile':'BatchRename.java','expectedBusinessClassCount':4,'expectedProbeClassCount':5,'runtimeSdkArtifact':'official_otk_jar','asyncSdkOnClasspath':False,'compilerExecutionOwner':'LOCAL_AUDITOR_ONLY','runtimeConclusionPromoted':False})
plans=json.loads((out/'evidence-template/negative-case-plan.json').read_text())
plan_fields={'caseId','expectedStage','expectedClassification','requiredObservationFields','prohibitedSdkCalls','status'}
check('negativePlansOnly',isinstance(plans,list) and len(plans)==12 and all(set(item)==plan_fields and item['status']=='UNVERIFIED' for item in plans))
forbidden_extensions={'.class','.jar','.dat','.bat','.rbn','.html','.js','.log','.png','.jpg','.jpeg','.bmp','.gif','.exe','.dll','.pfx','.p12','.pem','.key','.sig','.lic','.pyc'}
prohibited_files=[path.relative_to(out).as_posix() for path in out.rglob('*') if path.is_file() and path.suffix.lower() in forbidden_extensions]
check('packageHygieneNoRuntimeArtifacts',not prohibited_files)
check('tokenWorksheetFieldsUnfilled',set(worksheet)=={'recordType','state','entries'} and all(set(entry)=={'token','usedBy','purpose','owner','runtimeStatus','mustBeFilledBeforeRuntime','allowedLiteralClass'} for entry in worksheet_entries))
check('routeBBlockingRequirements',all(item.get('blocking') is (item.get('id')!='RESOURCE_LOOKUP') for item in prereq_items))
layer_rules=schema['properties']['observations']['items']['allOf']
source_rules={rule.get('if',{}).get('properties',{}).get('level',{}).get('const'):rule for rule in layer_rules if rule.get('if',{}).get('properties',{}).get('status',{}).get('const')=='VERIFIED'}
check('schemaLayerSourceBinding',all(source_rules.get(level,{}).get('then',{}).get('properties',{}).get('source',{}).get('const')==source and source_rules[level]['then']['properties'].get('refs') for level,source in [('L1_OBJECT','SDK_OUTCOME'),('L2_TRIGGER','MACRO_CALLBACK'),('L3_CANDIDATE_LIST','MANUAL_UI'),('L4_FIXED_BUTTON','MANUAL_UI')]))

(out/'evidence/change-whitelist.json').write_text(json.dumps({'scope':'hash comparison against immutable R4 archive manifest','allowedDiffFiles':allowed_diff,'outsideWhitelistChangedFiles':outside_whitelist,'frozenPayloadFiles':frozen_files,'businessSourceByteFrozen':checks['businessSourceByteFrozen']},indent=2)+'\n')

(out/'evidence/resource-coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
report={'scope':'text-only static checks; not Java compilation, UI verification or runtime evidence','baselineSha256':hashlib.sha256(baseline.read_bytes()).hexdigest(),'sourceSha256':hashlib.sha256((out/'BatchRename.java').read_bytes()).hexdigest(),'checks':checks,'allPassed':all(checks.values()),'templateAuditPass':template_pass,'protectedBlocksFrozen':all(x['unchanged'] for x in protected),'forbiddenCallCounts':forbidden_counts,'businessSourceByteFrozen':checks['businessSourceByteFrozen'],'allowedDiffFiles':allowed_diff,'outsideWhitelistChangedFiles':outside_whitelist,'runtimeCommandsNotExecuted':['javac','javap','jar','Creo','macro','deployment','feature creation','process inspection','runtime log inspection','license query'],'notExecuted':['javac','javap','jar','Creo','macro','deployment','feature creation','node --check','process inspection','runtime log inspection','browser','Mock/Stub']}
(out/'evidence/static-claims.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':sum(checks.values()),'total':len(checks),'failed':[k for k,v in checks.items() if not v],'unresolved':unresolved},ensure_ascii=False))
# Filename-only change summary avoids circular file-content digests in generated reports.
(out/'evidence/diff-summary.json').write_text(json.dumps({'baselineArchiveSha256':contract['archiveSha256'],'businessSourceByteFrozen':checks['businessSourceByteFrozen'],'allowedDiffFiles':allowed_diff,'outsideWhitelistChangedFiles':outside_whitelist,'modifiedPayloadFiles':[] if all(frozen_files.values()) else [name for name,unchanged in frozen_files.items() if not unchanged],'unchangedPayloadFiles':[name for name,unchanged in frozen_files.items() if unchanged],'UiExposureProbe.java':'BYTE_IDENTICAL_TO_R4' if frozen_files.get('probes/UiExposureProbe.java') else 'CHANGED','historicalR4Patch':'PRESERVED_BYTE_IDENTICAL; not an R5 patch','scope':'R5 changes checks, templates for evidence, documents and generated offline reports only'},indent=2)+'\n')
raise SystemExit(0 if report['allPassed'] else 1)

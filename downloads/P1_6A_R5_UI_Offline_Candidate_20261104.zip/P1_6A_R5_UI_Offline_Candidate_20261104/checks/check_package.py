"""Read-only SHA256SUMS coverage/integrity and package hygiene check. Writes no output files."""
from pathlib import Path,PurePosixPath
import hashlib,json,re,sys
out=Path(__file__).resolve().parents[1];manifest=out/'SHA256SUMS'
if not manifest.is_file():
 print(json.dumps({'pass':False,'reason':'SHA256SUMS not generated yet'}));raise SystemExit(1)
listed={};duplicates=[];invalid=[];mismatches=[]
for line in manifest.read_text().splitlines():
 pieces=line.split('  ',1)
 if len(pieces)!=2:invalid.append(line);continue
 digest,name=pieces;path=PurePosixPath(name)
 if not re.fullmatch('[a-f0-9]{64}',digest) or path.is_absolute() or '..' in path.parts or name=='SHA256SUMS':invalid.append(name);continue
 if name in listed:duplicates.append(name)
 listed[name]=digest
 if not (out/name).is_file() or (out/name).is_symlink() or hashlib.sha256((out/name).read_bytes()).hexdigest()!=digest:mismatches.append(name)
actual={p.relative_to(out).as_posix() for p in out.rglob('*') if p.is_file() and p.name!='SHA256SUMS'}
prohibited={'.class','.jar','.dat','.bat','.rbn','.html','.js','.log','.png','.jpg','.jpeg','.bmp','.gif','.exe','.dll','.pfx','.p12','.pem','.key','.sig','.lic','.pyc'}
artifacts=[p.relative_to(out).as_posix() for p in out.rglob('*') if p.is_file() and p.suffix.lower() in prohibited]
result={'scope':'read-only file integrity, not runtime verification','listedFiles':len(listed),'actualFiles':len(actual),'mismatchCount':len(mismatches),'mismatchedFiles':mismatches,'unlistedFiles':sorted(actual-set(listed)),'nonexistentListedFiles':sorted(set(listed)-actual),'duplicateEntries':duplicates,'invalidEntries':invalid,'prohibitedArtifacts':artifacts}
result['pass']=not any([mismatches,actual-set(listed),set(listed)-actual,duplicates,invalid,artifacts]);print(json.dumps(result,indent=2));raise SystemExit(0 if result['pass'] else 1)

"""Text-only checks. No Java compilation, SDK execution, Creo, browser or network."""
from pathlib import Path
import difflib, hashlib, json, re, sys, zipfile
out=Path(__file__).resolve().parents[1]
baseline=Path(sys.argv[1])
s=(out/'BatchRename.java').read_text(); b=baseline.read_text(); checks={}
def check(name,ok): checks[name]=bool(ok)
def strip(text):
 return re.sub(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|//[^\n]*|/\*[\s\S]*?\*/',lambda m:''.join('\n' if c=='\n' else ' ' for c in m.group()),text)
def block(text,marker):
 clean=strip(text); start=text.index(marker); pos=clean.index('{',start); depth=1; i=pos+1
 while depth:
  depth+=(clean[i]=='{')-(clean[i]=='}');i+=1
 return text[start:i]
check('baseline_hash',hashlib.sha256(baseline.read_bytes()).hexdigest()=='3ca71ceac03fc67c9a1f8cb1bee2a5cf4df2c421a7d910b9a42a915aef142c71')
markers=[
'private static final class SmtConvertListener', 'private static final class ConversionFailure',
'private static Map<String,Object> convertPreselectedPlane', 'private static void verifyFaceInDefaultBody',
'private static boolean showConversionMessage', 'private static void requireConfirmedMillimetres',
'private static boolean readFeatureMetadata', 'private static void readFailedFeatureChildren',
'private static void ensureWfcSession', 'private static void recordNativeObject', 'private static long nativePointer',
'private static boolean sameModel', 'private static void addElement', 'private static void nativeAudit',
'private static void trackCommand', 'private static void untrackCommand', 'private static void detach',
'private static final class OpenPageListener', 'private static String guardedPageUrl', 'private static String detectActiveModelMode',
'private static String appendPageQuery', 'private static synchronized void ensureCreosonRunningAsync',
'private static WSession createWfcSession', 'public static void start()', 'public static void stop()']
for marker in markers:
 check('unchanged_'+marker.split('(')[0].split()[-1],block(s,marker)==block(b,marker))
# The overloaded wrappers form one contiguous unchanged section.
a='    private static WSolid wrapAsWSolid(Model model)';z='    /** Reuse the baseline WSession'
check('both_solid_wrappers_unchanged',s[s.index(a):s.index(z)]==b[b.index(a):b.index(z)])
check('unique_conversion_designate_keys','command, "SISW_SMT_CONVERT_LABEL", "SISW_SMT_CONVERT_HELP", "SISW_SMT_CONVERT_DESC"' in s)
check('candidate_specific_command_resource','MESSAGES = "p1_6a_ui_commands.txt"' in s)
check('registration_stages_logged',all(x in s for x in ['"UICreateCommand"','"Designate"','"SetIcon"','"RETURNED_NON_NULL"','"messageFile"','MESSAGE_LOOKUP_UNVERIFIED']))
check('effective_registry_not_fabricated',s.count('UNVERIFIED_REGISTRY_NOT_READ')==4)
probe=(out/'probes/UiExposureProbe.java').read_text(); pc=strip(probe)
check('probe_no_model_or_conversion_api',not re.search(r'\.(?:GetActiveModel|GetCurrentModel|WCreateFeature|WRegenerate|Save|OpenFile|Display|Navigate)\s*\(',pc) and 'BatchRename.' not in pc)
check('probe_routes_no_fallback','if ("B".equals(route))' in probe and 'no alternate registration route attempted' in probe)
check('probe_menu_not_guessed','SISW_UI_PROBE_MENU' in probe and 'menu == null || menu.isBlank()' in probe)
check('probe_ids_distinct_from_business','"SISWUIProbe" + route + suffix' in probe)
check('probe_request_id','String requestId = UUID.randomUUID().toString()' in probe)
check('probe_wrapper_routes', 'UiExposureProbe.start("A")' in (out/'probes/JLinkUiProbe.java').read_text() and 'UiExposureProbe.start("B")' in (out/'probes/OtkUiProbe.java').read_text())
source_files=[out/'BatchRename.java',*sorted((out/'probes').glob('*.java'))]
for p in source_files:
 code=strip(p.read_text()); stack=[]; pairs={')':'(',']':'[','}':'{'}; ok=True
 for c in code:
  if c in '([{':stack.append(c)
  elif c in ')]}':
   if not stack or stack.pop()!=pairs[c]:ok=False;break
 check('balanced_delimiters_only_'+p.name,ok and not stack)
 check('no_forbidden_api_'+p.name,not re.search(r'\.(?:Save|AddBrowserMessageListener)\s*\(|window\.external|PRO_E_SHELL_SRF',code))
resources={}
for layout in ['root-layout','usascii-layout']:
 folder=out/'resources'/layout/'text'
 if layout=='usascii-layout':folder=folder/'usascii'
 allkeys=[]
 for p in sorted(folder.glob('*.txt')):
  lines=p.read_text(encoding='ascii').splitlines(); keys=lines[::4]
  ok=len(lines)%4==0 and all(re.fullmatch(r'[A-Z0-9_]+',k) for k in keys)
  ok=ok and len(keys)==len(set(keys)) and all(lines[i+1] and lines[i+2]=='' and lines[i+3]=='' for i in range(0,len(lines),4))
  check('four_lines_'+layout+'_'+p.name,ok)
  resources[str(p.relative_to(out))]={'lines':len(lines),'keys':len(keys),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
  allkeys.extend(keys)
 check('unique_keys_across_files_'+layout,len(allkeys)==len(set(allkeys)))
for name in ['p1_6a_ui_commands.txt','p1_6a_r2.txt','p1_6a_ui_probe.txt']:
 check('identical_resource_variants_'+name,(out/'resources/root-layout/text'/name).read_bytes()==(out/'resources/usascii-layout/text/usascii'/name).read_bytes())
# Status text is identical to R2; only group padding changes.
if len(sys.argv)>2:
 with zipfile.ZipFile(sys.argv[2]) as z:
  old=z.read(next(n for n in z.namelist() if n.endswith('/text/p1_6a_r2.txt'))).decode('ascii').splitlines()
 now=(out/'resources/root-layout/text/p1_6a_r2.txt').read_text().splitlines()
 check('status_text_unchanged',{old[i]:old[i+1] for i in range(0,len(old),3)}=={now[i]:now[i+1] for i in range(0,len(now),4)})
for name in ['route-a-java','route-b-otk-java','business-java']:
 template=(out/'registration'/(name+'.dat.template')).read_text()
 check('unresolved_template_'+name,'@ABSOLUTE_' in template and template.endswith('end\n'))
check('no_runtime_artifacts',not any(p.suffix.lower() in {'.class','.jar','.dat','.bat','.rbn'} for p in out.rglob('*') if p.is_file()))
report={'scope':'text-only static assertions, not Java syntax/compile or runtime validation','baselineSha256':hashlib.sha256(baseline.read_bytes()).hexdigest(),'sourceSha256':hashlib.sha256((out/'BatchRename.java').read_bytes()).hexdigest(),'checks':checks,'resources':resources,'allPassed':all(checks.values()),'notExecuted':['javac','javap','jar packaging','node --check','Mock/Stub','HTTP tests','Creo','browser','deployment']}
(out/'evidence/static-claims.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':sum(checks.values()),'total':len(checks),'failed':[k for k,v in checks.items() if not v]},ensure_ascii=False))
raise SystemExit(0 if report['allPassed'] else 1)

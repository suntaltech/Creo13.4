# P1 第六轮 6A-R2 受控真机负面证据基线与待采集清单

生成时间：2026-11-03
范围：仅记录当前环境事实、源码静态门禁和受控采集要求；本文件不是真机成功证据，也不构成部署、打包或发布依据。

## 1. 测试前采集环境事实（历史快照，不代表当前状态）

> 本节记录受控切换前的只读状态；受控会话启动、命令注册和真机 `NO_MODEL` 结果以第 6 节为准。

| 项目 | 本次观测结果 | 口径 |
|---|---|---|
| Creo Parametric 进程 | 未发现 `parametric.exe` | 测试前快照；当时无法采集 Creo 原生按钮、选择缓冲区和 J-Link trace |
| Java 插件进程 | 未发现 `java.exe` | 测试前快照；当时没有 R2 候选或生产插件运行实例 |
| CREOSON 9056 端口 | 未监听；三个页面请求超时 | 测试前快照；仅说明当时服务未启动，不代表页面代码无效 |
| 现场 class 目录 `D:\creo-tools\jlink\classes` | 仍为旧版 4 个 class | 测试前快照；当时未复制、覆盖或删除任何现场 class |
| R2 隔离 class 目录 | 4 个 major=61 class，仅用于审核和受控候选 | 禁止复制到现场运行目录 |
| R2 候选文件扫描 | `.class`、`.rbn`、`.dat`、`.bat`、`.jar` 命中数为 0 | 候选包未携带运行产物或发布资源 |
| R2 受控测试目录 | `D:\creo-tools\build\review-p1-6a-r2-minimalfix-20261103\controlled-test-r2-20261103` 已准备 class、text、测试 dat 模板和说明；未写入 `config.pro`，未加载到 Creo | 测试前快照；仅为受控会话准备，不是现场部署 |
| 生产注册文件 `batchrename.dat` | `java_app_classpath D:\creo-tools\jlink\classes`，`text_dir D:\creo-tools\jlink\text` | 测试前快照；当时未修改注册文件和 `config.pro` |
| 当前日志 | `C:\Users\DELL\CreoBatchRename\jlink.log` 最后写入 2026-11-02 17:13:15，共 21,332 bytes | 测试前快照；旧日志只作历史对照，不能证明 R2 真机行为 |

### 1.1 现场旧 class 哈希（本次未改动）

| 文件 | 字节数 | SHA256 |
|---|---:|---|
| `BatchRename.class` | 24,995 | `DD6144A4B492C5126D5A992902F430A628E1DD21490BB1BA8E4BA447DBC39A17` |
| `BatchRename$OpenPageListener.class` | 3,160 | `3B496DE4BBA3C2C8B4E7EEA986668811A2E874FCE1F90C10E43FE962542A820C` |
| `BatchRename$SmtBridgeListener.class` | 2,293 | `86FA66026B6247FAA1F5E92F5DC48ABAA089BB675ED9615A7193C32908507DBA` |
| `BatchRename$SmtContext.class` | 689 | `532BF2858438DFD76AF252465FB41D272B45458955279EC4DADEFF46C8DF7857` |

### 1.2 R2 隔离候选哈希（禁止写入现场）

| 文件 | 字节数 | SHA256 |
|---|---:|---|
| `BatchRename.class` | 38,994 | `E7E46278E0786EF103AAD378052C3EF29D77D1DB8908F9848CD3AC2837C8BE5E` |
| `BatchRename$ConversionFailure.class` | 584 | `567F83A9EA9D0B988FA02E55CE0E3EB0D4330DE951E14974F85A7AE35CA894A3` |
| `BatchRename$OpenPageListener.class` | 3,755 | `C8BEA8C996246B1BC63944C9DE558153BFFD802E4F93145BE0095B9225CED657` |
| `BatchRename$SmtConvertListener.class` | 4,930 | `9F639EA57270A0C46995632C0E4C71C75AF234CCADF6282FB083B7CFFF8DEE5C` |

### 1.3 源码、补丁与资源哈希

| 对象 | 字节数 | SHA256 |
|---|---:|---|
| R2 `BatchRename.java` | 57,924 | `3CA71CEAC03FC67C9A1F8CB1BEE2A5CF4DF2C421A7D910B9A42A915AEF142C71` |
| `P1_6A_R2_MinimalFix.patch` | 37,638 | `454D1572F75E692D288AB66433EACC09FDC0FBB9F511F2EBA32B5758D492BCB1` |
| `text/p1_6a_r2.txt` | 767 | `B8939739DC213BDE0DB2D85C4D0D2EF6D583A927CABF4BCDE5EB00C57811AF06` |

## 2. 旧日志可引用事实与不可外推部分

旧日志可见：

1. 历史会话曾注册 `SISWBatchRename`、`SISWSheetMetal`、`SISWAbout` 三个页面命令。
2. 旧版 `detectActiveModelMode()` 曾抛出 `pfcPart$Part cannot be cast to wfcSolid.WSolid`，说明旧强转路径不可复用。
3. 旧日志没有 `SISWSheetMetalConvert`、R2 `requestId`、`WCreateFeature`、`WRegenerate`、`IsSheetmetal=true` 的运行证据。

因此旧日志只能用于证明历史问题和旧命令基线，不能作为 R2 原生转换、单位门禁、板厚输入或失败提示的观测结果。

## 3. R2 负面门禁静态清单（除 `NO_MODEL` 外，其余运行状态仍待真机采集）

| 门禁或失败码 | 源码条件 | 应在创建前停止 | 必须归档的运行证据 | 当前状态 |
|---|---|---|---|---|
| `NO_SESSION` | `session == null` | 是，不创建元素树 | `requestId`、`feedbackOutcome=SESSION_UNAVAILABLE`、缺失异常字段记 `N/A` | 待采集 |
| `NO_MODEL` | 无激活模型 | 是 | `failedPhase=READ_MODEL_FAILED`、无 `createdFeature`、无 `WRegenerate` | 已采集：见 6.3，创建前停止 |
| `NOT_PART` | 激活对象不是 `MDL_PART`，或不是 `.prt` | 是 | 实际模型类型、文件名、错误码、停止阶段 | 待采集 |
| `WRAP_SOLID_FAILED` | `wrapAsWSolid()` 返回空 | 是 | adapter 路由、异常类、指针或不可用原因 | 待采集 |
| `NO_BODY` | 默认实体体为空 | 是 | `defaultBody` 诊断、错误码 | 待采集 |
| `ALREADY_SHEETMETAL` | 默认体 `IsSheetmetal()` 为真 | 是，不重复转换 | 钣金状态、模型名、错误码、停止位置 | 待采集 |
| `NO_SELECTED_FACE` | 选择缓冲区数量为 0 | 是 | 选择计数、无特征创建证据 | 待采集 |
| `TOO_MANY_FACES` | 选择数量不为 1 | 是 | 选择数量、对象类型列表、错误码 | 待采集 |
| `SELECTED_FACE_INVALID` | 选择项为空、不是 `Surface`、不可见或面积无效 | 是 | 对象类型、可见性、面积、错误码 | 待采集 |
| `SELECTED_NOT_PLANE` | 曲面类型不是 `SURFACE_PLANE` | 是 | `selectedFaceId`、`selectedFaceType`、错误码 | 待采集 |
| `SELECTED_FACE_OTHER_MODEL` | 选择对象不属于当前激活零件 | 是 | 当前模型名、选择来源对象名、错误码 | 待采集 |
| `SELECTED_FACE_OTHER_BODY` | 面不属于默认实体体 | 是 | `faceOwnershipRoute`、native owner 诊断、错误码 | 待采集 |
| `UNIT_GATE_NON_MM_BLOCKED` | 人工声明 `NON_MM` | 是，不进入板厚提示或树构造 | `unitGate`、`unitGateInputOutcome`、外部原始输入记录 | 待采集 |
| 单位未知或未识别 | null、空值、其他 token | 是 | `unitGateInputOutcome=NULL_RETURNED` 或 `UNRECOGNISED_TOKEN` | 待采集 |
| 单位输入抛错 | `UIReadStringMessage` 抛异常 | 是 | `THROWN_EXCEPTION`、异常类、异常消息、堆栈 | 待采集 |
| `UI_PROMPT_FAILED` | 创建前消息提示调用返回失败 | 是，不创建特征 | `feedbackOutcome`、调用类型、`requestId`、停止阶段 | 待采集 |
| 板厚输入抛错 | `UIReadRealMessage` 抛异常 | 是 | `thicknessInputOutcome=THROWN_EXCEPTION`、异常类、消息 | 待采集 |
| 板厚取消返回 null | SDK 返回 `null` | 是，不创建特征 | `CANCEL_NULL_RETURNED`、`INPUT_CANCELLED_CREATE_NOT_DISPATCHED` | 待采集 |
| `INVALID_RANGE_REJECTED` | 非有限数、非正数、超出 0.1 至 20 | 是 | 输入文本、范围值、错误码、无创建证据 | 待采集 |
| `MODEL_CHANGED` | 板厚输入期间模型或会话状态变化 | 是 | 输入前后模型名、会话状态、错误码 | 待采集 |
| 反馈 `SESSION_UNAVAILABLE` | `session==null` 时进入消息分支 | 不产生异常记录 | 只写 `feedbackOutcome`；异常类、键日志、堆栈记 `N/A` | 待采集 |
| 反馈调用抛错 | `UIDisplayMessage` 抛 `Throwable` | 不改变技术阶段判定 | `STATUS_LINE_FAILED`、`feedbackExceptionClass`、`UI_FEEDBACK_FAILED; key=具体消息键` 日志和堆栈 | 待采集 |
| 反馈成功 | `UIDisplayMessage` 返回 | 不触发技术成功判定 | `STATUS_LINE_RETURNED`、`feedbackKey`、技术链路字段分列记录 | 已采集：`P1_6A_FAILED` 返回，见 6.3 |

## 4. 受控运行前必须满足的安全边界

1. 不把 `local-real-otk-classes` 复制到 `D:\creo-tools\jlink\classes`。
2. 不覆盖 `D:\creo-tools\jlink\text\batchrename.txt`，不把 `p1_6a_r2.txt` 作为生产资源发布。
3. 不修改、不手写、不导出新的 `toolkitribbonui.rbn`；本阶段不发布 Ribbon 布局结果。
4. 不修改 `creoson_run.bat`、`setvars.bat`、生产 Web 目录和 `config.pro` 的生产注册链路。
5. 不调用 `Save()`，不执行抽壳分支，不恢复 `AddBrowserMessageListener`，不使用 `window.external` 或旧 bridge action。
6. R2 类名和命令 ID 与旧插件存在重叠；若加载隔离候选，必须先准备独立测试 class 目录、独立测试 dat、备份与恢复记录，避免重复注册和现场覆盖。
7. 负面用例先于正向转换用例；任一阻断用例失败，不得进入 `WCreateFeature` 正向结论。

## 5. 测试前执行顺序建议（历史计划快照）

> 本节第 2 至第 4 项描述受控切换前的状态；实际注册切换、服务启动和 `NO_MODEL` 采集见第 6 节。

1. 独立受控测试目录已准备：`D:\creo-tools\build\review-p1-6a-r2-minimalfix-20261103\controlled-test-r2-20261103`；其中包含隔离 class、`p1_6a_r2.txt`、旧资源只读副本、测试 dat 模板和说明，哈希已记录。
2. 测试前计划：暂停或隔离生产 dat 注册链路，确保只运行一个插件实例；记录备份、切换和恢复方式。该切换在测试前尚未执行，测试后状态见第 6 节。
3. 测试前计划：启动 CREOSON 并记录 PID、命令行、端口监听状态；测试前 9056 未监听，测试后状态见第 6 节。
4. 测试前计划：启动 Creo，先执行旧三命令兼容性检查，再执行无模型、非零件、钣金零件、无选择、非平面、多选择、单位阻断、板厚取消、非法板厚等负面用例；测试前 Creo 未运行，当前仅 `NO_MODEL` 已采集。
5. 每个用例保存 `requestId`、错误码、阶段码、反馈三态分类、`jlink.log` 摘录、截图和模型状态。
6. 只有全部负面门禁按预期停止，才允许进入一个普通实体零件的受控正向用例；正向用例仍不调用 `Save()`。
7. 测试结束恢复生产 dat/class/text 链路，并比对现场文件哈希未变。

## 6. 受控真机负面证据（2026-11-03 复核）

### 6.1 受控会话与 UI 暴露复核

受控会话已按临时注册链路启动，`jlink.log` 在 `2026-11-03T07:33:03Z`（本地 15:33:03）记录：

1. 三个页面命令 `SISWBatchRename`、`SISWSheetMetal`、`SISWAbout` 注册完成。
2. 原生命令 `SISWSheetMetalConvert` 注册完成，`trackedPairs=4`。
3. 浏览器桥接保持禁用，6A 仅通过 `SISWSheetMetalConvert` 原生命令触发。

真实 UI 复核得到以下负面证据：

| 复核项 | 实际结果 |
|---|---|
| 顶部命令搜索完整 ID `SISWSheetMetalConvert` | 未找到 |
| 顶部命令搜索中文“实体转钣金” | 未找到 |
| Creo“自定义功能区”→`TOOLKIT 命令`，当前模式 | 列表为空 |
| 切换为所有模式后复查 `TOOLKIT 命令` | 列表仍为空 |
| 自定义功能区按 `SISW` 筛选 | 无结果 |
| 自定义功能区按“实体”筛选 | 无结果 |
| 受控 `batchrename.txt` 编码 | 无 BOM、GBK 可正确解码，368 bytes |
| 受控与生产 `batchrename.txt` 对比 | 长度和内容一致 |

因此，当前不能把 TOOLKIT 命令列表为空简单归因于受控资源独有编码错误；运行时资源加载、Designate 语义和命令暴露机制仍未证实。受控目录未包含 `toolkitribbonui.rbn`，本阶段也未手写或导出新的 rbn。

### 6.2 临时异步宏触发 harness

为避免手工修改 Ribbon 或手写 rbn，在受控目录下建立独立 harness：

- 目录：`D:\creo-tools\build\review-p1-6a-r2-minimalfix-20261103\controlled-test-r2-20261103\macro-harness`
- 触发宏：

```text
~ Command `SISWSheetMetalConvert`;
```

首次运行只加载默认 `jnicipjavamtz`，原生异步方法未注册，出现 `UnsatisfiedLinkError`；该结果属于 harness 装载问题，不作为 R2 命令证据。随后显式执行 `System.loadLibrary("pfcasyncmt")` 后重新运行，输出为：

```text
LOADING_NATIVE_ASYNC_LIBRARY
CONNECTING
CONNECTED
MACRO=~ Command `SISWSheetMetalConvert`;
RUNMACRO_RETURNED
DISCONNECTED
```

该过程只建立临时异步连接并执行宏，结束后调用 `Disconnect(null)`，未调用 `End()`，未关闭 Creo。

### 6.3 真机 `NO_MODEL` 阻断证据

`jlink.log` 记录到真实 `SISWSheetMetalConvert.OnCommand()`，关键字段如下：

| 字段 | 实际值 |
|---|---|
| `requestId` | `90a9e0f2-3acd-4d78-9c1a-a0a8a954d1d9` |
| 日志时间 | `2026-11-03T07:57:37Z`（本地 15:57:37） |
| `errorCode` | `NO_MODEL` |
| `failedPhase` | `READ_MODEL_FAILED` |
| `exceptionClass` | `BatchRename$ConversionFailure` |
| `exceptionMessage` | `请先打开普通零件` |
| `modelMayHaveChanged` | `false` |
| `saved` | `false` |
| `completionClass` | `CREATE_NOT_DISPATCHED` |
| `feedbackOutcome` | `STATUS_LINE_RETURNED` |
| `feedbackKey` | `P1_6A_FAILED` |
| `elapsedMs` | `262` |

调用栈显示异常发生于 `convertPreselectedPlane()` 读取激活模型并判定 `model == null` 的分支，随后由 `SmtConvertListener.OnCommand()` 捕获。该请求尚未进入实体包装、面选择校验、单位门禁、板厚输入、元素树构造和特征创建阶段；日志中没有本次请求的 `WCreateFeature` 或 `WRegenerate` 调用记录。

Creo 底部状态栏显示：`Command stopped before feature creation was dispatched. See jlink.log for requestId and failure details.`

截图已保存：

`D:\creo-tools\build\review-p1-6a-r2-minimalfix-20261103\controlled-test-r2-20261103\evidence-screenshots\R2_NO_MODEL_macro_status_20261103.png`

### 6.4 本轮证据文件哈希

| 文件 | 字节数 | SHA256 |
|---|---:|---|
| `macro-harness\MacroInvoke.java` | 1,426 | `F0A30DC317E8990A28A4682D89AC36A19573DDBD08B13146B7859F7668FD2B79` |
| `macro-harness\run-2-output.txt` | 128 | `3DA9E86F9879058A85F822FED2275A29759528B4308A2F08171FCEDC985B1EC1` |
| `macro-harness\CommandProbe.java` | 2,170 | `E303DFCB75F10984456B38CBC9A363E0C889BC6ED20B61087F54FB9F3C8A5BED` |
| `macro-harness\command-probe-output.txt` | 499 | `16FC553192F8CEA2A5B615F528C0E9A457D25992A5E3D6EB071A31F9F4E50315` |
| `evidence-screenshots\R2_NO_MODEL_macro_status_20261103.png` | 152,132 | `F59E6C659C24290E805DCAFEC321BDF6781A56BA3E90695E5871B70732C8E431` |
| `C:\Users\DELL\CreoBatchRename\jlink.log` | 26,039 | `67A2945F4B6FD020AA319B1C941D3A637DA9DA422BF8369CF69F24BDDA357728` |

### 6.5 证据边界与下一步重点

1. 宏已进入真实 `SISWSheetMetalConvert.OnCommand()`，说明命令并非完全未注册；但 Ribbon、命令搜索和 `TOOLKIT 命令` 列表均未暴露入口，UI 入口问题仍未解决。
2. 下一步优先核对 `Designate` 调用语义、消息资源加载路径和命令暴露机制，再继续非零件、未选面、非平面等负面用例。
3. 当前保留 R2 候选，不根据单个 `NO_MODEL` 用例修改驱动面元素树或特征创建选项。
4. 现有证据只能证明创建前阻断和 `P1_6A_FAILED` 状态栏反馈有效，不能证明元素树会被 Creo 接受，也不能证明转换成功。
5. 截图和原始日志均为本机受控路径并已记录哈希；其证明范围仅限本次 `NO_MODEL` 分支，不能外推到 `WCreateFeature`、`WRegenerate` 或钣金回读。

### 6.6 UI 入口只读补充诊断（2026-11-03 后续只读排查）

补充对象层探针 `CommandProbe.java` 不触发宏、不触发 `OnCommand()`、不修改模型；其输出证明四个命令 ID 均可由 `session.UIGetCommand(id)` 返回为 `com.ptc.pfc.Implementation.pfcCommand$UICommand`。该证据只能证明命令对象存在，不能证明 Customize Ribbon 的 `TOOLKIT 命令` 列表收录、命令搜索命中或按钮可点击。

静态排查新增三条候选原因，均未确认为唯一根因：

1. **注册模式待 A/B 区分**：受控 dat 当前为 J-Link `startup java`；本机 OTK Java 注册文档要求 `startup otk_java`、`toolkit object`、`creo_type parametric`，并要求应用 JAR、classpath 与解锁前提。当前 dat 缺少这些 OTK Java 字段。
2. **消息资源格式静态偏差**：官方消息文件要求四行组；`batchrename.txt` 为 26 行/9 键，`p1_6a_r2.txt` 为 18 行/6 键，均不满足 `键数×4` 结构。`P1_6A_FAILED` 状态栏返回不能外推为 Designate 的 Label/Help/Description 全部解析成功。
3. **旧 J-Link 菜单路径未使用**：本机免费 J-Link 示例常见 `UICreateCommand` 后调用 `UIAddButton`；R2 源码中 `UIAddButton`/`UIAddMenu` 命中数为 0。该路径即使出现旧菜单，也不能替代现代 Customize Ribbon `TOOLKIT 命令` 列表验收。

受控目录 `.rbn` 数量为 0；缺少已保存布局可解释“没有固定可见按钮”，但不能单独解释候选命令列表为空。详细分层证据、两条 UI 路线对比和给 ChatGPT 的最小整改要求见：

`D:\creo-tools\package\docs\P1第六轮6A_R2_UI入口只读诊断与ChatGPT最小整改要求_20261103.md`

## 7. 当前结论

当前已通过受控真机确认一个负面阻断分支：开始页无激活模型时，异步宏能够触发 `SISWSheetMetalConvert.OnCommand()`，并按 `NO_MODEL` / `READ_MODEL_FAILED` 在特征创建前停止，`completionClass=CREATE_NOT_DISPATCHED`，状态栏和 `jlink.log` 均给出可追溯证据。

该证据只证明本阻断分支有效，不证明实体转钣金成功，不代表其他负面门禁、元素树接受度、`WCreateFeature`、`WRegenerate` 或 `IsSheetmetal()` 回读已经通过。当前优先解决 UI 入口暴露问题，再继续其他负面用例；仍禁止部署、打包发布或宣称真实转换可用，测试结束后仍需恢复生产注册链路并复核现场哈希。

# P1 第六轮 6A-R2 UI 入口只读诊断与 ChatGPT 最小整改要求

生成时间：2026-11-03
范围：只诊断“命令对象已注册但 Ribbon/命令搜索/Customize Ribbon 列表未暴露”的原因；不修改生产 class、生产 dat、生产 text、生产 rbn，不打包发布，不改变 `WCreateFeature`、`WRegenerate`、`Save()` 等转换实现口径。

## 1. 当前分层结论

| 层次 | 已观测事实 | 可证明什么 | 不能证明什么 |
|---|---|---|---|
| 对象层 | 只读 `UIGetCommand()` 对 4 个 ID 均返回 `COMMAND_FOUND`，对象类为 `com.ptc.pfc.Implementation.pfcCommand$UICommand` | 4 个命令对象在当前 JVM 会话内可被解析 | 不能证明按钮可见、可点击、被 Customize Ribbon 收录或消息标签解析成功 |
| 触发层 | 宏 `~ Command \`SISWSheetMetalConvert\`;` 返回 `RUNMACRO_RETURNED`，随后 `Disconnected` | 宏字符串可驱动原生命令进入回调 | 不能证明普通用户可从 Ribbon 或命令搜索入口触发 |
| 执行层 | 开始页无模型时进入 `OnCommand()`，记录 `NO_MODEL` / `READ_MODEL_FAILED` / `CREATE_NOT_DISPATCHED`，`modelMayHaveChanged=false`、`saved=false` | 创建前阻断分支和 `P1_6A_FAILED` 状态栏反馈有效 | 不能证明面选择、单位门禁、板厚、元素树、特征创建或钣金回读成功 |
| UI 暴露层 | 命令搜索无结果；Customize Ribbon 的 `TOOLKIT 命令` 列表为空；受控目录无 `toolkitribbonui.rbn` | 当前缺少用户可见入口，也缺少受控 Ribbon 布局文件 | 不能单独据此判定命令未注册，也不能据此修改元素树 |

核心判断：当前问题不是“命令对象完全不存在”，而是“对象/宏触发成功，但用户可见 UI 暴露链路未闭合”。

## 2. 本轮只读证据

### 2.1 对象层探针

`macro-harness/command-probe-output.txt`（499 bytes，SHA256 `16FC553192F8CEA2A5B615F528C0E9A457D25992A5E3D6EB071A31F9F4E50315`）记录：

```text
LOADING_NATIVE_ASYNC_LIBRARY
CONNECTING
CONNECTED; SESSION_CLASS=com.ptc.pfc.Implementation.pfcSession$Session
COMMAND_FOUND=SISWBatchRename; OBJECT_CLASS=com.ptc.pfc.Implementation.pfcCommand$UICommand
COMMAND_FOUND=SISWSheetMetal; OBJECT_CLASS=com.ptc.pfc.Implementation.pfcCommand$UICommand
COMMAND_FOUND=SISWAbout; OBJECT_CLASS=com.ptc.pfc.Implementation.pfcCommand$UICommand
COMMAND_FOUND=SISWSheetMetalConvert; OBJECT_CLASS=com.ptc.pfc.Implementation.pfcCommand$UICommand
DISCONNECTED
```

探针只调用 `UIGetCommand(String)`，不触发宏、不触发 `OnCommand()`、不修改模型。

### 2.2 宏触发与 `NO_MODEL` 阻断

| 证据 | 关键值 |
|---|---|
| 成功宏 harness 输出 | `RUNMACRO_RETURNED`；文件 `macro-harness/run-2-output.txt`，128 bytes，SHA256 `3DA9E86F9879058A85F822FED2275A29759528B4308A2F08171FCEDC985B1EC1` |
| `requestId` | `90a9e0f2-3acd-4d78-9c1a-a0a8a954d1d9` |
| `errorCode` / `failedPhase` | `NO_MODEL` / `READ_MODEL_FAILED` |
| `completionClass` | `CREATE_NOT_DISPATCHED` |
| `modelMayHaveChanged` / `saved` | `false` / `false` |
| `feedbackOutcome` / `feedbackKey` | `STATUS_LINE_RETURNED` / `P1_6A_FAILED` |
| 特征创建证据 | 本次请求无 `WCreateFeature`、无 `WRegenerate` 记录 |

### 2.3 SDK 方法面事实

本机 `javap` 复核结果：

- `com.ptc.pfc.pfcCommand.UICommand` 仅公开：
  - `SetIcon(java.lang.String)`
  - `Designate(java.lang.String, java.lang.String, java.lang.String, java.lang.String)`
- `com.ptc.pfc.pfcSession.Session` 可见：
  - `UICreateCommand(String, UICommandActionListener)`
  - `UIAddMenu(String, String, String, String)`
  - `UIAddButton(UICommand, String, String, String, String, String)`
  - `UIGetCommand(java.lang.String)`
- `UICommand` 未公开程序化执行、隐藏、禁用或强制加入 Ribbon 列表的方法；按钮位置只能通过 Creo UI 布局保存或官方允许的资源机制生成。

R2 源码中 `UIAddButton` / `UIAddMenu` 命中数为 0；三个页面命令和转换命令均只走 `UICreateCommand` → `Designate` → `SetIcon` → Java 内部 `trackCommand`。

## 3. 候选原因排序（均需受控 A/B，禁止提前下唯一根因结论）

| 优先级 | 候选原因 | 支持证据 | 限制或反证 | 下一步验证 |
|---:|---|---|---|---|
| P1 | 注册模式混用：当前 dat 为 J-Link `startup java`，而 Designate/Customize Ribbon 文档主要面向 Creo Object TOOLKIT Java | 受控 dat 为 `startup java`，无 `toolkit object`、`creo_type parametric`、jar 打包和解锁字段；本地 OTK Java 注册文档要求 `startup otk_java`、`toolkit object`、`creo_type parametric` | `Designate` 调用未抛异常且 `UIGetCommand` 非空；这只证明对象存在，不证明现代列表收录 | 单独准备受控 `otk_java` dat/JAR 探针；若不支持必须记录启动失败日志，不得静默回退 |
| P2 | 消息资源格式或位置不符合 Designate 要求 | 官方文档要求每个消息为四行组；`batchrename.txt` 当前 26 行/9 个键、`p1_6a_r2.txt` 当前 18 行/6 个键，均不满足 `键数×4` 的总行数结构；文件直接位于受控 `text` 根目录，未使用 `text/usascii` 子目录 | `P1_6A_FAILED` 状态栏返回，说明至少部分状态消息链路可用；不能据此证明三个 Designate 标签/帮助/说明均被成功解析 | 受控副本改为四行组并测试 `text/usascii` 位置；每次修改后必须重启 Creo，因官方文档说明消息文件会话内只加载一次 |
| P3 | J-Link 示例常用 `UIAddButton` 旧菜单机制，当前源码完全未调用 | 本机免费 J-Link 示例 `ParamEditor.java` 使用 `UICreateCommand` 后直接调用 `UIAddButton`，未调用 `Designate` | `UIAddButton` 主要对应旧菜单/旧按钮位置，不能假设它必然进入现代 Customize Ribbon 的 `TOOLKIT 命令` 列表 | 仅在受控 dat/临时类中做探针，区分“旧菜单出现”和“现代 TOOLKIT 列表出现” |
| P4 | 受控目录缺少已保存的 Ribbon 布局 `toolkitribbonui.rbn` | 受控目录 `.rbn` 数量为 0；生产/包内二进制 rbn 不能文本搜索替代结构判断 | 缺少 rbn 可解释“没有固定可见按钮”，不能解释 Customize Ribbon 的候选列表为空；禁止手写二进制 rbn | 待候选列表先出现，再通过官方 UI Add 后 Save Auxiliary Application User Interface 导出 |
| P5 | 转换命令复用 `SISW_SMT_LABEL/HELP/DESC`，且 Designate 后缺少运行时标签解析诊断 | 官方建议应用消息键唯一；当前转换命令与页面钣金命令共用消息键 | 消息键复用是否直接导致列表隐藏尚无真机证据；不能作为唯一解释 | 为转换命令增加独立候选键，并记录 Designate 调用后是否有资源查找失败日志 |

## 4. 两条可选 UI 技术路线

| 路线 | 注册/API 特征 | 适用目标 | 主要风险/限制 |
|---|---|---|---|
| A. J-Link `startup java` + 旧菜单按钮 | `startup java`、`UICreateCommand`、`UIAddButton/UIAddMenu`；本机免费 J-Link 示例采用该思路 | 快速验证旧应用程序菜单或兼容入口是否出现 | 不等同于官方现代 Ribbon Customize 列表；按钮布局和可维护性较弱；不能宣称实现 OTK Ribbon 列表 |
| B. OTK Java `startup otk_java` + Designate | `startup otk_java`、`toolkit object`、`creo_type parametric`、应用 JAR、允许前提、`Designate`、合规消息资源；随后通过 Customize Ribbon Add 并保存 rbn | 目标是官方现代 `TOOLKIT 命令` 候选列表和可保存 Ribbon 布局 | 文档要求应用打包 JAR、classpath 包含相关包并满足解锁/运行前提；当前受控 dat 不满足这些字段；任一前提失败都需如实记录 |

不要把 A、B 两条路线混合解释：旧菜单按钮出现、宏可触发、`UIGetCommand` 非空，都不能替代路线 B 的 Customize Ribbon 列表验收。

## 5. 给 ChatGPT 的本轮最小整改要求（只做 UI/注册/资源层，不改转换算法）

### 5.1 必须保持不变

1. 不修改驱动面元素树、`WCreateFeature`、`WRegenerate`、材料侧选项、抽壳分支。
2. 不调用 `Save()`，不恢复 `AddBrowserMessageListener`，不恢复 `window.external.ptc` 桥接。
3. 不把候选 class、dat、text、rbn 复制到生产 `D:\creo-tools\jlink\`；不打包发布。
4. 不手写、不解析、不伪造二进制 `toolkitribbonui.rbn`。

### 5.2 建议提交的候选内容

1. **注册模式分离**
   - 保留当前 J-Link 转换业务类作为一个候选；
   - 另出一个受控 UI 探针候选：明确区分 `startup java + UIAddButton` 与 `startup otk_java + Designate`，不得在同一结论中混称成功。

2. **OTK Java 路线候选字段（如选择 B，仅受控测试）**
   - `startup otk_java`
   - `toolkit object`
   - `creo_type parametric`
   - 应用类打包为临时 JAR，`java_app_classpath` 同时给出应用 JAR 和官方要求的 SDK/JAR 路径；
   - 如运行时提示未解锁、无权限或启动拒绝，原样记录错误码和日志，不允许改为“Designate 成功”文案。

3. **消息资源合规**
   - 每个消息严格四行组：键、显示文本、翻译行（可 `#` 或空）、预留行（`#` 或空）；
   - 增加转换命令独立候选标签键，不复用页面命令的 `SISW_SMT_*`；
   - 受控同时准备 `text` 根目录与 `text/usascii` 两种资源位置对照，但不得覆盖生产资源；
   - 资源修改后必须重启 Creo 后再复核 UI 列表。

4. **诊断日志**
   - 每个命令记录：命令 ID、`UICreateCommand` 是否非空、`Designate` 是否返回、`SetIcon` 结果、使用的消息文件名；
   - 如 SDK 无法直接返回“消息键是否解析成功”，必须写 `MESSAGE_LOOKUP_UNVERIFIED`，不得推断为成功；
   - 记录 dat 的 `startup`、`toolkit`、`creo_type`、classpath 形态（目录/JAR）。

5. **旧菜单探针边界（如选择 A）**
   - 若使用 `UIAddButton`，只能记录其挂载菜单、返回结果和实际可见位置；
   - 不得把旧菜单出现等同于 Customize Ribbon `TOOLKIT 命令` 列表暴露。

### 5.3 验收证据清单

| 验收项 | 通过标准 | 失败记录要求 |
|---|---|---|
| Customize Ribbon 候选列表 | `TOOLKIT 命令` 中能看到 4 个命令的中文/英文标签，截图保存 | 列表为空时记录当前 `startup`、dat 字段、资源路径、日志尾和截图 |
| 命令搜索 | 完整命令 ID 或唯一中文标签可被搜索定位 | 记录搜索词、模式（所有模式/当前模式）和空结果截图 |
| 手动按钮触发 | 不依赖宏，点击 UI 按钮仍进入 `OnCommand()` 并产生 requestId | 记录按钮缺失、点击无效或无日志的具体阶段 |
| `NO_MODEL` 回归 | 点击按钮后仍在创建前停止，无 `WCreateFeature`/`WRegenerate`/`Save` | 若出现模型变更必须标记 `modelMayHaveChanged=true` 并停止后续正向测试 |
| 资源合规 | 每行消息组满足四行结构；键名唯一；文件位置与 dat `text_dir` 匹配 | 输出键数、行数、缺失行和实际加载目录 |
| 生产边界 | 生产 class/dat/text/rbn 哈希与备份一致，未新增发布 ZIP | 列出复制/未复制清单和哈希差异 |

## 6. 受控目录当前证据哈希

| 文件 | 字节数 | SHA256 |
|---|---:|---|
| `sisw_r2_controlled_test.dat` | 356 | `CCF997ED26A24E3F40BB57A51BA64380E06E21B2191E9965B07471E0CA9D2933` |
| `classes/BatchRename.class` | 38,994 | `E7E46278E0786EF103AAD378052C3EF29D77D1DB8908F9848CD3AC2837C8BE5E` |
| `classes/BatchRename$ConversionFailure.class` | 584 | `567F83A9EA9D0B988FA02E55CE0E3EB0D4330DE951E14974F85A7AE35CA894A3` |
| `classes/BatchRename$OpenPageListener.class` | 3,755 | `C8BEA8C996246B1BC63944C9DE558153BFFD802E4F93145BE0095B9225CED657` |
| `classes/BatchRename$SmtConvertListener.class` | 4,930 | `9F639EA57270A0C46995632C0E4C71C75AF234CCADF6282FB083B7CFFF8DEE5C` |
| `text/batchrename.txt` | 368 | `BD85E1352C3E0112FC36D07B11FEBABE1082859098EF7CFA8CD67C7F1760E31C` |
| `text/p1_6a_r2.txt` | 767 | `B8939739DC213BDE0DB2D85C4D0D2EF6D583A927CABF4BCDE5EB00C57811AF06` |
| `macro-harness/MacroInvoke.java` | 1,426 | `F0A30DC317E8990A28A4682D89AC36A19573DDBD08B13146B7859F7668FD2B79` |
| `macro-harness/run-2-output.txt` | 128 | `3DA9E86F9879058A85F822FED2275A29759528B4308A2F08171FCEDC985B1EC1` |
| `macro-harness/CommandProbe.java` | 2,170 | `E303DFCB75F10984456B38CBC9A363E0C889BC6ED20B61087F54FB9F3C8A5BED` |
| `macro-harness/command-probe-output.txt` | 499 | `16FC553192F8CEA2A5B615F528C0E9A457D25992A5E3D6EB071A31F9F4E50315` |
| `evidence-screenshots/R2_NO_MODEL_macro_status_20261103.png` | 152,132 | `F59E6C659C24290E805DCAFEC321BDF6781A56BA3E90695E5871B70732C8E431` |

受控目录递归扫描结果：`.rbn` 文件数量为 0；未复制生产 Web 文件、生产启动 BAT、生产 JAR 或生产 rbn。

## 7. 官方依据位置

1. `Designating_the_Command.html`：未调用 `Designate` 的命令不会出现在 Customize Ribbon 的 TOOLKIT Commands 列表；Label、Help、Description 必须来自消息文件，消息文件须位于 `text` 或 `text/<language>`。
2. `Registry_File.html`：J-Link 应用使用 `startup java`，字段包括 `java_app_class`、`java_app_classpath`、`text_dir` 等。
3. `RegistryFile1.html`：Creo Object TOOLKIT Java 使用 `startup otk_java`，并要求 `toolkit object`、`creo_type parametric`。
4. `Contents_of_the_Message_File.html`：消息文件每组四行：标识符、替换字符串、可空翻译、预留空行。
5. `Restrictions_on_the_Text_Message_File.html`：消息文件会话内只加载一次，修改后需重启 Creo；消息文件名和键名需唯一且合规。
6. Ribbon 工作流文档：候选命令出现后，先在 Customize Ribbon 中 Add，再通过官方界面保存 Auxiliary Application User Interface 生成 rbn；rbn 不允许手工编辑。

## 8. 当前结论

本轮只读诊断支持“先解决 UI 暴露机制，再继续其他转换负面用例”的顺序。现有证据足以排除“命令对象完全未注册”这一简单解释，但不足以指定唯一根因。优先级最高的受控验证是：注册模式（`java` vs `otk_java`）与消息资源格式/位置；`UIAddButton` 旧菜单路径只能作为兼容探针，不能替代现代 Ribbon 候选列表验收。

在 Customize Ribbon 列表和手动按钮点击链路被真机证据闭合前，仍禁止宣称 P1 实体转钣金可用、禁止部署候选 class、禁止打包发布或修改生产注册链路。

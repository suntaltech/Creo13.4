# 来源与未证实语义

输入报告原文附在本目录的ui-diagnosis-input.md与negative-evidence-input.md。官方文档目前只有本机报告提供的文件名与摘要；云端未取得原始HTML，不能冒称重新查阅或验证全文。

- SessionUI签名：原R2包附带的reference/javap-key/SessionUI.txt；包含UICreateCommand、UIAddButton(UICommand,String,String,String,String,String)等；本包复制该已有文本，不运行javap。
- UICommand.SetIcon(String)、Designate(String,String,String,String)：新诊断第2.3节本机javap事实；调用形式沿用可编译R2基线。
- Designating_the_Command.html：新诊断第7节摘要，Designate与Customize Ribbon关联；调用返回不证明实际标签解析或列表收录。
- Contents_of_the_Message_File.html：新诊断第7节摘要，每消息四行：键、替换正文、可空翻译、预留空行。本候选严格使用两条空行结尾，不使用#占位符。
- Restrictions_on_the_Text_Message_File.html：会话内只加载一次；同条件变更后重启才能重新比较。
- Registry_File.html与RegistryFile1.html：新诊断第3、4、7节摘要；分别为startup java与startup otk_java/toolkit object/creo_type parametric。JAR、SDK classpath及解锁运行前提未由云端验证，模板保留显式占位符。
- ParamEditor.java：新诊断提供“UICreateCommand后UIAddButton”的示例摘要，未附示例原文。UIAddButton参数语义、菜单名称及null neighbour必须由本机审核核对；A探针要求显式菜单环境变量，无默认菜单猜测。

本次没有引用新单位、owner、元素ID或特征创建API；没有修改WFC转换链路。探针使用原R2已有同步会话获取方法，未引入异步连接。

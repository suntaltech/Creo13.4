# P1 6A R2 UI 入口最小整改源码候选

日期：2026-11-03。本包是离线审核源码候选，不是运行安装包或发布包；未编译、未加载Creo、未修改任何现场文件。

## 依据与当前事实

输入基线为已交付R2源码，SHA256：`3ca71ceac03fc67c9a1f8cb1bee2a5cf4df2c421a7d910b9a42a915aef142c71`。
输入ZIP SHA256：`182e17eddfb282f8adb4053420dece5544c7bc787b18811f23f26a0c9745c54e`。
已核对下载包与基线源码哈希；用户提供的诊断记录四个UIGetCommand均找到对象、宏可触发NO_MODEL，但未显示现代UI入口。这些是输入报告中的本机观测，不是本轮云端重演。

上一版状态消息资源沿用三行组，偏离本次提供的官方四行结构要求；本轮修正。消息格式是已知静态偏差，尚不能把它或注册模式指定为唯一运行根因。

## 本轮改动

1. 业务类将Designate资源指向独立的`p1_6a_ui_commands.txt`，保留旧三个命令ID与原有页面URL、守卫、导航、监听器维护和转换实现。
2. 转换命令改用独立`SISW_SMT_CONVERT_LABEL/HELP/DESC`，不再复用`SISW_SMT_*`。候选标签使用ASCII英文，转换标签为`Convert Solid to Sheet Metal 6A`；未提供旧生产资源正文，不声称保持其中文逐字文案，也不覆盖旧batchrename.txt。
3. UICreateCommand、Designate和SetIcon记录命令ID、阶段、返回/抛错、消息文件和消息键；成功返回后依然记录`MESSAGE_LOOKUP_UNVERIFIED`与UI可见性未验证。新建命令空返回会明确报错。
4. 消息资源每键严格四行：键、正文、空翻译行、空预留行。命令资源12键48行，状态资源6键24行，探针资源25键100行。状态正文与R2完全一致，只改变分组空行。
5. 提供两个独立目录布局：`resources/root-layout/text`、`resources/usascii-layout/text/usascii`。每次仅选择一种layout，`text_dir`始终指向该layout的`text`目录，不是其`usascii`子目录。不要把两套资源合并进同一个搜索根目录。
6. 提供只读探针源码：`JLinkUiProbe`选择路线A，`OtkUiProbe`选择路线B，均使用`UiExposureProbe`。它们不调用BatchRename、不读取模型、不打开业务页面、不启动CREOSON、不创建特征。探针回调只生成UUID、记录日志并尝试状态行提示。
7. 三份`.dat.template`为含占位符的不可直接使用模板：业务类startup java、路线A startup java、路线B startup otk_java/toolkit object/creo_type parametric。没有输出真正.dat、class、jar、bat、rbn。

## 保持不变的范围

文本核对脚本逐块比较：转换OnCommand、convertPreselectedPlane、WFC适配器、面归属、单位门禁、板厚输入、7节点树、选项、特征创建/重生成/回读、失败诊断、反馈函数、原生审计、旧页面回调和守卫、track/untrack/detach、start/stop及既有CREOSON后台启动均保持基线。

不改WCreateFeature/WRegenerate，不添加Save、抽壳、浏览器监听、旧桥接或二进制Ribbon操作。没有因为UI失败而变更转换选项、材料侧节点或成功完整性判定。

保留现有UIDisplayMessage的null参数。本机报告已有P1_6A_FAILED成功返回证据；stringseq.create()虽有新签名事实，当前UI整改不把反馈参数替换混入同轮实验。

## 路线分离与验收

| 候选 | 注册方式/动作 | 命令ID | 能检验的范围 |
|---|---|---|---|
| 业务候选 | startup java，原有Designate流程，修正消息文件与日志 | SISWBatchRename、SISWSheetMetal、SISWAbout、SISWSheetMetalConvert | 资源格式修正后原四命令UI暴露与已有NO_MODEL回归；本轮未实际执行 |
| 探针A | startup java；UIAddButton，不调用Designate | SISWUIProbeA + Rename/SheetMetal/About/Convert | 旧菜单入口能否挂载；不替代现代TOOLKIT候选列表验收 |
| 探针B | startup otk_java；Designate，不调用UIAddButton | SISWUIProbeB + Rename/SheetMetal/About/Convert | OTK注册及现代列表的只读实验；不验证原业务四命令的转换行为 |

探针四个标签含`UI Probe A`或`UI Probe B`，不冒充实际转换按钮。必须先在新干净会话选择一个候选；不要在一个JVM中切换不同路线或布局，也不要与生产同名业务类重复加载。探针Stop只尝试移除listener，RemoveActionListener正常返回仍不证明命令对象已注销；下一轮换条件必须重启Creo。

路线A不猜菜单ID：本机审核者须依据实际安装的官方ParamEditor.java设定父进程环境变量`SISW_UI_PROBE_MENU`，并核对UIAddButton参数顺序（command、menu、neighbour、label、help、message file）和null neighbour接受度。未取得本机示例依据或菜单名时，不运行A、如实记未覆盖；代码无默认Utilities之类猜测。未提供原始ParamEditor.java，本轮只有任务单所列方法签名及示例摘要，参数语义待审核。

图标可选：环境变量`SISW_UI_PROBE_ICON`未设置时明确记SKIPPED_NO_ICON_CONFIGURED；有配置时记录SetIcon正常返回/异常。A旧菜单出现不能写成现代TOOLKIT列表通过；B若加载拒绝、未解锁、无权限或缺SDK，保存完整错误，不回退到A冒充成功。

## 注册配置证据如何记录

现有SDK签名没有直接读取生效dat字段的API。本业务候选日志将datStartup、datToolkit、datCreoType、datClasspathShape统一标记`UNVERIFIED_REGISTRY_NOT_READ`，不从命令对象存在或java.class.path猜测真实注册模式。

探针日志的startup/toolkit/creo_type及classpath形态明确标记为`TEMPLATE_DECLARATION_NOT_EFFECTIVE_REGISTRY_VERIFICATION`。实际字段、dat哈希、classpath条目与类型、text_dir、截图和对应registrationId/requestId必须由操作者填写`evidence/registration-context-template.json`，并附实际选用dat副本。这是外部证据模板，executed=false；未填写不算已记录实际生效配置。

路线B模板的应用JAR和SDK classpath是未解析占位符；需依据本机官方RegistryFile1文档核对Windows分隔符、空格路径、编码及必要SDK条目。应用JAR构建、OTK解锁/许可要求由本机合规环境审核，不提供绕过逻辑，也不虚构解锁字段。模板不是可直接加载的有效注册文件。

## 本机审核顺序（本轮未执行）

1. 核对输入基线和本包SHA256，隔离应用补丁，核对源码字节；用本机同步otk.jar、--release 17分别编译业务类与探针，记录退出码、类清单和major=61，禁止输出到生产目录，不混入pfcasync.jar。
2. 独立核对三种消息文件的四行结构、键与Designate/UIAddButton参数匹配；检查模板占位符，选定且只选一种layout，记录dat与text_dir实际值。
3. 先用业务startup java候选在root-layout测试修正的消息格式，记录4个ID的UICreateCommand/Designate/SetIcon结果。另一个全新会话仅切换为usascii-layout。不要同时改变注册方式和资源位置后声称已定位单一根因。
4. 如需进一步隔离，再分别使用A、B只读探针；同一路线改变资源位置仍须新会话。保存列表当前模式/所有模式、确切搜索词、截图、日志、模板声明与实际dat字段。消息文件会话内缓存，不能只改磁盘后沿用旧会话比较。
5. 探针A保存实际旧菜单位置及手动按钮调用UUID；探针B保存TOOLKIT候选列表、手工Add和按钮调用UUID。二者均不创建特征；探针回调不是NO_MODEL业务证据。
6. 只有选定路线及资源位置得到真实UI证据后，才单独确认将同一机制用于业务四命令。B探针成功不自动证明业务startup java成功，也不隐式授权把业务类注册方式切为OTK。
7. 业务候选同一会话内验证旧三命令，再从手动UI入口执行无模型NO_MODEL。核对CREATE_NOT_DISPATCHED、modelMayHaveChanged=false、无创建/重生成/保存。只有后续独立受控负面清单通过后才考虑正向转换。
8. 本阶段不输出或导出新rbn，不修改生产class/dat/text/config.pro/Web/启动脚本；会话结束记录恢复及生产哈希。后续正式Ribbon导出需单独安排。

## 验证范围与未决事项

本轮执行：Python文本核对、补丁应用检查与回放、归档哈希/文件范围检查。源码未经过编译或运行；文本括号检查不等同Java语法验证。

未执行：javac、javap、jar打包、node --check、Mock/Stub、HTTP测试、Creo/浏览器操作、GUI点击、dat加载、应用解锁、生产部署或发布。

未决：注册模式是否为根因、四行资源修正效果、语言资源路径、Designate内部解析、UIAddButton参数/菜单语义、OTK运行前提、命令搜索索引、图标路径、UI入口及业务NO_MODEL回归。原有转换风险不因本轮UI源码改变而关闭。

## 补丁空行注意事项

统一补丁同时包含业务源码、三个探针源码、两种布局的六个消息文件以及三个注册模板（共13个目标文件）。消息文件最后一个组也必须保留完整四行，因此git apply可能提示`new blank line at EOF`/whitespace warning。此次应用退出0且13个文件与候选逐字节一致；这些是预期资源空行，不能使用`--whitespace=fix`或编辑器“删除末尾空行”功能破坏四行分组。可使用`--whitespace=nowarn`抑制提示，但仍须核对SHA256和行组结构。

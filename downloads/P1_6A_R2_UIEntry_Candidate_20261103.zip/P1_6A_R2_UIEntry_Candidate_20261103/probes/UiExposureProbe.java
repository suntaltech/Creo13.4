import com.ptc.pfc.pfcCommand.DefaultUICommandActionListener;
import com.ptc.pfc.pfcCommand.UICommand;
import com.ptc.pfc.pfcSession.CreoCompatibility;
import com.ptc.pfc.pfcSession.Session;
import com.ptc.pfc.pfcSession.pfcSession;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Read-only UI exposure experiment. Never delegates to BatchRename or a model API. */
public final class UiExposureProbe {
    private static final String MESSAGES = "p1_6a_ui_probe.txt";
    private static Session session;
    private static String route;
    private static String registrationId;
    private static boolean active;
    private static final List<UICommand> commands = new ArrayList<>();
    private static final List<ProbeListener> listeners = new ArrayList<>();
    private UiExposureProbe() { }

    public static void start(String selectedRoute) throws Throwable {
        if (!"A".equals(selectedRoute) && !"B".equals(selectedRoute)) {
            throw new IllegalArgumentException("Route must be A or B");
        }
        if (session != null || !commands.isEmpty()) {
            throw new IllegalStateException("Stop the prior probe or restart Creo before loading another route");
        }
        route = selectedRoute;
        registrationId = UUID.randomUUID().toString();
        event("REGISTRY_DECLARATION", null, "startup=" + ("A".equals(route) ? "java" : "otk_java")
                + "; toolkit=" + ("A".equals(route) ? "NOT_DECLARED" : "object")
                + "; creo_type=" + ("A".equals(route) ? "NOT_DECLARED" : "parametric")
                + "; expectedClasspath=" + ("A".equals(route) ? "DIRECTORY" : "APPLICATION_JAR_AND_LOCAL_SDK")
                + "; source=TEMPLATE_DECLARATION_NOT_EFFECTIVE_REGISTRY_VERIFICATION", null, null);
        try {
            session = pfcSession.GetCurrentSessionWithCompatibility(CreoCompatibility.C4Compatible);
            if (session == null) throw new IllegalStateException("No synchronous session");
            String menu = System.getenv("SISW_UI_PROBE_MENU");
            if ("A".equals(route) && (menu == null || menu.isBlank())) {
                throw new IllegalStateException("Route A requires SISW_UI_PROBE_MENU from the installed official J-Link example; no menu ID is guessed");
            }
            for (String suffix : new String[] { "Rename", "SheetMetal", "About", "Convert" }) {
                register(suffix, menu);
            }
            active = true;
            event("START", null, "RETURNED; 4 read-only callbacks installed; UI_VISIBILITY_UNVERIFIED", null, null);
        } catch (Throwable error) {
            event("START", null, "THROWN; no alternate registration route attempted", null, error);
            stop();
            throw error;
        }
    }

    private static void register(String suffix, String menu) throws Throwable {
        String id = "SISWUIProbe" + route + suffix;
        String key = "P1_UI_" + route + "_" + suffix.toUpperCase(java.util.Locale.ROOT);
        ProbeListener listener = new ProbeListener(id);
        UICommand command;
        try {
            event("UICreateCommand", id, "ATTEMPT", null, null);
            command = session.UICreateCommand(id, listener);
            event("UICreateCommand", id, command == null ? "RETURNED_NULL" : "RETURNED_NON_NULL", null, null);
            if (command == null) throw new IllegalStateException("Null command");
        } catch (Throwable error) {
            event("UICreateCommand", id, "THROWN", null, error);
            throw error;
        }
        // Track before later SDK calls so partial registrations are included in stop cleanup.
        commands.add(command);
        try { listeners.add(listener); }
        catch (Throwable trackingError) {
            commands.remove(commands.size() - 1);
            try { command.RemoveActionListener(listener); }
            catch (Throwable detachError) { trackingError.addSuppressed(detachError); }
            throw trackingError;
        }
        if ("B".equals(route)) {
            try {
                event("Designate", id, "ATTEMPT; keys=" + key, null, null);
                command.Designate(MESSAGES, key + "_LABEL", key + "_HELP", key + "_DESC");
                event("Designate", id, "RETURNED; MESSAGE_LOOKUP_UNVERIFIED", null, null);
            } catch (Throwable error) {
                event("Designate", id, "THROWN", null, error);
                throw error;
            }
            event("UIAddButton", id, "NOT_REQUESTED_ROUTE_B", null, null);
        } else {
            event("Designate", id, "NOT_REQUESTED_ROUTE_A", null, null);
            try {
                event("UIAddButton", id, "ATTEMPT; menu=" + menu + "; neighbour=null; label=" + key + "_LABEL; help=" + key + "_HELP", null, null);
                // Signature supplied by SessionUI. Argument roles must be checked against local ParamEditor.java.
                session.UIAddButton(command, menu, null, key + "_LABEL", key + "_HELP", MESSAGES);
                event("UIAddButton", id, "RETURNED; menu=" + menu + "; ACTUAL_LOCATION_UNVERIFIED; NOT_MODERN_RIBBON_EVIDENCE", null, null);
            } catch (Throwable error) {
                event("UIAddButton", id, "THROWN; menu=" + menu, null, error);
                throw error;
            }
        }
        String icon = System.getenv("SISW_UI_PROBE_ICON");
        if (icon == null || icon.isBlank()) {
            event("SetIcon", id, "SKIPPED_NO_ICON_CONFIGURED", null, null);
        } else {
            try {
                command.SetIcon(icon);
                event("SetIcon", id, "RETURNED; icon=" + icon, null, null);
            } catch (Throwable error) {
                event("SetIcon", id, "THROWN; default icon retained", null, error);
            }
        }
    }

    public static void stop() {
        active = false;
        for (int i = commands.size() - 1; i >= 0; i--) {
            try {
                commands.get(i).RemoveActionListener(listeners.get(i));
                event("RemoveActionListener", listeners.get(i).id, "RETURNED; UNREGISTRATION_UNVERIFIED", null, null);
                commands.remove(i);
                listeners.remove(i);
            } catch (Throwable error) {
                event("RemoveActionListener", listeners.get(i).id, "THROWN; disabled pair retained; restart before reloading", null, error);
            }
        }
        session = null;
    }

    private static final class ProbeListener extends DefaultUICommandActionListener {
        private final String id;
        private ProbeListener(String id) { this.id = id; }
        @Override
        public void OnCommand() {
            String requestId = UUID.randomUUID().toString();
            event("OnCommand", id, "ENTERED; modelMayHaveChanged=false; saved=false; readonlyProbe=true", requestId, null);
            if (!active || session == null) {
                event("OnCommand", id, "INACTIVE_OR_NO_SESSION; no SDK called", requestId, null);
                return;
            }
            try {
                session.UIDisplayMessage(MESSAGES, "P1_UI_PROBE_CALLBACK", null);
                event("UIDisplayMessage", id, "RETURNED; key=P1_UI_PROBE_CALLBACK; no model API called", requestId, null);
            } catch (Throwable error) {
                event("UIDisplayMessage", id, "THROWN; key=P1_UI_PROBE_CALLBACK; no model API called", requestId, error);
            }
        }
    }

    private static void event(String stage, String id, String outcome, String requestId, Throwable error) {
        String text = Instant.now() + " UI_PROBE; registrationId=" + registrationId
                + "; route=" + route + "; commandId=" + id + "; requestId=" + requestId
                + "; stage=" + stage + "; messageFile=" + MESSAGES
                + "; messageLookup=MESSAGE_LOOKUP_UNVERIFIED; outcome=" + outcome;
        // A whole error record is emitted together; never print process environment or credentials.
        if (error != null) {
            java.io.StringWriter stack = new java.io.StringWriter();
            error.printStackTrace(new java.io.PrintWriter(stack));
            text += System.lineSeparator() + stack;
        }
        System.err.println(text);
    }
}

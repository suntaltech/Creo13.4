# R11 Stage1 校准字段整改候选（2026-11-16）

本包修正上一版字段错位及诊断输出膨胀，含源码、审核说明、37 项测试和 29 条真实样本的字段复核。**本轮完整校准回放仍待本机验证**，样本审核不等于校准通过。

先读 ROOT_CAUSE_AND_REVIEW.md。当前 reference/contract.json 为 v2；input_docs 保留历史及本轮任务供追溯，旧表的“ID12 无 Irp”和“完成首字段可能是 FileObject”已纠正。

## 本机先核对模板

在解压根目录，用 Python 3.9+ 复跑测试并检查两个 PowerShell 文件：

```powershell
$ErrorActionPreference = 'Stop'
py -3 -m unittest discover -s tests -v
if ($LASTEXITCODE -ne 0) { throw '单测失败，停止' }
foreach ($ReviewTool in @('tools\Check-R11ProviderSchema.ps1', 'tools\Extract-R11.ps1')) {
    $ReviewTokens = $null
    $ReviewParseErrors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile(
        (Join-Path (Get-Location).Path $ReviewTool), [ref]$ReviewTokens, [ref]$ReviewParseErrors)
    if ($null -ne $ReviewParseErrors -and $ReviewParseErrors.Count -gt 0) {
        $ReviewParseErrors
        throw 'PowerShell 语法门失败'
    }
}
.\tools\Check-R11ProviderSchema.ps1 -OutputFile '.\provider-schema-r1.json'
```

模板检查只读安装的 provider 元数据，不读 ETL、不启停 ETW。不一致或无法展开就停止，回传小型 provider-schema-r1.json 与报错；不按指针交集自行交换字段。报告与确切合同哈希绑定。

## 只读重跑现存校准 ETL

新输出目录保留上一轮证据和大日志；不要删除原始 ETL。旧提取件第二遍按错位键过滤，不能只换标签或改合同哈希来冒充本轮回放。

```powershell
$FormalEvidenceEtl = 'D:\creo-tools\build\p1-step41-r10-late-find-review-20261112\runtime-r11\formal.etl'
$CalibrationEvidenceEtl = Join-Path (Split-Path $FormalEvidenceEtl) 'calibrate.etl'
$OfflineReviewRoot = 'F:\P1_R11_Stage1_CalFix_20261116_R1'
if (-not (Test-Path -LiteralPath $CalibrationEvidenceEtl -PathType Leaf)) { throw '缺少现存校准 ETL，停止；不重采' }
.\tools\Extract-R11.ps1 -Etl $CalibrationEvidenceEtl -Mode calibration -OutputDirectory (Join-Path $OfflineReviewRoot 'cal-extract') -ProviderSchemaReport '.\provider-schema-r1.json'
py -3 .\tools\pair_r11.py --input-dir (Join-Path $OfflineReviewRoot 'cal-extract') --output-dir (Join-Path $OfflineReviewRoot 'cal-pairs')
if ($LASTEXITCODE -ne 0) { throw '校准门未过，停止并保留诊断件' }
```

须实际观测 offset 0 的 65B 写完成、随后 offset 0 的 65B 读完成和 offset 65 的读操作，写完成序号先于读起始。offset 65 通常是 EOF 探测，不能称为又读出 65B。仅当 accepted=true、calibration_gate=true、所有 gates 通过且退出码 0，才能进入正式证据回放。

## 校准通过后才读正式 ETL

```powershell
.\tools\Extract-R11.ps1 -Etl $FormalEvidenceEtl -Mode formal -OutputDirectory (Join-Path $OfflineReviewRoot 'formal-extract') -ProviderSchemaReport '.\provider-schema-r1.json'
py -3 .\tools\pair_r11.py --input-dir (Join-Path $OfflineReviewRoot 'formal-extract') --output-dir (Join-Path $OfflineReviewRoot 'formal-pairs') --calibration-report (Join-Path $OfflineReviewRoot 'cal-pairs\pairing-report.json')
if ($LASTEXITCODE -ne 0) { throw '正式回放门未通过，停止结论升级' }
```

所有步骤只读过去保留的证据，不改 Creo、UI、配置、模型或采集会话。已有输出目录拒绝覆盖；复跑选新名字，不删除旧证据。原 ETL 前后校验哈希。

## 输出与回传

重叠/跨上下文等每条最多 8 个历史引用，并保留总请求数与截断标志。overlaps、cross-context、unresolved、missing-anchor 四个重复诊断流默认各限 32MiB / 20,000 条；原始输入 JSONL 与核心 pairs/pending 保留。触限明确记省略数，并令 diagnostic_details_complete=false、accepted=false、文件级成功字节小计为 null，不静默丢掉原证据。确需扩大时，只对现存 JSONL 改用新输出目录并调整 --diagnostic-max-bytes / --diagnostic-max-records，无需重读或重采 ETL。

先回传两个脚本 Parser 结果、provider-schema-r1.json、新校准 extraction.json 和 pairing-report.json。失败再附基线路径附近少量原始请求/完成头与 raw_properties；不发整份 ETL 或大 JSONL。校准未过就不读正式 ETL。

tools/audit_samples.py 仅审核包内样本，结果见 validation/sample-field-review.json。17 条基线样本没有 ID24，另外 12 条 ID24 与基线读写请求 Irp 无交集；所以云端无法生成真实通过的 extraction.json / pairing-report.json，本包未捏造这些报告。

计数差异单列保留：校准 Get-WinEvent 1,085,012 / 原会话头 1,085,013；正式基线 1,916,191 / 原会话头 1,916,192，均相差一条，不擅自解释或强行对齐。BuffersLost 仍未知，其他编解码与时钟未决项不因此清零。

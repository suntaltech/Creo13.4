# 静态自查状态

主审核说明见 ROOT_CAUSE_AND_REVIEW.md。

- 输入 ZIP 外部 SHA256 及内部 7 项清单通过。
- 合同 v2 核对 ID12/13/14/15/16 Version 1、ID24 Version 0、Opcode 0 及原始类型，未知版本拒绝套用。
- 37 项 Python 测试通过；29 条真实样本只做字段复核，未证明真实校准配对通过。
- 微软参考源码固定提交并核对哈希；次级 manifest 与实际样本交叉核对；本机原生模板必须另审。
- Python AST 自查通过；本轮两个 PowerShell 文件的本机 Parser 与 ETL 执行尚待验证，不能继承上一版 Parser 成功结论。
- 没有覆盖旧代码、日志或 ETL；没有修改插件/UI/配置/模型或重采、部署。
- 未伪造校准 extraction.json / pairing-report.json；目前样本没有基线匹配完成事件。

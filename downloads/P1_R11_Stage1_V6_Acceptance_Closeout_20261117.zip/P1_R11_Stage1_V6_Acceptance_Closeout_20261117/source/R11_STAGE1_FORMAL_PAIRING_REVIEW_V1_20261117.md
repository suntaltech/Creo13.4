# R11 阶段一 formal.etl 配对审核记录 V1（2026-11-17）

## 1. 范围与边界

- 对象：正式会话 `formal.etl`（PID 23636，243,662,848B，SHA256 `AEDDC77D…BAD5`），使用第五轮 Exit Drain Fix 工具链（合同 schema `r11-stage1-contract/2`，配对报告 schema `r11-stage1-pairing/4`）。
- 只读重放提取产物；未启停 ETW、未 tracerpt、未改写 ETL、未改 Creo/模型/配置/UI、未部署、未重采、未发送 PTC。
- 结论仅限文件访问事件层的提取、字段映射与配对门；不构成 DLL 加载、GUI 命令枚举或实体转钣金可用性判定。
- 校准基准：v5 校准配对报告 `F:\P1_R11_Stage1_ExitDrainFix_20261116_R1\cal-pairs\pairing-report.json`（mode=calibration、accepted=true、calibration_gate=true、合同哈希 `ED3FFE8A…ABB4CF4`）。
- 分工：助手规划/规则/审核/验收；配对规则与代码实现归 ChatGPT。

## 2. 提取门（R2，通过）

首跑后台进程在尾部被中断（process 末条 seq 1,876,753 / 总 1,916,191），未写 extraction.json、两遍顺序哈希未留证，按规则不可验收；保留该不完整目录，重跑到新目录 `formal-extract-R2`。

R2 提取目录：`F:\P1_R11_Stage1_ExitDrainFix_20261116_R1\formal-extract-R2\`，报告 `extraction.json`。

| 项 | 结果 |
| --- | --- |
| complete / error | true / null |
| source_bytes / source_unchanged | 243,662,848 / true，前后哈希 `AEDDC77D…BAD5` |
| pass1 / pass2 总事件 | 1,916,191 / 1,916,191（合同 get_winevent_total 1,916,191） |
| target_order_matches | true，两遍顺序哈希一致 `0F6A9F0C…0C63` |
| decode_errors | 0；process_decode_errors=[] |
| context_records / process_records | 1,334,381 / 125 |
| target 计数 | 与合同 event_counts 逐项一致：10=1202,11=68,12=7147,13=6000,14=4370,15=38009,16=427,17=76,18=25,19=17,20=1305,21=17,22=5640,23=2512,24=60450,31=71,32=738,34=7 |

四产物独立回算哈希/字节全 MATCH，bad=0：target-events 117,256,082B、process-events 182,580B、context-events 1,222,598,198B、provider-schema 9,682B。

## 3. 配对门结论：accepted=false（27 道门 25 过 2 败）

配对目录：`F:\P1_R11_Stage1_ExitDrainFix_20261116_R1\formal-pairs\`，报告 `pairing-report.json`，退出码 2。

### 3.1 通过的门

extractor_completed、source_unchanged、contract_hash、source_size、two_pass_counts_equal、two_pass_target_order、payload_decoding、target_pid、etl_identity、total_event_baseline、installed_provider_schema、四产物哈希（hash_target/context/process/provider-schema）、process_payloads_decoded、formal_etl_hash、get_winevent_total、pid_counts_declared、calibration_65_byte_actual_replay（v5 校准 65B 回放合格）、target_creation_present、stored_counts_equal_extractor、all_payloads_mapped、target_inside_window、get_winevent_utc_clock（observed_offsets 仅 `Z`）、stored_counts_equal_baseline。

### 3.2 失败门 A：target_lifetime_known=false（unknown_process_lifetime=100）

进程边界（process 事件 raw_xml ProcessID=23636）：

- 创建边界 seq 393339，ID1/1，`2026-11-12T07:25:18.2888736Z`，代际 393339。
- 退出边界 seq 1326139，ID2/2，`2026-11-12T07:27:23.3964675Z`。
- 创建前（seq<393339）无 target 文件事件。

退出边界之后共 101 条 target 文件事件，按 resolve_event 规则复算分类：

| 分类 | 计数 | 说明 |
| --- | --- | --- |
| exit-drain（100ms 窗内） | 1 | ID24，seq1326962，88.223ms，归前代际 393339 |
| outside_controlled_exit_drain_window | 98 | 白名单 13/14/22/24，延迟 120–624.691ms，超 100ms 策略窗 |
| post_exit_event_not_in_drain_allowlist | 2 | ID23，159.779ms / 195.344ms，非 drain 白名单；InfoClass 590448 |

- 延迟桶：90–100ms 1；120–130ms 18；160–170ms 60；200–210ms 21；620–630ms 1。最晚一条 seq1335294 ID24 完成，624.691ms。
- 规则内行为正确：超窗、非白名单一律判 unknown，未放宽、未误配成数据请求。
- 根因：真机 formal 会话退出后内核收尾延迟跨度到约 625ms，超出当前 100ms 审核策略窗；ID23 是否属可归属收尾操作待规则裁决。这不是 ETL 丢失或解析错误——边界、计数、字段、哈希门全部通过。

### 3.3 失败门 B：diagnostic_details_complete=false

诊断流受采样上限（默认 20,000 条 / 32MB 每有限流）截断：

| 流 | 写入 | 省略 | 总量 |
| --- | --- | --- | --- |
| unresolved | 20,000 | 18,236 | 38,236 |
| overlaps | 17,624 | 31,466 | 49,090 |
| pairs | 22,312 | 0 | — |
| missing-anchor | 16,999 | 0 | — |
| pending | 44,049 | 0 | — |
| exit-drain | 1 | 0 | — |
| cross-context | 2 | 0 | — |
| context-reference | 20,000 | 1,314,381 | 允许采样，不计门 |

raw 输入 JSONL 全量保留并哈希留证；省略不是原始 ETL 丢失。属诊断保留容量配置，可通过提高 `--diagnostic-max-records` / `--diagnostic-max-bytes` 重跑消除，不改配对规则。

### 3.4 R2 提限复测（B 门隔离验证，2026-11-17）

为分离"诊断容量"与"生命周期规则"两个变量，以 R2 提取产物为输入，drain 窗保持默认 100ms 不变，仅提高诊断采样上限到 `--diagnostic-max-records 60000 --diagnostic-max-bytes 268435456`（256MB），重跑到新目录 `formal-pairs-R2`（既有 `formal-pairs` 未覆盖）。

| 项 | 首轮 formal-pairs | R2 formal-pairs-R2 |
| --- | --- | --- |
| accepted | false | false |
| diagnostic_details_complete | false | **true** |
| target_lifetime_known | false | false（unknown=100 不变） |
| pairs / pending / exit_drain / unknown | 22,312 / 44,049 / 1 / 100 | 22,312 / 44,049 / 1 / 100（逐项一致） |
| unresolved 写入 / 省略 | 20,000 / 18,236 | 38,236 / **0** |
| overlaps 写入 / 省略 | 17,624 / 31,466 | 49,090 / **0** |
| context-reference 省略 | 1,314,381 | 1,274,381（允许采样，不计门） |

结论：B 门确为采样容量问题，提限后 unresolved/overlaps 全量写全、门转 true；配对 counters 与首轮逐项一致，证明提限不改变任何归属判定。A 门独立保留，unknown=100 未受提限影响。

R2 全量 unresolved 流复核（38,236 条）：`overlapping_or_tainted_irp` 37,834、`no_same_scope_pending_request` 302、`unknown_process_lifetime` 100。100 条 unknown 子原因：

| 子原因 | 计数 | ID 分布 | 延迟 |
| --- | --- | --- | --- |
| outside_controlled_exit_drain_window | 98 | 13=23、24=51、14=20、22=4 | 115.600–624.691ms，超 100ms 窗 |
| post_exit_event_not_in_drain_allowlist | 2 | 23=2 | 非白名单直接排除（不记 elapsed），InfoClass 590448 |

两条 ID23：seq1327723（159.779ms）、seq1328038（195.344ms），InfoClass 均 590448，IssuingThreadId 7260。最晚超窗事件 seq1335294 ID24 完成，624.691ms，ExtraInformation 16384，Status 0。

### 3.5 700ms 窗复测与校准回归（2026-11-17，按裁决）

裁决：drain 策略窗放宽至 700ms；ID23 维持排除（不入白名单）。窗值通过配对器既有参数 `--exit-drain-max-ms 700` 传入，未改合同、提取脚本与归属代码；ID23 排除在窗判定之前（resolve_event 215–216 行），新操作 12/15/16 关窗逻辑（210–214 行）不受窗值影响。

**formal R3**（`formal-pairs-R3`，700ms 窗 + 60000 条/256MB 诊断上限）：

| 桶 | 首轮/R2（100ms） | R3（700ms） | 说明 |
| --- | --- | --- | --- |
| exit_drain | 1 | 99 | 98 条超窗白名单收尾被窗吸收 + 原 1 条 |
| unknown_process_lifetime | 100 | 2 | 仅剩 2 条 ID23 非白名单 |
| pairs | 22,312 | 22,296 | -16（作用域重划连带） |
| ambiguous_completions | 37,834 | 37,851 | +17 |
| cross_context_completions | 300,911 | 303,757 | +2,846（作用域重划连带） |
| overlap_requests | 43,944 | 43,958 | +14 |
| pending_requests | 44,049 | 44,065 | +16 |
| orphan / missing-anchor / FO-reuse / foreign | 302 / 16,985 / 5,146 / 1,334,381 | 不变 | — |

- 99 条 exit-drain 锚点核查：52 条 ID24 完成态无 FileObject（记录形态正常）；47 条 ID13/14/22 收尾 `open_anchor_present=True`、`file_object_previously_opened_in_generation=True`，FileObject 均在前代际已打开；未见前代际未见对象被误挂。
- 连带迁移性质：收尾事件归属前代际后，其 IRP/FO 作用域由 None 改为前代际，pending/ambiguous/cross-context/overlap 计数随之重划；活跃期事件归属逻辑未变。cross-context 增量为同 PID 完成态跨作用域未匹配（481–485 行），非 foreign PID 污染（foreign 在 355–376 行独立分流）。该连带变化列为待观察项，不据此宣称配对质量提升。
- R3 仍 `target_lifetime_known=false`：门口径为 `unknown_process_lifetime==0`（686 行），2 条 ID23 维持排除即必然 unknown。

**校准回归**（`cal-pairs-R2`，700ms 窗同参数）：accepted=true、退出码 0，全部门 true；counters 与 v5 基线逐项一致——exit_drain 371、unknown 0、pairs 29,956、orphan 835、ambiguous 117、cross-context 26,155、overlap 119、pending 123、missing-anchor 41、foreign 633,007；65B 链序号证明（180106/180107/180436/180437/180438/180439）不变。700ms 窗对校准会话零退化（校准 drain 最晚 40.98ms，窗放宽未吸收新事件）。

**待裁决硬冲突**：门口径要求 unknown=0，与"ID23 维持排除"互斥。可选路径：(a) 接受 formal 会话生命周期门不过，2 条 ID23 记 unknown、accepted=false；(b) 由 ChatGPT 拆分门口径，将可识别的非白名单收尾查询与真正不可归属事件分开统计，2 条 ID23 不计入阻断性 unknown；(c) 重新评估把 ID23 纳入白名单。

### 3.6 V6 生命周期门拆分回包本机验收（2026-11-17，路径 b 落地）

裁决落地为路径 (b)：阻断性 unknown 与非阻断退出后参考分离。回包 `P1_R11_Stage1_Lifetime_Gate_Split_V6_20261117.zip`（161,966B，SHA256 `26A904912C16AF58C03A7E5B5BA43EB029126AC9CDC79B6CDA148D11083B1C38`），解压根 `fix6\extracted\P1_R11_Stage1_Lifetime_Gate_Split_V6_20261117\`。

**静态完整性核对**

- 包内 SHA256SUMS 61 条目独立回算全 MATCH（BAD 0）。
- `reference/contract.json`、`tools/Extract-R11.ps1`、`tools/Check-R11ProviderSchema.ps1` 与 v5 fix4 基线逐字节 identical（合同 `ED3FFE8A…ABB4CF4`；两 ps1 哈希 `6115F72B…`、`3B6F4C38…`）。
- `tools/pair_r11.py` 50,135B（v5 44,333B），SHA256 `99528DD3DCE22C625457466936D16FC9316FED7CA4A6505D1963228B9B58543B`；报告 schema `r11-stage1-pairing/6`。
- 静态核对 diff 与源码：新增 `post_exit_reference_profile` 严格形状校验（ID23/v1/opcode0、Kernel-File provider、named mapping 无 decode_error、闭合六字段、三指针可解析、ExtraInformation=0、InfoClass=590448、无显式写候选）；非白名单且非 ID23 仍阻断 unknown；profile 不 qualified 回落 unknown；qualified 返回 `post_exit_classified_reference`，generation=null、reference_generation 仅作上下文、`excluded_from_matching=True`；reference 分支在代际/FO/锚点/pending/IRP 索引/配对/taint 变更之前 return；独立计数 `post_exit_classified_reference`；门 `target_lifetime_known`、`calibration_target_not_after_unmatched_exit` 仍只判阻断 `unknown_process_lifetime==0`；新增诊断流 `post-exit-classified-reference.jsonl`；CLI `--disable-post-exit-classified-reference` 可回退阻断。
- 包内 74 项 unittest 本机 `python -m unittest discover` 全过（4.101s，退出码 0），与云端 validation-status 记录一致；回退、坏指针/非零信息/写证据/未验证映射/超窗/新 IO/缺前代际等阻断边界均有单测。

**校准 V6 回归**（`cal-pairs-V6`，700ms 窗、60000 条/256MB 上限，不传校准报告）：accepted=true、退出码 0、全部门 true。counters 与 v5 基线逐项一致——exit_drain 371、unknown 0、pairs 29,956、orphan 835、ambiguous 117、cross-context 26,155、overlap 119、pending 123、missing-anchor 41、foreign 633,007；`post_exit_classified_reference=0`；65B 链六序号（180106/180107/180436/180437/180438/180439）与基线逐字段相等。700ms 窗 + V6 拆分对校准会话零退化。

**formal R4b**（`formal-pairs-R4b`，700ms 窗、60000/256MB、传入 v5 校准基线报告）：accepted=true、退出码 0、27 门全 true。

| 桶 | R3（700ms 旧规则） | R4b（V6） | delta |
| --- | --- | --- | --- |
| unknown_process_lifetime（阻断） | 2 | 0 | -2 |
| post_exit_classified_reference（非阻断） | — | 2 | +2（新桶） |
| exit_drain | 99 | 99 | 0 |
| pairs | 22,296 | 22,296 | 0 |
| ambiguous_completions | 37,851 | 37,851 | 0 |
| orphan_completions | 302 | 303 | +1 |
| cross_context_completions | 303,757 | 300,909 | -2,848 |
| overlap_requests | 43,958 | 43,958 | 0 |
| pending_requests | 44,065 | 44,063 | -2 |
| missing-anchor / FO-reuse / foreign | 16,985 / 5,146 / 1,334,381 | 不变 | 0 |

- 两条参考记录（`post-exit-classified-reference.jsonl`，恰 2 条，6,376B）：seq1327723（159.779ms，FO `0xffffa78c1c6053e0`、FK `0xffffdd08a2d67170`、Irp `0xffffa78bfdfe0b88`）、seq1328038（195.344ms，FO `0xffffa78c1b606e70`、FK `0xffffdd08be985170`、Irp `0xffffa78c02b85b88`）；reference_generation=393339、退出边界 seq1326139；`new_anchor/new_pending/pair_candidate=False`、`excluded_from_matching=True`、profile qualified、InfoClass 590448 标 unmapped、ExtraInformation 0、`transferred_bytes_candidate=None`。
- 配对签名对照器 `compare_v6_reports.py`（`v6-regression-review.json`，15 项全 true，退出码 0）：全时段 22,296 条签名 digest `350ea5b8…2197bae8f`、活跃期 22,263 条 digest `4c8c5381…2e0b9d` 与 R3 完全一致；校准 counters/六序号、合同哈希、700ms 政策、双方 accepted、阻断 unknown=0、参考恰两条、exit_drain=99 全部通过。

**连带迁移审计（未匹配桶内部重划，非新误配）**

- pending −2：两条 ID23 本体在 R3 占用 IRP pending 槽（R3 pending 各含本体 1 条），R4b 不建 pending、不进 IRP 索引；pending 槽位 107→105。
- orphan +1：seq1327724（PID 23636，ID24 完成态，Irp `0xffffa78bfdfe0b88`，与第一条 ID23 同 Irp）；R3 因 ID23 占用索引记 cross-context，R4b 失去引用槽位改判 orphan。R4b orphan 303 条 PID 全部 23636，无 foreign。
- cross-context −2,848：两条 ID23 不再把 IRP/FO 挂入前代际作用域后，同 PID 完成态的 IRP reference-only 命中减少；foreign 计数 1,334,381 不变（foreign 独立分流）。
- pairs/ambiguous/overlap/missing-anchor/foreign/exit_drain 三版不变，活跃期配对签名 digest 不变；变化仅限未匹配桶。该连带迁移沿用 R3 已记录的作用域重划性质，列为待观察项，不据此宣称配对质量提升。

**保守回落复测**（`formal-pairs-R4c`，`--disable-post-exit-classified-reference`）：accepted=false、退出码 2、`target_lifetime_known=false`；unknown=2、reference=0、exit_drain=99，orphan 302、cross-context 303,757、pending 44,065、pairs 22,296，逐项回到 R3 分布。证明例外开关只影响这两条归属，关闭后保守回落阻断，不扩展 drain 白名单。

> 备注：首跑 `formal-pairs-R4` 未传 `--calibration-report`，`calibration_65_byte_actual_replay=false`，属命令参数遗漏；已由 `formal-pairs-R4b` 补传校准报告复跑闭环，该中间目录保留不删、不作验收依据。

## 4. 配对计数（counters）

| 桶 | 计数 |
| --- | --- |
| pairs | 22,312 |
| orphan_completions | 302 |
| ambiguous_completions | 37,834 |
| requests_missing_anchor | 16,985 |
| cross_context_completions | 300,911 |
| overlap_requests | 43,944 |
| file_object_reuse_with_pending | 5,146 |
| pending_requests | 44,049 |
| foreign_context_records | 1,334,381 |
| exit_drain | 1 |
| unknown_process_lifetime | 100 |
| pending_irp_scope_slots | 105 |

V6 R4b 最终计数器（`formal-pairs-R4b`，accepted=true）：exit_drain 99、阻断 unknown_process_lifetime 0、post_exit_classified_reference 2、pairs 22,296、orphan 303、ambiguous 37,851、cross-context 300,909、overlap 43,958、pending 44,063、missing-anchor 16,985、FO-reuse 5,146、foreign 1,334,381、pending_irp_scope_slots 105。

- `calibration_sequence_proof=null`、`calibration_baseline_chain=null`：formal 会话本身无 65B 基线链；校准 65B 链来自 v5 校准报告回放，formal 门 `calibration_65_byte_actual_replay=true`。
- accepted=false 时成功读/写字节聚合不暴露为候选值（配对器规则），各路径 `successful_read/write_bytes_candidate=null`。
- target_coverage 观测到 10 个目标名路径（p1_fc.txt、p1_readonly_model_info.txt、p1_readonly_ping.txt、p1-step23.dat、p1_step41_r10_late_find_snapshot.dat/.dll、config.pro 三处、creo_parametric_customization.ui、d829u7mh.ui、.ui.bak）；空列表表示本次重放未见显式打开路径，不证明未访问。
- 头部：events_lost_reported=0；buffers_lost=null（未独立取得，不据校准零丢失推断）；header 引用哈希 `87f0246d…feb51e`。

## 5. 处置选项与待裁决

### 5.1 诊断门 B（容量配置，非规则变更）——已复测闭环

已按 `--diagnostic-max-records 60000 --diagnostic-max-bytes 256MB` 重跑（见 3.4），unresolved/overlaps 写全、`diagnostic_details_complete=true`，counters 与首轮逐项一致。后续正式配对可沿用该上限；不改动合同、提取脚本与配对归属规则。

### 5.2 生命周期门 A（规则裁决项，需 ChatGPT 改规则 + 助手审核）

- **裁决已落地（2026-11-17）**：drain 策略窗放宽至 700ms；ID23 维持排除（不入收尾白名单）。R3 复测与校准回归见 3.5。
- **后续裁决：拆分门口径（V6）**：阻断性 unknown 与非阻断退出后收尾参考分离；ID23 两条满足非阻断硬条件（退出后窗内、非新操作、无写候选、不建锚点/不进 pending/不产候选）时归入 `post_exit_classified_reference`，不计入阻断性 unknown。规则规格与验收口径见离线输入包。**V6 回包本机验收已通过（2026-11-17），结论与证据见 3.6。**
- 放宽前复核结论：700ms 窗对校准会话零退化；长窗内未见 PID 复用与活跃期误配证据；新操作（12/15/16）关窗规则未被绕过。
- 当前保守口径保留：不满足非阻断条件的事件记 unknown，不计成功字节。

## 6. 仍为未决、不下武断结论

- ID23 语义与 InfoClass 590448 映射；IOFlags 位定义；InfoClass 19/64/65 query/set 张力、0 未定义、589992(0x900E8) 非法值；0x216 无样本不可解码。
- tracerpt +07:59 偏移根因；历史卷号映射；BuffersLost 独立样本；.ui 写是否持久化；DLL 读取/加载结论；R10 DAT 与 config.pro 偏大完成传输量。
- 长窗放宽对校准会话既有结论的影响：已由 `cal-pairs-R2`（700ms 旧规则）与 `cal-pairs-V6`（700ms + 拆分规则）两次回归闭环，counters 与 65B 链零退化。

## 7. 关键路径

- v5 工具链解压：`D:\creo-tools\build\p1-step41-r11-stage1-review-20261116\fix4\extracted\P1_R11_Stage1_Exit_Drain_Fix_20261116\`
- formal R2 提取：`F:\P1_R11_Stage1_ExitDrainFix_20261116_R1\formal-extract-R2\`
- formal 首轮配对：`F:\P1_R11_Stage1_ExitDrainFix_20261116_R1\formal-pairs\`
- formal R2 提限复测配对：`F:\P1_R11_Stage1_ExitDrainFix_20261116_R1\formal-pairs-R2\`
- formal R3 700ms 窗配对：`F:\P1_R11_Stage1_ExitDrainFix_20261116_R1\formal-pairs-R3\`
- 校准 700ms 回归配对：`F:\P1_R11_Stage1_ExitDrainFix_20261116_R1\cal-pairs-R2\`
- 首跑不完整目录（保留未删）：`F:\P1_R11_Stage1_ExitDrainFix_20261116_R1\formal-extract\`
- v5 校准配对：`F:\P1_R11_Stage1_ExitDrainFix_20261116_R1\cal-pairs\pairing-report.json`
- 原始证据（只读）：`D:\creo-tools\build\p1-step41-r10-late-find-review-20261112\runtime-r11\formal.etl`
- V6 离线输入包目录：`D:\creo-tools\build\p1-step41-r11-stage1-review-20261116\stage1-lifetime-gate-split-v6-input-20261117\`
- V6 离线输入包 zip：`D:\creo-tools\build\P1_Step41_R11_Stage1_LifetimeGateSplit_V6_Offline_Input_20261117.zip`（17,767B，SHA256 `3160626AA8451A881743057800A438F8C231ED181CD54B4A752F6579F6F9944C`）
- V6 回包解压根：`D:\creo-tools\build\p1-step41-r11-stage1-review-20261116\fix6\extracted\P1_R11_Stage1_Lifetime_Gate_Split_V6_20261117\`
- V6 回包 zip：`D:\creo-tools\build\p1-step41-r11-stage1-review-20261116\fix6\downloads\P1_R11_Stage1_Lifetime_Gate_Split_V6_20261117.zip`（161,966B，SHA256 `26A904912C16AF58C03A7E5B5BA43EB029126AC9CDC79B6CDA148D11083B1C38`）
- 校准 V6 回归配对：`F:\P1_R11_Stage1_ExitDrainFix_20261116_R1\cal-pairs-V6\`
- formal V6 验收配对：`F:\P1_R11_Stage1_ExitDrainFix_20261116_R1\formal-pairs-R4b\`（含 `v6-regression-review.json`、`post-exit-classified-reference.jsonl`）
- formal V6 回退复测：`F:\P1_R11_Stage1_ExitDrainFix_20261116_R1\formal-pairs-R4c\`
- formal V6 首跑（漏传校准报告，保留不作依据）：`F:\P1_R11_Stage1_ExitDrainFix_20261116_R1\formal-pairs-R4\`

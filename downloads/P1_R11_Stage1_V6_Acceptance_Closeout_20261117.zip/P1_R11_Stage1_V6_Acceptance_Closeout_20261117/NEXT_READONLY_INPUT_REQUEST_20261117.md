# 下一步：只读目标文件证据对照的最小输入

阶段一 V6 已据本机报告通过。此任务仅收集现存验收产物，供云端读报告与做逐路径对照；不写新探针、不改代码、不重跑校准/正式 ETL、不启停 ETW、不部署、不改 Creo/模型/配置。

请按实际已保存位置收集以下四份文件，包内避免两个 pairing-report.json 同名覆盖：

| 包内路径 | 现存来源 |
|---|---|
|calibration/pairing-report.json|F:\P1_R11_Stage1_ExitDrainFix_20261116_R1\cal-pairs-V6\pairing-report.json|
|formal/pairing-report.json|F:\P1_R11_Stage1_ExitDrainFix_20261116_R1\formal-pairs-R4b\pairing-report.json|
|formal/v6-regression-review.json|报告所列 formal-pairs-R4b 内现存文件；若在其他目录只读定位，不重新运行生成|
|formal/post-exit-classified-reference.jsonl|formal-pairs-R4b 内已验收的两条参考流，报告大小 6,376B|

附现存文件的相对路径、字节数、SHA256 和一份来源说明；不带原始 ETL、整份 pairs/pending/context JSONL、大型 XML/CSV、DLL 或模型。缺文件就说明缺项，不拿 R4/R4c 或旧首轮输出顶替 R4b。

下一轮仅使用 accepted 的 formal report.files / target_coverage 逐路径列：

- 三个消息资源 p1_fc.txt、p1_readonly_model_info.txt、p1_readonly_ping.txt；
- p1-step23.dat、R10 dat、R10 dll；
- config.pro 各路径分别列，不能把三处混为一个文件；
- Roaming 和 Temp .ui 分开，.ui.bak 单列。

保留原始 NT 设备路径，不按当前主机重新猜历史盘符。字段包括 opens_observed、成功 Open 配对候选、读写请求次数/IOSize、成功读写完成字节候选、EOF 配对、pending 与覆盖状态。缺行只记“报告未见显式路径行”，不写成“从未访问”。

目标是确认目前有哪些文件层事实可以比较，以及哪些因歧义/缺锚点仍未知。此步骤不重新判定 DLL 初始化、GUI 枚举或实际转换成功；InfoClass590448 等未决语义继续保留。

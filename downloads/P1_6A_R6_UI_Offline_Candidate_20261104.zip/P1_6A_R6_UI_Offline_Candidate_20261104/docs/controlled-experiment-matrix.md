# R6单变量会话计划

JSON计划位于evidence-template/session-plan-matrix.json，plannedClass/plannedStartup/plannedLayout是设计条件，不是已加载的配置。selectedLayout、actualRestartObserved、feasibility、evidenceRefs仍未填。

| 计划 | 设计条件 | 单一变量 | 离线状态 |
|---|---|---|---|
| C1 | BatchRename / java / root | 基线layout | UNVERIFIED |
| C2 | 同一业务源码 / java / usascii | 只改变资源layout | UNVERIFIED |
| C3 | JLinkUiProbe / java | 只选一个既有策略ID | UNVERIFIED |
| C4 | OtkUiProbe / otk_java | 前提状态核对 | BLOCKED_PREREQUISITES计划形态，非实际运行结果 |

所有计划restartRequired=true仅为协议，实际重启仍UNVERIFIED。一次会话只选一种layout/startup/API路线；修改资源或身份需独立新会话。C1/C2与C3/C4不构成同一单因素因果链。C4 noFallbackToRouteA=true、derivedFromRouteA=false；不得引用C3作为B可行性。

未来每例前置记录：命令ID、源码/dat hash、layout与textDir、classpath身份、模型模式、是否重启。L1对象与L2触发分开，L3手动列表与L4手动Add/位置/反馈分开；全部引用须由操作者核对同用例，离线模板为空。L5不在本轮验证范围。

路线A依次独立记录FILE_EXPLICIT_NULL_NEIGHBOR、APPLICATIONS_EXPLICIT_NEIGHBOR、CUSTOM_TOP_LEVEL_INFO_MENU。源代码三个策略不改；旧菜单API仅NOT_MODERN_TOOLKIT_LIST_EVIDENCE。未来所有手动Add、触发、会话切换及配置处理均需明确授权；本文无运行命令或配置正文。

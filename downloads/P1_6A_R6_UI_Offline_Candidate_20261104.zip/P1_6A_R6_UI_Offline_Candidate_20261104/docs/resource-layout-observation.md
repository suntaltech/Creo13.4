# C1/C2资源观察（未来记录，未执行）

root-layout/text与usascii-layout/text/usascii保持独立且字节一致。清单selectedLayout=false，未选择优胜目录。实际text_dir是否查找某父目录/语言子目录仍UNVERIFIED；静态四行消息与键覆盖不证明原生解析。

C1/C2使用同一冻结业务源码，仅改变layout并新开会话。未来记录selectedLayout、textDir、restartedAfterLayoutChange、消息键加载状态和异常类，不能用计划字段证明已重启。

未来反馈分别标为调用未发生、调用返回未抛异常、调用抛异常、状态栏为空、文本与预期不一致；空白模板一律UNVERIFIED。保留RUNTIME_STRINGSEQ_ACCEPTANCE_UNVERIFIED；UIDisplayMessage第三参数仍null，没有空stringseq新分支。历史特定消息单次成功不外推其余上下文。

没有真实路径、截图、日志引用或执行结果写入本包。外部记录应由操作者核对同requestId/会话，不能拼接不同运行字段。

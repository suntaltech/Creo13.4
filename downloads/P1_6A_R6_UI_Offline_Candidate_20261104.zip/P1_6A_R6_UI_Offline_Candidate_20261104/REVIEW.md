# P1 6A R6 UI Offline 受控观察准备候选

日期：2026-11-04。R6是离线准备轮次，不是发布版本，不升级产品版本号。

固定边界：未编译、未加载、未部署、未证明UI可见、未证明OTK可行、未证明真实转钣金可用。

## 改动白名单与冻结契约

允许变更：checks/*.py、evidence-template/*.json、docs/*.md、evidence/*.json、REVIEW.md、SHA256SUMS。其余任何新增、删除或修改均失败。

BatchRename.java、三个探针、六份资源、三份注册模板共13个文件保持R5/R4字节；历史P1_6A_R4_UI_Offline.patch同样保留原字节，仅为历史材料，不是R6更新补丁。没有R6源码补丁，因为没有Java/资源/注册行为变化。

R5 ZIP SHA256：`18e61f253cb25c29e354952a1f12af488bc50c3f8bdf198df5273066aebd34fb`。
冻结业务源码SHA256：`9dbd71f36e403c3ed1a027d810a70befb57d3973c67aedca821f7b31df802400`。

新r5-baseline-files.json从保留的实际R5 ZIP生成离线文件哈希，检查器固定其内容摘要；R4历史冻结检查仍保留。新旧两份契约均无class或运行证据哈希。14个受保护业务块继续逐块冻结。

上传的R5审核报告/JSON与整改单列出的摘要匹配，结果见audit-input-identity.json。它们仅作为输入文件身份；未独立访问Windows编译产物、日志、截图、许可或机器状态。没有复制其中class哈希到R6证据。

## candidateSelfCheck与auditorLocalCompile

| 类别 | 含义 |
|---|---|
| candidateSelfCheck | 本轮实际Python文本、JSON/schema、白名单、反例及哈希完整性检查；不是SDK运行或UI验收。 |
| auditorLocalCompile | 本机审核者独立使用真实同步SDK/Java17隔离编译；不是本候选已执行事项。 |

R5报告中的140/16/25自查与本机4+5类major61结果继续作为已提供基线事实，不推翻也不升级。R6保留全部140主断言、16反例、25形状约束并叠加。源码不变时编译期望仍4+5类，但本轮没有编译结果或class文件。

## 新模板、空状态与断言

| 文件 | 空状态与用途 | 主要新增断言/反例 |
|---|---|---|
| controlled-case-record-skeleton.json | case/session/layer/status/model/selection/error/phase/completion均UNVERIFIED，creationAttempt=NO_ATTEMPT，featureCreated=UNVERIFIED，requestIds/evidenceRefs空，SDK触及信息UNVERIFIED | controlledCaseBlankDefaults、offlineTemplateNoRuntimeArtifactReference、featureCreatedHasNoSuccessValue；非空运行引用、L5成功误填反例 |
| manual-ui-observation-template.json | 命令/搜索/类别/L3/L4/点击/Designate/旧菜单结果UNVERIFIED，refs空 | manualUiTemplateRequiresEvidenceRefs；无refs的L3 PASS反例 |
| route-b-operator-record-template.json | 七项status/operatorObservation均UNVERIFIED、refs空、noFallbackToRouteA=true | routeBOperatorSevenBlankItems、routeBNoRuntimePrerequisiteClaim；UNLOCKED键误填反例 |
| session-plan-matrix.json | C1/C2/C3均UNVERIFIED；C4 BLOCKED_PREREQUISITES只是计划门禁，feasibility仍UNVERIFIED，无A替代、refs空 | sessionPlansSingleVariable、routeANotFallbackToRouteB、resourceLayoutNotSelectedOffline；C3替代C4和提前选layout反例 |

四份模板均runtime无证据，NO_ATTEMPT只是空白计划占位，不是已观察没有调用；C4默认阻断形态也不是对本机前提失败的实测结论。restartRequired=true只为协议，actualRestartObserved仍UNVERIFIED。

已有token工作表、12例负向计划、路线B七项前提、注册上下文及runtime骨架保持空白边界。全体实例JSON扫描运行引用、真实路径、成功值及认证声明；schema定义因必须列举未来允许值而单独处理，不将其enum声明误当运行结果。

## Schema新规则与兼容

R6新增PASS/FAILED/BLOCKED采集决策。为保留R5形状测试，旧observations/聚合字段中的VERIFIED兼容形式仍受原约束；新模板不预填该值，R6采集推荐使用新定义/字段，不自动把API返回或旧状态转换为PASS。

L1 PASS需SDK_OUTCOME、命令与真实源码/dat身份及CLASS/LOG引用；L2另需触发requestId和LOG；L3需MANUAL_UI、准确搜索/类别/可见性及SCREENSHOT/LOG；L4需手动Add、位置和只读反馈，且有SCREENSHOT及MANUAL_OPERATION_RECORD。新controlledCaseRecord在L3/L4 PASS时要求配套manualUiObservation；其详细条件单独验证。

FAILED记录需失败阶段、错误类别与WCreateFeature/WRegenerate/Save实际触及信息。creationAttempt独立为NO_ATTEMPT/BLOCKED_BEFORE_ATTEMPT/FAILED_ATTEMPT；离线不预填后两种。FAILED_ATTEMPT仅未来记录，必须有技术细节，不能填featureCreated成功值。新controlledCaseRecord的L5仅UNVERIFIED/BLOCKED，旧L5观察仍仅UNVERIFIED/NOT_APPLICABLE，不以失败尝试形成L5功能结论。

Schema只检查形状、字段和引用种类，不能认证截图、日志来源、许可、UI因果或模型结果。跨记录会话/命令/hash和引用是否实际匹配由操作者核对，不使用非标准schema等值扩展伪装认证。runtimeEvidenceAuthenticated=false，evidenceAuthenticity=UNVERIFIED。

形状用例只使用空骨架与孤立条件标签，不制造实际文件路径、requestId、截图或运行hash。临时文本反例只在临时目录构造错误JSON/文本，不执行Java、SDK或错误路径操作。

## 文档和操作者协议

controlled-operator-protocol.md明确单变量、前置身份、L1/L2分离、L3搜索类别与外部证据、L4另行授权手动Add、路线A独立策略、B前提阻断、负向门禁和生产边界。

layer-evidence-decision-rubric.md给出PASS最低证据及不足材料；resource-layout-observation.md只规划C1/C2实际layout/textDir/重启/消息键/异常观察；controlled-negative-case-plan.md保留12例并区分计划分类与实际码。

CREOSON_UNAVAILABLE仍仅辅助服务观察，不推断原生转换失败。板厚null/抛异常、原生内部拦截/Java校验、单位声明拒绝均须按未来实际路径记录。不能把“负向计划”解释为对任意模型触发业务回调都只读；未在预定门禁停止时应停止后续流程。

## 保持的行为与生产边界

业务、探针、资源、注册模板、历史补丁均不变。没有修改WCreateFeature、WRegenerate、钣金回读、面选择/归属、单位、板厚、树、失败诊断、保存、抽壳、桥接或CREOSON启动路径。探针仍不读模型或调用特征/服务；旧菜单返回仍NOT_MODERN_TOOLKIT_LIST_EVIDENCE。两布局不合并、不选择优胜；UIDisplayMessage第三参数仍null，RUNTIME_STRINGSEQ_ACCEPTANCE_UNVERIFIED保留。

- `config.proUnchanged=true (design promise; ChatGPT cannot verify machine state)`
- `productionFilesUntouched=true (design promise)`

设计承诺不是本机状态核验。历史R2配置恢复由操作者另行授权并管理备份；本包无config.pro片段、生产绝对路径、恢复/安装/卸载脚本、运行命令、自动UI调用或rbn手写内容。

## 确定性自查与未执行事项

报告只用相对文件名和稳定输入，不输出运行时间戳、临时路径、用户名或本机绝对路径。SHA256SUMS覆盖除自身外全部文件，check_package.py只读校验；原样复跑报告应保持字节一致。修改候选后不得沿用旧清单。

未执行javac、javap、jar、Creo、macro、进程查看、运行日志查看、许可查询、浏览器、deployment、feature creation、HTTP或SDK Mock/Stub。包内无class/jar/dat/bat/rbn/html/js/log、截图、解锁、签名或许可结论。

最终离线检查计数以evidence/static-claims.json、checker-negative-fixtures.json和schema-check.json为准；所有结果只支持准备材料的一致性，不支持L1/L2、L3/L4、OTK或L5的新增运行结论。

## 本轮candidateSelfCheck结果

161/161主断言、23/23临时文本反例、44/44 schema形状检查通过，原R5的140/16/25覆盖保留。业务、三个探针、六份资源、三份注册模板及历史补丁字节不变，R5白名单外差异为空。所有新模板空白，源文件身份核对不构成机器或运行认证。

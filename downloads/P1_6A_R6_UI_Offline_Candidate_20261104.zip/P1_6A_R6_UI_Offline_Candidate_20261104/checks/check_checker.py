"""Negative text/JSON fixtures only. Never compiles or executes Java or SDK."""
from pathlib import Path
import json,shutil,subprocess,sys,tempfile
out=Path(__file__).resolve().parents[1];baseline=Path(sys.argv[1]).resolve();results=[]
cases={
 'missing_referenced_key':'coverage_no_missing_root-layout',
 'unreferenced_extra_key':'coverage_no_unreferenced_root-layout',
 'business_missing_allow_stop':'template_exact_fields_business-java.dat.template',
 'route_b_missing_delay_start':'template_exact_fields_route-b-otk-java.dat.template',
 'route_b_wrong_startup':'template_forbidden_patterns_route-b-otk-java.dat.template',
 'template_async_sdk':'template_forbidden_patterns_route-a-java.dat.template',
 'template_production_path':'template_forbidden_patterns_route-a-java.dat.template',
 'protected_thickness_change':'protected_thicknessReadAndValidation',
 'recursive_forbidden_call':'recursive_forbidden_counts_zero',
 'business_byte_hash_change':'businessSourceByteFrozen',
 'outside_whitelist_file':'outsideWhitelistChangedFiles',
 'route_b_pass_state':'routeBPrerequisitesRemainUnverified',
 'offline_ui_success':'offlineSkeletonNoRuntimeSuccess',
 'resolved_template_path':'templateNoResolvedAbsolutePath',
 'duplicate_resource_key':'resourceKeysUnique',
 'probe_feature_call':'probeReadOnlyBoundary',
 'manual_ui_pass_without_refs':'manualUiTemplateRequiresEvidenceRefs',
 'route_b_unlocked_claim':'routeBNoRuntimePrerequisiteClaim',
 'negative_record_nonempty_runtime_reference':'offlineTemplateNoRuntimeArtifactReference',
 'feature_created_success':'featureCreatedHasNoSuccessValue',
 'route_a_result_used_for_b':'routeANotFallbackToRouteB',
 'root_selected_before_runtime':'resourceLayoutNotSelectedOffline',
 'instance_template_absolute_path':'templateNoProductionAbsolutePath'
}
for mutation,expected in cases.items():
 with tempfile.TemporaryDirectory(prefix='p1-r4-text-fixture-') as td:
  target=Path(td)/'candidate';target.mkdir()
  shutil.copytree(out,target,dirs_exist_ok=True)
  if mutation in {'missing_referenced_key','unreferenced_extra_key'}:
   p=target/'resources/root-layout/text/p1_6a_ui_commands.txt';lines=p.read_text().splitlines()
   if mutation=='missing_referenced_key':p.write_text('\n'.join(lines[4:])+'\n')
   else:p.write_text(p.read_text()+'P1_UNREFERENCED_FIXTURE\nExtra static-only fixture key\n\n\n')
  elif mutation=='business_missing_allow_stop':
   p=target/'registration/business-java.dat.template';p.write_text(p.read_text().replace('allow_stop @ALLOW_STOP_TRUE@\n',''))
  elif mutation=='route_b_missing_delay_start':
   p=target/'registration/route-b-otk-java.dat.template';p.write_text(p.read_text().replace('delay_start @DELAY_START_FALSE@\n',''))
  elif mutation=='route_b_wrong_startup':
   p=target/'registration/route-b-otk-java.dat.template';p.write_text(p.read_text().replace('startup otk_java','startup java'))
  elif mutation=='template_async_sdk':
   p=target/'registration/route-a-java.dat.template';p.write_text(p.read_text().replace('@ABSOLUTE_ISOLATED_PROBE_CLASSES_DIRECTORY@','pfcasync.jar'))
  elif mutation=='template_production_path':
   p=target/'registration/route-a-java.dat.template';sep=chr(92);fixture=chr(68)+':'+sep+'creo-tools'+sep+'jlink'+sep+'text'
   p.write_text(p.read_text().replace('@ABSOLUTE_SELECTED_RESOURCE_LAYOUT_TEXT_DIRECTORY@',fixture))
  elif mutation=='protected_thickness_change':
   p=target/'BatchRename.java';p.write_text(p.read_text().replace('entered <= 0.0','entered <= 0.01'))
  elif mutation=='recursive_forbidden_call':
   # Deliberately invalid-for-release Java TEXT fixture; never compiled, executed or copied to output.
   (target/'probes/StaticForbiddenFixture.java').write_text('class StaticForbiddenFixture { void f() { Save(); } }\n')
  elif mutation=='business_byte_hash_change':
   p=target/'BatchRename.java';p.write_text(p.read_text()+'\n// Byte-freeze text fixture only.\n')
  elif mutation=='outside_whitelist_file':
   (target/'unexpected-whitelist-fixture.txt').write_text('Not in the approved diff allowlist.\n')
  elif mutation=='route_b_pass_state':
   p=target/'evidence-template/route-b-prerequisite-checklist.json';value=json.loads(p.read_text());value['state']='PASS';p.write_text(json.dumps(value))
  elif mutation=='offline_ui_success':
   p=target/'evidence-template/runtime-evidence-skeleton.json';value=json.loads(p.read_text());value['evidence']['uiListed']='VERIFIED';p.write_text(json.dumps(value))
  elif mutation=='resolved_template_path':
   p=target/'registration/route-a-java.dat.template';sep=chr(92);fixture=chr(69)+':'+sep+'isolated-text-fixture';p.write_text(p.read_text().replace('@ABSOLUTE_SELECTED_RESOURCE_LAYOUT_TEXT_DIRECTORY@',fixture))
  elif mutation=='duplicate_resource_key':
   p=target/'resources/root-layout/text/p1_6a_ui_commands.txt';lines=p.read_text().splitlines();p.write_text(p.read_text()+'\n'.join(lines[:4])+'\n')
  elif mutation=='probe_feature_call':
   p=target/'probes/UiExposureProbe.java';text=p.read_text();text=text.replace('    public static void stop() {','    private static void staticOnlyFixture() { WCreateFeature(); }\n    public static void stop() {');p.write_text(text)
  elif mutation=='manual_ui_pass_without_refs':
   p=target/'evidence-template/manual-ui-observation-template.json';value=json.loads(p.read_text());value['l3CandidateListVisible']='PASS';p.write_text(json.dumps(value))
  elif mutation=='route_b_unlocked_claim':
   p=target/'evidence-template/route-b-operator-record-template.json';value=json.loads(p.read_text());value['UNLOCKED']=True;p.write_text(json.dumps(value))
  elif mutation=='negative_record_nonempty_runtime_reference':
   p=target/'evidence-template/controlled-case-record-skeleton.json';value=json.loads(p.read_text());value['requestIds']=['NON_RUNTIME_TEXT_FIXTURE'];p.write_text(json.dumps(value))
  elif mutation=='feature_created_success':
   p=target/'evidence-template/controlled-case-record-skeleton.json';value=json.loads(p.read_text());value['featureCreated']='SUCCESS';p.write_text(json.dumps(value))
  elif mutation=='route_a_result_used_for_b':
   p=target/'evidence-template/session-plan-matrix.json';value=json.loads(p.read_text());value['plans'][3]['derivedFromRouteA']=True;value['plans'][3]['feasibility']='PASS';p.write_text(json.dumps(value))
  elif mutation=='root_selected_before_runtime':
   p=target/'evidence-template/session-plan-matrix.json';value=json.loads(p.read_text());value['plans'][0]['selectedLayout']='root-layout';p.write_text(json.dumps(value))
  elif mutation=='instance_template_absolute_path':
   p=target/'evidence-template/controlled-case-record-skeleton.json';value=json.loads(p.read_text());sep=chr(92);value['operatorNotes']=chr(68)+':'+sep+'creo-tools'+sep+'jlink';p.write_text(json.dumps(value))
  run=subprocess.run([sys.executable,str(target/'checks/static_check.py'),str(baseline)],capture_output=True,text=True)
  report=json.loads((target/'evidence/static-claims.json').read_text())
  passed=run.returncode==1 and report['checks'].get(expected) is False
  results.append({'mutation':mutation,'expectedFailedAssertion':expected,'checkerExitCode':run.returncode,'detected':passed})
assert all(x['detected'] for x in results),results
(out/'evidence/checker-negative-fixtures.json').write_text(json.dumps({'scope':'temporary text-only mutations; not SDK mocks, process inspection or runtime tests','results':results,'allDetected':True},indent=2)+'\n')
print(json.dumps({'textNegativeFixturesDetected':len(results),'total':len(results)}))

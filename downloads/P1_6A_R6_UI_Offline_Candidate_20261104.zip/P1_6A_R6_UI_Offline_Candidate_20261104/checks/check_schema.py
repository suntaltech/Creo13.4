"""JSON-shape tests only. No runtime evidence, paths, hashes, images or logs are fabricated."""
from pathlib import Path
import copy,json
from jsonschema import Draft202012Validator
out=Path(__file__).resolve().parents[1]
schema=json.loads((out/'evidence-template/runtime-evidence-schema.json').read_text());Draft202012Validator.check_schema(schema)
validator=Draft202012Validator(schema);skeleton=json.loads((out/'evidence-template/runtime-evidence-skeleton.json').read_text())
results={'schemaStructureValid':True,'unfilledSkeletonValid':validator.is_valid(skeleton)}
for status in ['VERIFIED','FAILED']:
 value=copy.deepcopy(skeleton);value['observations']=[{'level':'L1_OBJECT','status':status,'source':'SDK_OUTCOME','refs':[]}]
 results[status.lower()+'WithoutRefsRejected']=not validator.is_valid(value)
for field in ['objectRegistered','macroDispatchable','uiListed','ribbonVisible','featureCreated']:
 value=copy.deepcopy(skeleton);value['evidence'][field]='VERIFIED';results[field+'WithoutLayerEvidenceRejected']=not validator.is_valid(value)
value=copy.deepcopy(skeleton);value['runtimeEvidenceAuthenticated']=True;results['schemaCannotAuthenticateRuntime']=not validator.is_valid(value)
value=copy.deepcopy(skeleton);value['observations']=[{'level':'L5_FEATURE_CREATION','status':'VERIFIED','source':'SDK_OUTCOME','refs':[]}];results['l5VerifiedRejected']=not validator.is_valid(value)
# Test conditional source/type predicates in isolation. These are not complete evidence objects:
# refs contain ONLY kind tags, never invented runtime file paths or SHA256 values.
obs=schema['properties']['observations']['items']
requirements={'L1_OBJECT':('SDK_OUTCOME',['LOG']),'L2_TRIGGER':('MACRO_CALLBACK',['LOG']),'L3_CANDIDATE_LIST':('MANUAL_UI',['SCREENSHOT']),'L4_FIXED_BUTTON':('MANUAL_UI',['SCREENSHOT','MANUAL_OPERATION_RECORD'])}
for level,(source,kinds) in requirements.items():
 rule=next(rule for rule in obs['allOf'] if rule.get('if',{}).get('properties',{}).get('level',{}).get('const')==level and rule.get('if',{}).get('properties',{}).get('status',{}).get('const')=='VERIFIED')
 predicate=Draft202012Validator(rule)
 value={'level':level,'status':'VERIFIED','source':source,'refs':[{'kind':kind} for kind in kinds]}
 results[level+'_conditionalTagsAccepted']=predicate.is_valid(value)
 value['source']='SDK_OUTCOME' if source!='SDK_OUTCOME' else 'MANUAL_UI';results[level+'_wrongSourceRejected']=not predicate.is_valid(value)
 value['source']=source;value['refs']=[{'kind':'OTHER'}];results[level+'_wrongRefKindsRejected']=not predicate.is_valid(value)
 if level=='L4_FIXED_BUTTON':
  value['refs']=[{'kind':'SCREENSHOT'}];results['l4ScreenshotWithoutManualRecordRejected']=not predicate.is_valid(value)
value={'level':'L3_CANDIDATE_LIST','status':'VERIFIED','source':'SDK_OUTCOME','designateReturned':'RETURNED','refs':[]}
rule=next(rule for rule in obs['allOf'] if rule.get('if',{}).get('properties',{}).get('level',{}).get('const')=='L3_CANDIDATE_LIST' and rule.get('if',{}).get('properties',{}).get('status',{}).get('const')=='VERIFIED')
results['designateReturnAloneCannotProveL3']=not Draft202012Validator(rule).is_valid(value)
# R6 additions retain the 25 R5 tests above and add new blank-record and PASS constraints.
for filename,definition in [('controlled-case-record-skeleton.json','controlledCaseRecord'),('manual-ui-observation-template.json','manualUiObservation')]:
 instance=json.loads((out/'evidence-template'/filename).read_text())
 view={'$schema':schema['$schema'],'$ref':'#/$defs/'+definition,'$defs':schema['$defs']}
 results[definition+'_blankValid']=Draft202012Validator(view).is_valid(instance)
case_view={'$schema':schema['$schema'],'$ref':'#/$defs/controlledCaseRecord','$defs':schema['$defs']}
case_validator=Draft202012Validator(case_view);blank_case=json.loads((out/'evidence-template/controlled-case-record-skeleton.json').read_text())
value=copy.deepcopy(blank_case);value['creationAttempt']='FAILED_ATTEMPT';results['r6FailedAttemptWithoutTechnicalDetailsRejected']=not case_validator.is_valid(value)
value=copy.deepcopy(blank_case);value['featureCreated']='SUCCESS';results['r6CaseFeatureSuccessRejected']=not case_validator.is_valid(value)
manual_view={'$schema':schema['$schema'],'$ref':'#/$defs/manualUiObservation','$defs':schema['$defs']}
manual_validator=Draft202012Validator(manual_view);blank_ui=json.loads((out/'evidence-template/manual-ui-observation-template.json').read_text())
value=copy.deepcopy(blank_ui);value['l3CandidateListVisible']='PASS';value['designateReturned']='RETURNED';results['r6ManualL3ApiReturnWithoutEvidenceRejected']=not manual_validator.is_valid(value)
value=copy.deepcopy(blank_ui);value['l4FixedLocationRecorded']='PASS';value['oldMenuReturned']='RETURNED';results['r6ManualL4OldMenuReturnRejected']=not manual_validator.is_valid(value)
# Conditional predicates use only tags, not invented file paths, requestIds or hashes.
for level,(source,kinds) in requirements.items():
 rule=next(rule for rule in obs['allOf'] if rule.get('if',{}).get('properties',{}).get('level',{}).get('const')==level and rule.get('if',{}).get('properties',{}).get('status',{}).get('const')=='PASS')
 predicate=Draft202012Validator(rule)
 value={'level':level,'status':'PASS','source':'SDK_OUTCOME' if source!='SDK_OUTCOME' else 'MANUAL_UI','commandId':'UNVERIFIED','refs':[]}
 results['r6_'+level+'_passWrongSourceRejected']=any(list(error.path)==['source'] and error.validator=='const' for error in predicate.iter_errors(value))
 value['source']=source
 if level=='L4_FIXED_BUTTON':
  value['manualAddRecorded']=True;value['fixedLocationRecorded']=True;value['readOnlyFeedbackRecorded']=True
 value['refs']=[{'kind':'OTHER'}];results['r6_'+level+'_passWrongRefKindRejected']=any(list(error.path)[:1]==['refs'] for error in predicate.iter_errors(value))
for field in ['manualAddRecorded','fixedLocationRecorded','readOnlyFeedbackRecorded']:
 rule=next(rule for rule in obs['allOf'] if rule.get('if',{}).get('properties',{}).get('level',{}).get('const')=='L4_FIXED_BUTTON' and rule.get('if',{}).get('properties',{}).get('status',{}).get('const')=='PASS')
 results['r6L4Requires_'+field]=field in rule['then']['required'] and rule['then']['properties'][field].get('const') is True
failure_rule=next(rule for rule in obs['allOf'] if rule.get('if',{}).get('properties',{}).get('status',{}).get('const')=='FAILED' and 'sdkCallTouches' in rule.get('then',{}).get('required',[]))
results['r6FailureRequiresStageErrorAndCallTouches']=set(failure_rule['then']['required'])=={'failedPhase','errorCategory','sdkCallTouches'}
results['r6CreationAttemptSeparateFromFeatureSuccess']=schema['properties']['creationAttempt']['enum']==['NO_ATTEMPT','BLOCKED_BEFORE_ATTEMPT','FAILED_ATTEMPT'] and set(schema['properties']['evidence']['properties']['featureCreated']['enum'])=={'UNVERIFIED','NOT_APPLICABLE'}

assert all(results.values()),results
(out/'evidence/schema-check.json').write_text(json.dumps({'scope':'schema structure, unfilled skeleton and isolated conditional shape predicates; not complete runtime evidence fixtures','checks':results,'allPassed':True,'schemaValidatedEvidence':True,'runtimeEvidenceAuthenticated':False},indent=2)+'\n')
print(json.dumps({'schemaShapeChecksPassed':len(results),'total':len(results)}))

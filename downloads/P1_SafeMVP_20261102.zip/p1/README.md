# P1 安全校验与只读分析整合模块

按 2026-11-02 开发要点实现第一阶段：**只读分析 + 参数校验 + 声明式元素树规格 + 结构化日志**。`nativeConvertReady` 固定为 `false`，不创建特征、不保存模型。

当前仓库只有 r4/r5 ZIP，没有现场新版 `BatchRename.java`、`sheetmetal.js` 和 `core.js`。本目录是独立增量模块，未修改原 ZIP，也没有覆盖现场代码。整合已有前端时合并这些功能，不直接覆盖现场同名 `core.js`。

## 文件与职责

| 文件 | 职责 |
|---|---|
| `java/P1Contract.java` | Java 17 纯校验、模式守卫、错误码、元素树规格、关闭的转换入口 |
| `java/JsonlAudit.java` | 有界异步 JSONL 写入，调用端不执行磁盘 IO，暴露丢弃计数/写入异常 |
| `web/sheetmetal.html` | 独立只读页面，所需控件 ID 与要求一致 |
| `web/assets/js/core.js` | 只读 CREOSON 客户端、超时、业务错误、JSONL 日志 |
| `web/assets/js/sheetmetal.js` | URL 守卫、只读分析、失败提示、禁用状态、日志导出 |
| `tests/` | Java 契约与前端 HTTP/DOM 模拟检查、可复跑入口 |
| `evidence/` | 本轮实际检查日志；**不是 Creo 实机执行日志** |

## 运行与复核

本云环境已准备 `/workspace/creo-dev/tools/jdk-17.0.17+10`，Node/Python 使用现有运行时。

```sh
cd /workspace/Creo13.4
python3 p1/tests/run_checks.py \
  --jdk /workspace/creo-dev/tools/jdk-17.0.17+10 \
  --output /workspace/creo-dev/p1-check-new
```

输出目录必须不存在，防止把历史结果误认为本次检查；每次使用新目录。检查包括 `javac --release 17`、class major=61、Java 契约测试、两项 `node --check`、前端行为测试和 JSONL 解析。所有底层命令必须返回 0。

Windows 现场先编译**新增纯 Java 模块到新暂存目录**：

```powershell
& 'D:\creoson\jdk25\jdk-25.0.5+8\bin\javac.exe' --release 17 -encoding UTF-8 `
  -cp 'D:\Program Files\PTC\Creo 13.4.0.0\Common Files\text\java\otk.jar' `
  -d '<新建暂存目录>' '.\p1\java\P1Contract.java' '.\p1\java\JsonlAudit.java'
node --check .\p1\web\assets\js\core.js
node --check .\p1\web\assets\js\sheetmetal.js
```

现场合并 `BatchRename.java` 后，使用相同 `--release 17` 与唯一 SDK `otk.jar` 编译合并源码和上述模块，预期退出 0。**本轮没有执行 Windows/JDK25/真实 SDK 编译**；纯模块编译不证明 WFC/J-Link 接口兼容。不得混入 `pfcasync.jar` 或把测试替身部署为 SDK。

## 只读分析边界

页面需由普通零件命令打开，携带 `modelMode=solid_part`。守卫在首次渲染时生效，`guard=need_part` 和 `state=sheetmetal` 优先。URL 仅控制展示与只读入口，不是后台授权证据。

同源请求默认 POST `/creoson`，顺序为：connect → 当前 get_fileinfo → feature/list → get_surfaces → bound_box → 再读当前 get_fileinfo。绑定首次读到的文件名，并拒绝分析过程中切换模型/修订的结果。重复点击受 busy 守卫保护；业务错误、格式错误、网络失败和 10 秒超时分别处理。HTTP 客户端有固定只读白名单，不能调用 save 或虚构的转换接口。

根据官方 CREOSON 仓库 `creoson-server/web/assets/creoson_stuff/jsonSpecs` 的五项定义实现；`get_surfaces` 使用 `surflist`、`surface_id`、`area`，包围盒使用 `xmin/xmax/...`。官方 `SurfaceData` 不含曲面类型、可见性或实体数量，因此：

- 候选平面数、最大平面返回 `null`，明确要求原生确认；不将最大面积面冒充驱动面。
- 包围尺寸显示为模型单位，不冒充 mm；板厚始终由用户显式输入，前后端统一范围 0.1–20 mm。
- 不根据特征名猜测 `IsSheetmetal()`；普通零件入口状态仍需 UI 线程原生复核。
- 不自动选 driving/shell，不写入 localStorage 的保存状态。当前所有转换参数及保存框禁用。

参考：<https://github.com/SimplifiedLogic/creoson/tree/master/creoson-server/web/assets/creoson_stuff/jsonSpecs>。现场 CREOSON 2.8.2 的接口形状仍需用实际响应复核。

## Java 整合边界

`validate(Map<String,String>, Snapshot)` 接受宿主按契约解析后的字符串参数；JSON 适配层须先校验类型，boolean 仅接受 JSON 布尔值，禁止任意对象/数组转字符串。`save` 缺省为 false，传 true 或非法值均返回 `SAVE_DISABLED`；`confirm` 必须明确 true。额外错误码为 `INVALID_REQUEST`、`UNKNOWN_ACTION`、`MODEL_CHANGED`、`CONFIRM_REQUIRED`、`MULTI_BODY_UNSUPPORTED`。

`Snapshot` 不是页面声明，也不是缓存的原生句柄。未来宿主须在真实命令动作/UI 线程重新读取当前模型、默认体、实体数、`IsSheetmetal()`、真实可见平面，并在同一动作中重新验证。当前构造 `Snapshot` 的测试不调用 Creo。

`describeRequiredTree` 只返回不可执行的规格：386 根/level0/null，387=32，1964 名称，1131=15 或24，6612 默认体角色，driving 专属5111，3332显式板厚。`SelectionRole` 是规格标识，**不能传给 SDK 当选择句柄**。没有增加未确认可选元素；shell 移除面尚未实现。

`convertActivePart` 对有效请求记录校验通过后返回 `CHANNEL_BLOCKED`，不会返回创建成功。没有 WFC 创建、重生成或保存调用，也没有注册浏览器监听、Timer、HTTP 服务或后台 Creo 调用。

## 原生通道待接入设计

优先在独立原生命令动作中执行；先在真实 SDK 上证明回调线程与三个既有 Ribbon 命令正常。页面参数传递仍未验收，不实现本地队列或未经确认的工厂/回调 API。不得只把健康标志改 true 来启用转换。

后续必须闭环：参数确认/一次性请求 ID → UI 动作重新读模型及单位 → 用户确认真实驱动/移除曲面 → `pfcSelect.CreateModelItemSelection` → 最小官方元素树 → `CreateElementTree` → `WCreateFeature` → `WRegenerate` → `IsSheetmetal()` 和 featureId 复查 → `saved=false`。这些调用仅为接入顺序要求，本模块没有猜写 SDK 签名。

需明确动作取消、重复请求拒绝、结果关联、异常与失败后不保存关闭策略；创建或重生成失败不能报告成功，也不能宣称已自动回滚。创建过程的 `Throwable` 堆栈只允许进 `jlink.log`，前端只接收可读错误。日志器应在非 UI 线程初始化，宿主退出时在非 UI 线程 flush/close；不得在 Creo UI 线程等待日志。

## 日志与后续整合

`schemaVersion=1`，核心字段为 timestamp（UTC ISO8601）、build、source、requestId、stage、outcome、errorCode、saved。Java 附 model/mode/thickness，前端记录只读接口阶段及分析结果；不记录 sessionId、认证信息或原始远端异常。

- Java 有效输入：`request_received/pending → validation/passed → native_channel/blocked`。
- Java 非法输入：`request_received/pending → validation/rejected`，附错误码。
- 前端：`analysis/started → 各只读请求 started/passed或failed → analysis/passed或failed`。
- `analysis/passed` 只代表只读分析成功；不能合并成转换成功。全部 `saved=false`。
- Java 日志标记 `executionContext=contract_only`；前端证据请求 ID 使用 `mock-evidence-*`，场景首尾标记 `mock_http`。这些是测试调用真实生成的日志，不是虚构真机记录。
- Java 队列128条，溢出/IO错误通过 `droppedCount()` / `failure()` 暴露，close时报错。前端保留1000条，导出末尾 `audit_summary` 包含丢弃数量。不是完整持久审计系统；生产整合需确定轮转及保留策略。

## 真机验收与未完成项

| 项目 | 本轮状态 | 下一步 |
|---|---|---|
| C1–C6 模式/模型/壁厚拒绝 | 离线契约与前端模拟覆盖 | 真实 UI 下重复 |
| C7 driving、C8 shell 创建 | 未执行，入口关闭 | 使用测试副本、人工确认曲面，创建后复查 |
| C9 Creo 拒绝不适用几何 | 未执行 | 验证错误回传及不保存退出 |
| C10 三个 Ribbon 命令无阻塞 | 未执行 | 检查 SISWBatchRename / SISWSheetMetal / SISWAbout |
| C11 前端语法 | 已执行 | 现场部署后检查嵌入式浏览器兼容性 |
| C12 真实 SDK 编译 | 未执行 | Windows 指定 JDK25 + otk.jar；当前仅纯模块 Java17 编译通过 |

还需新版现场源码才能制作其精确补丁；当前新增目录可供人工合并。未部署任何生产 class，未修改 RBN、现有 Ribbon、原模型或现场安装。保存、备份恢复、材料侧可选元素与 A4 批量转换均未实现。当前不能宣称“转钣金功能已经可用”。

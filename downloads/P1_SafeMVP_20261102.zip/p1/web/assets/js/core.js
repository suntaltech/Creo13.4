(function (root) {
  'use strict';
  class P1Error extends Error {
    constructor(code, message) { super(message); this.code = code; }
  }
  class Audit {
    constructor() { this.events = []; this.dropped = 0; this.sequence = 0; }
    emit(requestId, stage, outcome, extra = {}) {
      const event = { schemaVersion: '1', build: 'p1-validation-20261102',
        timestamp: new Date().toISOString(), source: 'frontend', sequence: ++this.sequence,
        requestId, stage, outcome, ...extra, saved: false };
      if (this.events.length === 1000) { this.events.shift(); this.dropped++; }
      this.events.push(event);
    }
    jsonl() {
      const summary = { schemaVersion: '1', source: 'frontend', stage: 'audit_summary',
        timestamp: new Date().toISOString(), retainedEvents: this.events.length,
        droppedEvents: this.dropped, saved: false };
      return [...this.events, summary].map(e => JSON.stringify(e)).join('\n') + '\n';
    }
  }
  class ReadClient {
    constructor(fetchFn, audit, endpoint = '/creoson') {
      this.fetch = fetchFn; this.audit = audit; this.endpoint = endpoint; this.sessionId = null;
    }
    async call(command, fn, data, requestId) {
      const allowed = new Set(['connection/connect', 'file/get_fileinfo', 'feature/list',
        'geometry/get_surfaces', 'geometry/bound_box']);
      if (!allowed.has(`${command}/${fn}`)) throw new P1Error('READ_ONLY', '只读客户端拒绝此操作');
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 10000);
      this.audit.emit(requestId, `${command}/${fn}`, 'started');
      try {
        const body = { command, function: fn, data };
        if (this.sessionId) body.sessionId = this.sessionId;
        const response = await this.fetch(this.endpoint, { method: 'POST',
          headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: controller.signal });
        if (!response.ok) throw new P1Error('HTTP_ERROR', `只读接口 HTTP ${response.status}`);
        const json = await response.json();
        if (!json || json.status?.error !== false) throw new P1Error('CREOSON_ERROR',
          'CREOSON 返回业务错误，请检查连接和当前激活模型');
        if (command === 'connection') {
          if (typeof json.sessionId !== 'string' || !json.sessionId) throw new P1Error('NO_SESSION', '未取得 CREOSON 会话');
          this.sessionId = json.sessionId;
        } else if (!json.data || typeof json.data !== 'object' || Array.isArray(json.data)) {
          throw new P1Error('INVALID_RESPONSE', '只读接口响应缺少 data');
        }
        this.audit.emit(requestId, `${command}/${fn}`, 'passed');
        return json.data || {};
      } catch (error) {
        const safe = error instanceof P1Error ? error : new P1Error(
          error.name === 'AbortError' ? 'TIMEOUT' : 'NETWORK_ERROR',
          error.name === 'AbortError' ? '只读请求超时，请检查 CREOSON' : '无法读取 CREOSON，请检查服务与响应格式');
        this.audit.emit(requestId, `${command}/${fn}`, 'failed', { errorCode: safe.code });
        throw safe;
      } finally { clearTimeout(timer); }
    }
  }
  const api = { P1Error, Audit, ReadClient };
  if (typeof module !== 'undefined') module.exports = api;
  root.P1Core = api;
})(globalThis);

(function (root) {
  'use strict';
  const { P1Error } = typeof module !== 'undefined' ? require('./core.js') : root.P1Core;
  const HEALTH = Object.freeze({ nativeConvertReady: false, reason: '安全原生写通道尚未验收' });
  function thickness(raw) {
    if (typeof raw !== 'string' || !/^(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?$/.test(raw.trim())) return null;
    const n = Number(raw);
    return Number.isFinite(n) && n >= 0.1 && n <= 20 ? n : null;
  }
  function modeBlock(search) {
    const p = new URLSearchParams(search);
    const mode = p.get('modelMode') || 'unknown';
    // URL is a display/read guard only; it never authorizes a model write.
    if (p.get('guard') === 'need_part') return '当前不是普通零件，请切换到 .prt';
    if (p.get('state') === 'sheetmetal' || mode === 'sheetmetal') return '当前已是钣金，无需重复转换';
    if (mode !== 'solid_part') return `当前模型状态 ${mode}，请从普通零件原生命令重新打开页面`;
    return '';
  }
  async function analyze(client, requestId) {
    await client.call('connection', 'connect', {}, requestId);
    const info = await client.call('file', 'get_fileinfo', {}, requestId);
    if (typeof info.file !== 'string' || !/\.prt$/i.test(info.file)) throw new P1Error('NOT_PART', '当前激活模型不是 .prt 普通零件');
    const file = info.file;
    const features = await client.call('feature', 'list', { file, inc_unnamed: true }, requestId);
    const surfaces = await client.call('geometry', 'get_surfaces', { file }, requestId);
    const bbox = await client.call('geometry', 'bound_box', { file }, requestId);
    if (!Array.isArray(features.featlist) || !Array.isArray(surfaces.surflist)) {
      throw new P1Error('INVALID_RESPONSE', '特征或曲面列表格式不正确');
    }
    const spans = ['x', 'y', 'z'].map(axis => {
      const min = bbox[axis + 'min'], max = bbox[axis + 'max'];
      if (!Number.isFinite(min) || !Number.isFinite(max) || max < min) throw new P1Error('INVALID_RESPONSE', '模型包围范围无效');
      return max - min;
    });
    for (const s of surfaces.surflist) {
      if (!Number.isInteger(s.surface_id) || !Number.isFinite(s.area) || s.area < 0) {
        throw new P1Error('INVALID_RESPONSE', '曲面 ID 或面积无效');
      }
    }
    const after = await client.call('file', 'get_fileinfo', {}, requestId);
    if (after.file !== file || after.revision !== info.revision) throw new P1Error('MODEL_CHANGED', '分析期间激活模型或修订发生变化，请重新分析');
    return { model: file, modelState: '普通零件入口（IsSheetmetal/实体数需原生确认）',
      featureCount: features.featlist.length, surfaceCount: surfaces.surflist.length,
      planarCandidateCount: null, largestPlanarCandidate: null, boundingDimensions: spans,
      dimensionUnit: '模型单位（尚未确认是否为 mm）', specifiedThickness: null,
      recommendation: '等厚薄板可评估 driving；块状实体可评估 shell。需用户选择及原生面确认。',
      warnings: ['HTTP 未提供曲面类型/可见性，不能确认平面候选。',
        '包围尺寸不是板厚，未自动填入指定板厚。', '同名模型内几何变化不能靠文件名检测，创建前必须在 UI 线程重读。'],
      nativeConvertReady: false, saved: false };
  }
  function mount(doc, location, client, audit) {
    const el = id => doc.getElementById(id);
    const modes = [...doc.querySelectorAll('input[name="smtMode"]')];
    let busy = false, result = null;
    const blocked = modeBlock(location.search);
    function applyModeBlock() {
      el('smtAnalyzeBtn').disabled = !!blocked || busy;
      // Deliberately no readiness override: this build has no native write transport.
      modes.forEach(e => { e.disabled = true; });
      el('smtThickness').disabled = true;
      el('smtSave').checked = false; el('smtSave').disabled = true;
      el('smtConvertBtn').disabled = true;
    }
    el('smtAnalyzeBtn').addEventListener('click', async () => {
      if (blocked || busy) return;
      busy = true; result = null; el('smtResult').textContent = ''; applyModeBlock();
      const requestId = root.crypto.randomUUID();
      audit.emit(requestId, 'analysis', 'started');
      el('smtStatus').textContent = '正在读取当前零件几何…';
      try {
        result = await analyze(client, requestId);
        el('smtResult').textContent = JSON.stringify(result, null, 2);
        el('smtStatus').textContent = '只读分析成功；平面、实体及单位需原生确认；转换通道未启用';
        audit.emit(requestId, 'analysis', 'passed', { model: result.model, surfaceCount: result.surfaceCount });
      } catch (e) {
        const code = e instanceof P1Error ? e.code : 'ANALYSIS_FAILED';
        el('smtStatus').textContent = `${code}：${e instanceof P1Error ? e.message : '分析失败，请查看诊断日志'}`;
        audit.emit(requestId, 'analysis', 'failed', { errorCode: code });
      } finally { busy = false; applyModeBlock(); }
    });
    el('smtConvertBtn').addEventListener('click', () => {
      el('smtStatus').textContent = HEALTH.reason + '，未创建特征、未保存';
      audit.emit(root.crypto.randomUUID(), 'native_channel', 'blocked', { errorCode: 'CHANNEL_BLOCKED' });
    });
    el('smtExportLog').addEventListener('click', () => {
      const url = URL.createObjectURL(new Blob([audit.jsonl()], { type: 'application/x-ndjson' }));
      const a = doc.createElement('a'); a.href = url; a.download = 'p1-analysis.jsonl'; a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
    applyModeBlock();
    el('smtStatus').textContent = blocked || '可只读分析；安全原生转换通道尚未验收';
    audit.emit(root.crypto.randomUUID(), 'mode_guard', blocked ? 'blocked' : 'passed',
      blocked ? { errorCode: 'MODE_BLOCKED' } : {});
    return { applyModeBlock, getResult: () => result };
  }
  const api = { HEALTH, thickness, modeBlock, analyze, mount };
  if (typeof module !== 'undefined') module.exports = api;
  root.P1Sheetmetal = api;
})(globalThis);

package creo.p1;

import java.nio.file.*;
import java.util.*;

public final class P1ContractTest {
    private static int checks;
    private static void check(boolean ok, String name) {
        if (!ok) throw new AssertionError(name);
        checks++; System.out.println("PASS " + name);
    }
    private static P1Contract.Snapshot snapshot(String mode) {
        return new P1Contract.Snapshot("测试功能02.prt", mode, true, true, Set.of(43));
    }
    private static Map<String, String> valid() {
        return new HashMap<>(Map.of("action", "convert", "model", "测试功能02.prt", "mode", "driving",
                "thickness", "1.0", "confirm", "true", "save", "false"));
    }
    private static void rejects(Map<String, String> p, P1Contract.Snapshot s, String code) {
        try { P1Contract.validate(p, s); throw new AssertionError("expected " + code); }
        catch (P1Contract.Rejected e) { check(code.equals(e.code), code); }
    }
    public static void main(String[] args) throws Exception {
        for (String mode : List.of("assembly", "drawing", "other", "unknown", "")) rejects(valid(), snapshot(mode), "NOT_PART");
        rejects(valid(), null, "NO_SESSION");
        rejects(valid(), snapshot("no_session"), "NO_SESSION");
        rejects(valid(), snapshot("no_model"), "NO_MODEL");
        rejects(valid(), snapshot("sheetmetal"), "ALREADY_SHEETMETAL");
        rejects(null, snapshot("solid_part"), "INVALID_REQUEST");
        rejects(valid(), new P1Contract.Snapshot("x.asm", "solid_part", true, true, Set.of()), "NOT_PART");
        rejects(valid(), new P1Contract.Snapshot("测试功能02.prt", "solid_part", false, true, Set.of()), "NO_BODY");
        rejects(valid(), new P1Contract.Snapshot("测试功能02.prt", "solid_part", true, false, Set.of()), "MULTI_BODY_UNSUPPORTED");
        rejects(valid(), new P1Contract.Snapshot("测试功能02.prt", "solid_part", true, true, Set.of()), "NO_DRIVING_FACE");
        for (String raw : List.of("", " ", "0", "-1", "0.099", "20.01", "NaN", "Infinity", "1,2", "75.750", "0x1", "1d")) {
            var p = valid(); p.put("thickness", raw); rejects(p, snapshot("solid_part"), "INVALID_THICKNESS");
        }
        var absent = valid(); absent.remove("thickness"); rejects(absent, snapshot("solid_part"), "INVALID_THICKNESS");
        for (String raw : List.of("0.1", "1", "20")) {
            var p = valid(); p.put("thickness", raw);
            check(P1Contract.validate(p, snapshot("solid_part")).thickness() == Double.parseDouble(raw), "explicit thickness " + raw);
        }
        for (var entry : Map.of("save", "true", "mode", "auto", "confirm", "false", "action", "save", "model", "other.prt").entrySet()) {
            var p = valid(); p.put(entry.getKey(), entry.getValue());
            rejects(p, snapshot("solid_part"), Map.of("save", "SAVE_DISABLED", "mode", "UNKNOWN_MODE",
                    "confirm", "CONFIRM_REQUIRED", "action", "UNKNOWN_ACTION", "model", "MODEL_CHANGED").get(entry.getKey()));
        }
        var noSave = valid(); noSave.remove("save");
        check(!P1Contract.validate(noSave, snapshot("solid_part")).save(), "save defaults false");
        for (String mode : List.of("driving", "shell")) {
            var p = valid(); p.put("mode", mode);
            var r = P1Contract.validate(p, snapshot("solid_part"));
            var tree = P1Contract.describeRequiredTree(r);
            check(tree.get(0).id() == 386 && tree.get(0).level() == 0 && tree.get(0).value() == null, mode + " compound root");
            check(tree.get(1).value().equals(32) && tree.get(3).value().equals(mode.equals("driving") ? 15 : 24), mode + " root and subtype");
            check(tree.stream().skip(1).allMatch(e -> e.level() == 1), mode + " levels");
            check(tree.stream().noneMatch(e -> e.id() == 7185 || e.id() == 6876 || e.id() == 6284 || e.id() == 6285), mode + " minimal elements");
            check(tree.stream().anyMatch(e -> e.id() == 5111) == mode.equals("driving"), mode + " selection role");
        }
        check(Boolean.FALSE.equals(P1Contract.health().get("nativeConvertReady")), "channel always closed");
        List<P1Contract.Event> events = new ArrayList<>();
        var result = P1Contract.convertActivePart(valid(), snapshot("solid_part"), events::add);
        check(!result.ok() && result.errorCode().equals("CHANNEL_BLOCKED") && !result.saved(), "valid conversion blocked without writes");
        check(events.stream().map(P1Contract.Event::requestId).distinct().count() == 1 && events.size() == 3, "correlated validation stages");
        Path log = Path.of(args[0]);
        try (var audit = new JsonlAudit(log)) {
            for (var e : events) audit.accept(e);
            var shell = valid(); shell.put("mode", "shell");
            var shellResult = P1Contract.convertActivePart(shell, snapshot("solid_part"), audit);
            check(shellResult.errorCode().equals("CHANNEL_BLOCKED") && !shellResult.saved(), "shell blocked without writes");
            var bad = valid(); bad.put("thickness", "75.750");
            P1Contract.convertActivePart(bad, snapshot("solid_part"), audit);
            var escaped = valid(); escaped.put("model", "bad\n\"name.prt");
            P1Contract.convertActivePart(escaped, snapshot("solid_part"), audit);
        }
        check(Files.readAllLines(log).size() == 10, "JSONL flushed and newline escaped");
        System.out.println("TOTAL " + checks + " passed; contract tests only, native SDK/Creo NOT RUN");
    }
}

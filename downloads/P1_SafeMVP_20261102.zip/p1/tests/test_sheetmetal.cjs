'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const { Audit, ReadClient } = require('../web/assets/js/core.js');
const { HEALTH, thickness, modeBlock, analyze, mount } = require('../web/assets/js/sheetmetal.js');
let checks = 0;
async function test(name, fn) { await fn(); checks++; console.log(`PASS ${name}`); }
function fixture(options = {}) {
  const calls = [], audit = new Audit();
  let fileReads = 0;
  const fetch = async (_url, request) => {
    const p = JSON.parse(request.body); calls.push(p);
    const key = p.command + '/' + p.function;
    const responses = {
      'connection/connect': { status: { error: false }, sessionId: 'mock-session-not-a-credential' },
      'file/get_fileinfo': { file: (++fileReads > 2 && options.changed) ? 'changed.prt' : (options.file || '测试功能02.prt'), revision: 1 },
      'feature/list': { featlist: [{ type: 'DATUM_SURFACE', status: 'ACTIVE' }] },
      'geometry/get_surfaces': { surflist: [{ surface_id: 43, area: 100 }] },
      'geometry/bound_box': { xmin: 0, xmax: 337.5, ymin: 0, ymax: 75.75, zmin: 0, zmax: 389 }
    };
    if (options.fail === key) return { ok: true, json: async () => ({ status: { error: true } }) };
    const value = options.override?.[key] || responses[key];
    assert.ok(value, 'unexpected API: ' + key);
    return { ok: true, json: async () => value.status ? value : { status: { error: false }, data: value } };
  };
  return { client: new ReadClient(fetch, audit), calls, audit };
}
function dom() {
  const ids = {};
  for (const id of ['smtAnalyzeBtn', 'smtConvertBtn', 'smtThickness', 'smtSave', 'smtStatus', 'smtResult', 'smtExportLog']) {
    ids[id] = { disabled: false, checked: false, textContent: '', handlers: {}, addEventListener(k, f) { this.handlers[k] = f; } };
  }
  const modes = [{}, {}];
  return { ids, modes, getElementById: id => ids[id], querySelectorAll: () => modes };
}
(async () => {
  await test('thickness finite and explicit, never bounding size', () => {
    for (const x of ['', ' ', '0', '-1', 'NaN', 'Infinity', '20.1', '75.750', '0.099', '0x1', '1d']) assert.equal(thickness(x), null);
    for (const x of ['0.1', '1', '20']) assert.equal(thickness(x), Number(x));
  });
  await test('URL guard wins over claimed ordinary part', () => {
    assert.ok(modeBlock('?modelMode=solid_part&guard=need_part'));
    assert.ok(modeBlock('?modelMode=solid_part&state=sheetmetal'));
    for (const x of ['assembly', 'drawing', 'sheetmetal', 'no_model', 'no_session', 'unknown', 'other']) assert.ok(modeBlock('?modelMode=' + x));
    assert.ok(modeBlock('')); assert.equal(modeBlock('?modelMode=solid_part'), '');
  });
  await test('analysis uses official readonly shapes; does not fabricate planes, units or thickness', async () => {
    const f = fixture(); const r = await analyze(f.client, 'mock-analysis');
    assert.deepEqual(r.boundingDimensions, [337.5, 75.75, 389]);
    assert.equal(r.specifiedThickness, null); assert.equal(r.planarCandidateCount, null);
    assert.equal(r.nativeConvertReady, false); assert.equal(r.saved, false);
    assert.equal(f.calls.length, 6); assert.equal(f.calls[1].data.file, undefined);
    assert.equal(f.calls.at(-1).data.file, undefined);
    for (const e of f.audit.events) assert.equal(e.requestId, 'mock-analysis');
    assert.ok(!f.audit.jsonl().includes('mock-session-not-a-credential'));
  });
  await test('assembly response stops before geometry calls', async () => {
    const f = fixture({ file: 'a.asm' });
    await assert.rejects(analyze(f.client, 'x'), { code: 'NOT_PART' }); assert.equal(f.calls.length, 2);
  });
  await test('business errors stay failures', async () => {
    const f = fixture({ fail: 'geometry/get_surfaces' });
    await assert.rejects(analyze(f.client, 'x'), { code: 'CREOSON_ERROR' });
    assert.equal(f.audit.events.at(-1).outcome, 'failed');
  });
  await test('missing session is rejected', async () => {
    const f = fixture({ override: { 'connection/connect': { status: { error: false } } } });
    await assert.rejects(analyze(f.client, 'x'), { code: 'NO_SESSION' });
  });
  await test('malformed surfaces and box fail rather than pass', async () => {
    for (const override of [{ 'geometry/get_surfaces': { surflist: [{}] } }, { 'geometry/bound_box': { xmin: 0, xmax: -1 } }]) {
      await assert.rejects(analyze(fixture({ override }).client, 'x'), { code: 'INVALID_RESPONSE' });
    }
  });
  await test('active model changes invalidate analysis', async () => {
    await assert.rejects(analyze(fixture({ changed: true }).client, 'x'), { code: 'MODEL_CHANGED' });
  });
  await test('read client rejects writes before fetch', async () => {
    const f = fixture(); await assert.rejects(f.client.call('file', 'save', {}, 'x'), { code: 'READ_ONLY' });
    assert.equal(f.calls.length, 0);
  });
  await test('network errors redact raw stack and host details', async () => {
    const audit = new Audit(); const c = new ReadClient(async () => { throw new Error('private details'); }, audit);
    await assert.rejects(c.call('connection', 'connect', {}, 'x'), { code: 'NETWORK_ERROR' });
    assert.ok(!audit.jsonl().includes('private details'));
  });
  await test('all guard modes disable analysis before clicks', async () => {
    for (const mode of ['assembly', 'drawing', 'sheetmetal', 'no_model', 'unknown']) {
      const d = dom(), f = fixture(); mount(d, { search: '?modelMode=' + mode }, f.client, f.audit);
      assert.equal(d.ids.smtAnalyzeBtn.disabled, true); await d.ids.smtAnalyzeBtn.handlers.click(); assert.equal(f.calls.length, 0);
    }
  });
  await test('busy guard, success rendering and fixed disabled writes', async () => {
    const d = dom(), f = fixture(); const ui = mount(d, { search: '?modelMode=solid_part' }, f.client, f.audit);
    const first = d.ids.smtAnalyzeBtn.handlers.click();
    assert.equal(d.ids.smtAnalyzeBtn.disabled, true); assert.match(d.ids.smtStatus.textContent, /正在读取/);
    await d.ids.smtAnalyzeBtn.handlers.click(); await first;
    assert.equal(f.calls.length, 6); assert.ok(ui.getResult()); assert.match(d.ids.smtStatus.textContent, /只读分析成功/);
    for (const key of ['smtThickness', 'smtSave', 'smtConvertBtn']) assert.equal(d.ids[key].disabled, true);
    assert.ok(d.modes.every(m => m.disabled)); assert.equal(d.ids.smtSave.checked, false);
    await d.ids.smtConvertBtn.handlers.click(); assert.equal(f.calls.length, 6);
    assert.equal(f.audit.events.at(-1).errorCode, 'CHANNEL_BLOCKED');
    assert.equal(HEALTH.nativeConvertReady, false);
  });
  await test('analysis error clears stale result, restores analyze button', async () => {
    const d = dom(), f = fixture({ fail: 'feature/list' });
    const ui = mount(d, { search: '?modelMode=solid_part' }, f.client, f.audit);
    await d.ids.smtAnalyzeBtn.handlers.click(); assert.equal(ui.getResult(), null);
    assert.match(d.ids.smtStatus.textContent, /CREOSON_ERROR/); assert.equal(d.ids.smtAnalyzeBtn.disabled, false);
  });
  await test('bounded audit detects dropped events and exports valid JSONL', () => {
    const audit = new Audit(); for (let i = 0; i < 1002; i++) audit.emit('mock', 'analysis', 'passed');
    assert.equal(audit.events.length, 1000); assert.equal(audit.dropped, 2);
    for (const line of audit.jsonl().trim().split('\n')) assert.equal(JSON.parse(line).saved, false);
  });
  if (process.argv[2]) {
    const samples = [];
    for (const [name, options] of [['readonly', {}], ['not-part', {file: 'a.asm'}],
      ['business-error', {fail: 'geometry/get_surfaces'}], ['model-changed', {changed: true}]]) {
      const actual = fixture(options);
      const id = 'mock-evidence-' + name;
      actual.audit.emit(id, 'analysis', 'started', { executionContext: 'mock_http' });
      try { await analyze(actual.client, id); actual.audit.emit(id, 'analysis', 'passed', { executionContext: 'mock_http' }); }
      catch (e) { actual.audit.emit(id, 'analysis', 'failed', { executionContext: 'mock_http', errorCode: e.code }); }
      samples.push(actual.audit.jsonl());
    }
    fs.writeFileSync(process.argv[2], samples.join(''));
  }
  console.log(`TOTAL ${checks} passed; mock HTTP/DOM only, live CREOSON/Creo NOT RUN`);
})().catch(e => { console.error(e); process.exitCode = 1; });

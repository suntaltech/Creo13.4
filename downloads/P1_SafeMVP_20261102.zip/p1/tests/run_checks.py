"""Run isolated P1 checks; output folder must not already exist. No Creo/SDK access."""
from pathlib import Path
import argparse
import hashlib
import json
import struct
import subprocess
from datetime import datetime, timezone

parser = argparse.ArgumentParser()
parser.add_argument('--jdk', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
output = args.output.resolve()
output.mkdir(parents=True, exist_ok=False)
classes = output / 'classes'
classes.mkdir()
results = []

def run(name, command):
    p = subprocess.run([str(x) for x in command], cwd=root, text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=90)
    (output / (name + '.log')).write_text(p.stdout, encoding='utf-8')
    results.append({'name': name, 'exitCode': p.returncode, 'command': [str(x) for x in command]})
    print(f'{name}: exit={p.returncode}')
    if p.returncode:
        print(p.stdout)
        raise RuntimeError(name + ' failed')

summary = {'executionContext': 'offline_contract_and_mock', 'startedAt': datetime.now(timezone.utc).isoformat(),
           'nativeSdkCompile': 'not_run', 'liveCreoson': 'not_run', 'creoConversion': 'not_run',
           'ribbonRegression': 'not_run', 'saved': False, 'checks': results}
try:
    run('javac-version', [args.jdk / 'bin/javac', '-version'])
    run('javac-release17', [args.jdk / 'bin/javac', '--release', '17', '-encoding', 'UTF-8', '-d', classes,
                           root/'java/P1Contract.java', root/'java/JsonlAudit.java', root/'tests/P1ContractTest.java'])
    for path in classes.rglob('*.class'):
        major = struct.unpack('>H', path.read_bytes()[6:8])[0]
        assert major == 61, (path, major)
    run('java-contract', [args.jdk/'bin/java', '-cp', classes, 'creo.p1.P1ContractTest', output/'backend.jsonl'])
    for name in ['core', 'sheetmetal']:
        run('syntax-' + name, ['node', '--check', root/f'web/assets/js/{name}.js'])
    run('frontend-mock', ['node', root/'tests/test_sheetmetal.cjs', output/'frontend.jsonl'])
    for filename in ['backend.jsonl', 'frontend.jsonl']:
        for line in (output/filename).read_text(encoding='utf-8').splitlines():
            event = json.loads(line)
            assert event['saved'] is False
    summary['passed'] = True
finally:
    summary['finishedAt'] = datetime.now(timezone.utc).isoformat()
    summary.setdefault('passed', False)
    summary['sourceSha256'] = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
                               for folder in ['java', 'web', 'tests'] for p in (root/folder).rglob('*')
                               if p.is_file() and '__pycache__' not in p.parts}
    (output/'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

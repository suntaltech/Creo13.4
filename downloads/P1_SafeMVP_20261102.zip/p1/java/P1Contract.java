package creo.p1;

import java.time.Instant;
import java.util.*;
import java.util.function.Consumer;

/** Pure Java 17 contract. No SDK objects, model writes, browser listeners or Save calls. */
public final class P1Contract {
    private P1Contract() {}
    public static final String BUILD = "p1-validation-20261102";
    public record Snapshot(String model, String modelMode, boolean hasBody,
                           boolean singleBody, Set<Integer> visiblePlanarFaces) {
        public Snapshot { visiblePlanarFaces = Set.copyOf(visiblePlanarFaces); }
    }
    public record Request(String model, String mode, double thickness, boolean save) {}
    /** Declarative specification only: SelectionRole is NOT a native selection handle. */
    public enum SelectionRole { DEFAULT_BODY, USER_CONFIRMED_DRIVING_SURFACE }
    public record ElementSpec(int id, int level, String valueType, Object value) {}
    public record Result(boolean ok, String errorCode, String message, boolean saved) {}
    public record Event(String schemaVersion, String build, String requestId, String timestamp,
                        String source, String stage, String outcome, String errorCode,
                        String model, String mode, String thickness, boolean saved) {}
    public static final class Rejected extends IllegalArgumentException {
        public final String code;
        public Rejected(String code, String message) { super(message); this.code = code; }
    }
    private static void require(boolean ok, String code, String message) {
        if (!ok) throw new Rejected(code, message);
    }
    public static double resolveConversionThickness(String raw) {
        require(raw != null && !raw.isBlank(), "INVALID_THICKNESS", "请输入 0.1–20 mm 的板厚");
        require(raw.trim().matches("(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)(?:[eE][+-]?[0-9]+)?"),
                "INVALID_THICKNESS", "板厚必须为十进制数字");
        double n;
        try { n = Double.parseDouble(raw); }
        catch (NumberFormatException e) { throw new Rejected("INVALID_THICKNESS", "板厚必须是数字"); }
        require(Double.isFinite(n) && n >= 0.1 && n <= 20,
                "INVALID_THICKNESS", "板厚必须为 0.1–20 mm，不能使用包围尺寸代替");
        return n;
    }
    public static void guard(Snapshot s) {
        require(s != null, "NO_SESSION", "J-Link 会话不存在");
        String mode = s.modelMode();
        if ("no_session".equals(mode)) throw new Rejected("NO_SESSION", "J-Link 会话不存在");
        if ("no_model".equals(mode)) throw new Rejected("NO_MODEL", "请先打开普通零件");
        if ("sheetmetal".equals(mode)) throw new Rejected("ALREADY_SHEETMETAL", "当前已是钣金，无需转换");
        require("solid_part".equals(mode), "NOT_PART", "只允许当前激活普通实体零件");
        require(s.model() != null && s.model().toLowerCase(Locale.ROOT).endsWith(".prt"),
                "NOT_PART", "当前模型必须为 .prt");
        require(s.hasBody(), "NO_BODY", "零件没有默认实体体");
        require(s.singleBody(), "MULTI_BODY_UNSUPPORTED", "多实体模型需要人工处理");
    }
    public static Request validate(Map<String, String> p, Snapshot active) {
        require(p != null, "INVALID_REQUEST", "缺少请求参数");
        require("convert".equals(p.get("action")), "UNKNOWN_ACTION", "仅接受 convert 请求");
        guard(active);
        require(active.model().equalsIgnoreCase(p.getOrDefault("model", "")),
                "MODEL_CHANGED", "激活模型已变化，请重新分析");
        String mode = p.get("mode");
        require("driving".equals(mode) || "shell".equals(mode), "UNKNOWN_MODE", "请选择 driving 或 shell");
        double t = resolveConversionThickness(p.get("thickness"));
        require(!p.containsKey("save") || "false".equals(p.get("save")),
                "SAVE_DISABLED", "当前版本禁止保存");
        require("true".equals(p.get("confirm")), "CONFIRM_REQUIRED", "请明确确认测试副本且不保存");
        if ("driving".equals(mode)) require(!active.visiblePlanarFaces().isEmpty(),
                "NO_DRIVING_FACE", "缺少可见平面候选，不自动选择曲面");
        return new Request(active.model(), mode, t, false);
    }
    /** For review/tests only. Does NOT construct a WFC tree or prove native API compatibility. */
    public static List<ElementSpec> describeRequiredTree(Request r) {
        require(r != null, "INVALID_REQUEST", "缺少已校验请求");
        resolveConversionThickness(Double.toString(r.thickness()));
        require(!r.save(), "SAVE_DISABLED", "当前版本禁止保存");
        require("driving".equals(r.mode()) || "shell".equals(r.mode()), "UNKNOWN_MODE", "非法方式");
        List<ElementSpec> tree = new ArrayList<>();
        tree.add(new ElementSpec(386, 0, "compound", null));
        tree.add(new ElementSpec(387, 1, "int", 32));
        tree.add(new ElementSpec(1964, 1, "string", "SMT_CONV_" + r.mode().toUpperCase(Locale.ROOT)));
        tree.add(new ElementSpec(1131, 1, "int", "driving".equals(r.mode()) ? 15 : 24));
        tree.add(new ElementSpec(6612, 1, "selection_role", SelectionRole.DEFAULT_BODY));
        if ("driving".equals(r.mode())) tree.add(new ElementSpec(5111, 1, "selection_role",
                SelectionRole.USER_CONFIRMED_DRIVING_SURFACE));
        tree.add(new ElementSpec(3332, 1, "double", r.thickness()));
        return List.copyOf(tree);
    }
    public static Map<String, Object> health() {
        return Map.of("nativeConvertReady", false, "reason", "safe native write channel pending validation",
                "build", BUILD, "saved", false);
    }
    /** Fail closed even with valid input. audit must be a bounded nonblocking enqueue, not disk IO. */
    public static Result convertActivePart(Map<String, String> p, Snapshot active, Consumer<Event> audit) {
        String id = UUID.randomUUID().toString();
        emit(audit, id, "request_received", "pending", "", p);
        try {
            validate(p, active);
            emit(audit, id, "validation", "passed", "", p);
            emit(audit, id, "native_channel", "blocked", "CHANNEL_BLOCKED", p);
            return new Result(false, "CHANNEL_BLOCKED", "安全原生通道尚未验收，未创建特征、未保存", false);
        } catch (Rejected e) {
            emit(audit, id, "validation", "rejected", e.code, p);
            return new Result(false, e.code, e.getMessage(), false);
        }
    }
    private static void emit(Consumer<Event> sink, String id, String stage, String outcome,
                             String code, Map<String, String> p) {
        sink.accept(new Event("1", BUILD, id, Instant.now().toString(), "java-contract", stage,
                outcome, code, field(p, "model"), field(p, "mode"), field(p, "thickness"), false));
    }
    private static String field(Map<String, String> p, String key) {
        String s = p == null ? "" : p.getOrDefault(key, "");
        return s == null ? "" : s.substring(0, Math.min(s.length(), 256));
    }
}

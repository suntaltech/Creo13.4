package creo.p1;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.function.Consumer;

/** Construct and close off the Creo UI thread. accept only enqueues; overflow/failures are observable. */
public final class JsonlAudit implements Consumer<P1Contract.Event>, AutoCloseable {
    private final ThreadPoolExecutor writer;
    private final BufferedWriter output;
    private final AtomicLong dropped = new AtomicLong();
    private final AtomicReference<IOException> failure = new AtomicReference<>();
    public JsonlAudit(Path path) throws IOException {
        Files.createDirectories(path.toAbsolutePath().getParent());
        output = Files.newBufferedWriter(path, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        writer = new ThreadPoolExecutor(1, 1, 0, TimeUnit.SECONDS, new ArrayBlockingQueue<>(128), r -> {
            Thread t = new Thread(r, "p1-audit-writer"); t.setDaemon(true); return t;
        }, new ThreadPoolExecutor.AbortPolicy());
    }
    public void accept(P1Contract.Event e) {
        try { writer.execute(() -> {
            try { output.write(json(e)); output.newLine(); output.flush(); }
            catch (IOException ex) { failure.compareAndSet(null, ex); dropped.incrementAndGet(); }
        }); } catch (RejectedExecutionException ex) { dropped.incrementAndGet(); }
    }
    public long droppedCount() { return dropped.get(); }
    public IOException failure() { return failure.get(); }
    public void close() throws IOException {
        writer.shutdown();
        try { if (!writer.awaitTermination(10, TimeUnit.SECONDS)) throw new IOException("audit flush timeout"); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new IOException(e); }
        output.close();
        if (failure.get() != null) throw failure.get();
        if (dropped.get() != 0) throw new IOException("audit events dropped: " + dropped.get());
    }
    static String quote(String v) {
        StringBuilder b = new StringBuilder("\"");
        for (char c : v.toCharArray()) {
            if (c == '"' || c == '\\') b.append('\\').append(c);
            else if (c < 32 || Character.isSurrogate(c)) b.append(String.format("\\u%04x", (int)c));
            else b.append(c);
        }
        return b.append('"').toString();
    }
    public static String json(P1Contract.Event e) {
        return "{\"executionContext\":\"contract_only\",\"schemaVersion\":" + quote(e.schemaVersion()) + ",\"build\":" + quote(e.build())
                + ",\"requestId\":" + quote(e.requestId()) + ",\"timestamp\":" + quote(e.timestamp())
                + ",\"source\":" + quote(e.source()) + ",\"stage\":" + quote(e.stage())
                + ",\"outcome\":" + quote(e.outcome()) + ",\"errorCode\":" + quote(e.errorCode())
                + ",\"model\":" + quote(e.model()) + ",\"mode\":" + quote(e.mode())
                + ",\"thickness\":" + quote(e.thickness()) + ",\"saved\":false}";
    }
}
